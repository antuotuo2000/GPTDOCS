
    (function () {
      'use strict';

      /* ======================================================================
         1. Grounded Datasets & State Model
         ====================================================================== */
      var STORAGE_THEME_KEY = 'mui_portal_theme_v4';
      var STORAGE_LANG_KEY = 'mui_portal_lang_v1';
      var DOC_TITLE_ZH = '苹果公司 Apple Inc. (AAPL) 企业文化与组织架构深度研究报告 | 数据中心';
      var DOC_TITLE_EN = 'Apple Inc. (AAPL) Corporate Culture & Organizational Architecture Deep Dive | Research Hub';
      var I18N_RICH_LIST = [{"key": "aapl_r00", "match_zh": "苹果公司 Apple Inc. 企业文化与组织架构深度研究报告：", "zh": "苹果公司 Apple Inc. 企业文化与组织架构深度研究报告：<span class=\"gradient-accent\">专家统治、零部门墙全栈协同与“世界最大初创企业”的创新法则</span>", "en": "Apple Inc. Corporate Culture &amp; Organizational Architecture Deep Dive: <span class=\"gradient-accent\">Experts Leading Experts, Zero-Silo Single P&amp;L &amp; Rules of the \"World's Biggest Startup\"</span>"}, {"key": "aapl_r01", "match_zh": "为什么几乎所有跨入千亿美元营收规模的巨头", "zh": "为什么几乎所有跨入千亿美元营收规模的巨头都会裂变为各自算账的独立事业部（M-Form），唯独<strong>苹果公司（Apple Inc., NASDAQ: AAPL）</strong>能在近半万亿美元营收体量下依然保持浑然一体的产品灵魂？答案深植于 1997 年史蒂夫·乔布斯回归后单日废除全部产品事业部总经理、沿用至今的<strong>“按专业职能高度集权（Functional Organization）+ 全公司唯一一张损益表（Single P&amp;L）”</strong>架构 <a class=\"cite-link\" href=\"https://www.apple.com/careers/pdf/HBR_How_Apple_Is_Organized_For_Innovation-4.pdf\" target=\"_blank\" rel=\"noopener noreferrer\">HBR · Podolny &amp; Hansen ↗</a>。 在苹果内部，没有“iPhone 事业部总裁”或“Mac 利润中心”，决策权严格对齐专业深度——由顶尖专家管理专家，每项任务明确唯一署名的<strong>直接责任人（DRI）</strong>，消除了内部转移定价与跨部门抢利内耗 <a class=\"cite-link\" href=\"https://fortune.com/article/how-apple-works-inside-the-worlds-biggest-startup/\" target=\"_blank\" rel=\"noopener noreferrer\">Fortune Inside Apple ↗</a>。 据 2026 年 11 月披露的 FY2026 财报及 Form 10-K，苹果仅凭约 <strong>167,000 名全职员工</strong>（同比仅微增 <strong>+0.6%</strong>，其中工程研发人员占比高达 <strong>41%</strong>） <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000032019326000026/aapl-20260926.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC FY26 10-K ↗</a> <a class=\"cite-link\" href=\"https://sqmagazine.co.uk/how-many-people-work-at-apple/\" target=\"_blank\" rel=\"noopener noreferrer\">SQ Magazine ↗</a>， 创下全年净营收 <strong>$4,788.34 亿（+15.1% YoY）</strong>、全年综合毛利率 <strong>48.8%</strong>（服务毛利率达 <strong>76.2%</strong>）、GAAP 净利润 <strong>$1,321.75 亿</strong>及人均创收 <strong>$2.87M</strong> 的历史最高纪录 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000032019326000024/a8-kex991q4202609262026.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC Q4/FY26 8-K ↗</a>。 2026 年 9 月 1 日，深耕苹果 25 年的硬件工程统帅 <strong>约翰·特努斯（John Ternus）</strong>正式接替转任执行董事长的蒂姆·库克（Tim Cook）出任 CEO，携折叠屏 iPhone Duo、iPhone 18 Pro 与触控 Mac 开启第三代“工程师治企”新纪元 <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/04/tim-cook-to-become-apple-executive-chairman-john-ternus-to-become-apple-ceo/\" target=\"_blank\" rel=\"noopener noreferrer\">Apple CEO Succession ↗</a>。", "en": "Why does virtually every enterprise crossing $100B in sales fragment into autonomous business-unit fiefdoms (M-Form), while <strong>Apple Inc. (NASDAQ: AAPL)</strong> preserves a singular product soul at nearly half a trillion dollars in annual revenue? The answer traces to Steve Jobs's 1997 return, when he abolished all product-line general managers in a single day and established Apple's enduring <strong>\"Functional Organization + Single Company-Wide P&amp;L\"</strong> <a class=\"cite-link\" href=\"https://www.apple.com/careers/pdf/HBR_How_Apple_Is_Organized_For_Innovation-4.pdf\" target=\"_blank\" rel=\"noopener noreferrer\">HBR · Podolny &amp; Hansen ↗</a>. Inside Apple, there is no \"President of iPhone\" or \"Mac Profit Center\"—decision rights follow domain mastery as <em>experts lead experts</em>, and every deliverable names a single <strong>Directly Responsible Individual (DRI)</strong>, eliminating transfer-pricing turf wars <a class=\"cite-link\" href=\"https://fortune.com/article/how-apple-works-inside-the-worlds-biggest-startup/\" target=\"_blank\" rel=\"noopener noreferrer\">Fortune Inside Apple ↗</a>. Per its November 2026 FY2026 Form 10-K and earnings release, Apple employed <strong>~167,000 FTEs</strong> (up just <strong>+0.6% YoY</strong>, with <strong>41%</strong> in engineering R&amp;D) <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000032019326000026/aapl-20260926.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC FY26 10-K ↗</a> <a class=\"cite-link\" href=\"https://sqmagazine.co.uk/how-many-people-work-at-apple/\" target=\"_blank\" rel=\"noopener noreferrer\">SQ Magazine ↗</a>, delivering all-time record net sales of <strong>$478.83B (+15.1% YoY)</strong>, consolidated gross margin of <strong>48.8%</strong> (Services at <strong>76.2%</strong>), GAAP net income of <strong>$132.18B</strong>, and <strong>$2.87M</strong> in revenue per employee <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000032019326000024/a8-kex991q4202609262026.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC Q4/FY26 8-K ↗</a>. On September 1, 2026, 25-year hardware engineering chief <strong>John Ternus</strong> succeeded Tim Cook (now Executive Chairman) as CEO, ushering in a third generation of engineer-led stewardship alongside foldable iPhone Duo, iPhone 18 Pro, and Touch Mac <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/04/tim-cook-to-become-apple-executive-chairman-john-ternus-to-become-apple-ceo/\" target=\"_blank\" rel=\"noopener noreferrer\">Apple CEO Succession ↗</a>."}, {"key": "aapl_r02", "match_zh": "16.7 万名全职员工（较 FY25 仅增", "zh": "16.7 万名全职员工（较 FY25 仅增 1,000 人）人均创收达 $287 万、人均净利 $79.1 万，显著高于 FY11 ($1.79M) <a class=\"cite-link\" href=\"https://bullfincher.io/companies/apple/number-of-employees\" target=\"_blank\" rel=\"noopener noreferrer\">Bullfincher 10-K ↗</a>。", "en": "167,000 FTEs (+1,000 vs. FY25) generate $2.87M in revenue and $791K in GAAP net profit per employee—far above FY11 ($1.79M) <a class=\"cite-link\" href=\"https://bullfincher.io/companies/apple/number-of-employees\" target=\"_blank\" rel=\"noopener noreferrer\">Bullfincher 10-K ↗</a>."}, {"key": "aapl_r03", "match_zh": "FY26 总净营收同比增长 +15.1%", "zh": "FY26 总净营收同比增长 +15.1% 至 $4,788.34 亿（iPhone $2,541.0 亿、服务 $1,233.0 亿），稀释 EPS 增 20.4% 至 $8.98 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000032019326000024/a8-kex991q4202609262026.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC FY26 8-K ↗</a>。", "en": "FY26 net sales jumped +15.1% YoY to $478.83B (iPhone $254.10B, Services $123.30B), lifting diluted EPS +20.4% to $8.98 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000032019326000024/a8-kex991q4202609262026.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC FY26 8-K ↗</a>."}, {"key": "aapl_r04", "match_zh": "Apple Silicon 全线自研与高粘性服务", "zh": "Apple Silicon 全线自研与高粘性服务推动全年综合毛利率由 FY22 的 43.3% 跃升至 FY26 的 48.8%（Q4 单季 47.9%） <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/11/apple-reports-fourth-quarter-results/\" target=\"_blank\" rel=\"noopener noreferrer\">Q4 FY26 Release ↗</a>。", "en": "Custom Apple Silicon and high-margin Services expanded full-year gross margin from 43.3% (FY22) to 48.8% in FY26 (47.9% in Q4) <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/11/apple-reports-fourth-quarter-results/\" target=\"_blank\" rel=\"noopener noreferrer\">Q4 FY26 Release ↗</a>."}, {"key": "aapl_r05", "match_zh": "全球超 25 亿台活跃设备与 540 家", "zh": "全球超 25 亿台活跃设备与 540 家 Apple Store 同享一套系统底座；FY26 研发投入飙升 +32.5% 至 $457.65 亿 <a class=\"cite-link\" href=\"https://9to5mac.com/2026/01/29/apple-reveals-it-has-2-5-billion-active-devices-around-the-world/\" target=\"_blank\" rel=\"noopener noreferrer\">2.5B Devices ↗</a>。", "en": ">2.5B active devices and 540 Apple Stores run on one unified OS foundation; FY26 R&amp;D rose +32.5% YoY to $45.77B <a class=\"cite-link\" href=\"https://9to5mac.com/2026/01/29/apple-reveals-it-has-2-5-billion-active-devices-around-the-world/\" target=\"_blank\" rel=\"noopener noreferrer\">2.5B Devices ↗</a>."}, {"key": "aapl_r06", "match_zh": "传统 M-Form 大厂各产品线总经理", "zh": "传统 M-Form 大厂各产品线总经理为保当季部门利润，往往排斥高成本前沿部件；苹果取消事业部损益表，使双摄/潜望镜头、钛金属中框或 OLED 触控屏可率先在旗舰验证后迅速普惠全产品线 <a class=\"cite-link\" href=\"https://www.apple.com/careers/pdf/HBR_How_Apple_Is_Organized_For_Innovation-4.pdf\" target=\"_blank\" rel=\"noopener noreferrer\">HBR Study ↗</a>。", "en": "Traditional M-Form unit GMs often resist costly frontier components to protect quarterly unit margins; Apple's Single P&amp;L lets periscope optics, custom silicon, and OLED touch displays scale rapidly across product lines <a class=\"cite-link\" href=\"https://www.apple.com/careers/pdf/HBR_How_Apple_Is_Organized_For_Innovation-4.pdf\" target=\"_blank\" rel=\"noopener noreferrer\">HBR Study ↗</a>."}, {"key": "aapl_r07", "match_zh": "苹果不设“Mac 芯片部”或“iPad 相机部”", "zh": "苹果不设“Mac 芯片部”或“iPad 相机部”，同一支芯片与算法专家团队在立项前 3–4 年便与工业设计及系统团队联合定义架构，推动 Products 硬件毛利率在 FY26 升至 39.3% <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000032019326000024/a8-kex991q4202609262026.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC FY26 8-K ↗</a>。", "en": "Rather than separate \"Mac Silicon\" or \"iPad Camera\" silos, unified silicon and imaging teams co-architect chips 3–4 years ahead with ID and OS peers—lifting FY26 Products gross margin to 39.3% <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000032019326000024/a8-kex991q4202609262026.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC FY26 8-K ↗</a>."}, {"key": "aapl_r08", "match_zh": "当同行在 2020–2022 年翻倍扩招", "zh": "当同行在 2020–2022 年翻倍扩招随后万人大裁员时，苹果严守 A 级人才密度：FY2022 至 FY2026 全职员工仅从 16.4 万人微增至 16.7 万人，而同期年营收净增逾 $845 亿 <a class=\"cite-link\" href=\"https://www.mokahr.io/myblog/talent-culture-strategy-at-apple/\" target=\"_blank\" rel=\"noopener noreferrer\">MokaHR Analysis ↗</a>。", "en": "While Big Tech peers doubled headcount in 2020–22 only to conduct mass layoffs, Apple held FTEs nearly flat from 164k (FY22) to 167k (FY26) while adding >$84.5B in annual revenue <a class=\"cite-link\" href=\"https://www.mokahr.io/myblog/talent-culture-strategy-at-apple/\" target=\"_blank\" rel=\"noopener noreferrer\">MokaHR Analysis ↗</a>."}, {"key": "aapl_r09", "match_zh": "2026年9月1日“工程师治企”跨代交接", "zh": "<strong>2026年9月1日“工程师治企”跨代交接：John Ternus (CEO) × Tim Cook (执行董事长)</strong> —— 现年 51 岁、2001 年加入苹果产品设计团队并主导 Mac 向 Apple Silicon 历史性迁移的 John Ternus 正式接任 CEO（Art Levinson 转任首席独立董事），携 iPhone Duo 折叠形态与全新 Siri AI 开启新产品超级周期 <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/04/tim-cook-to-become-apple-executive-chairman-john-ternus-to-become-apple-ceo/\" target=\"_blank\" rel=\"noopener noreferrer\">Official Release ↗</a>。", "en": "<strong>Sep 1, 2026 Engineer-Led Succession: John Ternus (CEO) × Tim Cook (Executive Chairman)</strong> — Ternus (age 51, joined Product Design in 2001 and led the Apple Silicon Mac transition) became CEO (with Art Levinson as Lead Independent Director), launching foldable iPhone Duo and next-gen Siri AI <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/04/tim-cook-to-become-apple-executive-chairman-john-ternus-to-become-apple-ceo/\" target=\"_blank\" rel=\"noopener noreferrer\">Official Release ↗</a>."}, {"key": "aapl_r10", "match_zh": "在苹果内部，芯片架构师在终端问世前", "zh": "在苹果内部，芯片架构师在终端问世前 3–4 年便与工业设计及系统算法团队同桌协同，将相机 ISP、ProRes 编解码器与端侧 AI 加速矩阵直接固化进硅片，支撑 FY2026 硬件产品毛利率同比扩张 2.5 个百分点至 39.3% <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000032019326000024/a8-kex991q4202609262026.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC FY26 8-K ↗</a>。", "en": "Silicon architects collaborate 3–4 years pre-launch alongside Industrial Design and OS software teams to bake custom ISPs, ProRes media engines, and Neural accelerators directly into die—driving FY26 Products gross margin up +2.5pp YoY to 39.3% <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000032019326000024/a8-kex991q4202609262026.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC FY26 8-K ↗</a>."}, {"key": "aapl_r11", "match_zh": "自乔布斯确立“好木匠连柜子背面也用好木头”", "zh": "自乔布斯确立“好木匠连柜子背面也用好木头”传统以来，工业设计与人机交互团队直通最高决策层：工程团队不以“量产困难”否决设计，而是发明全新铰链、材料与封装工艺兑现 iPhone Duo、iPhone 18 Pro 与触控 Mac 愿景 <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/11/apple-reports-fourth-quarter-results/\" target=\"_blank\" rel=\"noopener noreferrer\">Q4 FY26 Newsroom ↗</a>。", "en": "Rooted in Jobs's \"craft the back of the cabinet\" ethos, Industrial Design and Human Interface report at the top table: hardware engineers invent new hinges, alloys, and packaging to realize iPhone Duo, iPhone 18 Pro, and Touch Mac <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/11/apple-reports-fourth-quarter-results/\" target=\"_blank\" rel=\"noopener noreferrer\">Q4 FY26 Newsroom ↗</a>."}, {"key": "aapl_r12", "match_zh": "苹果将“隐私是基本人权”转化为差异化产品架构", "zh": "苹果将“隐私是基本人权”转化为差异化产品架构（端侧加密、Private Cloud Compute、AirDrop 与跨端接力），将全球超 25 亿台活跃设备锁定在极高留存闭环中，推动 FY2026 Services 净营收创下 $1,233.01 亿新高 <a class=\"cite-link\" href=\"https://fifthperson.com/apple-q4-2026/\" target=\"_blank\" rel=\"noopener noreferrer\">Fifth Person Q4 ↗</a>。", "en": "Translating \"privacy as a fundamental human right\" into architecture (on-device encryption, Private Cloud Compute, Continuity) locks >2.5B active devices into high-retention ecosystems, propelling FY26 Services revenue to a record $123.30B <a class=\"cite-link\" href=\"https://fifthperson.com/apple-q4-2026/\" target=\"_blank\" rel=\"noopener noreferrer\">Fifth Person Q4 ↗</a>."}, {"key": "aapl_r13", "match_zh": "苹果通过轻资产制造协同全球约 45 万供应链产业工人", "zh": "苹果通过轻资产制造协同全球约 45 万供应链产业工人，全年资本开支仅 $90.41 亿（占营收 1.89%），却创造出高达 $1,450.97 亿经营现金流与 $1,360.56 亿自由现金流；终端 540 家直营店坚持零销售提成，专注用户体验与 Genius Bar 信任建设 <a class=\"cite-link\" href=\"https://sqmagazine.co.uk/how-many-people-work-at-apple/\" target=\"_blank\" rel=\"noopener noreferrer\">SQ Magazine ↗</a>。", "en": "Orchestrating ~450,000 supplier workers with asset-light CapEx of just $9.04B (1.89% of sales), Apple generated $145.10B in operating cash flow and $136.06B in free cash flow—while 540 Apple Stores use non-commissioned staff focused on NPS and Genius Bar trust <a class=\"cite-link\" href=\"https://sqmagazine.co.uk/how-many-people-work-at-apple/\" target=\"_blank\" rel=\"noopener noreferrer\">SQ Magazine ↗</a>."}, {"key": "aapl_r14", "match_zh": "1. 破除大企业“事业部封建割据”：", "zh": "<strong>1. 破除大企业“事业部封建割据”：</strong>单一 P&amp;L 让芯片、硬件、系统与服务团队围绕同一产品体验无缝咬合，支撑近 $4,800 亿体量仍具初创敏捷度。<br/> <strong>2. 制度化的工程师治企传承：</strong>从乔布斯、库克到 2026 年 9 月接任 CEO 的硬件工程统帅 John Ternus，始终由懂产品细节的内部领军者掌舵。<br/> <strong>3. 轻资产高现金流复利机器：</strong>FY26 仅用 $90.4 亿 CapEx 撬动 $1,360.6 亿自由现金流，免于云巨头重资产折旧泥潭。", "en": "<strong>1. Eliminates Divisional Fiefdoms:</strong> A single company-wide P&amp;L aligns silicon, hardware, OS, and services around unified UX at ~$480B scale.<br/> <strong>2. Institutionalized Product Stewardship:</strong> From Jobs and Cook to hardware veteran John Ternus (Sep 2026), insiders steeped in product craft lead the firm.<br/> <strong>3. Capital-Light FCF Engine:</strong> Just $9.04B in FY26 CapEx unlocked $136.06B in free cash flow—avoiding hyperscaler depreciation drag."}, {"key": "aapl_r15", "match_zh": "1. 跨职能横向协调的高层带宽瓶颈：", "zh": "<strong>1. 跨职能横向协调的高层带宽瓶颈：</strong>所有核心决策均需跨部门对齐，一旦缺乏清晰边界（如早年耗资百亿最终关停的 Titan 造车项目）易陷入拉锯。<br/> <strong>2. 孤岛保密文化与开放 AI 生态的磨合：</strong>严格的“需知原则”曾与前沿大模型学术发表文化产生摩擦，倒逼 FY26 研发费用激增 +32.5% 追赶 Siri AI。<br/> <strong>3. 围墙花园的全球反垄断与关税/存储成本逆风：</strong>欧盟 DMA、美国外部支付链接裁决及存储芯片涨价令 Q1 FY27 毛利率面临短期波动考验 <a class=\"cite-link\" href=\"https://fifthperson.com/apple-q4-2026/\" target=\"_blank\" rel=\"noopener noreferrer\">Fifth Person ↗</a>。", "en": "<strong>1. Executive Coordination Bottlenecks:</strong> Cross-functional escalation demands immense leadership bandwidth and can stall ill-defined bets like the canceled Project Titan EV.<br/> <strong>2. Secrecy vs. Open AI Research Culture:</strong> Strict compartmentalization clashed with open LLM publishing norms, prompting a +32.5% R&amp;D surge ($45.77B) in FY26 to accelerate Siri AI.<br/> <strong>3. Antitrust &amp; Memory Cost Headwinds:</strong> EU DMA rules, App Store payment injunctions, and memory component inflation test near-term margin resilience <a class=\"cite-link\" href=\"https://fifthperson.com/apple-q4-2026/\" target=\"_blank\" rel=\"noopener noreferrer\">Fifth Person ↗</a>."}, {"key": "aapl_r16", "match_zh": "早年乔布斯率 Macintosh 团队升起海盗旗", "zh": "早年乔布斯率 Macintosh 团队升起海盗旗确立叛逆与极致设计基因；但 1985 年乔布斯出走后，历任职业经理人引入传统多事业部制（各产品线独立背负 P&amp;L），导致 Performa 等数十款机型相互倾轧，1997 年距破产仅剩 90 天现金流 <a class=\"cite-link\" href=\"https://www.apple.com/careers/pdf/HBR_How_Apple_Is_Organized_For_Innovation-4.pdf\" target=\"_blank\" rel=\"noopener noreferrer\">HBR History ↗</a>。", "en": "Jobs's original Macintosh \"Pirate Flag\" team forged Apple's design rebellion; yet after his 1985 ouster, conventional executives installed siloed M-Form divisions with separate P&amp;Ls—spawning dozens of cannibalizing Performa models and bringing Apple within 90 days of insolvency in 1997 <a class=\"cite-link\" href=\"https://www.apple.com/careers/pdf/HBR_How_Apple_Is_Organized_For_Innovation-4.pdf\" target=\"_blank\" rel=\"noopener noreferrer\">HBR History ↗</a>."}, {"key": "aapl_r17", "match_zh": "1997 年乔布斯回归后一天内裁撤全部事业部总经理", "zh": "1997 年乔布斯回归后一天内裁撤全部事业部总经理，合并为单一损益表职能制；以 2×2 四象限砍掉 70% 产品线，推行 DRI 问责与 Top 100 秘密峰会，并于 2008 年创办 Apple University，接连缔造 iMac、iPod、iPhone、App Store 与 iPad <a class=\"cite-link\" href=\"https://fortune.com/article/how-apple-works-inside-the-worlds-biggest-startup/\" target=\"_blank\" rel=\"noopener noreferrer\">Fortune ↗</a>。", "en": "Upon returning in 1997, Jobs terminated all divisional GMs in a single day, unified Apple under one P&amp;L, axed 70% of SKUs into a 2×2 grid, instituted DRI accountability and Top 100 retreats, and founded Apple University in 2008—unleashing iMac, iPod, iPhone, App Store, and iPad <a class=\"cite-link\" href=\"https://fortune.com/article/how-apple-works-inside-the-worlds-biggest-startup/\" target=\"_blank\" rel=\"noopener noreferrer\">Fortune ↗</a>."}, {"key": "aapl_r18", "match_zh": "库克保留职能制骨架，将高压冲突柔化为沉稳跨部门协作", "zh": "库克保留职能制骨架，将高压冲突柔化为沉稳跨部门协作，孵化 Apple Watch、AirPods、Apple Silicon 与千亿级服务生态，将年营收从 $1,082 亿推升至 $4,788 亿；2026 年 9 月 1 日，硬件工程 SVP John Ternus 正式接任 CEO，库克转任执行董事长护航平稳过渡 <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/04/tim-cook-to-become-apple-executive-chairman-john-ternus-to-become-apple-ceo/\" target=\"_blank\" rel=\"noopener noreferrer\">Apple Newsroom ↗</a>。", "en": "Cook preserved the functional spine while evolving abrasive debate into disciplined collaboration—scaling Apple Watch, AirPods, Apple Silicon, and $123B+ Services as revenue grew from $108.2B to $478.8B. On Sep 1, 2026, Hardware SVP John Ternus became CEO with Cook as Executive Chairman <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/04/tim-cook-to-become-apple-executive-chairman-john-ternus-to-become-apple-ceo/\" target=\"_blank\" rel=\"noopener noreferrer\">Apple Newsroom ↗</a>."}, {"key": "aapl_r19", "match_zh": "若按事业部核算，Mac 部门绝不敢独自承担", "zh": "若按事业部核算，Mac 部门绝不敢独自承担底层指令集切换风险；而在单一 P&amp;L 下，Srouji 芯片组、Federighi 系统组与 Ternus 硬件组零内耗会战，助力 FY26 Mac 营收创 $379.3 亿历史新高 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000032019326000024/a8-kex991q4202609262026.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC FY26 ↗</a>。", "en": "A standalone Mac P&amp;L unit could never have shouldered an ISA transition alone; under one P&amp;L, Srouji's Silicon, Federighi's OS, and Ternus's Hardware teams executed seamlessly—propelling FY26 Mac revenue to an all-time record $37.93B <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000032019326000024/a8-kex991q4202609262026.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC FY26 ↗</a>."}, {"key": "aapl_r20", "match_zh": "不同于许多科技巨头选拔财务或销售背景接班人", "zh": "不同于许多科技巨头选拔财务或销售背景接班人，苹果董事会全票推举深度主导 iPad、Mac 与 iPhone 工程架构的 John Ternus 掌舵，发布 iPhone Duo 与触控 Mac 延续产品本位灵魂 <a class=\"cite-link\" href=\"https://www.apple.com/leadership/\" target=\"_blank\" rel=\"noopener noreferrer\">Apple Leadership ↗</a>。", "en": "Unlike tech peers appointing finance or sales executives, Apple's Board elevated 25-year hardware architect John Ternus—who engineered iPad, Mac, and iPhone transitions—shipping iPhone Duo and Touch Mac to preserve product-first leadership <a class=\"cite-link\" href=\"https://www.apple.com/leadership/\" target=\"_blank\" rel=\"noopener noreferrer\">Apple Leadership ↗</a>."}];
      var I18N_TEXT_PAIRS = [["数据中心", "Research Hub"], ["苹果公司 (Apple) 企业文化与组织架构研报", "Apple Corporate Culture & Org Report"], ["苹果企业文化研报", "Apple Culture Monograph"], ["职能制集权 × 全公司单一 P&L × 专家领导专家 × DRI 直接责任人 · “世界最大初创公司”创新密码", "Functional Org × Single Unified P&L × Experts Leading Experts × DRI Accountability"], ["组织形态与损益表", "Org & P&L Model"], ["职能制 · 单一 P&L", "Functional · Single P&L"], ["FY26 全职编制 / 人效", "FY26 FTEs / Rev per FTE"], ["16.7万人 · $2.87M", "167k FTE · $2.87M"], ["FY26 综合毛利 / 服务毛利", "FY26 Total / Services GM"], ["站点与关联导航", "Site & Related Reports"], ["返回数据中心首页", "Back to Research Hub"], ["史蒂夫·乔布斯深度研报", "Steve Jobs Monograph"], ["蒂姆·库克深度研报", "Tim Cook Monograph"], ["iPhone 生态深度研报", "iPhone Ecosystem Report"], ["核心研究章节 (00 – 07)", "Report Chapters (00 – 07)"], ["执行摘要与核心指标", "Executive Summary & KPIs"], ["职能制架构与单一P&L协同", "Functional Org & Single P&L"], ["四大文化支柱与创新护城河", "4 Cultural Pillars & Moat"], ["全球科技巨头文化横向对比", "Global Big Tech Peer Matrix"], ["全栈红利、利润率与复利推演", "Full-Stack Margins & Flywheel"], ["三代演进与四大战役复盘", "3-Era Evolution & Case Studies"], ["苹果文化法则核查清单", "Org Diagnostic Checklist"], ["数据来源与监管核验索引", "Primary Filings & Sources"], ["阅读与导出工具", "Reading & Export Tools"], ["浅色外观", "Light"], ["深色外观", "Dark"], ["导出 HTML", "Export HTML"], ["打印 / PDF", "Print / PDF"], ["组织史定评：商业史唯一以“初创公司职能制”运转的 $5万亿级全栈帝国", "Verdict: History's Only ~$5T Full-Stack Enterprise Run Like a Functional Startup"], ["研究横跨：乔布斯废藩重塑 (1997–2011) · 库克倍增 (2011–2026) · 特努斯接棒 (2026.09+)", "Scope: Jobs Reset (1997–2011) · Cook Scaling (2011–2026) · Ternus Era (Sep 2026+)"], ["数据基准：FY2025–FY2026 10-K", "Baseline: FY2025–FY2026 10-K"], ["CORE THESIS · 职能制集权 (Functional Org) × 全公司唯一损益表 (Single P&L) × 专家领导专家 × DRI 直接责任人", "CORE THESIS · Functional Organization × Single Company-Wide P&L × Experts Leading Experts × DRI Ownership"], ["全公司唯一损益表 (Single Unified P&L)", "Single Unified P&L (Zero Unit Silos)"], ["芯片、硬件、软件与工业设计副总裁均不背负独立产品线利润指标，全集团仅财务部核算一张总损益表，让工程团队纯粹围绕极致用户体验协同攻关。", "Silicon, hardware, OS, and design SVPs carry no standalone product-unit P&L targets—Finance maintains one enterprise P&L so engineers optimize purely for holistic user experience."], ["专家领导专家 × DRI 直接责任人制", "Experts Leading Experts × Single DRI"], ["拒绝让不懂技术的行政通才拍板，要求各级主管向下深入三层技术细节；每个项目节点署名唯一 DRI，彻底杜绝大公司委员会扯皮与集体推诿。", "Domain masters lead domain specialists and probe three levels deep into technical detail; every milestone names a single DRI, eliminating committee gridlock."], ["Apple University 极简传承与招聘克制", "Apple University Craft & Hiring Restraint"], ["以毕加索《公牛》石版画将“对 1,000 个平庸点子说不”沉淀为制度化审美；FY22–FY26 四年间净增员不足 2%，免疫硅谷大扩招大裁员震荡。", "Institutionalizes 'saying no to 1,000 things' via Picasso's Bull lithographs while holding net headcount growth under 2% across FY22–FY26—avoiding boom-bust layoffs."], ["人均创收与工程密度 (FY26)", "Rev / Employee & R&D Share (FY26)"], ["41% 工程研发", "41% Engineering"], ["FY2026 创纪录营收与净利", "FY2026 Record Net Sales & Profit"], ["净利 $132.2B", "Net Inc $132.2B"], ["全栈自研综合毛利率护城河", "Full-Stack Gross Margin Moat"], ["服务毛利 76.2%", "Services GM 76.2%"], ["全球活跃设备底座与研发投入", "Active Installed Base & R&D"], ["研发 $45.77B", "R&D $45.77B"], ["一、职能制集权与单一损益表：苹果如何用 16.7 万人实现无孤岛全栈协同？", "1. Functional Organization & Single P&L: Zero-Silo Full-Stack Synergy Across 167,000 People"], ["拒绝事业部诸侯割据：一套芯片架构、一套设计语言与六大同源系统横跨五大硬件生态", "Rejecting M-Form fiefdoms: one silicon architecture, one design language, and shared OS kernels across five product ecosystems"], ["研发 $45.8B = 1.54x 销管费用", "R&D $45.8B = 1.54x SG&A"], ["Apple Inc. 执行团队中枢（Executive Team · Cupertino Apple Park · 全公司唯一损益表 Single P&L）", "Apple Inc. Executive Team Hub (Cupertino Apple Park · Single Unified Enterprise P&L)"], ["2026.09.01 新核心班底：John Ternus (CEO, 25年硬件老将) × Tim Cook (执行董事长) × Kevan Parekh (CFO)", "Sep 1, 2026 Leadership Core: John Ternus (CEO, 25-yr Hardware Veteran) × Tim Cook (Exec Chair) × Kevan Parekh (CFO)"], ["SILICON · 硬件技术心脏", "SILICON · CUSTOM ARCHITECTURE"], ["Johny Srouji 统领：A/M 系列 SoC、ISP 图像引擎、端侧 Neural Engine 与定制射频芯片跨产品线统一复用。", "Led by Johny Srouji: A/M-series SoCs, custom ISPs, Neural Engines, and wireless silicon shared across all product lines."], ["HARDWARE · 精密工程与设计", "HARDWARE · ENGINEERING & ID"], ["折叠屏 iPhone Duo、iPhone 18 Pro（FY26 板块 $254.1B）、MacBook Neo / 触控 Mac（$37.9B）、iPad 与 Vision Pro。", "Foldable iPhone Duo & iPhone 18 Pro ($254.1B FY26 segment), MacBook Neo & Touch Mac ($37.9B), iPad, and Vision Pro."], ["SOFTWARE & AI · 六大系统平台", "SOFTWARE & AI · UNIFIED OS"], ["Craig Federighi 统领：iOS / iPadOS / macOS / watchOS / visionOS 27 共享内核与端云一体隐私 AI 架构。", "Led by Craig Federighi: iOS / iPadOS / macOS / watchOS / visionOS 27 shared kernels and Private Cloud Compute AI."], ["SERVICES & OPS · 生态与供应链", "SERVICES & OPS · FLYWHEEL"], ["Eddy Cue & Sabih Khan：>25 亿活跃设备支撑 $123.3B 服务营收（毛利率 76.2%）及全球 540 家直营店体验闭环。", "Eddy Cue & Sabih Khan: >2.5B active devices powering $123.3B Services (76.2% GM) and 540 Apple Retail stores worldwide."], ["全公司唯一损益表机制（Single Unified P&L · 零部门结算墙）", "Single Company-Wide P&L Mechanism (Zero Internal Transfer-Pricing Walls)"], ["工程副总裁只需回答“这项技术是否显著提升整体用户体验”，成本权衡由财务与运营在集团总账层面统一统筹。", "Engineering VPs focus solely on elevating end-user experience while Finance and Operations balance costs on a single company ledger."], ["ANPP 新品开发流程 × DRI 直接责任人 × 每周一高管评审会", "ANPP Product Process × Single DRI × Monday Executive Team Review"], ["将充满不确定性的硬科技研发拆解为精密工序，每个模块仅署名一位 DRI，每周一由核心高管团队面对面拍板调配全公司资源。", "Codifies frontier hardware development into clear milestones, a single named DRI per workstream, and weekly Monday executive decisions."], ["1. 砍掉事业部 P&L：把研发从短期利润表解放", "1. Abolishing Unit P&Ls: Freeing R&D from Quarterly Silo Metrics"], ["2. 拒绝重复造轮子：一套底层硅片赋能全终端", "2. Shared Core Architecture: One Silicon Stack Across All Devices"], ["3. 反硅谷周期的招聘克制与极高组织定力", "3. Counter-Cyclical Hiring Restraint & A-Player Density"], ["换届里程碑", "SUCCESSION"], ["FY2025 vs FY2026 五大生态产品线净营收协同跃升（$B · SEC Form 10-K）", "FY2025 vs. FY2026 Net Sales Across Five Product & Service Ecosystems ($B · SEC 10-K)"], ["单一损益表消除部门墙：iPhone ($254.10B, +21.2%)、Services ($123.30B, +13.0%) 与 Mac ($37.93B, +12.5%) 齐创纪录", "Single P&L synergy drove all-time records in iPhone ($254.10B, +21.2%), Services ($123.30B, +13.0%), and Mac ($37.93B, +12.5%)"], ["视图A: 五大生态营收协同", "View A: 5-Segment Net Sales"], ["视图B: 招聘克制与人效跃迁", "View B: FTE Restraint & Rev/FTE"], ["跨职能芯片与硬件联合定义（Apple Silicon × Hardware Eng.）", "Co-Engineered Custom Silicon & Hardware (Apple Silicon × Hardware Eng.)"], ["FY26 研发 $45.77B", "FY26 R&D $45.77B"], ["展开微观执行机制", "Show Execution Mechanics"], ["收起微观执行机制", "Hide Execution Mechanics"], ["FY2026 研发费用首次突破单季百亿美元门槛（全年达 $457.65 亿，占营收 9.56%），而销管费用（SG&A）仅占营收 6.22%，凸显资源向硬核工程研发的极致倾斜。", "FY2026 R&D crossed $10B/quarter for the first time ($45.77B full year, 9.56% of net sales), while SG&A stood at just 6.22%—underscoring capital concentration in core engineering."], ["工业设计至上主义与旗舰形态革新（ID & Human Interface）", "Industrial Design Supremacy & Form-Factor Innovation (ID & HI)"], ["受益于 iPhone 17 超级周期与 2026 年 9 月首款折叠屏 iPhone Duo / iPhone 18 Pro 首发，FY2026 iPhone 净营收同比增长 +21.2% 至 $2,540.98 亿，Mac 净营收亦增长 +12.5% 至创纪录的 $379.29 亿。", "Propelled by the iPhone 17 cycle and Sep 2026 foldable iPhone Duo / iPhone 18 Pro launch, FY26 iPhone sales rose +21.2% to $254.10B while Mac climbed +12.5% to a record $37.93B."], ["隐私价值观护城河与高毛利服务飞轮（Services Ecosystem）", "Privacy-By-Design Moat & High-Margin Services Flywheel"], ["服务毛利率 76.2%", "Services GM 76.2%"], ["FY2026 Services 板块创造高达 $939.43 亿毛利（毛利率 76.19%），以 25.8% 的营收占比贡献了全公司 40.2% 的总毛利，成为平滑硬件换机波动的超级现金压舱石。", "In FY2026, Services generated $93.94B in gross profit (76.19% gross margin), contributing 40.2% of total company gross margin from 25.8% of net sales."], ["“乳制品级”供应链纪律与非提成零售文化（Ops & Apple Store）", "'Dairy-Fresh' Supply Chain Velocity & Non-Commission Retail Culture"], ["FY2026 苹果通过 $863.90 亿股票回购与 $157.21 亿现金分红合计向股东返还 $1,021.11 亿现金，同时期末仍手握 $1,369.35 亿现金及有价证券（净现金 +$568.2 亿）。", "In FY2026, Apple returned $102.11B via $86.39B in share buybacks and $15.72B in dividends while holding $136.94B in cash & marketable securities (+$56.8B net cash)."], ["二、四大企业文化支柱：专家领导专家、DRI 问责、Apple University 与战略减法", "2. Four Cultural Pillars: Experts Leading Experts, DRI Ownership, Apple University & Strategic Focus"], ["点击左侧任一文化支柱卡片，联动查看苹果底层组织行为准则与五维创新竞争力雷达画像", "Click any pillar card on the left to inspect Apple's leadership principles and 5-axis cultural radar"], ["护城河定性：极宽 (Wide Moat · 全栈协同 + 25亿终端生态 + 制度化品味)", "Moat Rating: Wide Moat (Full-Stack Synergy + >2.5B Installed Base + Institutionalized Taste)"], ["01 · 专家领导专家（Experts Leading Experts）", "01 · Experts Leading Experts"], ["向下深入三层细节", "3 Levels Deep"], ["苹果从不让“懂管理但不懂技术的职业通才”统管研发：相机硬件必须由顶级光学专家领导，各级主管必须兼具纵深专业造诣、微观细节掌控与跨部门共同辩论三大领导力特质。", "Apple never puts generalist administrators over technical teams: camera hardware is led by optics masters, and leaders combine deep domain expertise, immersion in detail, and collaborative debate."], ["02 · DRI 直接责任人与零委员会制（Accountability）", "02 · Single DRI & Zero Standing Committees"], ["唯一署名担责", "Single Named Owner"], ["内部严禁成立权责模糊的跨部门常设委员会；从周一高管评审会到每一行底层固件任务，行动项旁必须且只能写上一位 DRI 的名字，做到权责极度透明。", "No diffused cross-department committees: from Monday Executive Team reviews down to firmware tasks, every action item carries exactly one named DRI."], ["03 · Apple University 与毕加索《公牛》极简哲学", "03 · Apple University & Picasso's 'The Bull' Simplicity"], ["对 1,000 件事说不", "Say No to 1,000 Things"], ["2008 年创立内部保密商学院 Apple University，通过毕加索历经 11 版石版画将繁复公牛提炼为极简神韵的经典案例，向新晋管理者传授“残酷砍掉冗余 SKU 与繁琐参数”的审美纪律。", "Founded in 2008, Apple University uses Picasso's 11-plate Bull lithograph progression to teach leaders the discipline of stripping away clutter and redundant SKUs."], ["04 · ANPP 保密机制与长期主义深潜（Secrecy & Grit）", "04 · ANPP Milestones & Multi-Year Stealth R&D"], ["5–10 年秘密攻关", "5–10 Yr Horizon"], ["依托 ANPP 标准里程碑与“需知原则（Need-to-Know）”物理隔离，让工程团队免受外部舆论与短期华尔街噪音干扰，得以在自研芯片、空间计算与折叠形态上进行十年磨一剑式投入。", "ANPP stage-gates and Need-to-Know compartmentalization shield engineering teams from short-term market noise across decade-long silicon, spatial, and foldable bets."], ["苹果企业文化五维特征对比雷达图（10分制标杆评估）", "5-Axis Corporate Culture Benchmark Radar (10-Point Institutional Scale)"], ["点击下方图例胶囊可单独开关对比曲线，悬停顶点查看各维度评分", "Click legend pills below to toggle peer curves; hover vertices for exact scores"], ["苹果 (Apple · 职能集权全栈)", "Apple (AAPL · Functional Full-Stack)"], ["英伟达 (NVIDIA · 扁平全栈算力)", "NVIDIA (NVDA · Flat Full-Stack AI)"], ["传统多事业部科技巨头基准", "Traditional M-Form Tech Conglomerate"], ["三、全球顶级科技与商业巨头文化对比：五种组织基因与人效利润率统治力", "3. Global Big Tech & Iconic Enterprise Peer Matrix: Five Organizational Archetypes"], ["支持按企业、掌舵人（特努斯 / 黄仁勋 / 纳德拉 / 贾西 / 阿贝尔）或组织机制（DRI / 双披萨 / 单一P&L）实时筛选对比", "Filter or search in real time by company, leader (Ternus / Huang / Nadella / Jassy / Abel), or org model (DRI / Two-Pizza / Single P&L)"], ["全部标杆企业", "All Peers"], ["职能集权与全栈派", "Functional & Full-Stack"], ["分权自治与事业部派", "Divisional & Decentralized"], ["企业与文化掌舵人", "Company & Stewards"], ["底层组织架构形态", "Organizational Structure"], ["核心决策与问责机制", "Decision & Accountability DNA"], ["员工规模与人效特征", "Workforce & Rev / FTE"], ["利润率与核心财务表现", "Margins & Financial Scale"], ["与苹果企业文化的异同及适配场景评估", "Comparative Fit vs. Apple"], ["组织文化向盈利能力与人才密度的转化：苹果核心利润率与员工职能占比拆解（%）", "Translating Culture into Profitability & Talent Density: Apple Margins & Functional Mix (%)"], ["数据来源：Apple FY2026 Q4/Full-Year SEC 8-K & Form 10-K 财务报表及 SQ Magazine 员工职能分布统计", "Sources: Apple FY2026 SEC 8-K & Form 10-K financial statements and SQ Magazine workforce breakdown"], ["Services 毛利 76.2% · 全年综合毛利 48.8%", "Services GM 76.2% · Consolidated GM 48.8%"], ["绿色/蓝色：FY2026 分板块毛利率、营业利润率与净利率 (虚线为 45% 硬科技高毛利锚)", "Green / Blue: FY2026 Gross & Operating Margins (dashed = 45% benchmark)"], ["紫色/琥珀色：全公司工程研发 (41%) vs 商业管理 (15%) 职能占比对比", "Purple / Amber: Engineering R&D (41%) vs. Business & Admin (15%) Headcount Share"], ["四、全栈自研红利与文化复利推演：从 $287万超高人效到 $1,361亿年度自由现金流", "4. Full-Stack Silicon Dividends & Compounding: From $2.87M Rev/FTE to $136.1B Free Cash Flow"], ["用五年连跨台阶的毛利率（43.3% → 48.8%）与千亿美元级年度回购分红检验职能制效率", "Validating functional synergy via +550 bps gross-margin expansion (43.3% → 48.8%) and $102.1B annual capital return"], ["FY26 股东总回报 $102.1B", "FY26 Capital Return $102.1B"], ["FY26 服务业务营收首破 $1,233 亿，毛利达 $939.4 亿，贡献全公司逾四成总毛利。", "FY26 Services sales topped $123.3B with $93.94B in gross profit—generating over 40% of total company gross profit."], ["经营现金流 $1,451.0 亿减去极度克制的 $90.4 亿资本开支，自由现金流刷新历史峰值。", "$145.10B operating cash flow minus lean $9.04B CapEx delivered all-time record free cash flow."], ["FY26 股票回购注销 $863.9 亿 + 现金股息 $157.2 亿（季度股息上调至 $0.27/股）。", "$86.39B in FY26 share repurchases plus $15.72B in cash dividends ($0.27/sh quarterly payout)."], ["从 FY25 净利 $1,120.1 亿（26.9%）进一步跃升至 FY26 的 $1,321.8 亿，盈利质量冠绝消费硬件史。", "Rose from $112.01B (26.9% net margin) in FY25 to $132.18B in FY26—unmatched at hardware scale."], ["FY2022–FY2026 全栈自研红利释放期：GAAP 年度净利润 ($B) 与综合毛利率 (%)", "FY2022–FY2026 Full-Stack Payoff: GAAP Net Income ($B) & Consolidated Gross Margin (%)"], ["柱状图（左轴）为 GAAP 年度净利润；折线（右轴）为全年综合毛利率（Apple Silicon 与服务占比双轮抬升 +550 bps）", "Bars (left axis): GAAP Annual Net Income ($B); Line (right axis): Consolidated Gross Margin (+550 bps via Silicon & Services)"], ["毛利率 43.3% → 48.8%", "Gross Margin 43.3% → 48.8%"], ["■ 左轴：GAAP 年度净利润 ($B)", "■ Left Axis: GAAP Net Income ($B)"], ["● 右轴：全年综合毛利率 (%)", "● Right Axis: Consolidated Gross Margin (%)"], ["GAAP 年度净利润 (左轴 · $B)", "GAAP Net Income (Left · $B)"], ["全年综合毛利率 (右轴 · %)", "Consolidated Gross Margin (Right · %)"], ["--- 自研芯片高毛利跃升线 45.0%", "--- 45.0% High-Margin Benchmark"], ["苹果跨代际组织文化复利推演器", "Multi-Era Organizational Flywheel Compounding Simulator"], ["叠加千亿回购注销 + 股息再投增厚 (+2.2%/年)", "Include Buyback Cannibalization + Dividend Yield (+2.2%/yr)"], ["映射每年约 $85B–$90B 持续缩股注销与分红复投带来的每股权益加速", "Models per-share compounding boost from ~$85B–$90B annual share retirement and reinvested dividends"], ["① 2011–2026 库克制度化全球倍增期", "① 2011–2026 Cook Global Scaling Era"], ["15年 · 21.5%+回购", "15Y · 21.5%+Buyback"], ["② 1997–2011 乔布斯职能制重塑逆袭期", "② 1997–2011 Jobs Functional Turnaround"], ["14年 · 39.3%", "14Y · 39.3%"], ["③ 2026–2036 特努斯 AI 硬件新周期基准", "③ 2026–2036 Ternus AI Hardware Base Case"], ["10年 · 11.5%+回购", "10Y · 11.5%+Buyback"], ["初始投入本金 (USD)", "Initial Principal (USD)"], ["长期持有年限 (Years)", "Holding Horizon (Years)"], ["核心内生年化增值率 (Base CAGR %)", "Organic Base Return CAGR (%)"], ["期末预估总资产 (Ending Value)", "Projected Ending Value"], ["总回报倍数 (MOIC) / 综合年化", "Total MOIC / Blended CAGR"], ["累计净复利收益 (Net Gain)", "Cumulative Net Gain"], ["━ 含回购缩股与分红再投总资产轨迹", "━ Total Wealth with Buyback & Dividend Boost"], ["- - 仅内生业务估值增长基准", "- - Organic Base Return Only (Ex-Buyback)"], ["悬停曲线可逐年对比“叠加持续回购缩股+分红复投”与“纯内生股价增长”的跨周期财富复利效应。", "Hover along the curve to compare year-by-year total compounding with buyback retirement vs. base growth alone."], ["正向组织文化遗产定评", "Enduring Organizational Strengths"], ["客观局限与组织张力反思", "Structural Constraints & Tensions"], ["五、三代文化演进与四大战役复盘：从“海盗旗创业帮”到跨半世纪创新机器", "5. Three-Generation Cultural Evolution & Landmark Battles: 50 Years of Apple (1976–2026)"], ["苹果之所死守职能制，正源于 1985–1997 年“传统事业部制”几乎令公司破产的惨痛历史教训", "Apple guards its functional organization fiercely because 1985–1997 divisionalization nearly bankrupted the company"], ["1976 创立 → 2026 跨越 50 周年", "Founded 1976 → 50th Anniversary 2026"], ["第一幕 · 海盗旗基因与多事业部割据危机 (1976–1997) —— 传统 M-Form 的反面教材", "Act I · Pirate Flag Origins & Divisional Crisis (1976–1997) — Cautionary Tale of M-Form"], ["1997 净亏 $10.45亿", "FY97 Net Loss $1.05B"], ["第二幕 · 一日废藩、单一 P&L 与制度化审美 (1997–2011) —— 乔布斯重塑组织骨架", "Act II · Single-Day Reset, Unified P&L & Apple University (1997–2011) — Jobs Rebuilds"], ["市值 ~$3B → ~$350B", "Mkt Cap ~$3B → ~$350B"], ["第三幕 · 协作进化、全栈自研与第三代掌舵交棒 (2011–2026+) —— 库克倍增与特努斯履新", "Act III · Collaborative Scale, Apple Silicon & Ternus Succession (2011–2026+)"], ["2026.09.01 Ternus 任 CEO", "Sep 1, 2026 Ternus CEO"], ["案例 01 · 2008 & 2012", "Case 01 · 2008 & 2012"], ["DRI 铁腕问责", "DRI Accountability"], ["MobileMe 与 Apple Maps 首发失误的果断换帅", "Decisive DRI Accountability After MobileMe & Maps Misfires"], ["当 2008 年 MobileMe 同步故障及 2012 年 Apple Maps 体验未达标时，乔布斯与库克均立即启动 DRI 问责并调整高管分工，直接催生出高可靠的 iCloud 与跨部门融合的软件工程新秩序。", "When MobileMe (2008) and Apple Maps (2012) fell short of quality bars, Jobs and Cook immediately enforced DRI accountability and reorganized leadership—forging iCloud reliability and unified OS engineering."], ["案例 02 · 2020–2026", "Case 02 · 2020–2026"], ["全栈协同巅峰", "Full-Stack Triumph"], ["Apple Silicon 告别英特尔的“无缝换心手术”", "Apple Silicon Breakaway from Intel Across All Macs"], ["案例 03 · 2024–2026", "Case 03 · 2024–2026"], ["战略减法纪律", "Strategic Subtraction"], ["十年泰坦造车（Project Titan）果断止损转投 AI", "Canceling Decade-Long Project Titan EV to Focus on AI"], ["面对整车制造低毛利与 L5 自动驾驶商业闭环尚不成熟，管理层拒绝被百亿美元沉没成本绑架，果断终止造车并将精锐工程力量集中转入端侧智能与新形态硬件研发。", "Refusing sunk-cost fallacy amid structurally low auto margins and unready L5 autonomy, leadership terminated Project Titan and redeployed elite engineers into on-device AI and next-gen hardware."], ["案例 04 · 2026.09", "Case 04 · Sep 2026"], ["跨代治理范本", "Engineer Succession"], ["选拔 25 年硬件统帅 John Ternus 接棒 CEO", "Elevating 25-Year Hardware Architect John Ternus to CEO"], ["法则一：", "Law 01:"], ["决策权必须跟着“专业技术深度”走而非跟着“行政头衔”走——让顶尖专家领导专家，并向下掌握三层微观细节。", "Decision rights must follow technical mastery rather than administrative rank—let domain experts lead experts three levels deep."], ["法则二：", "Law 02:"], ["凡需要软硬芯无缝咬合的产品生态，切忌过早拆分为各自背负 P&L 的独立事业部，否则内部结算墙必将瓦解用户体验。", "Never splinter tightly integrated hardware-software-silicon ecosystems into separate P&L units whose transfer-pricing walls fracture UX."], ["法则三：", "Law 03:"], ["用唯一署名的 DRI 消灭推诿迷雾，用“对 1,000 个好点子说不”的减法纪律守护 A 级人才密度与超高毛利率。", "Eliminate ambiguity with a single named DRI, and protect A-player talent density and gross margins by saying no to 1,000 good ideas."], ["六、“苹果文化法则”科技企业组织与创新力交互式核查清单", "6. Interactive 'Apple Culture Laws' Organization & Innovation Diagnostic Checklist"], ["用于诊断任何硬科技企业、产品团队或投资标的是否具备高人效全栈协同基因（勾选状态自动保存在本地）", "Diagnose whether a technology company or product organization exhibits high-density full-stack synergy (saved locally)"], ["全部勾选", "Check All"], ["重置清单", "Reset"], ["数据来源与一手监管/学术核验索引（SEC EDGAR · Apple Newsroom · Harvard Business Review）", "Primary Regulatory Filings & Academic Sources Index (SEC EDGAR · Apple Newsroom · HBR)"], ["本研报所有财务、员工编制、分业务毛利率、管理层换届与组织治理研究数据均严格核验自美国证监会（SEC EDGAR）、苹果公司官方新闻中心（Apple Newsroom）、《哈佛商业评论》（HBR · Podolny & Hansen）及权威公开数据库，仅供企业文化与组织架构学术/商业研究参考，不构成任何证券投资建议。", "All financial, FTE headcount, segment gross margin, CEO succession, and organizational governance figures are verified directly against U.S. SEC EDGAR filings, Apple Newsroom releases, Harvard Business Review (Podolny & Hansen), and public disclosures. For research purposes only; not investment advice."]];
      var I18N_ATTR_PAIRS = [["展开/收起章节目录", "Toggle Chapter Sidebar"], ["切换目录侧边栏", "Toggle Chapter Sidebar"], ["面包屑导航", "Breadcrumb Navigation"], ["检索章节或指标…", "Jump to chapter or KPI…"], ["快速跳转章节或指标", "Quick jump to chapter or metric"], ["研究章节目录与站点导航", "Report Chapters & Site Navigation"], ["站点导航与章节目录", "Site Links & Table of Contents"], ["外观模式切换", "Appearance Theme Switch"], ["阅读与导出工具", "Reading & Export Tools"], ["导出独立 HTML 文件 (.html)", "Export Standalone HTML File (.html)"], ["打印或导出 PDF 研报", "Print or Save Report as PDF"], ["第一章图表视图切换", "Chapter 01 Chart View Switch"], ["搜索企业、掌舵人、架构特征 (DRI / 双披萨 / 分权) 或利润率…", "Search company, CEO, org trait (DRI / Two-Pizza / Single P&L) or margin…"], ["筛选对比企业", "Filter benchmark peers"], ["标杆企业分类筛选", "Peer category filter"], ["全球顶级科技与商业巨头企业文化横向对比表", "Global Big Tech & Iconic Enterprise Corporate Culture Comparison"], ["苹果历史与前瞻复利预设周期", "Historical & Forward Compounding Presets"], ["核查完成度进度条", "Checklist Completion Progress"]];

      var PILLAR_NOTES_EN = [
        '<strong>Selected Pillar (01 · Experts Leading Experts):</strong> As Apple University Dean Joel Podolny notes, Apple leaders must combine deep domain expertise, immersion three levels down into detail, and collaborative debate—exemplified by Hardware Chief John Ternus becoming CEO in Sep 2026 <a class="cite-link" href="https://www.apple.com/careers/pdf/HBR_How_Apple_Is_Organized_For_Innovation-4.pdf" target="_blank" rel="noopener noreferrer">HBR Paper ↗</a>.',
        '<strong>Selected Pillar (02 · Single DRI Ownership):</strong> Apple bans diffused standing committees; every hardware feature, firmware module, and supply-chain ramp names exactly one Directly Responsible Individual (DRI) in meeting notes <a class="cite-link" href="https://fortune.com/article/how-apple-works-inside-the-worlds-biggest-startup/" target="_blank" rel="noopener noreferrer">Fortune Inside Apple ↗</a>.',
        '<strong>Selected Pillar (03 · Apple University &amp; Radical Focus):</strong> Picasso\'s 11-state <em>Bull</em> lithograph curriculum trains leaders to eliminate clutter and mediocre SKUs—enabling a remarkably focused flagship lineup to generate $478.83B in FY26 sales <a class="cite-link" href="https://www.bestcollegereviews.org/apple-university/" target="_blank" rel="noopener noreferrer">Apple University ↗</a>.',
        '<strong>Selected Pillar (04 · ANPP &amp; Multi-Year Stealth R&amp;D):</strong> Protected by ANPP milestones and physical compartmentalization, Apple boosted FY26 R&amp;D +32.5% YoY to $45.77B across custom silicon, foldable iPhone Duo, and next-gen Siri AI <a class="cite-link" href="https://www.sec.gov/Archives/edgar/data/320193/000032019326000024/a8-kex991q4202609262026.htm" target="_blank" rel="noopener noreferrer">SEC FY26 8-K ↗</a>.'
      ];

      var PEER_ROWS_EN = [
        {
          category: 'functional',
          benchmark: true,
          company: 'Benchmark: Apple Inc. (AAPL)',
          leader: 'Jobs / Cook / John Ternus (Sep 2026+)',
          positioning: 'Functional Organization + Single Company-Wide P&L',
          culture: 'Experts Leading Experts + Single DRI + Apple University simplicity',
          headcount: '167,000 FTE (41% Eng) · $2.87M Rev / FTE',
          margins: 'FY26 Sales $478.8B · 48.8% GM (Services 76.2%) · Net Inc $132.2B',
          verdict: 'Full-stack gold standard: zero unit P&L silos unlock seamless hardware-silicon-OS synergy across >2.5B active devices and $136.1B FCF.',
          sourceLabel: 'SEC FY26 10-K / HBR',
          sourceUrl: 'https://www.apple.com/careers/pdf/HBR_How_Apple_Is_Organized_For_Innovation-4.pdf'
        },
        {
          category: 'functional',
          benchmark: false,
          company: 'NVIDIA (NVDA)',
          leader: 'Jensen Huang',
          positioning: 'Ultra-flat functional network + ~60 direct reports + unified AI stack',
          culture: 'No business-unit silos + Top-5 email transparency + speed-of-light execution',
          headcount: '~42,000 FTE (~74% R&D) · ~$5.14M Rev / FTE',
          margins: 'FY26 Sales $215.9B · 71.1% GAAP GM · Net Inc $120.1B',
          verdict: 'Closest hard-tech cousin: likewise rejects divisional P&Ls for full-stack silicon + CUDA integration, favoring open info flow vs. Apple secrecy.',
          sourceLabel: 'NVIDIA FY26 Stats',
          sourceUrl: 'https://www.gradually.ai/en/nvidia-statistics/'
        },
        {
          category: 'divisional',
          benchmark: false,
          company: 'Microsoft (MSFT)',
          leader: 'Satya Nadella',
          positioning: 'Three major business segments (Intelligent Cloud / Productivity / Personal Computing)',
          culture: 'Growth Mindset + cross-division enterprise cloud & AI platform synergy',
          headcount: '~223,000 FTE (77k R&D) · ~$1.49M Rev / FTE',
          margins: 'FY26 Sales $331.8B · High enterprise cloud & software operating margins',
          verdict: 'Enterprise software powerhouse: excels across diverse B2B software verticals, though divisional boundaries limit Apple-style consumer hardware craft.',
          sourceLabel: 'MSFT FY26 10-K Data',
          sourceUrl: 'https://bebop.ai/companies/largest-tech-companies'
        },
        {
          category: 'divisional',
          benchmark: false,
          company: 'Amazon (AMZN)',
          leader: 'Jeff Bezos / Andy Jassy',
          positioning: 'Decoupled API service architecture + thousands of Two-Pizza Teams',
          culture: 'Day 1 mentality + 16 Leadership Principles + 6-Pager narrative memos',
          headcount: '~1.55M+ (including global fulfillment network)',
          margins: 'FY25 Sales $716.9B · AWS cloud & high-margin advertising profit engines',
          verdict: 'Decentralized experimentation engine: Two-Pizza autonomy thrives on rapid parallel bets, whereas Apple centralizes to perfect a few flagship icons.',
          sourceLabel: 'Amazon 2025 AR',
          sourceUrl: 'https://s2.q4cdn.com/299287126/files/doc_financials/2026/ar/Amazon-2025-Annual-Report.pdf'
        },
        {
          category: 'divisional',
          benchmark: false,
          company: 'Berkshire Hathaway (BRK.B)',
          leader: 'Buffett / Munger / Greg Abel',
          positioning: '27-person Omaha HQ + 60+ autonomous operating subsidiaries',
          culture: 'Near-100% operating decentralization + centralized float & capital allocation',
          headcount: '~388,000 FTE · Only 27 at parent HQ',
          margins: 'Perpetual cash-compounding federation across insurance, rail, energy & retail',
          verdict: 'Philosophical mirror image: Berkshire decentralizes unrelated businesses while Apple unifies one ecosystem—yet Buffett made Apple a core holding.',
          sourceLabel: 'Berkshire AR',
          sourceUrl: 'https://www.berkshirehathaway.com/2025ar/2025ar.pdf'
        }
      ];

      var CHECKLIST_ITEMS_EN = [
        {
          tag: 'Domain Mastery',
          title: '1. "Experts Leading Experts" Test: Do decision-makers master details three levels down?',
          desc: 'Verify whether core engineering and product leaders are world-class domain authorities (like Ternus in hardware, Srouji in silicon) rather than generalist managers.'
        },
        {
          tag: 'Single P&L Synergy',
          title: '2. Zero Profit-Wall Test: Are hardware and software teams free from transfer-pricing turf wars?',
          desc: 'Assess whether silicon, OS, and design teams share breakthroughs seamlessly for overall UX rather than optimizing isolated divisional P&Ls.'
        },
        {
          tag: 'Single DRI',
          title: '3. DRI Accountability Test: Does every critical deliverable carry a single named owner?',
          desc: 'Check project trackers and review notes to ensure zero "joint committee ownership" ambiguity—every milestone has one accountable DRI.'
        },
        {
          tag: 'Picasso Subtraction',
          title: '4. Strategic Focus Test: Does leadership have the courage to kill 90% of distractions & sunk costs?',
          desc: 'Facing hype cycles or multi-billion sunk costs (like Project Titan), can leadership decisively cut losses and focus A-players on category-defining flagships?'
        },
        {
          tag: '$2.87M / FTE',
          title: '5. Hiring Restraint & Talent Density Test: Is revenue per employee compounding with scale?',
          desc: 'Benchmarked against Apple\'s 41% engineering mix and +0.6% FY26 FTE growth, is growth driven by A-player leverage rather than headcount bloat?'
        },
        {
          tag: '76.2% Services GM',
          title: '6. Ecosystem Flywheel Test: Does hardware retention naturally spawn high-margin recurring services?',
          desc: 'Verify whether installed-base loyalty generates high-margin recurring services cash flow and disciplined capital return to shareholders.'
        }
      ];

      var QUICK_JUMP_EN = [
        { sec: 'sec-00', title: '00 Executive Summary & KPIs', sub: '$478.8B Sales · $2.87M Rev/FTE · 48.8% Gross Margin' },
        { sec: 'sec-01', title: '01 Functional Org & Single P&L', sub: 'John Ternus CEO · 5-Segment Sales & Productivity Charts' },
        { sec: 'sec-02', title: '02 Four Cultural Pillars & Moat', sub: 'Experts Leading Experts · DRI · Apple University · 5-Axis Radar' },
        { sec: 'sec-03', title: '03 Global Big Tech Peer Matrix', sub: 'Apple vs. NVIDIA vs. Microsoft vs. Amazon vs. Berkshire' },
        { sec: 'sec-04', title: '04 Full-Stack Margins & Flywheel', sub: 'FY22–FY26 Profit & GM Expansion · Multi-Era Simulator' },
        { sec: 'sec-05', title: '05 Three-Era Evolution & Battles', sub: '1997 Reset · Apple Silicon · Sep 2026 Ternus Succession' },
        { sec: 'sec-06', title: '06 Apple Culture Checklist', sub: '6-Point Full-Stack Org Diagnostic (Saved Locally)' },
        { sec: 'sec-07', title: '07 Primary Filings & Sources', sub: 'SEC FY26 10-K/8-K · Apple Newsroom · HBR Monograph' }
      ];

      var STORAGE_CHECK_KEY = 'mui_aapl_culture_checks_v1';

      var PILLAR_NOTES = [
        '<strong>当前选中支柱解读（01 专家领导专家）：</strong>苹果大学院长 Joel Podolny 指出，苹果要求各级管理者具备“深厚领域专业知识 + 向下深入三层细节 + 跨职能协作辩论”三大特质；2026 年 9 月硬件统帅 John Ternus 出任 CEO 正是这一基因的延续 <a class="cite-link" href="https://www.apple.com/careers/pdf/HBR_How_Apple_Is_Organized_For_Innovation-4.pdf" target="_blank" rel="noopener noreferrer">HBR Paper ↗</a>。',
        '<strong>当前选中支柱解读（02 DRI 直接责任人制）：</strong>在苹果内部不存在权责模糊的协调委员会，每一项功能模块、每一次供应链良率攻关在会议纪要上都只写唯一一位 DRI 的名字，消灭跨部门扯皮 <a class="cite-link" href="https://fortune.com/article/how-apple-works-inside-the-worlds-biggest-startup/" target="_blank" rel="noopener noreferrer">Fortune Inside Apple ↗</a>。',
        '<strong>当前选中支柱解读（03 Apple University 与极简减法）：</strong>通过毕加索《公牛》11 版石版画课程向管理者灌输“删繁就简”哲学，每年砍掉大量平庸产品构想，以极精简旗舰矩阵撬动 FY26 $4,788.3 亿总营收 <a class="cite-link" href="https://www.bestcollegereviews.org/apple-university/" target="_blank" rel="noopener noreferrer">Apple University ↗</a>。',
        '<strong>当前选中支柱解读（04 ANPP 流程与十年秘密深潜）：</strong>依托严密的 ANPP 里程碑与物理隔离保密制度，苹果在 FY26 将研发投入大幅拉升 +32.5% 至 $457.7 亿，集中攻坚自研芯片、iPhone Duo 折叠形态与全新 Siri AI <a class="cite-link" href="https://www.sec.gov/Archives/edgar/data/320193/000032019326000024/a8-kex991q4202609262026.htm" target="_blank" rel="noopener noreferrer">SEC FY26 8-K ↗</a>。'
      ];

      var PEER_ROWS = [
        {
          category: 'functional',
          benchmark: true,
          company: '研究基准：苹果公司 (Apple · AAPL)',
          leader: '乔布斯 / 库克 / 约翰·特努斯 (2026.09+)',
          positioning: '职能制集权 (Functional Org) + 全公司唯一损益表 (Single P&L)',
          culture: '专家领导专家 + DRI 直接责任人 + Apple University 极简审美',
          headcount: '16.7万人 (41%工程) · 人均创收 $2.87M',
          margins: 'FY26 营收 $4,788亿 · 综合毛利 48.8% (服务 76.2%) · 净利 $1,322亿',
          verdict: '软硬芯服全栈协同标杆：取消事业部利润墙，以极少 SKU 打造全球最高粘性生态（>25亿活跃设备）与 $1,361亿年度自由现金流。',
          sourceLabel: 'SEC FY26 10-K / HBR',
          sourceUrl: 'https://www.apple.com/careers/pdf/HBR_How_Apple_Is_Organized_For_Innovation-4.pdf'
        },
        {
          category: 'functional',
          benchmark: false,
          company: '英伟达 (NVIDIA · NVDA)',
          leader: '黄仁勋 (Jensen Huang)',
          positioning: '超扁平职能网络 + ~60名高管直报 CEO + 单一全栈算力平台',
          culture: '无事业部割据 + Top-5 邮件全透明信息流 + 光速执行哲学',
          headcount: '~4.2万人 (研发占 ~74%) · 人均创收 ~$5.14M',
          margins: 'FY26 营收 $2,159亿 · GAAP 毛利率 71.1% · 净利 $1,201亿',
          verdict: '最接近苹果的硬科技同盟：同样拒绝独立事业部 P&L、坚持芯片与 CUDA 软件全栈耦合，但英伟达强调全员信息透明，而苹果实行严格物理保密。',
          sourceLabel: 'NVIDIA FY26 Stats',
          sourceUrl: 'https://www.gradually.ai/en/nvidia-statistics/'
        },
        {
          category: 'divisional',
          benchmark: false,
          company: '微软 (Microsoft · MSFT)',
          leader: '萨提亚·纳德拉 (Satya Nadella)',
          positioning: '三大业务板块事业部矩阵 (智能云 Azure / 生产力 M365 / 个人计算)',
          culture: '成长型思维 (Growth Mindset) + 事业部 P&L 协同 + 开放生态',
          headcount: '~22.3万人 (研发 7.7万人) · 人均创收 ~$1.49M',
          margins: 'FY26 营收 $3,318亿 · 企业云与软件高营业利润率驱动',
          verdict: '企业级软件广度霸主：纳德拉重塑跨事业部协作打赢云与企业 AI 战役，但在消费硬件端难以复制苹果单一损益表下的工业设计统一性。',
          sourceLabel: 'MSFT FY26 10-K Data',
          sourceUrl: 'https://bebop.ai/companies/largest-tech-companies'
        },
        {
          category: 'divisional',
          benchmark: false,
          company: '亚马逊 (Amazon · AMZN)',
          leader: '贝索斯 / 安迪·贾西 (Andy Jassy)',
          positioning: '解耦 API 契约化服务 + 数千支“双披萨自治小队 (Two-Pizza Teams)”',
          culture: '永远的 Day 1 + 16条领导力准则 + 六页纸叙事备忘录',
          headcount: '~155万+ (含全球仓储物流履约网络)',
          margins: 'FY25 营收 $7,169亿 · AWS 云基建与高毛利广告双擎盈利',
          verdict: '分布式并行试错机器：双披萨分权架构极度适合电商与云服务横向扩张试错，而苹果职能集权则专为打磨零容错软硬一体精品而生。',
          sourceLabel: 'Amazon 2025 AR',
          sourceUrl: 'https://s2.q4cdn.com/299287126/files/doc_financials/2026/ar/Amazon-2025-Annual-Report.pdf'
        },
        {
          category: 'divisional',
          benchmark: false,
          company: '伯克希尔·哈撒韦 (Berkshire · BRK.B)',
          leader: '巴菲特 / 芒格 / 格雷格·阿贝尔 (Greg Abel)',
          positioning: '奥马哈 27 人极简总部 + 60+ 独立子公司极端分权联邦',
          culture: '经营权接近 100% 下放自治 + 浮存金与资本配置权绝对集中',
          headcount: '~38.8万人 · 集团总部仅 27 人',
          margins: '跨保险、铁路、能源与消费品的永续现金复利综合体',
          verdict: '集权与分权的哲学双子星：伯克希尔管异质百业靠“子公司零干预”，苹果造同源生态靠“跨职能 100% 咬合”——巴菲特却长期将苹果列为核心重仓。',
          sourceLabel: 'Berkshire AR',
          sourceUrl: 'https://www.berkshirehathaway.com/2025ar/2025ar.pdf'
        }
      ];

      var CHECKLIST_ITEMS = [
        {
          tag: '专家决策权',
          title: '1. “专家领导专家”测试：拍板者是否掌握向下三层的技术细节？',
          desc: '核查核心部门主管是否为本领域一线技术/设计权威（如硬件专家 Ternus、芯片专家 Srouji），而非仅看财务报表的行政通才。'
        },
        {
          tag: '单一 P&L 协同',
          title: '2. 零部门利润墙测试：软硬件团队是否免于内部结算与抢利内耗？',
          desc: '观察底层芯片、系统算法与工业设计团队能否为提升整体体验无私共享研发成果，而非因独立事业部考核各自为政。'
        },
        {
          tag: 'DRI 唯一问责',
          title: '3. DRI 直接责任人测试：每个关键交付节点旁是否只写一个名字？',
          desc: '检验项目看板与会议纪要是否彻底杜绝“多部门联合负责”，确保每项特性与供应链节点均有唯一可拍板、可追责的 DRI。'
        },
        {
          tag: '《公牛》极简力',
          title: '4. 战略减法与聚焦测试：管理层是否有勇气砍掉 90% 伪机会与冗余 SKU？',
          desc: '面对诱人风口或百亿沉没成本（如造车项目），管理层能否果断止损，将顶尖研发带宽集中于极少数能做到全球第一的旗舰产品。'
        },
        {
          tag: '$2.87M 人效锚',
          title: '5. 招聘克制与人才密度测试：人均创收是否随规模持续跃升？',
          desc: '对标苹果 41% 工程研发占比与 FY26 仅 +0.6% 的极低净增员率，检验企业是否靠 A 级人才密度而非盲目堆人头驱动增长。'
        },
        {
          tag: '76.2% 服务毛利',
          title: '6. 软硬服生态粘性测试：硬件存量底座能否自然生长出高毛利服务现金流？',
          desc: '核查硬件用户留存率是否足以衍生出高毛利、高复购的订阅与服务飞轮，并转化为持续回馈股东的千亿级自由现金流。'
        }
      ];

      var QUICK_JUMP_INDEX = [
        { sec: 'sec-00', title: '00 执行摘要与核心指标', sub: '$478.8B 营收 · $2.87M 人均创收 · 48.8% 综合毛利率' },
        { sec: 'sec-01', title: '01 职能制架构与单一 P&L 协同', sub: 'John Ternus 履新 CEO · 五大生态营收与人效双视图图表' },
        { sec: 'sec-02', title: '02 四大文化支柱与创新护城河', sub: '专家领导专家 · DRI 问责 · Apple University · 五维雷达图' },
        { sec: 'sec-03', title: '03 全球科技巨头文化横向对比', sub: 'Apple vs NVIDIA vs Microsoft vs Amazon vs Berkshire' },
        { sec: 'sec-04', title: '04 全栈红利、利润率与复利推演', sub: 'FY22–FY26 净利与毛利率双升 · 跨代文化复利推演器' },
        { sec: 'sec-05', title: '05 三代演进与四大战役复盘', sub: '1997 一日废藩 · Apple Silicon 换心 · 2026.09 特努斯接棒' },
        { sec: 'sec-06', title: '06 苹果文化法则核查清单', sub: '6 项全栈创新组织诊断与本地持久化评分' },
        { sec: 'sec-07', title: '07 数据来源与监管核验索引', sub: 'SEC FY26 10-K/8-K · Apple Newsroom · HBR 权威信源' }
      ];

      var PRESETS = {
        p1: { principal: 10000, years: 15, priceCagr: 21.5, drip: true },
        p2: { principal: 10000, years: 14, priceCagr: 39.3, drip: false },
        p3: { principal: 10000, years: 10, priceCagr: 11.5, drip: true }
      };

      var state = {
        lang: 'zh',
        theme: 'light',
        ch1View: 'viewA',
        activePillar: 0,
        radarSeries: { aapl: true, nvda: true, mform: true },
        peerFilter: 'all',
        peerQuery: '',
        sim: { principal: 10000, years: 15, priceCagr: 21.5, drip: true, preset: 'p1' },
        checks: [true, true, true, false, false, false]
      };

      function safeGetStorage(key) {
        try {
          return window.localStorage.getItem(key);
        } catch (err) {
          return null;
        }
      }

      function safeSetStorage(key, val) {
        try {
          window.localStorage.setItem(key, val);
        } catch (err) {}
      }

      var toastTimer = null;
      function showToast(message) {
        var el = document.getElementById('muiSnackbar');
        if (!el) return;
        el.textContent = message;
        el.classList.add('show');
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(function () {
          el.classList.remove('show');
        }, 2800);
      }

      /* ======================================================================
         2. Theme Switching & Sidebar Drawer
         ====================================================================== */
      function isEn() {
        return state.lang === 'en';
      }

      var _zhToEnText = {};
      var _enToZhText = {};
      for (var _ti = 0; _ti < I18N_TEXT_PAIRS.length; _ti++) {
        _zhToEnText[I18N_TEXT_PAIRS[_ti][0]] = I18N_TEXT_PAIRS[_ti][1];
        _enToZhText[I18N_TEXT_PAIRS[_ti][1]] = I18N_TEXT_PAIRS[_ti][0];
      }
      var _zhToEnAttr = {};
      var _enToZhAttr = {};
      for (var _ai = 0; _ai < I18N_ATTR_PAIRS.length; _ai++) {
        _zhToEnAttr[I18N_ATTR_PAIRS[_ai][0]] = I18N_ATTR_PAIRS[_ai][1];
        _enToZhAttr[I18N_ATTR_PAIRS[_ai][1]] = I18N_ATTR_PAIRS[_ai][0];
      }
      var _richMapByKey = {};
      for (var _ri = 0; _ri < I18N_RICH_LIST.length; _ri++) {
        _richMapByKey[I18N_RICH_LIST[_ri].key] = I18N_RICH_LIST[_ri];
      }

      function bindRichBlocksOnce() {
        var candidates = document.querySelectorAll('h1, p, div');
        for (var i = 0; i < candidates.length; i++) {
          var el = candidates[i];
          if (el.getAttribute('data-i18n-rich')) continue;
          if (el.id === 'pillarFocusNote' || el.closest('#pillarFocusNote')) continue;
          var normTxt = (el.textContent || '').replace(/\s+/g, ' ').trim();
          for (var j = 0; j < I18N_RICH_LIST.length; j++) {
            var item = I18N_RICH_LIST[j];
            if (normTxt.indexOf(item.match_zh) === 0 && el.children.length <= 25) {
              if (!el.querySelector('div, p, ul, table, canvas')) {
                el.setAttribute('data-i18n-rich', item.key);
                break;
              }
            }
          }
        }
      }

      function syncCh1HeaderText() {
        var titleEl = document.getElementById('ch1ChartTitle');
        var subEl = document.getElementById('ch1ChartSub');
        if (!titleEl || !subEl) return;
        if (state.ch1View === 'viewA') {
          titleEl.textContent = isEn()
            ? 'FY2025 vs. FY2026 Net Sales Across Five Product & Service Ecosystems ($B · SEC 10-K)'
            : 'FY2025 vs FY2026 五大生态产品线净营收协同跃升（$B · SEC Form 10-K）';
          subEl.textContent = isEn()
            ? 'Single P&L synergy drove all-time records in iPhone ($254.10B, +21.2%), Services ($123.30B, +13.0%), and Mac ($37.93B, +12.5%)'
            : '单一损益表消除部门墙：iPhone ($254.10B, +21.2%)、Services ($123.30B, +13.0%) 与 Mac ($37.93B, +12.5%) 齐创纪录';
        } else {
          titleEl.textContent = isEn()
            ? 'FY2021–FY2026 Disciplined FTE Headcount (k) vs. Revenue per Employee ($M · 10-K)'
            : 'FY2021–FY2026 招聘克制（千人）vs 人均创收跃迁（$M · Form 10-K）';
          subEl.textContent = isEn()
            ? 'Four-year FTE headcount held nearly flat (164k → 167k) while revenue per employee surged to a record $2.87M in FY26'
            : '四年间全职员工稳定在 16.4万–16.7万人区间，FY26 人均年创收跃升至创纪录的 $2.87M';
        }
      }

      function syncCollapseButtonsText() {
        var btns = document.querySelectorAll('[data-collapse-target]');
        for (var i = 0; i < btns.length; i++) {
          var pid = btns[i].getAttribute('data-collapse-target');
          var panel = document.getElementById(pid);
          var isOpen = panel && panel.classList.contains('open');
          if (isEn()) {
            btns[i].innerHTML = isOpen ? '<span>Hide Execution Mechanics</span> <span>⌃</span>' : '<span>Show Execution Mechanics</span> <span>⌄</span>';
          } else {
            btns[i].innerHTML = isOpen ? '<span>收起微观执行机制</span> <span>⌃</span>' : '<span>展开微观执行机制</span> <span>⌄</span>';
          }
        }
      }

      function applyLanguage(lang, silent) {
        bindRichBlocksOnce();
        state.lang = lang === 'en' ? 'en' : 'zh';
        var en = isEn();
        document.documentElement.setAttribute('lang', en ? 'en' : 'zh-CN');
        document.documentElement.setAttribute('data-lang', state.lang);
        document.title = en ? DOC_TITLE_EN : DOC_TITLE_ZH;

        var lGrp = document.getElementById('langSwitchGroup');
        if (lGrp) lGrp.setAttribute('aria-label', en ? 'Language switcher' : '语言切换');
        var abThmBtn = document.getElementById('appbarThemeBtn');
        if (abThmBtn) {
          abThmBtn.setAttribute('title', en ? 'Toggle Light / Dark theme' : '切换浅色 / 深色主题');
          abThmBtn.setAttribute('aria-label', en ? 'Toggle color theme' : '切换深浅色主题');
        }
        var dynNavSpans = document.querySelectorAll('[data-i18n-zh][data-i18n-en]');
        for (var dn = 0; dn < dynNavSpans.length; dn++) {
          dynNavSpans[dn].textContent = en ? dynNavSpans[dn].getAttribute('data-i18n-en') : dynNavSpans[dn].getAttribute('data-i18n-zh');
        }
        var lGrp2 = document.getElementById('langSwitchGroup');
        if (lGrp2) lGrp2.setAttribute('aria-label', en ? 'Language switcher' : '语言切换');
        var zhBtn = document.getElementById('langZhBtn');
        var enBtn = document.getElementById('langEnBtn');
        if (zhBtn && enBtn) {
          zhBtn.classList.toggle('active', !en);
          enBtn.classList.toggle('active', en);
          zhBtn.setAttribute('aria-pressed', !en ? 'true' : 'false');
          enBtn.setAttribute('aria-pressed', en ? 'true' : 'false');
        }
        var dynNavSpans = document.querySelectorAll('[data-i18n-zh][data-i18n-en]');
        for (var dn = 0; dn < dynNavSpans.length; dn++) {
          dynNavSpans[dn].textContent = en ? dynNavSpans[dn].getAttribute('data-i18n-en') : dynNavSpans[dn].getAttribute('data-i18n-zh');
        }

        /* 1. Update Rich Prose Blocks */
        var richNodes = document.querySelectorAll('[data-i18n-rich]');
        for (var r = 0; r < richNodes.length; r++) {
          var rk = richNodes[r].getAttribute('data-i18n-rich');
          var rEntry = _richMapByKey[rk];
          if (rEntry) {
            richNodes[r].innerHTML = en ? rEntry.en : rEntry.zh;
          }
        }

        /* 2. Walk Pure Text Nodes */
        var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
        var tNode;
        while ((tNode = walker.nextNode())) {
          var pEl = tNode.parentElement;
          if (!pEl) continue;
          var tag = pEl.tagName;
          if (tag === 'SCRIPT' || tag === 'STYLE') continue;
          if (pEl.closest('#langSwitchGroup') || pEl.closest('[data-i18n-rich]') || pEl.closest('#pillarFocusNote')) continue;
          var raw = tNode.nodeValue || '';
          var trimmed = raw.replace(/\s+/g, ' ').trim();
          if (!trimmed) continue;
          var mapped = en ? _zhToEnText[trimmed] : _enToZhText[trimmed];
          if (mapped) {
            var leadMatch = raw.match(/^\s*/);
            var trailMatch = raw.match(/\s*$/);
            tNode.nodeValue = (leadMatch ? leadMatch[0] : '') + mapped + (trailMatch ? trailMatch[0] : '');
          }
        }

        /* 3. Update Attributes (placeholder, title, aria-label) */
        var allEls = document.querySelectorAll('[placeholder], [title], [aria-label]');
        var attrNames = ['placeholder', 'title', 'aria-label'];
        for (var a = 0; a < allEls.length; a++) {
          if (allEls[a].closest('#langSwitchGroup')) continue;
          for (var k = 0; k < attrNames.length; k++) {
            var an = attrNames[k];
            var av = allEls[a].getAttribute(an);
            if (!av) continue;
            var nextAv = en ? _zhToEnAttr[av] : _enToZhAttr[av];
            if (nextAv) allEls[a].setAttribute(an, nextAv);
          }
        }

        /* 4. Update Dynamic Panels & Redraw All 5 High-DPI Charts */
        var pNote = document.getElementById('pillarFocusNote');
        if (pNote) {
          var notesArr = en ? PILLAR_NOTES_EN : PILLAR_NOTES;
          pNote.innerHTML = '<div>' + notesArr[state.activePillar] + '</div>';
        }
        syncCh1HeaderText();
        syncCollapseButtonsText();
        renderPeerTable();
        renderChecklist();
        updateSimulatorUI();
        renderAllCharts();
        safeSetStorage(STORAGE_LANG_KEY, state.lang);

        if (!silent) {
          showToast(en ? 'Switched to English Research Edition' : '已切换至中文深度研报视图');
        }
      }

      function applyTheme(theme, silent) {
        state.theme = theme === 'dark' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', state.theme);
        var abIconEl = document.getElementById('appbarThemeIcon');
        if (abIconEl) abIconEl.innerHTML = (state.theme === 'dark') ? '<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zm18 0h2c.55 0 1-.45 1-1s-.45-1-1-1h-2c-.55 0-1 .45-1 1s.45 1 1 1zM11 2v2c0 .55.45 1 1 1s1-.45 1-1V2c0-.55-.45-1-1-1s-1 .45-1 1zm0 18v2c0 .55.45 1 1 1s1-.45 1-1v-2c0-.55-.45-1-1-1s-1 .45-1 1zM5.99 4.58a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0s.39-1.03 0-1.41L5.99 4.58zm12.37 12.37a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0a.996.996 0 0 0 0-1.41l-1.06-1.06zm1.06-10.96a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06zM7.05 18.36a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06z"/></svg>' : '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3a9 9 0 1 0 9 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 0 1-4.4 2.26 5.403 5.403 0 0 1-3.14-9.8c-.44-.06-.9-.1-1.36-.1z"/></svg>';
        var sDarkBtn = document.getElementById('sideThemeDarkBtn');
        var sLightBtn = document.getElementById('sideThemeLightBtn');
        if (sDarkBtn && sLightBtn) {
          void 0;
          void 0;
        }
        safeSetStorage(STORAGE_THEME_KEY, state.theme);
        renderAllCharts();
        if (!silent) {
          showToast(state.theme === 'dark' ? (isEn() ? 'Switched to Dark Mode' : '已切换至 MUI 深海黑曜石护眼模式') : (isEn() ? 'Switched to Light Mode' : '已切换至 MUI 浅色明亮阅读模式'));
        }
      }

      function toggleSidebar() {
        if (window.innerWidth <= 1120) {
          document.body.classList.toggle('drawer-open');
        } else {
          document.body.classList.toggle('sidebar-collapsed');
          setTimeout(renderAllCharts, 60);
        }
      }

      function closeMobileDrawer() {
        document.body.classList.remove('drawer-open');
      }

      /* ======================================================================
         3. Peer Comparison Table Rendering & Filtering
         ====================================================================== */
      function escapeHtml(str) {
        return String(str)
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;');
      }

      function highlightMatch(text, query) {
        var safe = escapeHtml(text);
        if (!query) return safe;
        var escapedQ = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        var re = new RegExp('(' + escapedQ + ')', 'gi');
        return safe.replace(re, '<mark class="hl">$1</mark>');
      }

      function renderPeerTable() {
        var tbody = document.getElementById('peerTableBody');
        var badge = document.getElementById('peerCountBadge');
        if (!tbody) return;

        var activeRows = isEn() ? PEER_ROWS_EN : PEER_ROWS;
        var q = state.peerQuery.trim().toLowerCase();
        var filtered = activeRows.filter(function (row, idx) {
          var catOk = state.peerFilter === 'all' || row.category === state.peerFilter;
          if (!catOk) return false;
          if (!q) return true;
          var zhR = PEER_ROWS[idx] || row;
          var enR = PEER_ROWS_EN[idx] || row;
          var hay = (zhR.company + ' ' + zhR.leader + ' ' + zhR.positioning + ' ' + zhR.culture + ' ' + zhR.verdict + ' ' + enR.company + ' ' + enR.leader + ' ' + enR.positioning + ' ' + enR.culture + ' ' + enR.verdict).toLowerCase();
          return hay.indexOf(q) !== -1;
        });

        if (badge) {
          badge.textContent = isEn()
            ? ('Showing ' + filtered.length + ' / ' + activeRows.length + ' Peers')
            : ('显示 ' + filtered.length + ' / ' + activeRows.length + ' 家标杆企业');
        }

        if (!filtered.length) {
          tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:28px;">' + (isEn() ? 'No matching benchmark companies found. Try another keyword or reset filters.' : '未找到匹配的标杆企业记录，请尝试其他关键词或重置筛选条件。') + '</td></tr>';
          return;
        }

        var rawQ = state.peerQuery.trim();
        tbody.innerHTML = filtered.map(function (r) {
          return '<tr class="' + (r.benchmark ? 'benchmark-row' : '') + '">' +
            '<td><strong style="color:var(--text-primary);display:block;">' + highlightMatch(r.company, rawQ) + '</strong><span style="font-size:0.76rem;color:var(--text-muted);">' + highlightMatch(r.leader, rawQ) + '</span></td>' +
            '<td>' + highlightMatch(r.positioning, rawQ) + '</td>' +
            '<td>' + highlightMatch(r.culture, rawQ) + '</td>' +
            '<td class="mono" style="font-size:0.79rem;">' + highlightMatch(r.headcount, rawQ) + '</td>' +
            '<td class="mono" style="font-size:0.79rem;color:var(--mui-primary-lighter);font-weight:700;">' + highlightMatch(r.margins, rawQ) + '</td>' +
            '<td>' + highlightMatch(r.verdict, rawQ) + ' <a class="cite-link" href="' + r.sourceUrl + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(r.sourceLabel) + ' ↗</a></td>' +
            '</tr>';
        }).join('');
      }

      /* ======================================================================
         4. Multi-Era Cultural Compounding Simulator
         ====================================================================== */
      function formatCurrency(val) {
        if (val >= 10000000) {
          return '$' + (val / 1000000).toFixed(2) + 'M';
        }
        return '$' + Math.round(val).toLocaleString('en-US');
      }

      function updateSimulatorUI() {
        var p = state.sim.principal;
        var yrs = state.sim.years;
        var cagr = state.sim.priceCagr;
        var dripRate = state.sim.drip ? 2.2 : 0.0;
        var totalRate = (cagr + dripRate) / 100;

        var endingValue = p * Math.pow(1 + totalRate, yrs);
        var moic = endingValue / p;
        var netGain = endingValue - p;
        var midYear = Math.max(1, Math.floor(yrs / 2));
        var midValue = p * Math.pow(1 + totalRate, midYear);

        document.getElementById('simPrincipalLabel').textContent = '$' + Math.round(p).toLocaleString('en-US');
        document.getElementById('simYearsLabel').textContent = yrs + (isEn() ? ' yrs' : ' 年');
        document.getElementById('simCagrLabel').textContent = cagr.toFixed(1) + '%';

        document.getElementById('simEndingVal').textContent = formatCurrency(endingValue);
        document.getElementById('simMoicVal').textContent = (moic >= 100 ? moic.toFixed(1) : moic.toFixed(2)) + 'x · ' + (totalRate * 100).toFixed(2) + '%';
        document.getElementById('simNetGainVal').textContent = formatCurrency(netGain);
        document.getElementById('simMidLabel').textContent = isEn() ? ('Year ' + midYear + ' Midpoint Value') : ('第 ' + midYear + ' 年中期资产节点');
        document.getElementById('simMidVal').textContent = formatCurrency(midValue);

        var presetBtns = document.querySelectorAll('[data-preset]');
        for (var i = 0; i < presetBtns.length; i++) {
          presetBtns[i].classList.toggle('active', presetBtns[i].getAttribute('data-preset') === state.sim.preset);
        }

        drawSimChart();
      }

      /* ======================================================================
         5. Interactive Checklist
         ====================================================================== */
      function renderChecklist() {
        var container = document.getElementById('checklistContainer');
        var chip = document.getElementById('checklistScoreChip');
        var bar = document.getElementById('checklistProgressBar');
        if (!container) return;

        var itemsList = isEn() ? CHECKLIST_ITEMS_EN : CHECKLIST_ITEMS;
        var doneCount = state.checks.filter(Boolean).length;
        var pct = Math.round((doneCount / itemsList.length) * 100);
        if (chip) {
          chip.textContent = isEn()
            ? ('Verified ' + doneCount + ' / ' + itemsList.length + ' (' + pct + '%)')
            : ('已核查 ' + doneCount + ' / ' + itemsList.length + ' 项 (' + pct + '%)');
        }
        if (bar) {
          bar.style.width = pct + '%';
        }

        container.innerHTML = itemsList.map(function (item, idx) {
          var isChecked = !!state.checks[idx];
          return '<label class="check-card ' + (isChecked ? 'checked' : '') + '" data-check-idx="' + idx + '">' +
            '<input type="checkbox" data-check-input="' + idx + '" ' + (isChecked ? 'checked' : '') + ' />' +
            '<div style="flex:1;">' +
              '<div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:6px;margin-bottom:4px;">' +
                '<span class="check-title">' + escapeHtml(item.title) + '</span>' +
                '<span class="mui-chip mono">' + escapeHtml(item.tag) + '</span>' +
              '</div>' +
              '<p class="check-desc">' + escapeHtml(item.desc) + '</p>' +
            '</div>' +
          '</label>';
        }).join('');
      }

      /* ======================================================================
         6. Built-In Zero-Dependency MUI X Charts-Style High-DPI Engine
         ====================================================================== */
      state.ch1Series = { s1: true, s2: true };
      state.epsSeries = { eps: true, oci: true };

      var hitRegions = {
        chartCh1: [],
        chartRadar: [],
        chartBars: [],
        chartEps: [],
        chartSim: []
      };

      var hoverState = {
        chartCh1: -1,
        chartRadar: -1,
        chartBars: -1,
        chartEps: -1,
        chartSim: -1
      };

      function getPalette() {
        var cs = getComputedStyle(document.documentElement);
        var isDark = state.theme === 'dark';
        return {
          isDark: isDark,
          grid: cs.getPropertyValue('--chart-grid').trim() || (isDark ? 'rgba(148,163,184,0.13)' : 'rgba(100,116,139,0.16)'),
          tick: cs.getPropertyValue('--chart-tick').trim() || '#94A3B8',
          text: cs.getPropertyValue('--text-primary').trim() || '#F3F6F9',
          sub: cs.getPropertyValue('--text-secondary').trim() || '#B2BAC2',
          pillBg: isDark ? 'rgba(9, 13, 22, 0.88)' : 'rgba(255, 255, 255, 0.94)',
          pillBorder: isDark ? 'rgba(51, 153, 255, 0.28)' : 'rgba(0, 115, 230, 0.24)',
          trackBg: isDark ? 'rgba(148, 163, 184, 0.10)' : 'rgba(15, 25, 36, 0.06)',
          hoverBand: isDark ? 'rgba(51, 153, 255, 0.07)' : 'rgba(0, 115, 230, 0.05)',
          c1: cs.getPropertyValue('--chart-c1').trim() || '#3399FF',
          c2: cs.getPropertyValue('--chart-c2').trim() || '#22C55E',
          c3: cs.getPropertyValue('--chart-c3').trim() || '#FFB74D',
          c4: cs.getPropertyValue('--chart-c4').trim() || '#A78BFA'
        };
      }

      function prepareCanvas(id) {
        var canvas = document.getElementById(id);
        if (!canvas || !canvas.parentElement) return null;
        var stage = canvas.parentElement;
        var rect = stage.getBoundingClientRect();
        var w = Math.max(240, Math.floor(rect.width));
        var h = Math.max(170, Math.floor(rect.height));
        var dpr = Math.min(window.devicePixelRatio || 1, 2.5);
        canvas.style.width = w + 'px';
        canvas.style.height = h + 'px';
        var targetW = Math.floor(w * dpr);
        var targetH = Math.floor(h * dpr);
        if (canvas.width !== targetW) canvas.width = targetW;
        if (canvas.height !== targetH) canvas.height = targetH;
        var ctx = canvas.getContext('2d');
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, w, h);
        return { ctx: ctx, w: w, h: h, canvas: canvas };
      }

      function roundRectPath(ctx, x, y, w, h, r) {
        if (w <= 0 || h <= 0) return;
        var radius = Math.min(r, w / 2, h / 2);
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + w - radius, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
        ctx.lineTo(x + w, y + h - radius);
        ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
        ctx.lineTo(x + radius, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
      }

      function topRoundedBar(ctx, x, y, w, h, r) {
        if (w <= 0 || h <= 0) return;
        var rad = Math.min(r, w / 2, h);
        ctx.beginPath();
        ctx.moveTo(x, y + h);
        ctx.lineTo(x, y + rad);
        ctx.quadraticCurveTo(x, y, x + rad, y);
        ctx.lineTo(x + w - rad, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
        ctx.lineTo(x + w, y + h);
        ctx.closePath();
      }

      function drawValueBadge(ctx, text, cx, cy, fgColor, pal) {
        ctx.save();
        ctx.font = '700 10.5px "IBM Plex Mono", system-ui, sans-serif';
        var tw = ctx.measureText(text).width + 9;
        var th = 17;
        var bx = cx - tw / 2;
        var by = cy - th / 2;
        ctx.fillStyle = pal.pillBg;
        roundRectPath(ctx, bx, by, tw, th, 5);
        ctx.fill();
        ctx.strokeStyle = pal.pillBorder;
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.fillStyle = fgColor;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(text, cx, cy + 0.5);
        ctx.restore();
      }

      function drawSmoothLine(ctx, pts) {
        if (!pts.length) return;
        ctx.beginPath();
        ctx.moveTo(pts[0].x, pts[0].y);
        for (var i = 0; i < pts.length - 1; i++) {
          var xc = (pts[i].x + pts[i + 1].x) / 2;
          ctx.bezierCurveTo(xc, pts[i].y, xc, pts[i + 1].y, pts[i + 1].x, pts[i + 1].y);
        }
      }

      /* Chart 1: View A (5 Ecosystem Categories FY25 vs FY26) & View B (Hiring Restraint vs Rev/Emp) */
      function drawCh1Chart() {
        var env = prepareCanvas('chartCh1');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h;
        var pal = getPalette();
        hitRegions.chartCh1 = [];

        var metaEl = document.getElementById('ch1AxisMeta');
        var leg1 = document.getElementById('ch1Leg1');
        var leg2 = document.getElementById('ch1Leg2');

        if (state.ch1View === 'viewA') {
          if (metaEl) {
            metaEl.innerHTML = isEn()
              ? '<span style="color:var(--chart-c1);">■ Blue: FY2025 Segment Net Sales ($B)</span><span style="color:var(--chart-c2);">■ Green: FY2026 Segment Net Sales ($B · Total $478.83B)</span>'
              : '<span style="color:var(--chart-c1);">■ 蓝色：FY2025 分业务净营收 ($B)</span><span style="color:var(--chart-c2);">■ 绿色：FY2026 分业务净营收 ($B · 总计 $478.83B)</span>';
          }
          if (leg1) leg1.textContent = isEn() ? 'FY2025 Segment Net Sales ($B · Total $416.16B)' : 'FY2025 分业务净营收 ($B · 合计 $416.16B)';
          if (leg2) leg2.textContent = isEn() ? 'FY2026 Segment Net Sales ($B · Total $478.83B)' : 'FY2026 分业务净营收 ($B · 合计 $478.83B)';

          var padA = { top: 30, right: 18, bottom: 44, left: 50 };
          var pwA = w - padA.left - padA.right;
          var phA = h - padA.top - padA.bottom;
          var labelsA = ['iPhone', 'Services', 'Mac', 'Wearables', 'iPad'];
          var subA = ['+21.2% YoY', '+13.0% YoY', '+12.5% YoY', '-0.3% YoY', '-0.3% YoY'];
          var fy25 = [209.59, 109.16, 33.71, 35.69, 28.02];
          var fy26 = [254.10, 123.30, 37.93, 35.58, 27.93];
          var maxY = 280.0;

          for (var g = 0; g <= 4; g++) {
            var val = (maxY / 4) * g;
            var gy = padA.top + phA - (g / 4) * phA;
            ctx.strokeStyle = pal.grid;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(padA.left, gy);
            ctx.lineTo(padA.left + pwA, gy);
            ctx.stroke();

            ctx.fillStyle = pal.tick;
            ctx.font = '11px "IBM Plex Mono", sans-serif';
            ctx.textAlign = 'right';
            ctx.textBaseline = 'middle';
            ctx.fillText('$' + val.toFixed(0) + 'B', padA.left - 8, gy);
          }

          var stepA = pwA / labelsA.length;
          var barW = Math.min(38, Math.max(14, stepA * 0.27));

          for (var i = 0; i < labelsA.length; i++) {
            var cx = padA.left + stepA * (i + 0.5);

            if (hoverState.chartCh1 === i) {
              ctx.fillStyle = pal.hoverBand;
              roundRectPath(ctx, padA.left + stepA * i + 4, padA.top, stepA - 8, phA, 8);
              ctx.fill();
            }

            var y1 = padA.top + phA - (fy25[i] / maxY) * phA;
            var y2 = padA.top + phA - (fy26[i] / maxY) * phA;

            if (state.ch1Series.s1) {
              var h1 = (fy25[i] / maxY) * phA;
              var x1 = state.ch1Series.s2 ? (cx - barW - 3) : (cx - barW / 2);
              var grad1 = ctx.createLinearGradient(0, y1, 0, padA.top + phA);
              grad1.addColorStop(0, '#3399FF');
              grad1.addColorStop(1, '#0066CC');
              ctx.fillStyle = grad1;
              topRoundedBar(ctx, x1, y1, barW, h1, 5);
              ctx.fill();
              if (!state.ch1Series.s2 || w >= 680) {
                var b1Y = (state.ch1Series.s2 && Math.abs(y2 - y1) < 18) ? (Math.max(y1, y2) - 11) : (y1 - 12);
                if (!state.ch1Series.s2 || Math.abs(y2 - y1) >= 18) {
                  drawValueBadge(ctx, '$' + fy25[i].toFixed(1) + 'B', x1 + barW / 2, b1Y, pal.c1, pal);
                }
              }
            }

            if (state.ch1Series.s2) {
              var h2 = (fy26[i] / maxY) * phA;
              var x2 = state.ch1Series.s1 ? (cx + 3) : (cx - barW / 2);
              var grad2 = ctx.createLinearGradient(0, y2, 0, padA.top + phA);
              grad2.addColorStop(0, '#34D399');
              grad2.addColorStop(1, '#16A34A');
              ctx.fillStyle = grad2;
              topRoundedBar(ctx, x2, y2, barW, h2, 5);
              ctx.fill();
              var b2X = (state.ch1Series.s1 && (w < 680 || Math.abs(y2 - y1) < 18)) ? cx : (x2 + barW / 2);
              drawValueBadge(ctx, '$' + fy26[i].toFixed(1) + 'B', b2X, Math.min(y1, y2) - 12, pal.c2, pal);
            }

            ctx.fillStyle = pal.text;
            ctx.font = '700 ' + (w < 440 ? '11px' : '12px') + ' system-ui, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'alphabetic';
            ctx.fillText(labelsA[i], cx, padA.top + phA + 19);
            ctx.fillStyle = subA[i].indexOf('+') === 0 ? pal.c2 : pal.tick;
            ctx.font = '600 10px "IBM Plex Mono", sans-serif';
            ctx.fillText(subA[i], cx, padA.top + phA + 34);

            hitRegions.chartCh1.push({
              idx: i,
              x: padA.left + stepA * i, y: padA.top, w: stepA, h: phA + 36,
              html: isEn()
                ? ('<strong>' + labelsA[i] + ' Net Sales Comparison (SEC 10-K)</strong><br/>' +
                   '• FY2025 Net Sales: <strong>$' + fy25[i].toFixed(2) + 'B</strong><br/>' +
                   '• FY2026 Net Sales: <strong>$' + fy26[i].toFixed(2) + 'B</strong> (' + subA[i] + ')<br/>' +
                   '• Share of FY26 Total Sales: <strong>' + ((fy26[i] / 478.834) * 100).toFixed(1) + '%</strong>')
                : ('<strong>' + labelsA[i] + ' 生态净营收对比 (SEC 10-K)</strong><br/>' +
                   '• FY2025 净营收：<strong>$' + fy25[i].toFixed(2) + 'B</strong><br/>' +
                   '• FY2026 净营收：<strong>$' + fy26[i].toFixed(2) + 'B</strong> (' + subA[i] + ')<br/>' +
                   '• 占 FY26 全集团营收比重：<strong>' + ((fy26[i] / 478.834) * 100).toFixed(1) + '%</strong>')
            });
          }
        } else {
          if (metaEl) {
            metaEl.innerHTML = isEn()
              ? '<span style="color:var(--chart-c1);">■ Left Axis: Full-Time Equivalents (k · Disciplined)</span><span style="color:var(--chart-c2);">● Right Axis: Annual Revenue / Employee ($M)</span>'
              : '<span style="color:var(--chart-c1);">■ 左轴：全职员工人数 (千人 · FY22–FY26 高度克制)</span><span style="color:var(--chart-c2);">● 右轴：人均年创收 ($M/人)</span>';
          }
          if (leg1) leg1.textContent = isEn() ? 'Full-Time Equivalents (Left Axis · k)' : '全职员工人数 Full-Time Equivalents (左轴 · 千人)';
          if (leg2) leg2.textContent = isEn() ? 'Annual Revenue per Employee (Right Axis · $M)' : '人均年创收 Revenue per Employee (右轴 · $M)';

          var padB = { top: 28, right: 52, bottom: 38, left: 48 };
          var pwB = w - padB.left - padB.right;
          var phB = h - padB.top - padB.bottom;
          var labelsB = ['FY21', 'FY22', 'FY23', 'FY24', 'FY25', 'FY26'];
          var fullLabelsB = isEn() ? ['FY2021', 'FY2022', 'FY2023 (Zero Mass Layoffs)', 'FY2024', 'FY2025', 'FY2026 (Record Productivity)'] : ['FY2021', 'FY2022', 'FY2023 (零大规模裁员)', 'FY2024', 'FY2025', 'FY2026 (创纪录人效)'];
          var empK = [154.0, 164.0, 161.0, 164.0, 166.0, 167.0];
          var revM = [2.38, 2.40, 2.38, 2.38, 2.51, 2.87];
          var maxEmp = 320.0;
          var minRev = 1.60, maxRev = 3.10;

          for (var j = 0; j <= 4; j++) {
            var r = j / 4;
            var yGrid = padB.top + phB - r * phB;
            ctx.strokeStyle = pal.grid;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(padB.left, yGrid);
            ctx.lineTo(padB.left + pwB, yGrid);
            ctx.stroke();

            ctx.font = '11px "IBM Plex Mono", sans-serif';
            ctx.textBaseline = 'middle';
            ctx.fillStyle = pal.tick;
            ctx.textAlign = 'right';
            ctx.fillText((maxEmp * r).toFixed(0) + 'k', padB.left - 7, yGrid);

            ctx.fillStyle = pal.c2;
            ctx.textAlign = 'left';
            ctx.fillText('$' + (minRev + r * (maxRev - minRev)).toFixed(2) + 'M', padB.left + pwB + 7, yGrid);
          }

          var stepB = pwB / labelsB.length;
          var bWidth = Math.min(38, Math.max(18, stepB * 0.42));
          var pts = [];

          for (var k = 0; k < labelsB.length; k++) {
            var centerX = padB.left + stepB * (k + 0.5);
            if (hoverState.chartCh1 === k) {
              ctx.fillStyle = pal.hoverBand;
              roundRectPath(ctx, padB.left + stepB * k + 3, padB.top, stepB - 6, phB, 6);
              ctx.fill();
            }

            if (state.ch1Series.s1) {
              var bH = (empK[k] / maxEmp) * phB;
              var bX = centerX - bWidth / 2;
              var bY = padB.top + phB - bH;
              var bGrad = ctx.createLinearGradient(0, bY, 0, padB.top + phB);
              if (pal.isDark) {
                bGrad.addColorStop(0, 'rgba(51, 153, 255, 0.72)');
                bGrad.addColorStop(1, 'rgba(0, 115, 230, 0.26)');
              } else {
                bGrad.addColorStop(0, '#1985F1');
                bGrad.addColorStop(1, '#0066CC');
              }
              ctx.fillStyle = bGrad;
              topRoundedBar(ctx, bX, bY, bWidth, bH, 5);
              ctx.fill();
              ctx.strokeStyle = pal.c1;
              ctx.lineWidth = 1.2;
              ctx.stroke();

              if (bH > 22) {
                ctx.fillStyle = '#FFFFFF';
                ctx.font = '700 9.5px "IBM Plex Mono", sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'alphabetic';
                ctx.fillText(empK[k].toFixed(0) + 'k', centerX, bY + 15);
              }
            }

            var lY = padB.top + phB - ((revM[k] - minRev) / (maxRev - minRev)) * phB;
            pts.push({ x: centerX, y: lY, rev: revM[k] });

            ctx.fillStyle = k === 5 ? pal.text : pal.tick;
            ctx.font = (k === 5 ? '700 ' : '600 ') + '11.5px system-ui, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'alphabetic';
            ctx.fillText(labelsB[k], centerX, padB.top + phB + 22);

            hitRegions.chartCh1.push({
              idx: k,
              x: padB.left + stepB * k, y: padB.top, w: stepB, h: phB + 28,
              html: isEn()
                ? ('<strong>' + fullLabelsB[k] + ' (Form 10-K)</strong><br/>' +
                   '• Full-Time Equivalents: <strong>' + Math.round(empK[k] * 1000).toLocaleString() + ' FTEs</strong><br/>' +
                   '• Revenue / Employee: <strong>$' + revM[k].toFixed(2) + 'M / FTE</strong>')
                : ('<strong>' + fullLabelsB[k] + ' (Form 10-K)</strong><br/>' +
                   '• 全职员工总数：<strong>' + Math.round(empK[k] * 1000).toLocaleString() + ' 人</strong><br/>' +
                   '• 人均年创收：<strong>$' + revM[k].toFixed(2) + 'M / 人</strong>')
            });
          }

          if (state.ch1Series.s2) {
            ctx.save();
            drawSmoothLine(ctx, pts);
            ctx.strokeStyle = pal.c2;
            ctx.lineWidth = 2.8;
            ctx.stroke();
            ctx.restore();

            for (var n = 0; n < pts.length; n++) {
              ctx.fillStyle = pal.pillBg;
              ctx.beginPath();
              ctx.arc(pts[n].x, pts[n].y, 6, 0, Math.PI * 2);
              ctx.fill();
              ctx.fillStyle = pal.c2;
              ctx.beginPath();
              ctx.arc(pts[n].x, pts[n].y, 4.2, 0, Math.PI * 2);
              ctx.fill();

              if (w >= 500 || n % 2 === 1) {
                drawValueBadge(ctx, '$' + pts[n].rev.toFixed(2) + 'M', pts[n].x, pts[n].y - 16, pal.c2, pal);
              }
            }
          }
        }
      }

      /* Chart 2: 5-Dimension Corporate Culture Radar Chart */
      function drawRadarChart() {
        var env = prepareCanvas('chartRadar');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h;
        var pal = getPalette();
        hitRegions.chartRadar = [];

        var axes = isEn() ? ['Stack Synergy', 'Expert Depth', 'Design Focus', 'Margin & FCF', 'M-Form Autonomy'] : [
          '跨部门全栈协同',
          '专家技术话语权',
          'SKU极简聚焦度',
          '供应链与保密纪律',
          '生态高毛利转化'
        ];
        var pillarAxisMap = [1, 0, 2, 3];
        var highlightedAxis = hoverState.chartRadar >= 0 ? hoverState.chartRadar : pillarAxisMap[state.activePillar];

        var series = [
          { key: 'aapl', name: '苹果 (Apple)', color: pal.c1, fill: 'rgba(51, 153, 255, 0.24)', vals: [9.8, 9.7, 9.6, 9.5, 9.4] },
          { key: 'nvda', name: '英伟达 (NVIDIA)', color: pal.c2, fill: 'rgba(34, 197, 94, 0.16)', vals: [9.4, 9.8, 8.9, 8.8, 9.7] },
          { key: 'mform', name: '多事业部科技巨头', color: pal.c3, fill: 'rgba(255, 183, 77, 0.14)', vals: [5.8, 6.4, 5.2, 7.2, 6.8] }
        ];

        var cx = w / 2;
        var cy = h / 2 + 8;
        var sidePad = w < 420 ? 88 : 108;
        var radius = Math.max(62, Math.min((w - sidePad * 2) / 2, h * 0.35));
        var total = axes.length;

        for (var ring = 2; ring <= 10; ring += 2) {
          var r = (ring / 10) * radius;
          ctx.strokeStyle = pal.grid;
          ctx.lineWidth = ring === 10 ? 1.3 : 1;
          ctx.beginPath();
          for (var i = 0; i < total; i++) {
            var ang = -Math.PI / 2 + (i * 2 * Math.PI) / total;
            var px = cx + Math.cos(ang) * r;
            var py = cy + Math.sin(ang) * r;
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
          }
          ctx.closePath();
          ctx.stroke();

          ctx.fillStyle = pal.tick;
          ctx.font = '600 9.5px "IBM Plex Mono", sans-serif';
          ctx.textAlign = 'left';
          ctx.textBaseline = 'middle';
          ctx.fillText(String(ring), cx + 4, cy - r);
        }

        for (var a = 0; a < total; a++) {
          var angle = -Math.PI / 2 + (a * 2 * Math.PI) / total;
          var ax = cx + Math.cos(angle) * radius;
          var ay = cy + Math.sin(angle) * radius;
          var isHi = a === highlightedAxis;

          ctx.strokeStyle = isHi ? pal.c1 : pal.grid;
          ctx.lineWidth = isHi ? 1.8 : 1;
          ctx.beginPath();
          ctx.moveTo(cx, cy);
          ctx.lineTo(ax, ay);
          ctx.stroke();

          var lx = cx + Math.cos(angle) * (radius + 14);
          var ly = cy + Math.sin(angle) * (radius + 15);
          ctx.fillStyle = isHi ? pal.c1 : pal.text;
          ctx.font = (isHi ? '800 ' : '600 ') + (w < 420 ? '10.5px' : '11.5px') + ' system-ui, sans-serif';
          ctx.textBaseline = 'middle';
          if (Math.abs(Math.cos(angle)) < 0.2) ctx.textAlign = 'center';
          else if (Math.cos(angle) > 0) ctx.textAlign = 'left';
          else ctx.textAlign = 'right';
          ctx.fillText(axes[a], lx, ly);

          hitRegions.chartRadar.push({
            idx: a,
            x: Math.min(ax, lx) - 36, y: Math.min(ay, ly) - 22, w: 72 + Math.abs(lx - ax), h: 44,
            html: isEn()
              ? ('<strong>' + axes[a] + ' (10-Pt Scale)</strong><br/>' +
                 '• Apple (AAPL): <strong>' + series[0].vals[a].toFixed(1) + ' / 10</strong><br/>' +
                 '• NVIDIA (NVDA): <strong>' + series[1].vals[a].toFixed(1) + ' / 10</strong><br/>' +
                 '• M-Form Tech Peers: <strong>' + series[2].vals[a].toFixed(1) + ' / 10</strong>')
              : ('<strong>' + axes[a] + ' (10分制标杆评估)</strong><br/>' +
                 '• 苹果 (AAPL)：<strong>' + series[0].vals[a].toFixed(1) + ' 分</strong><br/>' +
                 '• 英伟达 (NVDA)：<strong>' + series[1].vals[a].toFixed(1) + ' 分</strong><br/>' +
                 '• 多事业部科技巨头：<strong>' + series[2].vals[a].toFixed(1) + ' 分</strong>')
          });
        }

        for (var s = 0; s < series.length; s++) {
          var item = series[s];
          if (!state.radarSeries[item.key]) continue;
          ctx.beginPath();
          for (var idx = 0; idx < total; idx++) {
            var theta = -Math.PI / 2 + (idx * 2 * Math.PI) / total;
            var dist = (item.vals[idx] / 10) * radius;
            var vx = cx + Math.cos(theta) * dist;
            var vy = cy + Math.sin(theta) * dist;
            if (idx === 0) ctx.moveTo(vx, vy);
            else ctx.lineTo(vx, vy);
          }
          ctx.closePath();
          ctx.fillStyle = item.fill;
          ctx.fill();
          ctx.strokeStyle = item.color;
          ctx.lineWidth = 2.4;
          ctx.stroke();

          for (var pIdx = 0; pIdx < total; pIdx++) {
            var pTheta = -Math.PI / 2 + (pIdx * 2 * Math.PI) / total;
            var pDist = (item.vals[pIdx] / 10) * radius;
            var pX = cx + Math.cos(pTheta) * pDist;
            var pY = cy + Math.sin(pTheta) * pDist;
            ctx.fillStyle = pal.pillBg;
            ctx.beginPath();
            ctx.arc(pX, pY, 5.2, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = item.color;
            ctx.beginPath();
            ctx.arc(pX, pY, 3.6, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }

      /* Chart 3: Two-Deck Full-Width Horizontal Progress/Bar Chart */
      function drawHorizontalBars() {
        var env = prepareCanvas('chartBars');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h;
        var pal = getPalette();
        hitRegions.chartBars = [];

        var items = isEn() ? [
          { label: 'Services Segment Full-Year Gross Margin (FY26)', val: 76.2, cStart: '#34D399', cEnd: '#16A34A', sub: '$93,943M / $123,301M', note: 'Powered by >2.5B active devices; generates 40.2% of total gross profit' },
          { label: 'Apple Consolidated Full-Year Gross Margin (FY26)', val: 48.8, cStart: '#3399FF', cEnd: '#0073E6', sub: '$233,602M / $478,834M', note: 'All-time high full-year margin driven by custom Apple Silicon & Services mix' },
          { label: 'Products Segment Full-Year Gross Margin (FY26)', val: 39.3, cStart: '#60A5FA', cEnd: '#2563EB', sub: '$139,659M / $355,533M (+2.5pp)', note: 'Expanded +2.5pp YoY on iPhone Duo / 18 Pro mix and silicon integration' },
          { label: 'Apple Consolidated Operating Margin (FY26)', val: 33.0, cStart: '#38BDF8', cEnd: '#0284C7', sub: 'Op Income $158,063M (+18.8%)', note: 'SG&A held to just 6.22% of sales thanks to zero divisional bloat' },
          { label: 'Enterprise Engineering & R&D Headcount Share', val: 41.0, cStart: '#A78BFA', cEnd: '#7C3AED', sub: '~68,000+ Engineers', note: 'Foundation of Experts Leading Experts—2.7x Business & Admin share (15%)' },
          { label: 'Business & General Management Headcount Share', val: 15.0, cStart: '#FBBF24', cEnd: '#D97706', sub: 'Lean Non-Bureaucratic Layers', note: 'Eliminates redundant divisional middle-management generalists' }
        ] : [
          { label: 'Services 服务生态全年毛利率 (FY26)', val: 76.2, cStart: '#34D399', cEnd: '#16A34A', sub: '$93,943M / $123,301M', note: '25亿+活跃设备高粘性闭环驱动，贡献全公司 40.2% 总毛利' },
          { label: 'Apple 全集团全年综合毛利率 (FY26)', val: 48.8, cStart: '#3399FF', cEnd: '#0073E6', sub: '$233,602M / $478,834M', note: '自研 Apple Silicon 降本增效与服务占比共振，创公司史最高全年毛利率' },
          { label: 'Products 硬件产品全年毛利率 (FY26)', val: 39.3, cStart: '#60A5FA', cEnd: '#2563EB', sub: '$139,659M / $355,533M (+2.5pp)', note: 'iPhone Duo / 18 Pro 与自研芯片协同拉动硬件毛利率扩张' },
          { label: 'Apple 全集团全年营业利润率 Operating Margin (FY26)', val: 33.0, cStart: '#38BDF8', cEnd: '#0284C7', sub: '营业利润 $158,063M (+18.8%)', note: 'SG&A 费率压缩至仅 6.22%，凸显无事业部冗余层级的管理高效率' },
          { label: '全公司工程与研发技术人才占比 Engineering Share', val: 41.0, cStart: '#A78BFA', cEnd: '#7C3AED', sub: '~68,000+ 名研发工程师', note: '专家领导专家文化基石：工程技术岗占比近乎商业管理岗 (15%) 的 2.7 倍' },
          { label: '全公司商业与综合管理岗位占比 Business & Admin', val: 15.0, cStart: '#FBBF24', cEnd: '#D97706', sub: '极简非行政化组织层级', note: '杜绝冗余事业部中层通才，确保一线专业团队贴近产品决策' }
        ];

        var pad = { top: 10, right: 18, bottom: 26, left: 18 };
        var pw = w - pad.left - pad.right;
        var ph = h - pad.top - pad.bottom;
        var maxX = 85;

        for (var g = 0; g <= 4; g++) {
          var xVal = Math.round((maxX / 4) * g);
          var gx = pad.left + (xVal / maxX) * pw;
          ctx.strokeStyle = pal.grid;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(gx, pad.top);
          ctx.lineTo(gx, pad.top + ph);
          ctx.stroke();

          ctx.fillStyle = pal.tick;
          ctx.font = '10.5px "IBM Plex Mono", sans-serif';
          ctx.textAlign = g === 0 ? 'left' : (g === 4 ? 'right' : 'center');
          ctx.textBaseline = 'alphabetic';
          ctx.fillText(xVal + '%', gx, pad.top + ph + 18);
        }

        var rowH = ph / items.length;

        /* 45% High-Margin Benchmark Dashed Line spanning top 4 profitability rows */
        var targetX = pad.left + (45 / maxX) * pw;
        ctx.save();
        ctx.setLineDash([4, 4]);
        ctx.strokeStyle = pal.c3;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(targetX, pad.top + 4);
        ctx.lineTo(targetX, pad.top + rowH * 4 - 4);
        ctx.stroke();
        ctx.restore();

        for (var i = 0; i < items.length; i++) {
          var rowTop = pad.top + rowH * i;
          if (hoverState.chartBars === i) {
            ctx.fillStyle = pal.hoverBand;
            roundRectPath(ctx, pad.left - 6, rowTop + 2, pw + 12, rowH - 4, 8);
            ctx.fill();
          }

          var labelY = rowTop + Math.max(15, rowH * 0.34);
          var barY = rowTop + Math.max(22, rowH * 0.50);
          var barH = Math.min(15, Math.max(11, rowH * 0.26));
          var bw = Math.max(8, (items[i].val / maxX) * pw);

          ctx.fillStyle = pal.text;
          ctx.font = '600 ' + (w < 460 ? '11px' : '12px') + ' system-ui, sans-serif';
          ctx.textAlign = 'left';
          ctx.textBaseline = 'alphabetic';
          ctx.fillText(items[i].label, pad.left, labelY);

          var valStr = items[i].val.toFixed(1) + '%';
          ctx.font = '800 12.5px "IBM Plex Mono", sans-serif';
          ctx.fillStyle = pal.isDark ? items[i].cStart : items[i].cEnd;
          ctx.textAlign = 'right';
          ctx.fillText(valStr, pad.left + pw, labelY);

          if (w >= 560) {
            var valW = ctx.measureText(valStr).width + 10;
            ctx.font = '500 11px "IBM Plex Mono", system-ui, sans-serif';
            ctx.fillStyle = pal.tick;
            ctx.fillText(items[i].sub, pad.left + pw - valW, labelY);
          }

          ctx.fillStyle = pal.trackBg;
          roundRectPath(ctx, pad.left, barY, pw, barH, barH / 2);
          ctx.fill();

          var barGrad = ctx.createLinearGradient(pad.left, 0, pad.left + bw, 0);
          barGrad.addColorStop(0, items[i].cStart);
          barGrad.addColorStop(1, items[i].cEnd);
          ctx.fillStyle = barGrad;
          roundRectPath(ctx, pad.left, barY, bw, barH, barH / 2);
          ctx.fill();

          hitRegions.chartBars.push({
            idx: i,
            x: pad.left, y: rowTop, w: pw, h: rowH,
            html: isEn()
              ? ('<strong>' + items[i].label + ': ' + items[i].val.toFixed(1) + '%</strong><br/>• Basis: ' + items[i].sub + '<br/>• Org Insight: ' + items[i].note)
              : ('<strong>' + items[i].label + '：' + items[i].val.toFixed(1) + '%</strong><br/>• 口径明细：' + items[i].sub + '<br/>• 组织与业务解读：' + items[i].note)
          });
        }
      }

      /* Chart 4: FY2022–FY2026 GAAP Net Income ($B) & Consolidated Gross Margin (%) */
      function drawEpsComboChart() {
        var env = prepareCanvas('chartEps');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h;
        var pal = getPalette();
        hitRegions.chartEps = [];

        var years = ['FY2022', 'FY2023', 'FY2024', 'FY2025', 'FY2026'];
        var subYears = isEn() ? ['(M2 Debut)', '(Full Silicon)', '(EU Tax Chg)', '(+19.5% YoY)', '(Record High)'] : ['(M2起步)', '(全线自研)', '(含欧盟税项)', '(+19.5% YoY)', '(历史最高)'];
        var netB = [99.80, 97.00, 93.74, 112.01, 132.18];
        var gmPct = [43.3, 44.1, 46.2, 46.9, 48.8];

        var pad = { top: 26, right: 50, bottom: 44, left: 50 };
        var pw = w - pad.left - pad.right;
        var ph = h - pad.top - pad.bottom;

        var minNet = 60.0, maxNet = 175.0;
        var minGm = 39.0, maxGm = 50.5;

        for (var g = 0; g <= 4; g++) {
          var ratio = g / 4;
          var gy = pad.top + ph - ratio * ph;
          ctx.strokeStyle = pal.grid;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(pad.left, gy);
          ctx.lineTo(pad.left + pw, gy);
          ctx.stroke();

          var nTick = minNet + ratio * (maxNet - minNet);
          var mTick = minGm + ratio * (maxGm - minGm);
          ctx.font = '11px "IBM Plex Mono", sans-serif';
          ctx.textBaseline = 'middle';
          ctx.fillStyle = pal.tick;
          ctx.textAlign = 'right';
          ctx.fillText('$' + nTick.toFixed(0) + 'B', pad.left - 7, gy);
          ctx.textAlign = 'left';
          ctx.fillStyle = pal.c2;
          ctx.fillText(mTick.toFixed(1) + '%', pad.left + pw + 7, gy);
        }

        var targetY = pad.top + ph - ((45.0 - minGm) / (maxGm - minGm)) * ph;
        ctx.save();
        ctx.setLineDash([5, 5]);
        ctx.strokeStyle = pal.c3;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(pad.left, targetY);
        ctx.lineTo(pad.left + pw, targetY);
        ctx.stroke();
        ctx.restore();

        var step = pw / years.length;
        var barW = Math.min(46, Math.max(24, step * 0.42));
        var linePts = [];

        for (var i = 0; i < years.length; i++) {
          var cx = pad.left + step * (i + 0.5);
          if (hoverState.chartEps === i) {
            ctx.fillStyle = pal.hoverBand;
            roundRectPath(ctx, pad.left + step * i + 4, pad.top, step - 8, ph, 6);
            ctx.fill();
          }

          if (state.epsSeries.eps) {
            var bh = ((netB[i] - minNet) / (maxNet - minNet)) * ph;
            var bx = cx - barW / 2;
            var by = pad.top + ph - bh;
            var eGrad = ctx.createLinearGradient(0, by, 0, pad.top + ph);
            if (i === 4) {
              eGrad.addColorStop(0, '#66B2FF');
              eGrad.addColorStop(1, '#1985F1');
            } else {
              eGrad.addColorStop(0, '#3399FF');
              eGrad.addColorStop(1, '#0066CC');
            }
            ctx.fillStyle = eGrad;
            topRoundedBar(ctx, bx, by, barW, bh, 6);
            ctx.fill();

            ctx.fillStyle = '#FFFFFF';
            ctx.font = '700 10.5px "IBM Plex Mono", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'alphabetic';
            ctx.fillText('$' + netB[i].toFixed(1) + 'B', cx, by + 17);
          }

          var oy = pad.top + ph - ((gmPct[i] - minGm) / (maxGm - minGm)) * ph;
          linePts.push({ x: cx, y: oy, gm: gmPct[i] });

          ctx.fillStyle = pal.text;
          ctx.font = '700 11.5px system-ui, sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'alphabetic';
          ctx.fillText(years[i], cx, pad.top + ph + 19);
          if (subYears[i]) {
            ctx.fillStyle = pal.tick;
            ctx.font = '10px system-ui, sans-serif';
            ctx.fillText(subYears[i], cx, pad.top + ph + 33);
          }

          hitRegions.chartEps.push({
            idx: i,
            x: pad.left + step * i, y: pad.top, w: step, h: ph + 36,
            html: isEn()
              ? ('<strong>' + years[i] + ' ' + subYears[i] + '</strong><br/>• GAAP Net Income: <strong>$' + netB[i].toFixed(2) + 'B</strong><br/>• Consolidated Gross Margin: <strong>' + gmPct[i].toFixed(1) + '%</strong>')
              : ('<strong>' + years[i] + ' ' + subYears[i] + '</strong><br/>• GAAP 年度净利润：<strong>$' + netB[i].toFixed(2) + 'B</strong><br/>• 全年综合毛利率：<strong>' + gmPct[i].toFixed(1) + '%</strong>')
          });
        }

        if (w >= 460) {
          drawValueBadge(ctx, '自研跃升锚 45.0%', pad.left + pw * 0.24, targetY - 12, pal.c3, pal);
        }

        if (state.epsSeries.oci) {
          ctx.save();
          drawSmoothLine(ctx, linePts);
          ctx.strokeStyle = pal.c2;
          ctx.lineWidth = 2.8;
          ctx.stroke();
          ctx.restore();

          for (var m = 0; m < linePts.length; m++) {
            ctx.fillStyle = pal.pillBg;
            ctx.beginPath();
            ctx.arc(linePts[m].x, linePts[m].y, 6, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = pal.c2;
            ctx.beginPath();
            ctx.arc(linePts[m].x, linePts[m].y, 4.2, 0, Math.PI * 2);
            ctx.fill();
            drawValueBadge(ctx, linePts[m].gm.toFixed(1) + '%', linePts[m].x, linePts[m].y - 16, pal.c2, pal);
          }
        }
      }

      /* Chart 5: Cultural Compounding Flywheel Dual-Curve Chart */
      function drawSimChart() {
        var env = prepareCanvas('chartSim');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h;
        var pal = getPalette();
        hitRegions.chartSim = [];

        var p = state.sim.principal;
        var yrs = state.sim.years;
        var priceRate = state.sim.priceCagr / 100;
        var totalRate = (state.sim.priceCagr + (state.sim.drip ? 2.2 : 0)) / 100;

        var totalSeries = [];
        var priceOnlySeries = [];
        for (var y = 0; y <= yrs; y++) {
          totalSeries.push(p * Math.pow(1 + totalRate, y));
          priceOnlySeries.push(p * Math.pow(1 + priceRate, y));
        }

        var maxVal = Math.max(totalSeries[yrs], priceOnlySeries[yrs], p * 1.2) * 1.08;
        var pad = { top: 20, right: 20, bottom: 28, left: 60 };
        var pw = w - pad.left - pad.right;
        var ph = h - pad.top - pad.bottom;

        for (var g = 0; g <= 3; g++) {
          var v = (maxVal / 3) * g;
          var gy = pad.top + ph - (g / 3) * ph;
          ctx.strokeStyle = pal.grid;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(pad.left, gy);
          ctx.lineTo(pad.left + pw, gy);
          ctx.stroke();

          ctx.fillStyle = pal.tick;
          ctx.font = '10.5px "IBM Plex Mono", sans-serif';
          ctx.textAlign = 'right';
          ctx.textBaseline = 'middle';
          var labelStr = v >= 1000000 ? ('$' + (v / 1000000).toFixed(1) + 'M') : ('$' + Math.round(v / 1000) + 'k');
          ctx.fillText(labelStr, pad.left - 7, gy);
        }

        var stepX = pw / yrs;

        ctx.save();
        ctx.setLineDash([4, 4]);
        ctx.strokeStyle = pal.tick;
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        for (var i = 0; i <= yrs; i++) {
          var px = pad.left + stepX * i;
          var py = pad.top + ph - (priceOnlySeries[i] / maxVal) * ph;
          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.stroke();
        ctx.restore();

        var totalPts = [];
        for (var k = 0; k <= yrs; k++) {
          totalPts.push({
            x: pad.left + stepX * k,
            y: pad.top + ph - (totalSeries[k] / maxVal) * ph
          });
        }

        ctx.save();
        ctx.beginPath();
        ctx.moveTo(totalPts[0].x, pad.top + ph);
        for (var a = 0; a < totalPts.length; a++) {
          ctx.lineTo(totalPts[a].x, totalPts[a].y);
        }
        ctx.lineTo(totalPts[totalPts.length - 1].x, pad.top + ph);
        ctx.closePath();
        var areaGrad = ctx.createLinearGradient(0, pad.top, 0, pad.top + ph);
        areaGrad.addColorStop(0, 'rgba(51, 153, 255, 0.30)');
        areaGrad.addColorStop(1, 'rgba(51, 153, 255, 0.01)');
        ctx.fillStyle = areaGrad;
        ctx.fill();
        ctx.restore();

        ctx.strokeStyle = pal.c1;
        ctx.lineWidth = 2.6;
        ctx.beginPath();
        for (var m = 0; m < totalPts.length; m++) {
          if (m === 0) ctx.moveTo(totalPts[m].x, totalPts[m].y);
          else ctx.lineTo(totalPts[m].x, totalPts[m].y);
        }
        ctx.stroke();

        for (var t = 0; t <= yrs; t++) {
          var tx = totalPts[t].x;
          if (t === 0 || t === Math.floor(yrs / 2) || t === yrs) {
            ctx.fillStyle = pal.tick;
            ctx.font = '10.5px "IBM Plex Mono", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'alphabetic';
            ctx.fillText('Y' + t, tx, pad.top + ph + 18);
          }

          if (hoverState.chartSim === t) {
            ctx.save();
            ctx.strokeStyle = pal.c1;
            ctx.setLineDash([3, 3]);
            ctx.beginPath();
            ctx.moveTo(tx, pad.top);
            ctx.lineTo(tx, pad.top + ph);
            ctx.stroke();
            ctx.restore();

            ctx.fillStyle = pal.c1;
            ctx.beginPath();
            ctx.arc(tx, totalPts[t].y, 5, 0, Math.PI * 2);
            ctx.fill();
          }

          hitRegions.chartSim.push({
            idx: t,
            x: tx - stepX / 2, y: pad.top, w: Math.max(10, stepX), h: ph + 22,
            html: '<strong>持有第 ' + t + ' 年资产对比</strong><br/>' +
                  '• 含回购缩股与分红再投：<strong>' + formatCurrency(totalSeries[t]) + '</strong><br/>' +
                  '• 仅内生业务增长基准：<strong>' + formatCurrency(priceOnlySeries[t]) + '</strong><br/>' +
                  '• 资本配置复利超额增益：<strong>+' + formatCurrency(totalSeries[t] - priceOnlySeries[t]) + '</strong>'
          });
        }
      }

      function renderAllCharts() {
        drawCh1Chart();
        drawRadarChart();
        drawHorizontalBars();
        drawEpsComboChart();
        drawSimChart();
      }

      /* ======================================================================
         7. Unified High-Precision Canvas Hover Tooltip Dispatcher
         ====================================================================== */
      function wireCanvasTooltip(canvasId) {
        var canvas = document.getElementById(canvasId);
        var tip = document.getElementById('chartTooltip');
        if (!canvas || !tip) return;

        var redrawMap = {
          chartCh1: drawCh1Chart,
          chartRadar: drawRadarChart,
          chartBars: drawHorizontalBars,
          chartEps: drawEpsComboChart,
          chartSim: drawSimChart
        };

        function handlePointer(clientX, clientY) {
          var rect = canvas.getBoundingClientRect();
          var x = clientX - rect.left;
          var y = clientY - rect.top;
          var regions = hitRegions[canvasId] || [];
          var matched = null;
          for (var i = 0; i < regions.length; i++) {
            var r = regions[i];
            if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) {
              matched = r;
              break;
            }
          }

          var nextIdx = matched ? matched.idx : -1;
          if (hoverState[canvasId] !== nextIdx) {
            hoverState[canvasId] = nextIdx;
            if (redrawMap[canvasId]) redrawMap[canvasId]();
          }

          if (matched) {
            tip.innerHTML = matched.html;
            tip.style.display = 'block';
            var left = Math.min(window.innerWidth - 285, Math.max(12, clientX + 14));
            var top = Math.max(12, clientY - tip.offsetHeight - 12);
            tip.style.left = left + 'px';
            tip.style.top = top + 'px';
          } else {
            tip.style.display = 'none';
          }
        }

        canvas.addEventListener('mousemove', function (e) {
          handlePointer(e.clientX, e.clientY);
        });

        canvas.addEventListener('touchstart', function (e) {
          if (e.touches && e.touches[0]) {
            handlePointer(e.touches[0].clientX, e.touches[0].clientY);
          }
        }, { passive: true });

        canvas.addEventListener('mouseleave', function () {
          if (hoverState[canvasId] !== -1) {
            hoverState[canvasId] = -1;
            if (redrawMap[canvasId]) redrawMap[canvasId]();
          }
          tip.style.display = 'none';
        });
      }

      /* ======================================================================
         8. Standalone HTML Download Export
         ====================================================================== */
      function exportStandaloneHtml() {
        var doctype = '<!DOCTYPE html>\n';
        var htmlContent = doctype + document.documentElement.outerHTML;
        var blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
        var url = URL.createObjectURL(blob);
        var link = document.createElement('a');
        link.href = url;
        link.download = 'Apple_Corporate_Culture_Analysis.html';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(function () {
          URL.revokeObjectURL(url);
        }, 1500);
        showToast(isEn() ? 'Exported standalone file: Apple_Corporate_Culture_Analysis.html' : '已导出独立网页 Apple_Corporate_Culture_Analysis.html');
      }

      /* ======================================================================
         9. Event Listeners & Initialization
         ====================================================================== */
      function init() {
        var rawTheme = safeGetStorage(STORAGE_THEME_KEY);
        var savedTheme = rawTheme ? String(rawTheme).replace(/^"|"$/g, '') : '';
        if (savedTheme === 'light' || savedTheme === 'dark') {
          state.theme = savedTheme;
        }
        var rawLang = safeGetStorage(STORAGE_LANG_KEY);
        var savedLang = rawLang ? String(rawLang).replace(/^"|"$/g, '') : '';
        if (savedLang === 'zh' || savedLang === 'en') {
          state.lang = savedLang;
        }
        window.addEventListener('storage', function (ev) {
          if (ev.key === STORAGE_THEME_KEY && ev.newValue) {
            var nt = String(ev.newValue).replace(/^"|"$/g, '');
            if ((nt === 'light' || nt === 'dark') && nt !== state.theme) applyTheme(nt, true);
          } else if (ev.key === STORAGE_LANG_KEY && ev.newValue) {
            var nl = String(ev.newValue).replace(/^"|"$/g, '');
            if ((nl === 'zh' || nl === 'en') && nl !== state.lang) applyLanguage(nl, true);
          }
        });
        var savedChecks = safeGetStorage(STORAGE_CHECK_KEY);
        if (savedChecks) {
          try {
            var parsed = JSON.parse(savedChecks);
            if (Array.isArray(parsed) && parsed.length === CHECKLIST_ITEMS.length) {
              state.checks = parsed.map(Boolean);
            }
          } catch (e) {}
        }

        applyTheme(state.theme, true);
        applyLanguage(state.lang, true);
        document.getElementById('langZhBtn').addEventListener('click', function () { applyLanguage('zh', false); });
        document.getElementById('langEnBtn').addEventListener('click', function () { applyLanguage('en', false); });
        var abThm2 = document.getElementById('appbarThemeBtn');
        if (abThm2) {
          abThm2.addEventListener('click', function () {
            applyTheme(state.theme === 'dark' ? 'light' : 'dark', false);
          });
        }
        window.addEventListener('storage', function (ev) {
          if (ev.key === STORAGE_THEME_KEY && ev.newValue) {
            var nt = String(ev.newValue).replace(/^"|"$/g, '');
            if ((nt === 'light' || nt === 'dark') && nt !== state.theme) applyTheme(nt, true);
          } else if (ev.key === STORAGE_LANG_KEY && ev.newValue) {
            var nl = String(ev.newValue).replace(/^"|"$/g, '');
            if ((nl === 'zh' || nl === 'en') && nl !== state.lang) applyLanguage(nl, true);
          }
        });

        document.getElementById('sidebarToggleBtn').addEventListener('click', toggleSidebar);
        document.getElementById('drawerBackdrop').addEventListener('click', closeMobileDrawer);
        void 0;
        void 0;

        void 0;
        void 0;

        var tocLinks = document.querySelectorAll('#tocNavList .mui-nav-link');
        for (var t = 0; t < tocLinks.length; t++) {
          tocLinks[t].addEventListener('click', closeMobileDrawer);
        }

        var jumpInput = document.getElementById('quickJumpInput');
        var jumpPop = document.getElementById('quickJumpPopover');
        function renderJumpList(q) {
          var kw = (q || '').trim().toLowerCase();
          var activeJump = isEn() ? QUICK_JUMP_EN : QUICK_JUMP_INDEX;
          var list = activeJump.filter(function (item, idx) {
            var zhIt = QUICK_JUMP_INDEX[idx] || item;
            var enIt = QUICK_JUMP_EN[idx] || item;
            return !kw || (zhIt.title + ' ' + zhIt.sub + ' ' + enIt.title + ' ' + enIt.sub).toLowerCase().indexOf(kw) !== -1;
          });
          if (!list.length) {
            jumpPop.innerHTML = '<div style="padding:10px;font-size:0.78rem;color:var(--text-muted);">' + (isEn() ? 'No matching section' : '未匹配到对应章节') + '</div>';
          } else {
            jumpPop.innerHTML = list.map(function (item) {
              return '<button type="button" class="quick-jump-item" data-jump-sec="' + item.sec + '">' +
                '<span class="quick-jump-item-title">' + escapeHtml(item.title) + '</span>' +
                '<span class="quick-jump-item-sub">' + escapeHtml(item.sub) + '</span>' +
              '</button>';
            }).join('');
          }
          jumpPop.classList.add('open');
        }

        jumpInput.addEventListener('focus', function () { renderJumpList(jumpInput.value); });
        jumpInput.addEventListener('input', function () { renderJumpList(jumpInput.value); });
        jumpPop.addEventListener('click', function (e) {
          var btn = e.target.closest('[data-jump-sec]');
          if (!btn) return;
          var targetId = btn.getAttribute('data-jump-sec');
          var secEl = document.getElementById(targetId);
          if (secEl) secEl.scrollIntoView({ behavior: 'smooth' });
          jumpPop.classList.remove('open');
        });
        document.addEventListener('click', function (e) {
          if (!e.target.closest('.quick-search-wrap')) {
            jumpPop.classList.remove('open');
          }
        });
        document.addEventListener('keydown', function (e) {
          if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
            e.preventDefault();
            jumpInput.focus();
          } else if (e.key === 'Escape') {
            jumpPop.classList.remove('open');
            closeMobileDrawer();
          }
        });

        var ch1Btns = document.querySelectorAll('[data-ch1-view]');
        for (var c = 0; c < ch1Btns.length; c++) {
          ch1Btns[c].addEventListener('click', function () {
            state.ch1View = this.getAttribute('data-ch1-view');
            document.getElementById('ch1TabA').classList.toggle('active', state.ch1View === 'viewA');
            document.getElementById('ch1TabB').classList.toggle('active', state.ch1View === 'viewB');
            syncCh1HeaderText();
            drawCh1Chart();
          });
        }

        var collapseBtns = document.querySelectorAll('[data-collapse-target]');
        for (var m = 0; m < collapseBtns.length; m++) {
          collapseBtns[m].addEventListener('click', function () {
            var panelId = this.getAttribute('data-collapse-target');
            var panel = document.getElementById(panelId);
            if (!panel) return;
            var isOpen = panel.classList.toggle('open');
            syncCollapseButtonsText();
          });
        }

        var pillarCards = document.querySelectorAll('[data-pillar]');
        for (var p = 0; p < pillarCards.length; p++) {
          pillarCards[p].addEventListener('click', function () {
            var idx = parseInt(this.getAttribute('data-pillar'), 10) || 0;
            state.activePillar = idx;
            for (var k = 0; k < pillarCards.length; k++) {
              pillarCards[k].classList.toggle('active', k === idx);
            }
            document.getElementById('pillarFocusNote').innerHTML = '<div>' + (isEn() ? PILLAR_NOTES_EN : PILLAR_NOTES)[idx] + '</div>';
            drawRadarChart();
          });
        }

        var radarPills = document.querySelectorAll('[data-radar-key]');
        for (var r = 0; r < radarPills.length; r++) {
          radarPills[r].addEventListener('click', function () {
            var key = this.getAttribute('data-radar-key');
            state.radarSeries[key] = !state.radarSeries[key];
            if (!state.radarSeries.aapl && !state.radarSeries.nvda && !state.radarSeries.mform) {
              state.radarSeries[key] = true;
            }
            this.classList.toggle('muted', !state.radarSeries[key]);
            drawRadarChart();
          });
        }

        document.getElementById('peerSearchInput').addEventListener('input', function () {
          state.peerQuery = this.value;
          renderPeerTable();
        });
        var peerFilterBtns = document.querySelectorAll('[data-peer-filter]');
        for (var pf = 0; pf < peerFilterBtns.length; pf++) {
          peerFilterBtns[pf].addEventListener('click', function () {
            state.peerFilter = this.getAttribute('data-peer-filter');
            for (var x = 0; x < peerFilterBtns.length; x++) {
              peerFilterBtns[x].classList.toggle('active', peerFilterBtns[x] === this);
            }
            renderPeerTable();
          });
        }

        var pSlider = document.getElementById('simPrincipalSlider');
        var ySlider = document.getElementById('simYearsSlider');
        var cSlider = document.getElementById('simCagrSlider');
        var dToggle = document.getElementById('simDripToggle');

        pSlider.addEventListener('input', function () {
          state.sim.principal = parseFloat(this.value) || 10000;
          state.sim.preset = '';
          updateSimulatorUI();
        });
        ySlider.addEventListener('input', function () {
          state.sim.years = parseInt(this.value, 10) || 15;
          state.sim.preset = '';
          updateSimulatorUI();
        });
        cSlider.addEventListener('input', function () {
          state.sim.priceCagr = parseFloat(this.value) || 0;
          state.sim.preset = '';
          updateSimulatorUI();
        });
        dToggle.addEventListener('change', function () {
          state.sim.drip = !!this.checked;
          updateSimulatorUI();
        });

        var presetBtns = document.querySelectorAll('[data-preset]');
        for (var pb = 0; pb < presetBtns.length; pb++) {
          presetBtns[pb].addEventListener('click', function () {
            var key = this.getAttribute('data-preset');
            var cfg = PRESETS[key];
            if (!cfg) return;
            state.sim.principal = cfg.principal;
            state.sim.years = cfg.years;
            state.sim.priceCagr = cfg.priceCagr;
            state.sim.drip = cfg.drip;
            state.sim.preset = key;
            pSlider.value = String(cfg.principal);
            ySlider.value = String(cfg.years);
            cSlider.value = String(cfg.priceCagr);
            dToggle.checked = cfg.drip;
            updateSimulatorUI();
          });
        }

        document.getElementById('checklistContainer').addEventListener('change', function (e) {
          var input = e.target.closest('[data-check-input]');
          if (!input) return;
          var idx = parseInt(input.getAttribute('data-check-input'), 10);
          state.checks[idx] = !!input.checked;
          safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
          renderChecklist();
        });
        document.getElementById('checkAllBtn').addEventListener('click', function () {
          state.checks = [true, true, true, true, true, true];
          safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
          renderChecklist();
          showToast(isEn() ? 'Checked all 6 Apple organizational criteria' : '已勾选全部 6 项苹果企业文化核查指标');
        });
        document.getElementById('resetCheckBtn').addEventListener('click', function () {
          state.checks = [true, true, true, false, false, false];
          safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
          renderChecklist();
          showToast(isEn() ? 'Checklist reset to default baseline (50%)' : '核查清单已恢复默认基准状态 (50%)');
        });

        function updateScrollProgress() {
          var docEl = document.documentElement;
          var scrollTop = window.scrollY || docEl.scrollTop || 0;
          var maxScroll = Math.max(1, docEl.scrollHeight - window.innerHeight);
          var pct = Math.min(100, Math.max(0, (scrollTop / maxScroll) * 100));
          document.getElementById('readingProgressBar').style.width = pct + '%';
        }
        window.addEventListener('scroll', updateScrollProgress, { passive: true });
        updateScrollProgress();

        if ('IntersectionObserver' in window) {
          var secObserver = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
              if (entry.isIntersecting) {
                var id = entry.target.id;
                for (var i = 0; i < tocLinks.length; i++) {
                  tocLinks[i].classList.toggle('active', tocLinks[i].getAttribute('data-sec') === id);
                }
              }
            });
          }, { rootMargin: '-18% 0px -68% 0px', threshold: 0.02 });

          for (var s = 0; s <= 7; s++) {
            var secNode = document.getElementById('sec-0' + s);
            if (secNode) secObserver.observe(secNode);
          }
        }

        wireCanvasTooltip('chartCh1');
        wireCanvasTooltip('chartRadar');
        wireCanvasTooltip('chartBars');
        wireCanvasTooltip('chartEps');
        wireCanvasTooltip('chartSim');

        var ch1SeriesBtns = document.querySelectorAll('[data-ch1-series]');
        for (var csIdx = 0; csIdx < ch1SeriesBtns.length; csIdx++) {
          ch1SeriesBtns[csIdx].addEventListener('click', function () {
            var sk = this.getAttribute('data-ch1-series');
            state.ch1Series[sk] = !state.ch1Series[sk];
            if (!state.ch1Series.s1 && !state.ch1Series.s2) state.ch1Series[sk] = true;
            this.classList.toggle('muted', !state.ch1Series[sk]);
            drawCh1Chart();
          });
        }

        var epsSeriesBtns = document.querySelectorAll('[data-eps-series]');
        for (var esIdx = 0; esIdx < epsSeriesBtns.length; esIdx++) {
          epsSeriesBtns[esIdx].addEventListener('click', function () {
            var ek = this.getAttribute('data-eps-series');
            state.epsSeries[ek] = !state.epsSeries[ek];
            if (!state.epsSeries.eps && !state.epsSeries.oci) state.epsSeries[ek] = true;
            this.classList.toggle('muted', !state.epsSeries[ek]);
            drawEpsComboChart();
          });
        }

        var resizeTimer = null;
        function scheduleRedraw() {
          if (resizeTimer) clearTimeout(resizeTimer);
          resizeTimer = setTimeout(renderAllCharts, 60);
        }
        window.addEventListener('resize', scheduleRedraw);
        if ('ResizeObserver' in window) {
          var mainEl = document.querySelector('.main-content');
          if (mainEl) {
            var ro = new ResizeObserver(scheduleRedraw);
            ro.observe(mainEl);
          }
        }
      }

      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
      } else {
        init();
      }
    })();
  