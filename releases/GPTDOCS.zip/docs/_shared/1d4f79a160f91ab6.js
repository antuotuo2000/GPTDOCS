
  (function () {
    'use strict';

    var DATA = {"docTitleZh": "《席德·梅尔的文明 Sid Meier's Civilization》4X 策略 IP 深度研究报告 | 2K · Firaxis", "docTitleEn": "Sid Meier's Civilization 4X Strategy IP Deep Dive | 2K & Firaxis Games", "exportFileName": "ttwo_ip_civilization.html", "storageCheckKey": "ttwo_ip_civ_check_v1", "richMap": {"feat_0": {"zh": "第 3 回合侦察兵开迷雾、第 5 回合科技研发完毕、第 8 回合世界奇观竣工、第 12 回合邻国宣战——永远没有“所有事情刚好同时做完”的断点，构成游戏设计史最经典的无暴力心流引擎 <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>。", "en": "Staggered completion timers across tech research, Wonder construction, civic policies, and scouting ensure there is never a clean stopping point <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>."}, "feat_1": {"zh": "Firaxis 每一代正作严格遵循<strong>“1/3 保留经典核心、1/3 改良前作机制、1/3 大胆颠覆创新”</strong>（Civ V 取消堆叠改六角格、Civ VI 拆解城市区域、Civ VII 引入三时代演进与指挥官行军），绝不沦为换皮年货 <a class=\"cite-link\" href=\"https://www.gamefly.com/game/sid-meiers-civilization-vii/5043120\" target=\"_blank\" rel=\"noopener noreferrer\">GameFly Civ VII &#8599;</a>。", "en": "Every numbered entry keeps 1/3 core systems, improves 1/3, and reinvents 1/3 (Hexes in V, Districts in VI, Ages & Commanders in VII)—preventing sequel stagnation <a class=\"cite-link\" href=\"https://www.gamefly.com/game/sid-meiers-civilization-vii/5043120\" target=\"_blank\" rel=\"noopener noreferrer\">GameFly Civ VII &#8599;</a>."}, "feat_2": {"zh": "4X 大战略玩家平均年龄、收入与 DLC 购买意愿冠绝全行业：每一代《文明》首发后长达 6–8 年间通过两部 $30–$40 大型机制资料片、领袖季票与全平台移植持续释放高毛利现金流 <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>。", "en": "4X players exhibit industry-leading playtimes (hundreds of hours) and expansion attach rates across 6–8 year post-launch lifecycles <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>."}, "kpi_0": {"zh": "自 2021 年 5,800 万份一路增长超 2,200 万份突破 8,000 万大关，垄断历史 4X 赛道代名词地位 <a class=\"cite-link\" href=\"https://ir.take2games.com/static-files/0e369b39-2afc-4a88-b917-7799cd6ac566\" target=\"_blank\" rel=\"noopener noreferrer\">May 2026 IR Deck &#8599;</a>。", "en": "Surpassed 80M sold-in units (up from 58M in 2021), towering over all historical 4X competitors <a class=\"cite-link\" href=\"https://ir.take2games.com/static-files/0e369b39-2afc-4a88-b917-7799cd6ac566\" target=\"_blank\" rel=\"noopener noreferrer\">May 2026 IR Deck &#8599;</a>."}, "kpi_1": {"zh": "PC Metacritic 88 分，凭借《兴衰》《风云变幻》与新纪元季票成为系列史上最赚钱单作 <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>。", "en": "88 PC Metacritic; Rise and Fall, Gathering Storm & Leader Pass made Civ VI a decade-long cash cow <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>."}, "kpi_2": {"zh": "发售前位列 Steam 全球愿望单第 4 名（190万），首次同步覆盖 PC/PS5/XSX/Switch 与 Apple Arcade <a class=\"cite-link\" href=\"https://ir.take2games.com/static-files/0e369b39-2afc-4a88-b917-7799cd6ac566\" target=\"_blank\" rel=\"noopener noreferrer\">May 2026 IR Deck &#8599;</a>。", "en": "Ranked #4 globally on Steam with 1.9M pre-launch wishlists; simultaneous PC + console launch <a class=\"cite-link\" href=\"https://ir.take2games.com/static-files/0e369b39-2afc-4a88-b917-7799cd6ac566\" target=\"_blank\" rel=\"noopener noreferrer\">May 2026 IR Deck &#8599;</a>."}, "kpi_3": {"zh": "Firaxis 官宣免费大型更新《Arc of Tomorrow》（延伸至原子能时代）与首部重磅付费资料片《Earthrise》（太空时代） <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>。", "en": "Free 'Arc of Tomorrow' Atomic Age update + paid 'Earthrise' space-era expansion slated for 2027 <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>."}, "mat_col_0": {"zh": "<strong>为什么完全可逆？</strong>不同于动作游戏底层手感坏了没法改，4X 策略游戏的规则开关（如允许延续原文明模式）、UI 面板与第四时代完全可通过更新与资料片重构。", "en": "<strong>100% Fixable in 4X:</strong> Unlike broken action engines, 4X UI clarity, optional continuous-civ rules, and Atomic/Space eras are modular fixes."}, "mat_body_0": {"zh": "第一，首发版 UI 信息层级缺失（连基础产出数值与地图钉功能都需后续补丁补齐），暴露了跨全主机同步首发的工期紧迫；第二，强制在时代切换时更换文明并重置部分单位违背了部分玩家“带领同一个文明从石器时代走到太空”的代入感；第三，近现代之后缺少冷战与太空未来终局，显得意犹未尽 <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>。", "en": "Three pain points drove early Steam pushback: (1) rushed launch UI lacking key yield tooltips, (2) jarring forced civ transitions between Ages, and (3) ending abruptly before the Atomic and Information/Space eras <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>."}, "mat_col_1": {"zh": "<strong>历史对标：</strong>正如当年《文明5：美丽新世界》与《文明6：风云变幻》一举让在线人数反超首发期。", "en": "<strong>Historical Precedent:</strong> Mirrors how Brave New World (Civ V) and Gathering Storm (Civ VI) drove multi-year Steam concurrency highs."}, "mat_body_1": {"zh": "2K 与 Firaxis 没有把本该有的后期时代直接拿来圈钱，而是聪明地先向全体玩家<strong>免费推送《Arc of Tomorrow》大型更新将主线完整延伸至原子能时代</strong>挽回口碑，紧接着再推出真正重磅的太空时代付费资料片<strong>《Earthrise》</strong>——这套“免费修地基 + 付费建高楼”策略深得核心社区认可 <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>。", "en": "Rather than paywalling missing late-20th-century content, Firaxis is delivering the comprehensive Atomic-Age update <strong>Arc of Tomorrow for free</strong> to win back player goodwill ahead of the major premium space-era expansion <strong>Earthrise</strong> <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>."}, "mat_col_2": {"zh": "<strong>代际留存现象：</strong>甚至在《文明7》调整期，流失玩家也是退回去玩自家的《文明6》和《文明5》，肥水根本不流外人田！", "en": "<strong>Intra-Franchise Retention:</strong> When players pause Civ VII waiting for expansions, they play Civ VI or Civ V—keeping 100% of mindshare inside 2K!"}, "mat_body_2": {"zh": "2021–2024 年间世嘉《Humankind》、微软《Ara: History Untold》与 P社发行的《Millennia》轮番挑战历史 4X 王座，但均在首月后在线暴跌 90%+。原因在于历史人格化领袖魅力（核平甘地等文化梗）、奇观视听仪式感（肖恩·宾/格温多兰·克里斯蒂配音）与数百参数数值平衡唯有 Firaxis 掌握 <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>。", "en": "Recent challengers like Sega's Humankind, Microsoft's Ara: History Untold, and Paradox's Millennia lost >90% of players within weeks—lacking Civ's charismatic leaders, Wonder pageantry, and 35 years of pacing math <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>."}, "mat_body_3": {"zh": "2025 年秋 Firaxis 进行了约 60 人的结构精简与工作室管理层调整，明确宣布将资源聚焦于“核心设计、底层技术与玩家体验”，全力打赢《文明 VII》长线翻身仗与新《XCOM》攻坚战 <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>。", "en": "Firaxis streamlined leadership and team structure in late 2025 to sharpen focus on core systems design, UI polish, and Civ VII's 2027 expansion renaissance <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>."}, "econ_0": {"zh": "开发一部全新引擎正作（如《文明 VII》）需耗时 5–6 年重做渲染、联机与底层框架；而一旦地基建成，制作《Earthrise》这样的大型资料片仅需 18 个月与精干分队，定价却高达 <strong>$29.99–$39.99</strong>（且同时刺激数百万观望的“等等党”补票购入本体+资料片黄金版） <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>。", "en": "Building a new mainline Civ engine takes 5–6 years of heavy R&D; once shipped, $29.99–$39.99 expansions like <strong>Earthrise</strong> require a fraction of base-game cost while simultaneously pulling millions of patient fence-sitters into Gold/Anthology bundles <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>."}, "econ_1": {"zh": "在《文明 VII》打磨完善期间，《文明 VI 典藏版》依然在 Steam、iPad 与主机端面向入门价格敏感型新玩家每年热销超百万份，待新玩家迷上“再来一回合”后再升级购买包含《Earthrise》的《文明 VII》完全体 <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>。", "en": "While Civ VII matures toward its 2027 expansions, Civ VI Anthology continues onboarding budget-conscious newcomers across Steam, Switch, and iOS—creating a natural upgrade funnel <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>."}, "tl_0": {"zh": "1991 年席德·梅尔受桌游启发打造初代《文明》，1996 年与 Jeff Briggs 创立 Firaxis Games；2005 年 Take-Two 先买断《文明》IP 紧接着收购 Firaxis，同年发售的《文明 IV》（MC 94）成为无数策略玩家心目中的初代白月光 <a class=\"cite-link\" href=\"https://www.gamespot.com/\" target=\"_blank\" rel=\"noopener noreferrer\">GameSpot 80M &#8599;</a>。", "en": "Sid Meier created Civilization in 1991 and co-founded Firaxis in 1996; Take-Two acquired the IP and studio in 2005 just as 94-MC masterpiece Civilization IV launched <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Take-Two_Interactive\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia TTWO &#8599;</a>."}, "tl_1": {"zh": "《文明 V》与《文明 VI》大胆简化繁琐数值并拥抱 Steam 创意工坊、Switch 掌机与 iPad 触屏，将受众从硬核军棋迷扩展至全球大学生与白领阶层，两代合计贡献超 2,500 万份销量 <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>。", "en": "Civ V and Civ VI modernized visual clarity and expanded onto Steam Workshop, Switch, and iPad—selling >25M combined copies and carrying the series past 80M <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>."}, "tl_2": {"zh": "经历 2025 首发磨合与 2026 Apple Arcade 拓展后，Firaxis 将于 2027 推出免费原子能时代更新与首部太空时代大型资料片《Earthrise》，重走《美丽新世界》与《风云变幻》口碑逆袭之路 <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>。", "en": "Following 2025–2026 post-launch tuning and Apple Arcade expansion, 2027's free Arc of Tomorrow update and paid Earthrise expansion initiate Civ VII's classic second-act surge <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>."}, "case_0": {"zh": "许多新玩家不知道，2010 年《文明5》原版因后期单调遭四代老粉猛烈抨击；直到《众神与国王》加回宗教间谍、《美丽新世界》重做国际商路与考古旅游后，才逆袭为 Steam 十年常青神作——这正是评估《文明7》2027 潜力的最佳参照 <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>。", "en": "Vanilla Civ V faced fierce Civ IV fan criticism in 2010 before Gods & Kings and Brave New World overhauled trade routes, ideology, and culture—establishing Firaxis's expansion turnaround DNA <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>."}, "case_1": {"zh": "将完整端游级《文明》搬上 Switch 与苹果移动端（含 2026《文明7》登陆 Apple Arcade），精准击中商务人士十小时跨洋航班离线娱乐刚需，创造了策略品类罕见的移动端全价/订阅收入流 <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>。", "en": "Bringing full-fat Civilization onto Nintendo Switch, iPad, and Apple Arcade captured offline travelers and commuters—creating high-margin non-PC revenue <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>."}, "case_2": {"zh": "不同于部分大厂在新作差评后指责玩家不懂创新，Strauss Zelnick 坦率承认《文明7》首发体验存在不足并全力支持团队免费补齐原子能时代，为 2027 资料片销售重建信任纽带 <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>。", "en": "Rather than dismissing fan critiques, Take-Two acknowledged launch UI/pacing missteps and greenlit the free Arc of Tomorrow update to earn back community trust before selling Earthrise <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>."}, "case_3": {"zh": "即便在批评《文明7》时代切换的帖子里，绝大多数老玩家也一致盛赞“指挥官打包行军与集中升级”是全系列三十年最优秀的军事操作减负发明 <a class=\"cite-link\" href=\"https://www.gamefly.com/game/sid-meiers-civilization-vii/5043120\" target=\"_blank\" rel=\"noopener noreferrer\">GameFly Civ VII &#8599;</a>。", "en": "Even harsh critics of Civ VII's launch UI praised Army Commanders as the franchise's best military quality-of-life leap since hex grids <a class=\"cite-link\" href=\"https://www.gamefly.com/game/sid-meiers-civilization-vii/5043120\" target=\"_blank\" rel=\"noopener noreferrer\">GameFly Civ VII &#8599;</a>."}, "hero_h1": {"zh": "《席德·梅尔的文明 Civilization》系列 IP 深度分析：<span class=\"gradient-accent\">8,000万份历史策略霸主、三时代革新阵痛与2027资料片反转剧本</span>", "en": "Sid Meier&#x27;s Civilization Franchise IP Deep Dive: <span class=\"gradient-accent\">80M-Unit 4X Strategy Titan, Three-Age Architecture &amp; The 2027 Expansion Playbook</span>"}, "hero_lead": {"zh": "在电子游戏界，极少有哪句口头禅像<strong>“再来一回合（Just One More Turn…然后天亮了）”</strong>这样跨越三十五年世代经久不衰。自传奇设计师席德·梅尔（Sid Meier）于 1991 年推出初代以来，2K 旗下 Firaxis Games 执掌的《文明（Civilization）》系列累计销量已突破 <strong>8,000 万份</strong>，稳坐全球 PC 策略游戏头把交椅 <a class=\"cite-link\" href=\"https://ir.take2games.com/static-files/0e369b39-2afc-4a88-b917-7799cd6ac566\" target=\"_blank\" rel=\"noopener noreferrer\">May 2026 IR Deck &#8599;</a> <a class=\"cite-link\" href=\"https://www.gamespot.com/\" target=\"_blank\" rel=\"noopener noreferrer\">GameSpot 80M &#8599;</a>。2016 年问世的《文明 VI》凭借“城市区域解绑（Unstacking Cities）”与两部大型资料片长卖超 1,100 万份（PC MC 88 分） <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>。2025 年 2 月 11 日，首次实现 PC 与全主机全球同步首发的<strong>《文明 VII》</strong>携 <strong>190 万 Steam 愿望单与系列最高预购纪录</strong>上市（整体 Metacritic 79 分） <a class=\"cite-link\" href=\"https://ir.take2games.com/static-files/0e369b39-2afc-4a88-b917-7799cd6ac566\" target=\"_blank\" rel=\"noopener noreferrer\">May 2026 IR Deck &#8599;</a> <a class=\"cite-link\" href=\"https://gameworldobserver.com/2025/02/07/civilization-7-record-pre-orders-take-two-q3-report\" target=\"_blank\" rel=\"noopener noreferrer\">GWO Pre-Orders &#8599;</a>；面对初期 UI 简陋与时代切换割裂感引发的核心老玩家批评，管理层坦诚复盘（Zelnick 直言早期设计有失误）、于 2025 年秋重组 Firaxis 团队聚焦体验打磨，并官宣 2027 重磅翻盘组合拳——免费原子能时代大更<strong>《Arc of Tomorrow》</strong>与首部太空时代大型付费资料片<strong>《Earthrise》</strong> <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>，正式开启《文明》系列传承三代屡试不爽的“资料片封神”周期。", "en": "Few phrases in gaming carry the cultural weight of <strong>'Just One More Turn.'</strong> Created by Sid Meier in 1991 and stewarded by 2K's Firaxis Games (celebrating its 30th anniversary in 2026), <strong>Sid Meier's Civilization</strong> has surpassed <strong>80 million lifetime copies sold</strong> as the undisputed king of historical 4X strategy <a class=\"cite-link\" href=\"https://ir.take2games.com/static-files/0e369b39-2afc-4a88-b917-7799cd6ac566\" target=\"_blank\" rel=\"noopener noreferrer\">May 2026 IR Deck &#8599;</a>. Following <em>Civilization VI</em>'s >11M-unit, decade-long run (88 PC Metacritic) <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Civilization_VI\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia Civ VI &#8599;</a>, <strong>Civilization VII</strong> launched simultaneously across PC and consoles on February 11, 2025 with <strong>1.9M Steam wishlists, franchise-record pre-orders, and a 79 Metacritic score</strong> <a class=\"cite-link\" href=\"https://ir.take2games.com/static-files/0e369b39-2afc-4a88-b917-7799cd6ac566\" target=\"_blank\" rel=\"noopener noreferrer\">May 2026 IR Deck &#8599;</a> <a class=\"cite-link\" href=\"https://gameworldobserver.com/2025/02/07/civilization-7-record-pre-orders-take-two-q3-report\" target=\"_blank\" rel=\"noopener noreferrer\">GWO Pre-Orders &#8599;</a>. After candidly acknowledging early UI and Age-transition friction, Firaxis rolled out iterative patches, expanded to Apple Arcade in 2026, and unveiled its 2027 turnaround slate: the free Atomic-Age overhaul <strong>Arc of Tomorrow</strong> and first major space-era expansion <strong>Earthrise</strong> <a class=\"cite-link\" href=\"https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/\" target=\"_blank\" rel=\"noopener noreferrer\">GamesBeat 2027 DLC &#8599;</a>."}}, "quickJumpZh": [{"sec": "sec-00", "title": "00 IP 核心论点与 8,000万份里程碑", "sub": "全系超 8,000 万份 · Civ VI >1,100万份 · Civ VII 破预购纪录"}, {"sec": "sec-01", "title": "01 “再来一回合”心流与三时代变革", "sub": "短期/中期/远期三重奖励交错 × 文明7三时代解耦争议与进化"}, {"sec": "sec-02", "title": "02 四大策略护城河与 4X 品类雷达", "sub": "人类通史题材普适性 · Steam 创意工坊千小时留存 · 全端同步"}, {"sec": "sec-03", "title": "03 历代文明与全球大战略竞品对比", "sub": "文明5/6/7 vs 群星/欧陆风云(P社) vs 全面战争 vs 人类Humankind"}, {"sec": "sec-04", "title": "04 “本体首发→两部大资料片反转”测算", "sub": "复刻《诸神与国王》《风云变幻》口碑销量二次起飞模拟器"}, {"sec": "sec-05", "title": "05 35年演进与每一代“先骂后真香”复盘", "sub": "Civ V/VI 首发皆遭老粉抗议，最终均靠两部大型资料片封神"}, {"sec": "sec-06", "title": "06 文明 VII 2027 资料片突围核查清单", "sub": "6 项 Arc of Tomorrow 免费更新、Earthrise 太空时代与 UI 核查"}, {"sec": "sec-07", "title": "07 官方数据来源与核验索引", "sub": "May 2026 IR Slide 16 · GamesBeat 2027 DLC · Wikipedia"}], "quickJumpEn": [{"sec": "sec-00", "title": "00 IP Thesis & 80M-Unit Milestones", "sub": ">80M Series Units · Civ VI >11M · Civ VII Pre-Order Record"}, {"sec": "sec-01", "title": "01 'One More Turn' Loop & Ages Shift", "sub": "Interlocking Turn Horizons × Civ VII Three-Age Architecture"}, {"sec": "sec-02", "title": "02 Four Strategy Moats & 4X Radar", "sub": "Universal World History · Mod Ecosystem · Console/Apple Reach"}, {"sec": "sec-03", "title": "03 Civ Generations & 4X Peer Matrix", "sub": "Civ V/VI/VII vs. Paradox Grand Strategy vs. Total War vs. Humankind"}, {"sec": "sec-04", "title": "04 Base-to-Expansion Turnaround Sim", "sub": "Modeling 2027 Arc of Tomorrow + Earthrise Expansion Lift"}, {"sec": "sec-05", "title": "05 35-Year Arc & Expansion Redemptions", "sub": "Why Every Civ Launches Controversial Then Compounds for 8 Years"}, {"sec": "sec-06", "title": "06 Civ VII 2027 Turnaround Checklist", "sub": "6-Point Atomic/Space Age, UI Overhaul & Steam CCU Audit"}, {"sec": "sec-07", "title": "07 Official Sources & Verification", "sub": "May 2026 IR Slide 16 · GamesBeat 2027 Roadmap · Wikipedia"}], "ch1Chart": {"tabA_zh": "视图 A：系列总销量二十年增长斜率", "tabA_en": "View A: Franchise Sales Growth (M)", "tabB_zh": "视图 B：历代正作体量与资料片前后评分", "tabB_en": "View B: Mainline Units & Metacritic", "source_chip_zh": "数据源：May 2026 IR / GameSpot / Wikipedia", "source_chip_en": "Source: May 2026 IR / GameSpot / Wikipedia", "viewA": {"title_zh": "《席德·梅尔的文明》全系列累计销量攀升轨迹（2015 – 2026，百万份）", "title_en": "Sid Meier's Civilization Cumulative Franchise Units Sold (2015–2026, Millions)", "sub_zh": "从 2015 年的 3,300 万份到 2026 年突破 8,000 万份，十年间销量规模翻了 2.4 倍以上", "sub_en": "Expanded >2.4x over the past decade from 33M units pre-Civ VI to >80M lifetime units", "left_meta_zh": "左轴：全系列累计销量 (百万份)", "left_meta_en": "Left Axis: Cumulative Franchise Units (M)", "right_meta_zh": "右轴：覆盖终端平台数量 (PC/Mac/主机/移动)", "right_meta_en": "Right Axis: Supported Active Platforms", "leg1_zh": "文明全系列历史累计销量 (百万份)", "leg1_en": "Cumulative Franchise Units (M)", "leg2_zh": "覆盖主流硬件终端数 (个)", "leg2_en": "Active Hardware Platforms Supported", "labels_zh": ["2015 (Civ6前)", "2019 (风云变幻)", "2021年8月", "2023年5月", "2026年"], "labels_en": ["2015 (Pre-VI)", "2019 (Gathering)", "Aug 2021", "May 2023", "2026"], "s1": [33, 51, 58, 67, 80], "s2": [3, 6, 7, 7, 8], "min1": 0, "max1": 92, "p1": "", "u1": "M", "d1": 0, "min2": 0, "max2": 10, "p2": "", "u2": " 端", "d2": 0, "notes_zh": ["文明1–5代二十四年积累 3,300 万份硬核 PC 策略底盘", "文明6《风云变幻》资料片封神并成功移植 Switch 与 iPad", "新纪元季票（New Frontier Pass）推动全系突破 5,800 万份", "领袖季票与白金合集带动全系升至 6,700 万份（Civ6 单作破 1,100 万）", "Civ6 长尾 + 2025年2月《文明7》创预购纪录，全系突破 8,000 万份+"], "notes_en": ["Civ I through Civ V built a 33M-unit PC strategy foundation", "Civ VI: Gathering Storm + Switch/iOS ports lifted total past 51M", "New Frontier Pass pushed series past 58M units", "Leader Pass & Anthology bundles carried franchise to 67M", "Civ VI evergreen tail + Feb 2025 Civ VII launch propelled series past 80M+"]}, "viewB": {"title_zh": "近四代《文明》正作销量（百万份）与 Metacritic 评分演进", "title_en": "Civilization IV – VII: Mainline Units (Millions) vs. Metacritic Score", "sub_zh": "每一代长卖周期均超过 8 年；《文明 VII》正处于首部大型资料片上线前的典型蓄力窗口", "sub_en": "Civ IV, V, and VI each compounded across multi-year expansion cycles; Civ VII enters its 2027 expansion phase", "left_meta_zh": "左轴：单代累计销量估算 (百万份)", "left_meta_en": "Left Axis: Mainline Entry Units (M)", "right_meta_zh": "右轴：Metacritic 评分", "right_meta_en": "Right Axis: Metacritic Score", "leg1_zh": "单代累计销量 (百万份)", "leg1_en": "Mainline Entry Units (M)", "leg2_zh": "Metacritic 媒体评分", "leg2_en": "Metacritic Score", "labels_zh": ["文明 IV (2005)", "文明 V (2010)", "文明 VI (2016)", "文明 VII (2025初)"], "labels_en": ["Civ IV (2005)", "Civ V (2010)", "Civ VI (2016)", "Civ VII (2025)"], "s1": [6.5, 11.0, 14.5, 3.8], "s2": [94, 90, 88, 79], "min1": 0, "max1": 17, "p1": "", "u1": "M", "d1": 1, "min2": 65, "max2": 98, "p2": "MC ", "u2": "", "d2": 0, "notes_zh": ["Baba Yetu 主题曲获格莱美奖，硬核规则集大成者", "六角格与取消单位堆叠革命，凭借《美丽新世界》资料片长卖超千万份", "2023年已超 1,100 万份，至 2026 累计约 1,400 万–1,500 万份级", "首发打破预购纪录但因早期 UI/时代断层获 MC 79，静待 2027 Earthrise 反转"], "notes_en": ["Grammy-winning Baba Yetu theme; beloved classic stack-combat peak", "Hex-grid revolution; Brave New World turned Civ V into a 10M+ seller", "Surpassed 11M by 2023 and ~14M+ through 2026 via Anthology bundles", "Record pre-orders & 79 MC at launch; 2027 Earthrise expansion targets classic Civ rebound"]}}, "pillarNotesZh": ["<strong>破圈上限决定因素：</strong>通识直观性使《文明》成为唯一能卖到单代破千万份、全系破 8,000 万份的大战略游戏。", "<strong>全平台触屏/手柄适配：</strong>六角格回合制无手速要求，天然适合 iPad、Apple Arcade、Switch 2 与 Steam Deck 躺玩。", "<strong>免费研发外脑：</strong>高人气社区 UI Mod 往往被 Firaxis 官方吸收进后续正式补丁中。", "<strong>逆周期抗跌：</strong>即使宏观经济承压，花 $40 买一部能玩 500 小时的《文明》资料片也是娱乐性价比天花板（每小时仅 8 美分）。"], "pillarNotesEn": ["<strong>Mainstream Ceiling:</strong> Intuitive historical concepts explain why Civ sells >10M+ per entry while niche wargames cap at 1M–2M.", "<strong>Turn-Based Portability:</strong> Zero twitch-reflex requirements make Civ ideal for Switch 2, iPad, Apple Arcade, and Steam Deck.", "<strong>R&D Feedback Loop:</strong> Top community UI and balance mods directly inform official Firaxis patches.", "<strong>Recession-Proof Value:</strong> At ~$0.08 per hour played, Civ expansions deliver unmatched entertainment value during consumer downturns."], "radar": {"title_zh": "全球三大历史/大战略游戏系列五维竞争力雷达", "title_en": "5-Axis Global Strategy Franchise Capability Radar", "sub_zh": "对比《席德·梅尔的文明》、Paradox 历史大战略（群星/CK3）与世嘉《全面战争》", "sub_en": "Comparing Civilization (2K/Firaxis), Paradox Grand Strategy (CK3/Stellaris), and Total War (Sega/CA)", "axes_zh": ["大众破圈与单作总销量", "跨主机/移动/掌机全端适配", "资料片与季票长线复利", "上手直观度与心流成瘾", "千人即时战场微观操控"], "axes_en": ["Mainstream Unit Volume", "Console/Mobile/Handheld Fit", "Expansion & DLC Longevity", "Onboarding & '1 More Turn'", "Real-Time Tactical Battles"], "pillar_axis_map": [0, 1, 2, 3], "series_labels": {"s1_zh": "席德·梅尔的文明 (2K / Firaxis)", "s1_en": "Civilization (2K / Firaxis)", "s2_zh": "Paradox 大战略矩阵 (CK3/群星)", "s2_en": "Paradox Grand Strategy", "s3_zh": "全面战争 Total War (世嘉/CA)", "s3_en": "Total War (Sega / CA)"}, "s1": [98, 95, 94, 99, 45], "s2": [72, 58, 97, 76, 40], "s3": [76, 42, 84, 72, 98]}, "peerRowsZh": [{"category": "civ", "benchmark": true, "entity": "Sid Meier's Civilization VII (2025.02)", "sub": "Firaxis Games · 全平台同步首发", "col2": "三时代章节制 + 领袖与文明自由混搭 + 军队指挥官与可通航河流", "col3": "PC/Mac/PS5/XSX/Switch/Apple Arcade · 2027《Arc of Tomorrow》+《Earthrise》", "col4": "首发前 190万 Steam愿望单 · 创预购纪录", "col5": "MC 79 · 初期UI争议后进入资料片重塑期", "verdict": "底盘预购强劲但首发过急；2027 免费原子能时代 + 太空资料片有望复刻前两代逆袭曲线。", "sourceLabel": "GamesBeat 2027 DLC", "sourceUrl": "https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/"}, {"category": "civ", "benchmark": true, "entity": "Sid Meier's Civilization VI (2016)", "sub": "Firaxis Games · 十年长卖王", "col2": "城市区域解绑（学院/圣地/工业区铺格规划）+ 尤里卡/鼓舞加速双科技市政树", "col3": "兴衰 + 风云变幻 + 新纪元季票 + 领袖季票；覆盖 PC/主机/iOS/Android", "col4": ">1,100万–1,400万份+ (系列最高)", "col5": "PC MC 88 · Steam 常年数万同时在线", "verdict": "教科书级长尾：首发同样因画风遭老粉吐槽，但靠《风云变幻》气候外交系统封神长卖十年。", "sourceLabel": "Civ VI Wiki", "sourceUrl": "https://en.wikipedia.org/wiki/Civilization_VI"}, {"category": "civ", "benchmark": false, "entity": "Sid Meier's Civilization V (2010)", "sub": "Firaxis Games · 现代六角格奠基作", "col2": "废除方形格“末日单位堆叠（Stack of Doom）”，全面确立六角格一格一军（1UPT）战术", "col3": "《众神与国王》(2012) + 《美丽新世界》(2013) 彻底重构文化旅游与世界议会", "col4": ">1,000万份级", "col5": "MC 90 · 现代 4X 规则分水岭", "verdict": "首次证明“大刀阔斧砍旧机制必遭短期阵痛，但两部资料片补完后即成十年经典”。", "sourceLabel": "May 2026 IR Deck", "sourceUrl": "https://ir.take2games.com/static-files/0e369b39-2afc-4a88-b917-7799cd6ac566"}, {"category": "rival", "benchmark": false, "entity": "Humankind 人类 (2021)", "sub": "Amplitude Studios / 世嘉", "col2": "首创每进一个时代更换一次文明文化的混搭机制（Civ VII 部分设计灵感前身）", "col3": "PC / 主机 + Game Pass 首日入库", "col4": "首月冲高后活跃流失逾 90%，Amplitude 后脱离世嘉独立", "col5": "MC 77 · 后期数值崩坏", "verdict": "揭示了“时代换文明”若缺乏强人格化领袖锚点极易丧失代入感——Civ VII 保留固定领袖正是对此改良。", "sourceLabel": "Civ 80M Fandom", "sourceUrl": "https://vgsales.fandom.com/wiki/Best-selling_game_franchises"}, {"category": "rival", "benchmark": false, "entity": "Crusader Kings III / Stellaris (Paradox)", "sub": "Paradox Development Studio · 瑞典大战略", "col2": "中世纪家族联姻阴谋角色扮演（CK3）与太空歌剧种族演化（群星）", "col3": "持续 8–10 年每年推出数个 DLC + 月度 DLC 订阅制", "col4": "单作各自突破 300万–600万份+", "col5": "CK3 MC 91 · 核心粘性极强", "verdict": "DLC 变现纪律值得借鉴，但实时暂停复杂界面难以像《文明》那样破圈千万级大众市场。", "sourceLabel": "TTWO 10-K", "sourceUrl": "https://www.sec.gov/Archives/edgar/data/946581/000162828026037434/ttwo-20260331.htm"}, {"category": "rival", "benchmark": false, "entity": "Ara: History Untold (2024)", "sub": "Oxide Games (前 Firaxis 成员创立) / 微软发行", "col2": "同步回合制 + 精细物资供应链制作链条", "col3": "PC Steam + PC Game Pass", "col4": "Steam 峰值仅数千人，未能形成威胁", "col5": "MC 74 · 微操过于繁琐", "verdict": "就连前 Firaxis 核心技术骨干另起炉灶背靠微软资金，也未能撼动正统《文明》金字招牌分毫。", "sourceLabel": "GWO Civ VII", "sourceUrl": "https://gameworldobserver.com/2025/02/07/civilization-7-record-pre-orders-take-two-q3-report"}], "peerRowsEn": [{"category": "civ", "benchmark": true, "entity": "Sid Meier's Civilization VII (Feb 2025)", "sub": "Firaxis Games · Simultaneous Cross-Platform", "col2": "Three-Age structure + decoupled Leaders/Civs + Army Commanders & navigable rivers", "col3": "PC/Mac/PS5/XSX/Switch/Apple Arcade · 2027 Arc of Tomorrow + Earthrise DLC", "col4": "1.9M Steam wishlists · Record pre-orders", "col5": "MC 79 · Entering 2027 Expansion Rebound", "verdict": "Massive top-of-funnel demand tempered by early UI/Age debates; 2027 Atomic & Space expansions mirror prior Civ turnarounds.", "sourceLabel": "GamesBeat 2027 DLC", "sourceUrl": "https://gamesbeat.com/take-two-reports-bookings-for-fiscal-q2-of-1-6b-down-18-and-below-expectations/"}, {"category": "civ", "benchmark": true, "entity": "Sid Meier's Civilization VI (2016)", "sub": "Firaxis Games · Decade Evergreen Benchmark", "col2": "Unstacked city Districts on hexes + Eureka/Inspiration dual tech & civic trees", "col3": "Rise and Fall + Gathering Storm + New Frontier & Leader Passes across PC/Console/iOS", "col4": ">11M–14M+ units (Franchise #1)", "col5": "PC MC 88 · Perennial Steam Top-25 CCU", "verdict": "Proved the Civ arc: overcame launch art/AI debates via Gathering Storm to sell >11M+ copies over 9 years.", "sourceLabel": "Civ VI Wiki", "sourceUrl": "https://en.wikipedia.org/wiki/Civilization_VI"}, {"category": "civ", "benchmark": false, "entity": "Sid Meier's Civilization V (2010)", "sub": "Firaxis Games · Hex & 1UPT Pioneer", "col2": "Replaced square-grid 'Stacks of Doom' with tactical hexes and One-Unit-Per-Tile", "col3": "Gods & Kings (2012) + Brave New World (2013) transformed diplomacy & culture", "col4": ">10M+ lifetime units", "col5": "MC 90 · Modern 4X Blueprint", "verdict": "Demonstrated how bold structural rewrites spark Year-1 debate before expansions cement decade-long classics.", "sourceLabel": "May 2026 IR Deck", "sourceUrl": "https://ir.take2games.com/static-files/0e369b39-2afc-4a88-b917-7799cd6ac566"}, {"category": "rival", "benchmark": false, "entity": "Humankind (2021)", "sub": "Amplitude Studios / Sega", "col2": "Pioneered era-by-era culture swapping across historical epochs", "col3": "PC / Console + Day-One Game Pass", "col4": ">90% post-launch concurrency drop; Amplitude later bought out from Sega", "col5": "MC 77 · Late-game balance issues", "verdict": "Showed era-swapping needs persistent charismatic historical leaders—which Civ VII retained.", "sourceLabel": "Civ 80M Fandom", "sourceUrl": "https://vgsales.fandom.com/wiki/Best-selling_game_franchises"}, {"category": "rival", "benchmark": false, "entity": "Crusader Kings III / Stellaris (Paradox)", "sub": "Paradox Development Studio · Grand Strategy", "col2": "Dynastic RPG intrigue (CK3) and galactic 4X empire simulation (Stellaris)", "col3": "8–10 year continuous DLC tail + optional monthly expansion subscription", "col4": "3M–6M+ units each with high ARPU", "col5": "CK3 MC 91 · Hardcore Devotion", "verdict": "Elite DLC monetization model, though steeper real-time-with-pause UI caps casual reach vs. Civ.", "sourceLabel": "TTWO 10-K", "sourceUrl": "https://www.sec.gov/Archives/edgar/data/946581/000162828026037434/ttwo-20260331.htm"}, {"category": "rival", "benchmark": false, "entity": "Ara: History Untold (2024)", "sub": "Oxide Games (Ex-Firaxis Vets) / Xbox Publishing", "col2": "Simultaneous turns + deep goods-crafting supply chains", "col3": "Steam + PC Game Pass", "col4": "Modest thousand-player Steam peak", "col5": "MC 74 · Heavy micromanagement", "verdict": "Even ex-Firaxis veterans backed by Microsoft could not dent Civilization's 35-year brand moat.", "sourceLabel": "GWO Civ VII", "sourceUrl": "https://gameworldobserver.com/2025/02/07/civilization-7-record-pre-orders-take-two-q3-report"}], "peerCountUnitZh": "部策略标杆作品", "peerCountUnitEn": "Strategy Benchmarks", "barsChart": {"title_zh": "《文明》系列商业统治力与《文明 VII》首发漏斗关键核验数据", "title_en": "Civilization Franchise Dominance & Civ VII Demand Funnel Metrics", "sub_zh": "8,000 万份总销量规模相当于后面三名历史 4X 竞品总和的数倍", "sub_en": "Quantifying Civilization's structural lead in historical 4X strategy", "badge_zh": "官方披露数据核验", "badge_en": "Verified IR Figures", "maxX": 100, "prefix": "", "suffix": "Pts", "axisDecimals": 0, "valDecimals": 1, "items_zh": [{"label": "文明全系列历史累计销量 (百万份)", "val": 80.0, "sub": ">8,000 万份正版销量", "note": "稳居全球历史策略游戏第一大 IP"}, {"label": "文明 IV 经典媒体综评高度 (满分100)", "val": 94.0, "sub": "MC 94 / 100 · 格莱美音乐奖", "note": "策略游戏艺术与系统设计最高峰之一"}, {"label": "文明 VI PC 版 Metacritic 均分", "val": 88.0, "sub": "MC 88 · 单作突破 >1,100万份", "note": "依靠风云变幻与新纪元季票长卖十年"}, {"label": "文明 VII 总体 Metacritic 媒体评分", "val": 79.0, "sub": "MC 79 · 190万 Steam 愿望单 (#4)", "note": "2027 免费更新 + Earthrise 资料片启动口碑重塑"}, {"label": "Firaxis 工作室深耕历史策略年限 (x3)", "val": 90.0, "sub": "1996–2026 整整 30 周年积淀", "note": "2005年并入 Take-Two 2K 体系至今 21 年"}, {"label": "近五年系列新增销量占比 (2021–2026)", "val": 27.5, "sub": "五年净卖 >2,200万份 (58M→80M+)", "note": "老作合集与跨端移植提供极强抗周期底盘"}], "items_en": [{"label": "Civilization Franchise Lifetime Sales (M)", "val": 80.0, "sub": ">80M units sold-in since 1991", "note": "Undisputed #1 historical 4X strategy property"}, {"label": "Civilization IV Peak Critical Score", "val": 94.0, "sub": "94 / 100 Metacritic · Grammy Winner", "note": "Landmark entry in PC gaming history"}, {"label": "Civilization VI PC Metacritic Score", "val": 88.0, "sub": "88 MC · >11M+ units sold", "note": "Compounded across a full decade of expansions"}, {"label": "Civilization VII Launch Metacritic Score", "val": 79.0, "sub": "79 MC · 1.9M Steam Wishlists (#4)", "note": "2027 Arc of Tomorrow & Earthrise target 85+ rebound"}, {"label": "Firaxis Studio Heritage Index (30 Yrs x3)", "val": 90.0, "sub": "Founded 1996 by Sid Meier (30th Anniv.)", "note": "Part of Take-Two's 2K family since 2005"}, {"label": "5-Year Recent Volume Share (58M→80M+)", "val": 27.5, "sub": ">22M units added in past 5 years", "note": "Demonstrates accelerating modern strategy TAM"}]}, "histChart": {"title_zh": "历史参照：《文明 VI》发售 7 年内重大资料片节点如何阶梯拉升销量与在线峰值", "title_en": "Historical Proof: How Major Expansions Multiplied Civilization VI's Sales & Steam CCU", "sub_zh": "打破线性衰减规律：2019《风云变幻》与 2020《新纪元季票》令发售第 4–5 年的活跃度反超第 2 年！", "sub_en": "Gathering Storm (Yr 3) and New Frontier Pass (Yr 4–5) drove second-wind surges well above Year-2 levels", "badge_zh": "Civ VI 反转历史样本", "badge_en": "Civ VI Rebound Proof", "left_axis_zh": "■ 左轴：Civ VI 累计本体销量 (百万份)", "left_axis_en": "■ Left Axis: Cumulative Civ VI Units (M)", "right_axis_zh": "● 右轴：年度 Steam 峰值同时在线人数 (千人)", "right_axis_en": "● Right Axis: Annual Peak Steam CCU (Thousands)", "legend": {"bar_zh": "文明 VI 累计总销量 (左轴 · 百万份)", "bar_en": "Cumulative Civ VI Base Units (Left · M)", "line_zh": "年度 Steam 峰值同时在线 CCU (右轴 · 千人)", "line_en": "Annual Peak Steam Concurrent Players (Right · k)"}, "labels_zh": ["2017 (首发次年)", "2018 (兴衰DLC)", "2019 (风云变幻)", "2021 (新纪元季票)", "2023 (领袖季票)"], "labels_en": ["2017 (Post-Launch)", "2018 (Rise & Fall)", "2019 (Gathering)", "2021 (Frontier)", "2023 (Leader Pass)"], "subs_zh": ["(口碑磨合期)", "(时代分数机制)", "(气候外交封神)", "(累计破800万)", "(突破1,100万+)"], "subs_en": ["(Early Debate)", "(Loyalty Era)", "(Climate Peak)", "(>8.5M Units)", "(>11.0M+ Units)"], "bars": [2.4, 4.2, 6.5, 9.0, 11.5], "line": [62, 75, 98, 92, 89], "minB": 0, "maxB": 13.5, "pB": "", "uB": "M", "dB": 1, "minL": 30, "maxL": 115, "pL": "", "uL": "k", "dL": 0, "milestoneVal": 85, "milestone_zh": "8.5万 Steam 峰值长青线", "milestone_en": "85k Steam CCU Benchmark", "notes_zh": ["首发冲高后因AI与UI争议回落，等待首部大型资料片", "首部资料片《迭起兴衰》引入忠诚度与黄金/黑暗时代", "第二资料片《风云变幻》口碑大爆，Steam 峰值飙回近 10 万人", "双月更新的新纪元季票持续激发老玩家复购", "发售第 7 年仍维持近 9 万峰值在线，累计突破 1,100 万份"], "notes_en": ["Post-launch lull while players awaited major mechanical expansions", "Rise and Fall added Golden/Dark Ages and city loyalty", "Gathering Storm triggered massive critical & concurrency renaissance", "Bi-monthly New Frontier Pass sustained peak live engagement", "Leader Pass carried Year-7 concurrency near 90k and units >11M+"]}, "simConfig": {"presets": {"base": {"v1": 9.5, "v2": 44, "v3": 45, "flag": true}, "bull": {"v1": 12.5, "v2": 47, "v3": 55, "flag": true}, "bear": {"v1": 6.2, "v2": 37, "v3": 30, "flag": false}}, "defaultPreset": "base", "defaultVals": {"v1": 9.5, "v2": 44, "v3": 45, "flag": true}, "xLabelsZh": ["2025首发", "2026调整", "2027(Earthrise)", "2028(第2大包)", "2030(典藏版)"], "xLabelsEn": ["2025 Launch", "2026 Patch", "2027 Earthrise", "2028 Exp #2", "2030 Anthology"], "activeCurveLabelZh": "资料片反转全周期流水", "activeCurveLabelEn": "Expansion Ecosystem Bookings", "baseCurveLabelZh": "无资料片静态基准", "baseCurveLabelEn": "Base-Only Static Curve"}, "checklistZh": [{"tag": "Arc of Tomorrow", "title": "1. 2027 免费《Arc of Tomorrow》原子能时代大更后 Steam 在线反超测试", "desc": "观察免费补齐冷战与原子能时代后，Steam 同时在线人数（CCU）能否反超当前存量《文明 VI》在线人数，完成代际主力交接。"}, {"tag": "连续文明选项", "title": "2. “单一文明一玩到底（Classic Mode）”可选规则开关落地测试", "desc": "核验 Firaxis 是否提供官方可选开关允许传统派玩家跨时代保留同一文明名称与代入感，彻底化解首发最大设计争议。"}, {"tag": "Earthrise 资料片", "title": "3. 首部大型付费资料片《Earthrise》（太空时代）媒体评分与转化率测试", "desc": "跟踪《Earthrise》上市后能否斩获 MC 85+ 媒体好评，并带动首批百万级“等等党”购入本体+资料片捆绑包。"}, {"tag": "创意工坊完全体", "title": "4. 官方 Mod 开发工具包（SDK）开放深度与工坊活跃度测试", "desc": "核验社区地图编辑器与脚本工具链完善程度，观察头部 Mod 作者从《文明6》向《文明7》迁移的速度。"}, {"tag": "Switch 2 鼠标模式", "title": "5. Nintendo Switch 2 高性能与手柄/Joy-Con 交互体验拉动测试", "desc": "评估次世代掌机大屏与更高 CPU 算力在跑后期回合结算时的提速效果及便携端销量贡献。"}, {"tag": "Firaxis 双线稳定", "title": "6. Firaxis 重组后核心设计师留存与第二资料片（2028E）衔接节奏", "desc": "在 2025 秋架构精简后，确认文明组核心系统策划产能充沛，保障 2027–2029 稳定资料片供给。"}], "checklistEn": [{"tag": "Arc of Tomorrow", "title": "1. Free Atomic-Age Update Steam CCU Crossover vs. Civ VI Test", "desc": "Verify whether 2027's free Arc of Tomorrow overhaul pushes Civ VII daily Steam concurrency permanently past Civ VI."}, {"tag": "Classic Civ Toggle", "title": "2. Optional Continuous-Civilization Rule Mode & Age Transition Polish", "desc": "Check if smoother transition pacing or classic single-civ continuity options win back traditionalist 4X veterans."}, {"tag": "Earthrise Attach", "title": "3. 'Earthrise' Space-Era Expansion Critical Score (Target 85+ MC) & Sales", "desc": "Track Earthrise attach rates and Gold Edition bundle conversions among the 1.9M+ pre-launch wishlist cohort."}, {"tag": "Workshop SDK", "title": "4. Official Modding Tools & Steam Workshop Creator Migration", "desc": "Ensure full modding SDK support unlocks custom UI, map scripts, and total-conversion mods."}, {"tag": "Switch 2 Turn Times", "title": "5. Switch 2 Late-Game Turn Processing Speed & Portable Sales Lift", "desc": "Evaluate late-Age AI turn computation speed and portable adoption on Switch 2 and Apple silicon."}, {"tag": "Expansion #2 Relay", "title": "6. Post-Restructuring Firaxis Cadence Toward Expansion #2 (2028E)", "desc": "Confirm Firaxis's refocused Baltimore studio maintains steady momentum beyond Earthrise."}]};
    var STORAGE_THEME_KEY = 'mui_portal_theme_v4';
    var STORAGE_LANG_KEY = 'mui_portal_lang_v1';
    var STORAGE_CHECK_KEY = DATA.storageCheckKey;

    var state = {
      lang: 'zh',
      theme: 'light',
      ch1View: 'viewA',
      ch1Series: { s1: true, s2: true },
      activePillar: 0,
      radarSeries: { s1: true, s2: true, s3: true },
      peerFilter: 'all',
      peerQuery: '',
      epsSeries: { eps: true, oci: true },
      sim: Object.assign({ preset: DATA.simConfig.defaultPreset }, DATA.simConfig.defaultVals),
      checks: [true, true, true, false, false, false]
    };

    function isEn() { return state.lang === 'en'; }

    function safeGetStorage(key) {
      try { return window.localStorage.getItem(key); } catch (e) { return null; }
    }
    function safeSetStorage(key, val) {
      try { window.localStorage.setItem(key, val); } catch (e) { /* ignore */ }
    }

    var toastTimer = null;
    function showToast(msg) {
      var el = document.getElementById('muiSnackbar');
      if (!el) return;
      el.textContent = msg;
      el.classList.add('show');
      if (toastTimer) clearTimeout(toastTimer);
      toastTimer = setTimeout(function () { el.classList.remove('show'); }, 2600);
    }

    function escapeHtml(str) {
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    }

    function highlightMatch(text, query) {
      var safe = escapeHtml(text);
      if (!query) return safe;
      var escapedQ = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      var re = new RegExp('(' + escapedQ + ')', 'gi');
      return safe.replace(re, '<mark class="hl">$1</mark>');
    }

    function syncCh1HeaderText() {
      var v = state.ch1View === 'viewA' ? DATA.ch1Chart.viewA : DATA.ch1Chart.viewB;
      var tEl = document.getElementById('ch1ChartTitle');
      var sEl = document.getElementById('ch1ChartSub');
      if (tEl) tEl.textContent = isEn() ? v.title_en : v.title_zh;
      if (sEl) sEl.textContent = isEn() ? v.sub_en : v.sub_zh;
    }

    function syncCollapseButtonsText() {
      var btns = document.querySelectorAll('[data-collapse-target]');
      for (var i = 0; i < btns.length; i++) {
        var pid = btns[i].getAttribute('data-collapse-target');
        var panel = document.getElementById(pid);
        var isOpen = panel && panel.classList.contains('open');
        if (isEn()) {
          btns[i].innerHTML = isOpen ? '<span>Hide Mechanism &amp; Evidence</span> <span>&#8963;</span>' : '<span>Show Mechanism &amp; Evidence</span> <span>&#8964;</span>';
        } else {
          btns[i].innerHTML = isOpen ? '<span>收起底层机制与数据拆解</span> <span>&#8963;</span>' : '<span>展开底层机制与数据拆解</span> <span>&#8964;</span>';
        }
      }
    }

    function applyLanguage(lang, silent) {
      state.lang = lang === 'en' ? 'en' : 'zh';
      var en = isEn();
      document.documentElement.setAttribute('lang', en ? 'en' : 'zh-CN');
      document.documentElement.setAttribute('data-lang', state.lang);
      document.title = en ? DATA.docTitleEn : DATA.docTitleZh;

      var lGrp = document.getElementById('langSwitchGroup');
      if (lGrp) lGrp.setAttribute('aria-label', en ? 'Language switcher' : '语言切换');
      var abThmBtn = document.getElementById('appbarThemeBtn');
      if (abThmBtn) {
        abThmBtn.setAttribute('title', en ? 'Toggle Light / Dark theme' : '切换浅色 / 深色主题');
        abThmBtn.setAttribute('aria-label', en ? 'Toggle color theme' : '切换深浅色主题');
      }
      var zhBtn = document.getElementById('langZhBtn');
      var enBtn = document.getElementById('langEnBtn');
      if (zhBtn && enBtn) {
        zhBtn.classList.toggle('active', !en);
        enBtn.classList.toggle('active', en);
        zhBtn.setAttribute('aria-pressed', !en ? 'true' : 'false');
        enBtn.setAttribute('aria-pressed', en ? 'true' : 'false');
      }

      var biNodes = document.querySelectorAll('[data-i18n-zh][data-i18n-en]');
      for (var i = 0; i < biNodes.length; i++) {
        biNodes[i].textContent = en ? biNodes[i].getAttribute('data-i18n-en') : biNodes[i].getAttribute('data-i18n-zh');
      }

      var richNodes = document.querySelectorAll('[data-i18n-rich]');
      for (var r = 0; r < richNodes.length; r++) {
        var rk = richNodes[r].getAttribute('data-i18n-rich');
        var item = DATA.richMap[rk];
        if (item) richNodes[r].innerHTML = en ? item.en : item.zh;
      }

      var phNodes = document.querySelectorAll('[data-ph-zh][data-ph-en]');
      for (var p = 0; p < phNodes.length; p++) {
        phNodes[p].setAttribute('placeholder', en ? phNodes[p].getAttribute('data-ph-en') : phNodes[p].getAttribute('data-ph-zh'));
      }
      var tiNodes = document.querySelectorAll('[data-title-zh][data-title-en]');
      for (var t = 0; t < tiNodes.length; t++) {
        tiNodes[t].setAttribute('title', en ? tiNodes[t].getAttribute('data-title-en') : tiNodes[t].getAttribute('data-title-zh'));
      }
      var arNodes = document.querySelectorAll('[data-aria-zh][data-aria-en]');
      for (var a = 0; a < arNodes.length; a++) {
        arNodes[a].setAttribute('aria-label', en ? arNodes[a].getAttribute('data-aria-en') : arNodes[a].getAttribute('data-aria-zh'));
      }

      var pNote = document.getElementById('pillarFocusNote');
      if (pNote) {
        var notesArr = en ? DATA.pillarNotesEn : DATA.pillarNotesZh;
        pNote.innerHTML = '<div>' + notesArr[state.activePillar] + '</div>';
      }

      syncCh1HeaderText();
      syncCollapseButtonsText();
      renderPeerTable();
      renderChecklist();
      updateSimulatorUI();
      renderAllCharts();
      safeSetStorage(STORAGE_LANG_KEY, state.lang);

      if (!silent) {
        showToast(en ? 'Switched to English Research Edition' : '已切换至中文深度研报视图');
      }
    }

    function applyTheme(theme, silent) {
      state.theme = theme === 'dark' ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', state.theme);
      var abIconEl = document.getElementById('appbarThemeIcon');
      if (abIconEl) {
        abIconEl.innerHTML = (state.theme === 'dark')
          ? '<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zm18 0h2c.55 0 1-.45 1-1s-.45-1-1-1h-2c-.55 0-1 .45-1 1s.45 1 1 1zM11 2v2c0 .55.45 1 1 1s1-.45 1-1V2c0-.55-.45-1-1-1s-1 .45-1 1zm0 18v2c0 .55.45 1 1 1s1-.45 1-1v-2c0-.55-.45-1-1-1s-1 .45-1 1zM5.99 4.58a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0s.39-1.03 0-1.41L5.99 4.58zm12.37 12.37a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0a.996.996 0 0 0 0-1.41l-1.06-1.06zm1.06-10.96a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06zM7.05 18.36a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06z"/></svg>'
          : '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3a9 9 0 1 0 9 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 0 1-4.4 2.26 5.403 5.403 0 0 1-3.14-9.8c-.44-.06-.9-.1-1.36-.1z"/></svg>';
      }
      var sDarkBtn = document.getElementById('sideThemeDarkBtn');
      var sLightBtn = document.getElementById('sideThemeLightBtn');
      if (sDarkBtn && sLightBtn) {
        void 0;
        void 0;
      }
      safeSetStorage(STORAGE_THEME_KEY, state.theme);
      renderAllCharts();
      if (!silent) {
        showToast(state.theme === 'dark' ? (isEn() ? 'Switched to Dark Obsidian Mode' : '已切换至 MUI 深海黑曜石护眼模式') : (isEn() ? 'Switched to Crisp Light Mode' : '已切换至 MUI 浅色明亮阅读模式'));
      }
    }

    function toggleSidebar() {
      if (window.innerWidth <= 1120) {
        document.body.classList.toggle('drawer-open');
      } else {
        document.body.classList.toggle('sidebar-collapsed');
        setTimeout(renderAllCharts, 60);
      }
    }
    function closeMobileDrawer() { document.body.classList.remove('drawer-open'); }

    function renderPeerTable() {
      var tbody = document.getElementById('peerTableBody');
      var badge = document.getElementById('peerCountBadge');
      if (!tbody) return;
      var activeRows = isEn() ? DATA.peerRowsEn : DATA.peerRowsZh;
      var q = state.peerQuery.trim().toLowerCase();
      var filtered = activeRows.filter(function (row, idx) {
        var catOk = state.peerFilter === 'all' || row.category === state.peerFilter;
        if (!catOk) return false;
        if (!q) return true;
        var zhR = DATA.peerRowsZh[idx] || row;
        var enR = DATA.peerRowsEn[idx] || row;
        var hay = (zhR.entity + ' ' + zhR.sub + ' ' + zhR.col2 + ' ' + zhR.col3 + ' ' + zhR.col4 + ' ' + zhR.col5 + ' ' + zhR.verdict + ' ' +
                   enR.entity + ' ' + enR.sub + ' ' + enR.col2 + ' ' + enR.col3 + ' ' + enR.col4 + ' ' + enR.col5 + ' ' + enR.verdict).toLowerCase();
        return hay.indexOf(q) !== -1;
      });

      if (badge) {
        badge.textContent = isEn()
          ? ('Showing ' + filtered.length + ' / ' + activeRows.length + ' ' + DATA.peerCountUnitEn)
          : ('显示 ' + filtered.length + ' / ' + activeRows.length + ' ' + DATA.peerCountUnitZh);
      }

      if (!filtered.length) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:28px;">' + (isEn() ? 'No matching entries found. Try another keyword or reset filters.' : '未找到匹配的对比记录，请尝试其他关键词或重置筛选条件。') + '</td></tr>';
        return;
      }

      var rawQ = state.peerQuery.trim();
      tbody.innerHTML = filtered.map(function (r) {
        return '<tr class="' + (r.benchmark ? 'benchmark-row' : '') + '">' +
          '<td><strong style="color:var(--text-primary);display:block;">' + highlightMatch(r.entity, rawQ) + '</strong><span style="font-size:0.76rem;color:var(--text-muted);">' + highlightMatch(r.sub, rawQ) + '</span></td>' +
          '<td>' + highlightMatch(r.col2, rawQ) + '</td>' +
          '<td>' + highlightMatch(r.col3, rawQ) + '</td>' +
          '<td class="mono" style="font-size:0.79rem;">' + highlightMatch(r.col4, rawQ) + '</td>' +
          '<td class="mono" style="font-size:0.79rem;color:var(--mui-primary-lighter);font-weight:700;">' + highlightMatch(r.col5, rawQ) + '</td>' +
          '<td>' + highlightMatch(r.verdict, rawQ) + ' <a class="cite-link" href="' + escapeHtml(r.sourceUrl) + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(r.sourceLabel) + ' &#8599;</a></td>' +
          '</tr>';
      }).join('');
    }

    function computeSimModel(simState, en) {
      
              var unitsM = simState.v1;
              var baseAsp = simState.v2;
              var expAttachPct = simState.v3;
              var extraM = simState.flag ? 95.0 : 0.0;

              var baseGrossM = unitsM * baseAsp;
              var twoExpAvgRevPerAttached = 56.0;
              var expGrossM = unitsM * (expAttachPct / 100) * twoExpAvgRevPerAttached + extraM;
              var totalGrossM = baseGrossM + expGrossM;
              var ltvPerBuyer = totalGrossM / unitsM;

              var activePace = [0.26, 0.38, 0.64, 0.85, 1.00];
              var noExpBaseM = Math.min(baseGrossM, 5.2 * 40.0);
              var decayPace = [0.52, 0.72, 0.84, 0.93, 1.00];

              var activeSeries = [];
              var baseSeries = [];
              for (var i = 0; i < 5; i++) {
                activeSeries.push(totalGrossM * activePace[i]);
                baseSeries.push(noExpBaseM * decayPace[i]);
              }

              return {
                label1: unitsM.toFixed(1) + 'M',
                label2: '$' + baseAsp.toFixed(0),
                label3: expAttachPct.toFixed(0) + '%',
                out1: '$' + Math.round(baseGrossM) + 'M',
                out2: '+$' + Math.round(expGrossM) + 'M',
                out3: '$' + (totalGrossM / 1000).toFixed(2) + 'B',
                out4: '$' + ltvPerBuyer.toFixed(1) + (en ? ' / buyer' : ' / 人'),
                activeSeries: activeSeries,
                baseSeries: baseSeries,
                formatY: function (v) { return '$' + Math.round(v) + 'M'; }
              };
            
    }

    function updateSimulatorUI() {
      var m = computeSimModel(state.sim, isEn());
      document.getElementById('simVal1Label').textContent = m.label1;
      document.getElementById('simVal2Label').textContent = m.label2;
      document.getElementById('simVal3Label').textContent = m.label3;

      document.getElementById('simOut1').textContent = m.out1;
      document.getElementById('simOut2').textContent = m.out2;
      document.getElementById('simOut3').textContent = m.out3;
      document.getElementById('simOut4').textContent = m.out4;

      var presetBtns = document.querySelectorAll('[data-preset]');
      for (var i = 0; i < presetBtns.length; i++) {
        presetBtns[i].classList.toggle('active', presetBtns[i].getAttribute('data-preset') === state.sim.preset);
      }
      drawSimChart();
    }

    function renderChecklist() {
      var container = document.getElementById('checklistContainer');
      var chip = document.getElementById('checklistScoreChip');
      var bar = document.getElementById('checklistProgressBar');
      if (!container) return;
      var itemsList = isEn() ? DATA.checklistEn : DATA.checklistZh;
      var doneCount = state.checks.filter(Boolean).length;
      var pct = Math.round((doneCount / itemsList.length) * 100);
      if (chip) {
        chip.textContent = isEn()
          ? ('Verified ' + doneCount + ' / ' + itemsList.length + ' (' + pct + '%)')
          : ('已核查 ' + doneCount + ' / ' + itemsList.length + ' 项 (' + pct + '%)');
      }
      if (bar) bar.style.width = pct + '%';

      container.innerHTML = itemsList.map(function (item, idx) {
        var isChecked = !!state.checks[idx];
        return '<label class="check-card ' + (isChecked ? 'checked' : '') + '" data-check-idx="' + idx + '">' +
          '<input type="checkbox" data-check-input="' + idx + '" ' + (isChecked ? 'checked' : '') + ' />' +
          '<div style="flex:1;">' +
          '<div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:6px;margin-bottom:4px;">' +
          '<span class="check-title">' + escapeHtml(item.title) + '</span>' +
          '<span class="mui-chip mono">' + escapeHtml(item.tag) + '</span>' +
          '</div>' +
          '<p class="check-desc">' + escapeHtml(item.desc) + '</p>' +
          '</div></label>';
      }).join('');
    }

    /* High-DPI Built-In Canvas Chart Engine */
    var hitRegions = { chartCh1: [], chartRadar: [], chartBars: [], chartEps: [], chartSim: [] };
    var hoverState = { chartCh1: -1, chartRadar: -1, chartBars: -1, chartEps: -1, chartSim: -1 };

    function getPalette() {
      var cs = getComputedStyle(document.documentElement);
      var isDark = state.theme === 'dark';
      return {
        isDark: isDark,
        grid: cs.getPropertyValue('--chart-grid').trim() || (isDark ? 'rgba(148,163,184,0.13)' : 'rgba(100,116,139,0.16)'),
        tick: cs.getPropertyValue('--chart-tick').trim() || '#94A3B8',
        text: cs.getPropertyValue('--text-primary').trim() || '#F3F6F9',
        sub: cs.getPropertyValue('--text-secondary').trim() || '#B2BAC2',
        pillBg: isDark ? 'rgba(9, 13, 22, 0.88)' : 'rgba(255, 255, 255, 0.94)',
        pillBorder: isDark ? 'rgba(51, 153, 255, 0.28)' : 'rgba(0, 115, 230, 0.24)',
        trackBg: isDark ? 'rgba(148, 163, 184, 0.10)' : 'rgba(15, 25, 36, 0.06)',
        hoverBand: isDark ? 'rgba(51, 153, 255, 0.07)' : 'rgba(0, 115, 230, 0.05)',
        c1: cs.getPropertyValue('--chart-c1').trim() || '#3399FF',
        c2: cs.getPropertyValue('--chart-c2').trim() || '#22C55E',
        c3: cs.getPropertyValue('--chart-c3').trim() || '#FFB74D',
        c4: cs.getPropertyValue('--chart-c4').trim() || '#A78BFA'
      };
    }

    function prepareCanvas(id) {
      var canvas = document.getElementById(id);
      if (!canvas || !canvas.parentElement) return null;
      var stage = canvas.parentElement;
      var rect = stage.getBoundingClientRect();
      var w = Math.max(240, Math.floor(rect.width));
      var h = Math.max(170, Math.floor(rect.height));
      var dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      var targetW = Math.floor(w * dpr);
      var targetH = Math.floor(h * dpr);
      if (canvas.width !== targetW) canvas.width = targetW;
      if (canvas.height !== targetH) canvas.height = targetH;
      var ctx = canvas.getContext('2d');
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      return { ctx: ctx, w: w, h: h, canvas: canvas };
    }

    function roundRectPath(ctx, x, y, w, h, r) {
      if (w <= 0 || h <= 0) return;
      var radius = Math.min(r, w / 2, h / 2);
      ctx.beginPath();
      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + w - radius, y);
      ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
      ctx.lineTo(x + w, y + h - radius);
      ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
      ctx.lineTo(x + radius, y + h);
      ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
    }

    function topRoundedBar(ctx, x, y, w, h, r) {
      if (w <= 0 || h <= 0) return;
      var rad = Math.min(r, w / 2, h);
      ctx.beginPath();
      ctx.moveTo(x, y + h);
      ctx.lineTo(x, y + rad);
      ctx.quadraticCurveTo(x, y, x + rad, y);
      ctx.lineTo(x + w - rad, y);
      ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
      ctx.lineTo(x + w, y + h);
      ctx.closePath();
    }

    function drawValueBadge(ctx, text, cx, cy, fgColor, pal) {
      ctx.save();
      ctx.font = '700 10.5px "IBM Plex Mono", system-ui, sans-serif';
      var tw = ctx.measureText(text).width + 10;
      var th = 18;
      var bx = cx - tw / 2;
      var by = cy - th / 2;
      ctx.fillStyle = pal.pillBg;
      roundRectPath(ctx, bx, by, tw, th, 5);
      ctx.fill();
      ctx.strokeStyle = pal.pillBorder;
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.fillStyle = fgColor;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text, cx, cy + 0.5);
      ctx.restore();
    }

    function drawSmoothLine(ctx, pts) {
      if (!pts.length) return;
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (var i = 0; i < pts.length - 1; i++) {
        var xc = (pts[i].x + pts[i + 1].x) / 2;
        ctx.bezierCurveTo(xc, pts[i].y, xc, pts[i + 1].y, pts[i + 1].x, pts[i + 1].y);
      }
    }

    function fmtTick(val, prefix, suffix, decimals) {
      var neg = val < 0 ? '-' : '';
      var absV = Math.abs(val);
      return neg + (prefix || '') + absV.toFixed(decimals || 0) + (suffix || '');
    }

    /* Chart 1: Dual-View Bar + Line Combo */
    function drawCh1Chart() {
      var env = prepareCanvas('chartCh1');
      if (!env) return;
      var ctx = env.ctx, w = env.w, h = env.h;
      var pal = getPalette();
      hitRegions.chartCh1 = [];

      var v = state.ch1View === 'viewA' ? DATA.ch1Chart.viewA : DATA.ch1Chart.viewB;
      var en = isEn();
      var metaEl = document.getElementById('ch1AxisMeta');
      var leg1 = document.getElementById('ch1Leg1');
      var leg2 = document.getElementById('ch1Leg2');

      if (metaEl) {
        metaEl.innerHTML = '<span style="color:var(--chart-c1);">&#9632; ' + escapeHtml(en ? v.left_meta_en : v.left_meta_zh) + '</span>' +
                           '<span style="color:var(--chart-c2);">&#9679; ' + escapeHtml(en ? v.right_meta_en : v.right_meta_zh) + '</span>';
      }
      if (leg1) leg1.textContent = en ? v.leg1_en : v.leg1_zh;
      if (leg2) leg2.textContent = en ? v.leg2_en : v.leg2_zh;

      var pad = { top: 28, right: 54, bottom: 40, left: 54 };
      var pw = w - pad.left - pad.right;
      var ph = h - pad.top - pad.bottom;
      var labels = en ? v.labels_en : v.labels_zh;
      var s1 = v.s1;
      var s2 = v.s2;
      var min1 = v.min1 || 0, max1 = v.max1;
      var min2 = v.min2 || 0, max2 = v.max2;

      for (var g = 0; g <= 4; g++) {
        var r = g / 4;
        var gy = pad.top + ph - r * ph;
        ctx.strokeStyle = pal.grid;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(pad.left, gy);
        ctx.lineTo(pad.left + pw, gy);
        ctx.stroke();

        ctx.font = '10.5px "IBM Plex Mono", sans-serif';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = pal.tick;
        ctx.textAlign = 'right';
        ctx.fillText(fmtTick(min1 + r * (max1 - min1), v.p1, v.u1, v.d1), pad.left - 7, gy);

        ctx.fillStyle = pal.c2;
        ctx.textAlign = 'left';
        ctx.fillText(fmtTick(min2 + r * (max2 - min2), v.p2, v.u2, v.d2), pad.left + pw + 7, gy);
      }

      var step = pw / labels.length;
      var barW = Math.min(40, Math.max(18, step * 0.44));
      var pts = [];

      for (var i = 0; i < labels.length; i++) {
        var cx = pad.left + step * (i + 0.5);
        if (hoverState.chartCh1 === i) {
          ctx.fillStyle = pal.hoverBand;
          roundRectPath(ctx, pad.left + step * i + 3, pad.top, step - 6, ph, 6);
          ctx.fill();
        }

        if (state.ch1Series.s1) {
          var bH = Math.max(4, ((s1[i] - min1) / (max1 - min1)) * ph);
          var bX = cx - barW / 2;
          var bY = pad.top + ph - bH;
          var bGrad = ctx.createLinearGradient(0, bY, 0, pad.top + ph);
          if (pal.isDark) {
            bGrad.addColorStop(0, 'rgba(51, 153, 255, 0.82)');
            bGrad.addColorStop(1, 'rgba(0, 115, 230, 0.30)');
          } else {
            bGrad.addColorStop(0, '#1985F1');
            bGrad.addColorStop(1, '#0066CC');
          }
          ctx.fillStyle = bGrad;
          topRoundedBar(ctx, bX, bY, barW, bH, 5);
          ctx.fill();

          if (bH > 22 && w >= 460) {
            ctx.fillStyle = '#FFFFFF';
            ctx.font = '700 10px "IBM Plex Mono", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'alphabetic';
            ctx.fillText(fmtTick(s1[i], v.p1, v.u1, v.d1), cx, bY + 15);
          }
        }

        var ly = pad.top + ph - ((s2[i] - min2) / (max2 - min2)) * ph;
        pts.push({ x: cx, y: ly, val: s2[i] });

        ctx.fillStyle = pal.text;
        ctx.font = '600 ' + (w < 500 ? '10px' : '11px') + ' system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'alphabetic';
        ctx.fillText(labels[i], cx, pad.top + ph + 20);

        var noteTxt = (en ? v.notes_en : v.notes_zh)[i] || '';
        hitRegions.chartCh1.push({
          idx: i,
          x: pad.left + step * i, y: pad.top, w: step, h: ph + 32,
          html: '<strong>' + escapeHtml(labels[i]) + '</strong><br/>' +
                '&#8226; ' + escapeHtml(en ? v.leg1_en : v.leg1_zh) + ': <strong>' + fmtTick(s1[i], v.p1, v.u1, v.d1) + '</strong><br/>' +
                '&#8226; ' + escapeHtml(en ? v.leg2_en : v.leg2_zh) + ': <strong>' + fmtTick(s2[i], v.p2, v.u2, v.d2) + '</strong>' +
                (noteTxt ? '<br/>&#8226; ' + escapeHtml(noteTxt) : '')
        });
      }

      if (state.ch1Series.s2) {
        ctx.save();
        drawSmoothLine(ctx, pts);
        ctx.strokeStyle = pal.c2;
        ctx.lineWidth = 2.6;
        ctx.stroke();
        ctx.restore();

        for (var m = 0; m < pts.length; m++) {
          ctx.fillStyle = pal.pillBg;
          ctx.beginPath();
          ctx.arc(pts[m].x, pts[m].y, 5.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = pal.c2;
          ctx.beginPath();
          ctx.arc(pts[m].x, pts[m].y, 3.8, 0, Math.PI * 2);
          ctx.fill();
          if (w >= 540 || m === 0 || m === pts.length - 1) {
            drawValueBadge(ctx, fmtTick(pts[m].val, v.p2, v.u2, v.d2), pts[m].x, Math.max(14, pts[m].y - 15), pal.c2, pal);
          }
        }
      }
    }

    /* Chart 2: 5-Axis Radar Chart */
    function drawRadarChart() {
      var env = prepareCanvas('chartRadar');
      if (!env) return;
      var ctx = env.ctx, w = env.w, h = env.h;
      var pal = getPalette();
      hitRegions.chartRadar = [];

      var rad = DATA.radar;
      var axes = isEn() ? rad.axes_en : rad.axes_zh;
      var count = axes.length;
      var cx = w / 2;
      var cy = h / 2 + 6;
      var radius = Math.min(w, h) * 0.33;

      for (var ring = 1; ring <= 5; ring++) {
        var rr = (radius * ring) / 5;
        ctx.beginPath();
        for (var a = 0; a < count; a++) {
          var ang = -Math.PI / 2 + (a * 2 * Math.PI) / count;
          var rx = cx + Math.cos(ang) * rr;
          var ry = cy + Math.sin(ang) * rr;
          if (a === 0) ctx.moveTo(rx, ry);
          else ctx.lineTo(rx, ry);
        }
        ctx.closePath();
        ctx.strokeStyle = pal.grid;
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      var highlightAxis = rad.pillar_axis_map ? rad.pillar_axis_map[state.activePillar] : state.activePillar % count;

      for (var k = 0; k < count; k++) {
        var angK = -Math.PI / 2 + (k * 2 * Math.PI) / count;
        var ex = cx + Math.cos(angK) * radius;
        var ey = cy + Math.sin(angK) * radius;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(ex, ey);
        ctx.strokeStyle = k === highlightAxis ? pal.c1 : pal.grid;
        ctx.lineWidth = k === highlightAxis ? 2 : 1;
        ctx.stroke();

        var lx = cx + Math.cos(angK) * (radius + 24);
        var ly = cy + Math.sin(angK) * (radius + 18);
        ctx.font = (k === highlightAxis ? '800 ' : '600 ') + (w < 420 ? '10.5px' : '11.5px') + ' system-ui, sans-serif';
        ctx.fillStyle = k === highlightAxis ? pal.c1 : pal.text;
        ctx.textAlign = Math.abs(Math.cos(angK)) < 0.2 ? 'center' : (Math.cos(angK) > 0 ? 'left' : 'right');
        ctx.textBaseline = 'middle';
        ctx.fillText(axes[k], lx, ly);

        hitRegions.chartRadar.push({
          idx: k,
          x: lx - 48, y: ly - 16, w: 96, h: 32,
          html: '<strong>' + escapeHtml(axes[k]) + '</strong><br/>' +
                '&#8226; ' + escapeHtml(isEn() ? rad.series_labels.s1_en : rad.series_labels.s1_zh) + ': <strong>' + rad.s1[k] + '/100</strong><br/>' +
                '&#8226; ' + escapeHtml(isEn() ? rad.series_labels.s2_en : rad.series_labels.s2_zh) + ': ' + rad.s2[k] + '/100<br/>' +
                '&#8226; ' + escapeHtml(isEn() ? rad.series_labels.s3_en : rad.series_labels.s3_zh) + ': ' + rad.s3[k] + '/100'
        });
      }

      function plotPoly(vals, strokeCol, fillCol, widthLine) {
        ctx.beginPath();
        for (var idx = 0; idx < count; idx++) {
          var a = -Math.PI / 2 + (idx * 2 * Math.PI) / count;
          var dist = (vals[idx] / 100) * radius;
          var px = cx + Math.cos(a) * dist;
          var py = cy + Math.sin(a) * dist;
          if (idx === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fillStyle = fillCol;
        ctx.fill();
        ctx.strokeStyle = strokeCol;
        ctx.lineWidth = widthLine;
        ctx.stroke();

        for (var j = 0; j < count; j++) {
          var aj = -Math.PI / 2 + (j * 2 * Math.PI) / count;
          var dj = (vals[j] / 100) * radius;
          ctx.fillStyle = strokeCol;
          ctx.beginPath();
          ctx.arc(cx + Math.cos(aj) * dj, cy + Math.sin(aj) * dj, 3.6, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      if (state.radarSeries.s3) plotPoly(rad.s3, pal.c3, 'rgba(255, 183, 77, 0.12)', 1.8);
      if (state.radarSeries.s2) plotPoly(rad.s2, pal.c2, 'rgba(34, 197, 94, 0.13)', 2.0);
      if (state.radarSeries.s1) plotPoly(rad.s1, pal.c1, 'rgba(0, 115, 230, 0.22)', 2.6);
    }

    /* Chart 3: Horizontal Gradient Bars */
    function drawHorizontalBars() {
      var env = prepareCanvas('chartBars');
      if (!env) return;
      var ctx = env.ctx, w = env.w, h = env.h;
      var pal = getPalette();
      hitRegions.chartBars = [];

      var bc = DATA.barsChart;
      var items = isEn() ? bc.items_en : bc.items_zh;
      var maxX = bc.maxX || 100;
      var pad = { top: 10, right: 18, bottom: 26, left: 18 };
      var pw = w - pad.left - pad.right;
      var ph = h - pad.top - pad.bottom;

      for (var g = 0; g <= 5; g++) {
        var xVal = (maxX / 5) * g;
        var gx = pad.left + (xVal / maxX) * pw;
        ctx.strokeStyle = pal.grid;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(gx, pad.top);
        ctx.lineTo(gx, pad.top + ph);
        ctx.stroke();

        ctx.fillStyle = pal.tick;
        ctx.font = '10.5px "IBM Plex Mono", sans-serif';
        ctx.textAlign = g === 0 ? 'left' : (g === 5 ? 'right' : 'center');
        ctx.textBaseline = 'alphabetic';
        ctx.fillText(fmtTick(xVal, bc.prefix, bc.suffix, bc.axisDecimals || 0), gx, pad.top + ph + 18);
      }

      var colors = [
        ['#3399FF', '#0066CC'],
        ['#22C55E', '#15803D'],
        ['#A78BFA', '#6D28D9'],
        ['#FFB74D', '#D97706'],
        ['#38BDF8', '#0284C7'],
        ['#94A3B8', '#475569']
      ];

      var rowH = ph / items.length;
      for (var i = 0; i < items.length; i++) {
        var rowTop = pad.top + rowH * i;
        if (hoverState.chartBars === i) {
          ctx.fillStyle = pal.hoverBand;
          roundRectPath(ctx, pad.left - 6, rowTop + 2, pw + 12, rowH - 4, 8);
          ctx.fill();
        }

        var labelY = rowTop + Math.max(15, rowH * 0.34);
        var barY = rowTop + Math.max(22, rowH * 0.50);
        var barH = Math.min(15, Math.max(11, rowH * 0.26));
        var bw = Math.max(8, Math.min(pw, (items[i].val / maxX) * pw));
        var cPair = colors[i % colors.length];

        ctx.fillStyle = pal.text;
        ctx.font = '600 ' + (w < 460 ? '11px' : '12px') + ' system-ui, sans-serif';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'alphabetic';
        ctx.fillText(items[i].label, pad.left, labelY);

        var valStr = fmtTick(items[i].val, bc.prefix, bc.suffix, bc.valDecimals != null ? bc.valDecimals : 1);
        ctx.font = '800 12.5px "IBM Plex Mono", sans-serif';
        ctx.fillStyle = pal.isDark ? cPair[0] : cPair[1];
        ctx.textAlign = 'right';
        ctx.fillText(valStr, pad.left + pw, labelY);

        if (w >= 580 && items[i].sub) {
          var valW = ctx.measureText(valStr).width + 10;
          ctx.font = '500 11px "IBM Plex Mono", system-ui, sans-serif';
          ctx.fillStyle = pal.tick;
          ctx.fillText(items[i].sub, pad.left + pw - valW, labelY);
        }

        ctx.fillStyle = pal.trackBg;
        roundRectPath(ctx, pad.left, barY, pw, barH, barH / 2);
        ctx.fill();

        var barGrad = ctx.createLinearGradient(pad.left, 0, pad.left + bw, 0);
        barGrad.addColorStop(0, cPair[0]);
        barGrad.addColorStop(1, cPair[1]);
        ctx.fillStyle = barGrad;
        roundRectPath(ctx, pad.left, barY, bw, barH, barH / 2);
        ctx.fill();

        hitRegions.chartBars.push({
          idx: i,
          x: pad.left, y: rowTop, w: pw, h: rowH,
          html: '<strong>' + escapeHtml(items[i].label) + ': ' + valStr + '</strong>' +
                (items[i].sub ? '<br/>&#8226; ' + escapeHtml(items[i].sub) : '') +
                (items[i].note ? '<br/>&#8226; ' + escapeHtml(items[i].note) : '')
        });
      }
    }

    /* Chart 4: Historical 5-Period Bar + Line Combo */
    function drawEpsComboChart() {
      var env = prepareCanvas('chartEps');
      if (!env) return;
      var ctx = env.ctx, w = env.w, h = env.h;
      var pal = getPalette();
      hitRegions.chartEps = [];

      var hc = DATA.histChart;
      var en = isEn();
      var years = en ? hc.labels_en : hc.labels_zh;
      var subYears = en ? hc.subs_en : hc.subs_zh;
      var bars = hc.bars;
      var line = hc.line;

      var pad = { top: 26, right: 56, bottom: 44, left: 54 };
      var pw = w - pad.left - pad.right;
      var ph = h - pad.top - pad.bottom;

      var minB = hc.minB || 0, maxB = hc.maxB;
      var minL = hc.minL, maxL = hc.maxL;

      for (var g = 0; g <= 4; g++) {
        var ratio = g / 4;
        var gy = pad.top + ph - ratio * ph;
        ctx.strokeStyle = pal.grid;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(pad.left, gy);
        ctx.lineTo(pad.left + pw, gy);
        ctx.stroke();

        var bTick = minB + ratio * (maxB - minB);
        var lTick = minL + ratio * (maxL - minL);
        ctx.font = '10.5px "IBM Plex Mono", sans-serif';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = pal.tick;
        ctx.textAlign = 'right';
        ctx.fillText(fmtTick(bTick, hc.pB, hc.uB, hc.dB), pad.left - 7, gy);
        ctx.textAlign = 'left';
        ctx.fillStyle = pal.c2;
        ctx.fillText(fmtTick(lTick, hc.pL, hc.uL, hc.dL), pad.left + pw + 7, gy);
      }

      if (hc.milestoneVal != null) {
        var targetY = pad.top + ph - ((hc.milestoneVal - minL) / (maxL - minL)) * ph;
        ctx.save();
        ctx.setLineDash([5, 5]);
        ctx.strokeStyle = pal.c3;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(pad.left, targetY);
        ctx.lineTo(pad.left + pw, targetY);
        ctx.stroke();
        ctx.restore();
        if (w >= 460) {
          drawValueBadge(ctx, en ? hc.milestone_en : hc.milestone_zh, pad.left + pw * 0.28, Math.max(14, targetY - 12), pal.c3, pal);
        }
      }

      var step = pw / years.length;
      var barW = Math.min(46, Math.max(22, step * 0.42));
      var linePts = [];

      for (var i = 0; i < years.length; i++) {
        var cx = pad.left + step * (i + 0.5);
        if (hoverState.chartEps === i) {
          ctx.fillStyle = pal.hoverBand;
          roundRectPath(ctx, pad.left + step * i + 4, pad.top, step - 8, ph, 6);
          ctx.fill();
        }

        if (state.epsSeries.eps) {
          var bh = Math.max(4, ((bars[i] - minB) / (maxB - minB)) * ph);
          var bx = cx - barW / 2;
          var by = pad.top + ph - bh;
          var eGrad = ctx.createLinearGradient(0, by, 0, pad.top + ph);
          if (i === years.length - 1) {
            eGrad.addColorStop(0, '#66B2FF');
            eGrad.addColorStop(1, '#1985F1');
          } else {
            eGrad.addColorStop(0, '#3399FF');
            eGrad.addColorStop(1, '#0066CC');
          }
          ctx.fillStyle = eGrad;
          topRoundedBar(ctx, bx, by, barW, bh, 6);
          ctx.fill();

          if (bh > 20) {
            ctx.fillStyle = '#FFFFFF';
            ctx.font = '700 10px "IBM Plex Mono", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'alphabetic';
            ctx.fillText(fmtTick(bars[i], hc.pB, hc.uB, hc.dB), cx, by + 16);
          }
        }

        var oy = pad.top + ph - ((line[i] - minL) / (maxL - minL)) * ph;
        linePts.push({ x: cx, y: oy, val: line[i] });

        ctx.fillStyle = pal.text;
        ctx.font = '700 11px system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'alphabetic';
        ctx.fillText(years[i], cx, pad.top + ph + 19);
        if (subYears && subYears[i]) {
          ctx.fillStyle = pal.tick;
          ctx.font = '10px system-ui, sans-serif';
          ctx.fillText(subYears[i], cx, pad.top + ph + 33);
        }

        var extraNote = (en ? hc.notes_en : hc.notes_zh)[i] || '';
        hitRegions.chartEps.push({
          idx: i,
          x: pad.left + step * i, y: pad.top, w: step, h: ph + 36,
          html: '<strong>' + escapeHtml(years[i] + (subYears && subYears[i] ? ' ' + subYears[i] : '')) + '</strong><br/>' +
                '&#8226; ' + escapeHtml(en ? hc.legend.bar_en : hc.legend.bar_zh) + ': <strong>' + fmtTick(bars[i], hc.pB, hc.uB, hc.dB) + '</strong><br/>' +
                '&#8226; ' + escapeHtml(en ? hc.legend.line_en : hc.legend.line_zh) + ': <strong>' + fmtTick(line[i], hc.pL, hc.uL, hc.dL) + '</strong>' +
                (extraNote ? '<br/>&#8226; ' + escapeHtml(extraNote) : '')
        });
      }

      if (state.epsSeries.oci) {
        ctx.save();
        drawSmoothLine(ctx, linePts);
        ctx.strokeStyle = pal.c2;
        ctx.lineWidth = 2.8;
        ctx.stroke();
        ctx.restore();

        for (var m = 0; m < linePts.length; m++) {
          ctx.fillStyle = pal.pillBg;
          ctx.beginPath();
          ctx.arc(linePts[m].x, linePts[m].y, 6, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = pal.c2;
          ctx.beginPath();
          ctx.arc(linePts[m].x, linePts[m].y, 4.2, 0, Math.PI * 2);
          ctx.fill();
          drawValueBadge(ctx, fmtTick(linePts[m].val, hc.pL, hc.uL, hc.dL), linePts[m].x, Math.max(14, linePts[m].y - 16), pal.c2, pal);
        }
      }
    }

    /* Chart 5: Interactive Simulator Dual-Curve Projection */
    function drawSimChart() {
      var env = prepareCanvas('chartSim');
      if (!env) return;
      var ctx = env.ctx, w = env.w, h = env.h;
      var pal = getPalette();
      hitRegions.chartSim = [];

      var en = isEn();
      var m = computeSimModel(state.sim, en);
      var activeArr = m.activeSeries;
      var baseArr = m.baseSeries;
      var xLabels = en ? DATA.simConfig.xLabelsEn : DATA.simConfig.xLabelsZh;
      var n = activeArr.length - 1;

      var maxVal = 1;
      for (var z = 0; z <= n; z++) {
        if (activeArr[z] > maxVal) maxVal = activeArr[z];
        if (baseArr[z] > maxVal) maxVal = baseArr[z];
      }
      maxVal = maxVal * 1.12;

      var pad = { top: 20, right: 22, bottom: 28, left: 60 };
      var pw = w - pad.left - pad.right;
      var ph = h - pad.top - pad.bottom;

      for (var g = 0; g <= 3; g++) {
        var v = (maxVal / 3) * g;
        var gy = pad.top + ph - (g / 3) * ph;
        ctx.strokeStyle = pal.grid;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(pad.left, gy);
        ctx.lineTo(pad.left + pw, gy);
        ctx.stroke();

        ctx.fillStyle = pal.tick;
        ctx.font = '10.5px "IBM Plex Mono", sans-serif';
        ctx.textAlign = 'right';
        ctx.textBaseline = 'middle';
        ctx.fillText(m.formatY(v), pad.left - 7, gy);
      }

      var stepX = pw / n;

      ctx.save();
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = pal.tick;
      ctx.lineWidth = 1.7;
      ctx.beginPath();
      for (var i = 0; i <= n; i++) {
        var px = pad.left + (i / n) * pw;
        var py = pad.top + ph - (baseArr[i] / maxVal) * ph;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.stroke();
      ctx.restore();

      ctx.beginPath();
      for (var j = 0; j <= n; j++) {
        var tx = pad.left + (j / n) * pw;
        var ty = pad.top + ph - (activeArr[j] / maxVal) * ph;
        if (j === 0) ctx.moveTo(tx, ty);
        else ctx.lineTo(tx, ty);

        var diff = activeArr[j] - baseArr[j];
        var xLbl = xLabels[j] || ('T+' + j);
        hitRegions.chartSim.push({
          idx: j,
          x: tx - Math.max(8, stepX * 0.5), y: pad.top, w: Math.max(16, stepX), h: ph + 24,
          html: '<strong>' + escapeHtml(xLbl) + '</strong><br/>' +
                '&#8226; ' + escapeHtml(en ? DATA.simConfig.activeCurveLabelEn : DATA.simConfig.activeCurveLabelZh) + ': <strong>' + m.formatY(activeArr[j]) + '</strong><br/>' +
                '&#8226; ' + escapeHtml(en ? DATA.simConfig.baseCurveLabelEn : DATA.simConfig.baseCurveLabelZh) + ': ' + m.formatY(baseArr[j]) + '<br/>' +
                '&#8226; Delta: <strong style="color:#22C55E;">' + (diff >= 0 ? '+' : '-') + m.formatY(Math.abs(diff)) + '</strong>'
        });
      }
      ctx.strokeStyle = pal.c1;
      ctx.lineWidth = 2.8;
      ctx.stroke();

      ctx.lineTo(pad.left + pw, pad.top + ph);
      ctx.lineTo(pad.left, pad.top + ph);
      ctx.closePath();
      var grad = ctx.createLinearGradient(0, pad.top, 0, pad.top + ph);
      grad.addColorStop(0, 'rgba(0, 115, 230, 0.28)');
      grad.addColorStop(1, 'rgba(0, 115, 230, 0.01)');
      ctx.fillStyle = grad;
      ctx.fill();

      for (var km = 0; km <= n; km++) {
        var kx = pad.left + (km / n) * pw;
        var ky = pad.top + ph - (activeArr[km] / maxVal) * ph;
        ctx.fillStyle = pal.pillBg;
        ctx.beginPath();
        ctx.arc(kx, ky, 4.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = pal.c1;
        ctx.beginPath();
        ctx.arc(kx, ky, 3.2, 0, Math.PI * 2);
        ctx.fill();
      }

      var endX = pad.left + pw;
      var endY = pad.top + ph - (activeArr[n] / maxVal) * ph;
      drawValueBadge(ctx, m.formatY(activeArr[n]), Math.min(w - 44, endX - 24), Math.max(pad.top + 12, endY - 14), pal.c1, pal);

      ctx.fillStyle = pal.tick;
      ctx.font = '10.5px "IBM Plex Mono", sans-serif';
      ctx.textBaseline = 'alphabetic';
      for (var xl = 0; xl <= n; xl++) {
        if (n > 6 && xl !== 0 && xl !== Math.floor(n / 2) && xl !== n) continue;
        var xx = pad.left + (xl / n) * pw;
        ctx.textAlign = xl === 0 ? 'left' : (xl === n ? 'right' : 'center');
        ctx.fillText(xLabels[xl] || ('Y' + xl), xx, pad.top + ph + 19);
      }
    }

    var redrawMap = {
      chartCh1: drawCh1Chart,
      chartRadar: drawRadarChart,
      chartBars: drawHorizontalBars,
      chartEps: drawEpsComboChart,
      chartSim: drawSimChart
    };

    function renderAllCharts() {
      drawCh1Chart();
      drawRadarChart();
      drawHorizontalBars();
      drawEpsComboChart();
      drawSimChart();
    }

    function wireCanvasTooltip(canvasId) {
      var canvas = document.getElementById(canvasId);
      var tip = document.getElementById('chartTooltip');
      if (!canvas || !tip) return;

      function handlePointer(clientX, clientY) {
        var rect = canvas.getBoundingClientRect();
        var mx = clientX - rect.left;
        var my = clientY - rect.top;
        var regions = hitRegions[canvasId] || [];
        var found = null;
        for (var i = 0; i < regions.length; i++) {
          var r = regions[i];
          if (mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h) {
            found = r;
            break;
          }
        }
        var nextIdx = found && typeof found.idx === 'number' ? found.idx : -1;
        if (hoverState[canvasId] !== nextIdx) {
          hoverState[canvasId] = nextIdx;
          if (redrawMap[canvasId]) redrawMap[canvasId]();
        }
        if (found) {
          tip.innerHTML = found.html;
          tip.style.display = 'block';
          var tipW = tip.offsetWidth || 250;
          var tipH = tip.offsetHeight || 72;
          var leftPos = clientX + 14;
          if (leftPos + tipW > window.innerWidth - 12) leftPos = Math.max(12, clientX - tipW - 14);
          var topPos = Math.max(12, Math.min(window.innerHeight - tipH - 12, clientY - 18));
          tip.style.left = leftPos + 'px';
          tip.style.top = topPos + 'px';
        } else {
          tip.style.display = 'none';
        }
      }

      canvas.addEventListener('mousemove', function (e) { handlePointer(e.clientX, e.clientY); });
      canvas.addEventListener('touchstart', function (e) {
        if (e.touches && e.touches[0]) handlePointer(e.touches[0].clientX, e.touches[0].clientY);
      }, { passive: true });
      canvas.addEventListener('mouseleave', function () {
        if (hoverState[canvasId] !== -1) {
          hoverState[canvasId] = -1;
          if (redrawMap[canvasId]) redrawMap[canvasId]();
        }
        tip.style.display = 'none';
      });
    }

    function exportStandaloneHtml() {
      var doctype = '<!DOCTYPE html>\n';
      var htmlContent = doctype + document.documentElement.outerHTML;
      var blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
      var url = URL.createObjectURL(blob);
      var link = document.createElement('a');
      link.href = url;
      link.download = DATA.exportFileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
      showToast(isEn() ? ('Exported standalone file: ' + DATA.exportFileName) : ('已导出独立网页 ' + DATA.exportFileName));
    }

    function init() {
      var rawTheme = safeGetStorage(STORAGE_THEME_KEY);
      var savedTheme = rawTheme ? String(rawTheme).replace(/^"|"$/g, '') : '';
      if (savedTheme === 'light' || savedTheme === 'dark') state.theme = savedTheme;

      var rawLang = safeGetStorage(STORAGE_LANG_KEY);
      var savedLang = rawLang ? String(rawLang).replace(/^"|"$/g, '') : '';
      if (savedLang === 'zh' || savedLang === 'en') state.lang = savedLang;

      window.addEventListener('storage', function (ev) {
        if (ev.key === STORAGE_THEME_KEY && ev.newValue) {
          var nt = String(ev.newValue).replace(/^"|"$/g, '');
          if ((nt === 'light' || nt === 'dark') && nt !== state.theme) applyTheme(nt, true);
        } else if (ev.key === STORAGE_LANG_KEY && ev.newValue) {
          var nl = String(ev.newValue).replace(/^"|"$/g, '');
          if ((nl === 'zh' || nl === 'en') && nl !== state.lang) applyLanguage(nl, true);
        }
      });

      var savedChecks = safeGetStorage(STORAGE_CHECK_KEY);
      if (savedChecks) {
        try {
          var parsed = JSON.parse(savedChecks);
          if (Array.isArray(parsed) && parsed.length === DATA.checklistZh.length) {
            state.checks = parsed.map(Boolean);
          }
        } catch (e) { /* ignore */ }
      }

      applyTheme(state.theme, true);
      applyLanguage(state.lang, true);

      document.getElementById('langZhBtn').addEventListener('click', function () { applyLanguage('zh', false); });
      document.getElementById('langEnBtn').addEventListener('click', function () { applyLanguage('en', false); });
      document.getElementById('appbarThemeBtn').addEventListener('click', function () {
        applyTheme(state.theme === 'dark' ? 'light' : 'dark', false);
      });

      document.getElementById('sidebarToggleBtn').addEventListener('click', toggleSidebar);
      document.getElementById('drawerBackdrop').addEventListener('click', closeMobileDrawer);
      void 0;
      void 0;
      void 0;
      void 0;

      var tocLinks = document.querySelectorAll('#tocNavList .mui-nav-link');
      for (var t = 0; t < tocLinks.length; t++) {
        tocLinks[t].addEventListener('click', closeMobileDrawer);
      }

      var jumpInput = document.getElementById('quickJumpInput');
      var jumpPop = document.getElementById('quickJumpPopover');
      function renderJumpList(q) {
        var kw = (q || '').trim().toLowerCase();
        var activeJump = isEn() ? DATA.quickJumpEn : DATA.quickJumpZh;
        var list = activeJump.filter(function (item, idx) {
          var zhIt = DATA.quickJumpZh[idx] || item;
          var enIt = DATA.quickJumpEn[idx] || item;
          return !kw || (zhIt.title + ' ' + zhIt.sub + ' ' + enIt.title + ' ' + enIt.sub).toLowerCase().indexOf(kw) !== -1;
        });
        if (!list.length) {
          jumpPop.innerHTML = '<div style="padding:10px;font-size:0.78rem;color:var(--text-muted);">' + (isEn() ? 'No matching section' : '未匹配到对应章节') + '</div>';
        } else {
          jumpPop.innerHTML = list.map(function (item) {
            return '<button type="button" class="quick-jump-item" data-jump-sec="' + escapeHtml(item.sec) + '">' +
              '<span class="quick-jump-item-title">' + escapeHtml(item.title) + '</span>' +
              '<span class="quick-jump-item-sub">' + escapeHtml(item.sub) + '</span></button>';
          }).join('');
        }
        jumpPop.classList.add('open');
      }

      jumpInput.addEventListener('focus', function () { renderJumpList(jumpInput.value); });
      jumpInput.addEventListener('input', function () { renderJumpList(jumpInput.value); });
      jumpPop.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-jump-sec]');
        if (!btn) return;
        var secEl = document.getElementById(btn.getAttribute('data-jump-sec'));
        if (secEl) secEl.scrollIntoView({ behavior: 'smooth' });
        jumpPop.classList.remove('open');
      });
      document.addEventListener('click', function (e) {
        if (!e.target.closest('.quick-search-wrap')) jumpPop.classList.remove('open');
      });
      document.addEventListener('keydown', function (e) {
        if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
          e.preventDefault();
          jumpInput.focus();
        } else if (e.key === 'Escape') {
          jumpPop.classList.remove('open');
          closeMobileDrawer();
        }
      });

      var ch1Btns = document.querySelectorAll('[data-ch1-view]');
      for (var c = 0; c < ch1Btns.length; c++) {
        ch1Btns[c].addEventListener('click', function () {
          state.ch1View = this.getAttribute('data-ch1-view');
          document.getElementById('ch1TabA').classList.toggle('active', state.ch1View === 'viewA');
          document.getElementById('ch1TabB').classList.toggle('active', state.ch1View === 'viewB');
          syncCh1HeaderText();
          drawCh1Chart();
        });
      }

      var collapseBtns = document.querySelectorAll('[data-collapse-target]');
      for (var m = 0; m < collapseBtns.length; m++) {
        collapseBtns[m].addEventListener('click', function () {
          var panel = document.getElementById(this.getAttribute('data-collapse-target'));
          if (!panel) return;
          panel.classList.toggle('open');
          syncCollapseButtonsText();
        });
      }

      var pillarCards = document.querySelectorAll('[data-pillar]');
      for (var p = 0; p < pillarCards.length; p++) {
        pillarCards[p].addEventListener('click', function () {
          var idx = parseInt(this.getAttribute('data-pillar'), 10) || 0;
          state.activePillar = idx;
          for (var k = 0; k < pillarCards.length; k++) pillarCards[k].classList.toggle('active', k === idx);
          document.getElementById('pillarFocusNote').innerHTML = '<div>' + (isEn() ? DATA.pillarNotesEn : DATA.pillarNotesZh)[idx] + '</div>';
          drawRadarChart();
        });
      }

      var radarPills = document.querySelectorAll('[data-radar-key]');
      for (var r = 0; r < radarPills.length; r++) {
        radarPills[r].addEventListener('click', function () {
          var key = this.getAttribute('data-radar-key');
          state.radarSeries[key] = !state.radarSeries[key];
          if (!state.radarSeries.s1 && !state.radarSeries.s2 && !state.radarSeries.s3) state.radarSeries[key] = true;
          this.classList.toggle('muted', !state.radarSeries[key]);
          drawRadarChart();
        });
      }

      document.getElementById('peerSearchInput').addEventListener('input', function () {
        state.peerQuery = this.value;
        renderPeerTable();
      });
      var peerFilterBtns = document.querySelectorAll('[data-peer-filter]');
      for (var pf = 0; pf < peerFilterBtns.length; pf++) {
        peerFilterBtns[pf].addEventListener('click', function () {
          state.peerFilter = this.getAttribute('data-peer-filter');
          for (var x = 0; x < peerFilterBtns.length; x++) peerFilterBtns[x].classList.toggle('active', peerFilterBtns[x] === this);
          renderPeerTable();
        });
      }

      var sl1 = document.getElementById('simSlider1');
      var sl2 = document.getElementById('simSlider2');
      var sl3 = document.getElementById('simSlider3');
      var tg = document.getElementById('simToggle');

      sl1.addEventListener('input', function () { state.sim.v1 = parseFloat(this.value); state.sim.preset = ''; updateSimulatorUI(); });
      sl2.addEventListener('input', function () { state.sim.v2 = parseFloat(this.value); state.sim.preset = ''; updateSimulatorUI(); });
      sl3.addEventListener('input', function () { state.sim.v3 = parseFloat(this.value); state.sim.preset = ''; updateSimulatorUI(); });
      tg.addEventListener('change', function () { state.sim.flag = !!this.checked; state.sim.preset = ''; updateSimulatorUI(); });

      var presetBtns = document.querySelectorAll('[data-preset]');
      for (var pb = 0; pb < presetBtns.length; pb++) {
        presetBtns[pb].addEventListener('click', function () {
          var key = this.getAttribute('data-preset');
          var cfg = DATA.simConfig.presets[key];
          if (!cfg) return;
          state.sim.v1 = cfg.v1;
          state.sim.v2 = cfg.v2;
          state.sim.v3 = cfg.v3;
          state.sim.flag = cfg.flag;
          state.sim.preset = key;
          sl1.value = String(cfg.v1);
          sl2.value = String(cfg.v2);
          sl3.value = String(cfg.v3);
          tg.checked = !!cfg.flag;
          updateSimulatorUI();
        });
      }

      document.getElementById('checklistContainer').addEventListener('change', function (e) {
        var input = e.target.closest('[data-check-input]');
        if (!input) return;
        var idx = parseInt(input.getAttribute('data-check-input'), 10);
        state.checks[idx] = !!input.checked;
        safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
        renderChecklist();
      });
      document.getElementById('checkAllBtn').addEventListener('click', function () {
        state.checks = [true, true, true, true, true, true];
        safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
        renderChecklist();
        showToast(isEn() ? 'Checked all 6 diagnostic criteria' : '已勾选全部 6 项核心核查指标');
      });
      document.getElementById('resetCheckBtn').addEventListener('click', function () {
        state.checks = [true, true, true, false, false, false];
        safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
        renderChecklist();
        showToast(isEn() ? 'Checklist reset to baseline (50%)' : '核查清单已恢复默认基准状态 (50%)');
      });

      function updateScrollProgress() {
        var docEl = document.documentElement;
        var scrollTop = window.scrollY || docEl.scrollTop || 0;
        var maxScroll = Math.max(1, docEl.scrollHeight - window.innerHeight);
        var pct = Math.min(100, Math.max(0, (scrollTop / maxScroll) * 100));
        document.getElementById('readingProgressBar').style.width = pct + '%';
      }
      window.addEventListener('scroll', updateScrollProgress, { passive: true });
      updateScrollProgress();

      if ('IntersectionObserver' in window) {
        var secObserver = new IntersectionObserver(function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              var id = entry.target.id;
              for (var i = 0; i < tocLinks.length; i++) {
                tocLinks[i].classList.toggle('active', tocLinks[i].getAttribute('data-sec') === id);
              }
            }
          });
        }, { rootMargin: '-18% 0px -68% 0px', threshold: 0.02 });
        for (var s = 0; s <= 7; s++) {
          var secNode = document.getElementById('sec-0' + s);
          if (secNode) secObserver.observe(secNode);
        }
      }

      wireCanvasTooltip('chartCh1');
      wireCanvasTooltip('chartRadar');
      wireCanvasTooltip('chartBars');
      wireCanvasTooltip('chartEps');
      wireCanvasTooltip('chartSim');

      var ch1SeriesBtns = document.querySelectorAll('[data-ch1-series]');
      for (var csIdx = 0; csIdx < ch1SeriesBtns.length; csIdx++) {
        ch1SeriesBtns[csIdx].addEventListener('click', function () {
          var sk = this.getAttribute('data-ch1-series');
          state.ch1Series[sk] = !state.ch1Series[sk];
          if (!state.ch1Series.s1 && !state.ch1Series.s2) state.ch1Series[sk] = true;
          this.classList.toggle('muted', !state.ch1Series[sk]);
          drawCh1Chart();
        });
      }

      var epsSeriesBtns = document.querySelectorAll('[data-eps-series]');
      for (var esIdx = 0; esIdx < epsSeriesBtns.length; esIdx++) {
        epsSeriesBtns[esIdx].addEventListener('click', function () {
          var ek = this.getAttribute('data-eps-series');
          state.epsSeries[ek] = !state.epsSeries[ek];
          if (!state.epsSeries.eps && !state.epsSeries.oci) state.epsSeries[ek] = true;
          this.classList.toggle('muted', !state.epsSeries[ek]);
          drawEpsComboChart();
        });
      }

      var resizeTimer = null;
      function scheduleRedraw() {
        if (resizeTimer) clearTimeout(resizeTimer);
        resizeTimer = setTimeout(renderAllCharts, 60);
      }
      window.addEventListener('resize', scheduleRedraw);
      if ('ResizeObserver' in window) {
        var mainEl = document.querySelector('.main-content');
        if (mainEl) {
          var ro = new ResizeObserver(scheduleRedraw);
          ro.observe(mainEl);
        }
      }
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    } else {
      init();
    }
  })();
  