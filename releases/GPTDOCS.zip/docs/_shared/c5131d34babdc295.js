
 (function () {
 'use strict';

 /* ======================================================================
 1. Grounded Corporate Datasets & Bilingual State Model
 ====================================================================== */
 var STORAGE_THEME_KEY = 'mui_portal_theme_v4';
 var STORAGE_LANG_KEY = 'mui_portal_lang_v1';
 var STORAGE_CHECK_KEY = 'mui_rblx_corp_checks_v1';

 var DOC_TITLE_ZH = 'Roblox Corporation (NYSE: RBLX) 公司基本面与投资价值深度研究报告 | 数据中心';
 var DOC_TITLE_EN = 'Roblox Corporation (NYSE: RBLX) Equity Research & Corporate Fundamentals Deep Dive | Research Hub';

 var I18N_RICH_LIST = [
 {
 key: 'rc_r00',
 match_zh: 'Roblox Corporation (NYSE: RBLX) 公司基本面与投资价值深度研究报告：',
 zh: 'Roblox Corporation (NYSE: RBLX) 公司基本面与投资价值深度研究报告：<span class="gradient-accent">穿透 GAAP 表观亏损，解码高人效现金流机器与平台估值锚点</span>',
 en: 'Roblox Corporation (NYSE: RBLX) Corporate Fundamentals &amp; Equity Research Deep Dive: <span class="gradient-accent">Looking Past GAAP Losses Into a High-Efficiency Cash Compounder</span>'
 },
 {
 key: 'rc_r01',
 match_zh: '初看财务报表的投资者往往对 Roblox Corporation',
 zh: '初看财务报表的投资者往往对 Roblox Corporation（NYSE: RBLX）产生巨大误判：为什么一家在 FY2025 账面 GAAP 合并净亏损 <strong>$10.72 亿</strong>的公司，同期经营活动现金流却高达 <strong>$17.96 亿</strong>（+118% YoY）、自由现金流高达 <strong>$13.53 亿</strong>（+111% YoY），并在资产负债表上囤积了高达 <strong>$62.38 亿</strong>现金及投资（扣除 $10.09 亿长期债务后净现金达 <strong>$52.29 亿</strong>） <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/q4/Q4-2025-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">FY25 Financials ↗</a> <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/content_files/Q3-2026-Earnings-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">26Q3 Balance Sheet ↗</a>？ 核心秘密在于其独特的<strong>“预收现金 + 27个月递延确认收入 + 外包内容试错成本”</strong>商业架构：玩家充值 Robux 时公司即刻收到真金白银（计入 Bookings 与递延收入负债池，截至 26Q3 递延收入总额已膨胀至 <strong>$70.40 亿</strong>），而会计准则要求将收入分摊至 27 个月确认，研发、服务器与创作者分成（DevEx）却在当期全额费用化。 不同于传统游戏巨头动辄雇佣上万名美术策划押注单一 3A 续作，Roblox 总部仅凭 <strong>3,065 名全职员工</strong>（人均创造 Bookings 高达 <strong>$221 万</strong>）聚焦底层引擎、AI 模型与混合云基建 <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/ar/Roblox-2025-Annual-Report-and-2026-Proxy-Statement_Bookmarked.pdf" target="_blank" rel="noopener noreferrer">2026 Proxy &amp; AR ↗</a>。 2025 年 6 月新任 CFO <strong>Naveen Chopra</strong> 履新后，于 2026 年 5 月推出公司史上首个 <strong>$30 亿股票回购计划</strong>（前三季度已斥资 $5.80 亿注销 1,260 万股），标志着 Roblox 正式迈入规模扩张与股东资本纪律并重的新阶段 <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html" target="_blank" rel="noopener noreferrer">26Q3 Form 10-Q ↗</a>。',
 en: 'First-time readers of Roblox Corporation\'s (NYSE: RBLX) income statement often misread its economics: how did a company reporting a FY2025 GAAP net loss of <strong>$(1.07)B</strong> simultaneously generate <strong>$1.80B</strong> in operating cash flow (+118% YoY), <strong>$1.35B</strong> in free cash flow (+111% YoY), and amass <strong>$6.24B</strong> in cash and investments (<strong>$5.23B</strong> in net cash after $1.01B of debt) <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/q4/Q4-2025-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">FY25 Financials ↗</a> <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/content_files/Q3-2026-Earnings-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">26Q3 Balance Sheet ↗</a>? The answer lies in its <strong>"upfront Robux cash collection + 27-month deferred GAAP revenue amortization + outsourced content R&amp;D risk"</strong> model: cash arrives on day one (building a <strong>$7.04B</strong> deferred revenue pool as of Q3 2026), whereas DevEx, cloud hosting, and R&amp;D are expensed immediately. Rather than employing 10,000+ studio developers betting on single AAA sequels, Roblox employs just <strong>3,065 full-time staff</strong> (generating <strong>$2.21M</strong> in Bookings/employee) focused on core engine, AI, and cloud infrastructure <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/ar/Roblox-2025-Annual-Report-and-2026-Proxy-Statement_Bookmarked.pdf" target="_blank" rel="noopener noreferrer">2026 Proxy &amp; AR ↗</a>. Under CFO <strong>Naveen Chopra</strong> (appointed June 2025), Roblox launched an inaugural <strong>$3.0B share repurchase program</strong> in May 2026 ($580M / 12.6M shares retired in 9M26), entering a mature era of disciplined capital allocation <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html" target="_blank" rel="noopener noreferrer">26Q3 Form 10-Q ↗</a>.'
 },
 {
 key: 'rc_r02',
 match_zh: 'FY25 全职员工 3,065 人（超 60% 为研发工程师）',
 zh: 'FY25 全职员工 3,065 人（超 60% 为研发工程师），人均创造 $221 万 Bookings 与 $44.1 万自由现金流 <a class="cite-link" href="https://bullfincher.io/companies/roblox-corporation/number-of-employees" target="_blank" rel="noopener noreferrer">10-K Headcount ↗</a>。',
 en: '3,065 FTEs in FY25 (>60% engineers), generating $2.21M in Bookings and $441K in free cash flow per employee <a class="cite-link" href="https://bullfincher.io/companies/roblox-corporation/number-of-employees" target="_blank" rel="noopener noreferrer">10-K Headcount ↗</a>.'
 },
 {
 key: 'rc_r03',
 match_zh: 'FY25 自由现金流同比翻倍至 $13.53 亿',
 zh: 'FY25 自由现金流同比翻倍至 $13.53 亿（占 Bookings 19.9%）；2026 前三季度累计再创 $12.56 亿自由现金流 <a class="cite-link" href="https://businessquant.com/metrics/rblx/free-cash-flow" target="_blank" rel="noopener noreferrer">FCF Series ↗</a>。',
 en: 'FY25 FCF more than doubled to $1.35B (19.9% of Bookings), followed by $1.26B of cumulative FCF across 9M 2026 <a class="cite-link" href="https://businessquant.com/metrics/rblx/free-cash-flow" target="_blank" rel="noopener noreferrer">FCF Series ↗</a>.'
 },
 {
 key: 'rc_r04',
 match_zh: '$62.38 亿现金及投资减去 $10.09 亿长期优先票据',
 zh: '$62.38 亿现金及投资减去 $10.09 亿长期优先票据；$70.40 亿递延收入池高确定性锁定未来 27 个月 GAAP 营收增长 <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/content_files/Q3-2026-Earnings-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">26Q3 10-Q ↗</a>。',
 en: '$6.24B cash &amp; investments less $1.01B senior notes; $7.04B deferred revenue locks in 27-month forward GAAP revenue visibility <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/content_files/Q3-2026-Earnings-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">26Q3 10-Q ↗</a>.'
 },
 {
 key: 'rc_r05',
 match_zh: '管理层在 2023–2024 年严控编制',
 zh: '管理层在 2023–2024 年严控编制（FY24 员工仅净增 17 人，+0.69%），待 2025 年业务爆发后精准扩充 AI 与基建工程师至 3,065 人，使 25Q4 不含 SBC 人员费用占 Bookings 比重骤降 346 bps 至 11.2% <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/q4/Q4-2025-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">Cost Leverage ↗</a>。',
 en: 'Held FY24 headcount nearly flat (+17 FTEs, +0.69%) before selectively scaling AI/infra engineers to 3,065 in FY25—driving Q4 2025 cash personnel costs down 346 bps YoY to 11.2% of Bookings <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/q4/Q4-2025-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">Cost Leverage ↗</a>.'
 },
 {
 key: 'rc_r06',
 match_zh: '顺应全球应用商店监管松绑',
 zh: '顺应全球应用商店监管松绑，重构“Buy Robux”购买动线引导用户转向网页直充与预付礼品卡等低费率第一方渠道，推动支付处理费占 Bookings 比例进入多年期下行通道 <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/content_files/Q3-2026-Earnings-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">26Q3 COR ↗</a>。',
 en: 'Redesigned "Buy Robux" flows to steer purchases toward lower-fee direct web and prepaid channels, unlocking multi-year gross margin expansion <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/content_files/Q3-2026-Earnings-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">26Q3 COR ↗</a>.'
 },
 {
 key: 'rc_r07',
 match_zh: '将安全审核、推荐与 3D 生成等高频负载',
 zh: '将安全审核、推荐与 3D 生成等高频负载从第三方云迁回自有 GPU 数据中心，特定 AI 负载效率提升达 10 倍，在支撑日活翻倍的同时长期压降单小时服务成本（Cost-to-Serve） <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/q4/Q4-2025-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">Infra ROI ↗</a>。',
 en: 'Migrating AI moderation, discovery, and generation workloads from 3P cloud to Roblox-owned GPU data centers delivered 10x efficiency gains on key workloads while lowering long-term Cost-to-Serve <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/q4/Q4-2025-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">Infra ROI ↗</a>.'
 },
 {
 key: 'rc_r08',
 match_zh: '2025–2026 财务掌舵升级：CFO Naveen Chopra',
 zh: '<strong>2025–2026 财务掌舵升级：CFO Naveen Chopra 推动“$30亿股票回购 + 告别年度指引噪音”</strong> —— 前派拉蒙 CFO Naveen Chopra 于 2025 年 6 月接替功勋 CFO Michael Guthrie，一方面启动公司史上首个 $30 亿回购计划控制股本稀释，另一方面宣布自 2027 年起全面转向“季度指引 + 长期 20%+ 复合增长框架”，引导华尔街聚焦多年期自由现金流复利 <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html" target="_blank" rel="noopener noreferrer">Buyback &amp; Guidance ↗</a>。',
 en: '<strong>2025–2026 Financial Stewardship Upgrade: CFO Naveen Chopra Launches $3B Buyback &amp; Guidance Reset</strong> — Joining in June 2025 to succeed Michael Guthrie, Chopra initiated Roblox\'s first $3.0B share repurchase program while shifting toward quarterly outlooks anchored on a 20%+ multi-year growth framework <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html" target="_blank" rel="noopener noreferrer">Buyback &amp; Guidance ↗</a>.'
 },
 {
 key: 'rc_r09',
 match_zh: 'Roblox 实行 Class A（1票/股）与 Class B',
 zh: 'Roblox 实行 Class A（1票/股）与 Class B（20票/股）双层股权架构，创始人兼 CEO David Baszucki 掌握公司绝对多数表决权，且自 2021 年上市以来领取 $0 基本现金年薪，薪酬完全绑定长期市值与经营里程碑期权 <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/ar/Roblox-2025-Annual-Report-and-2026-Proxy-Statement_Bookmarked.pdf" target="_blank" rel="noopener noreferrer">2026 Proxy ↗</a>。',
 en: 'Under a dual-class Class A (1 vote) and Class B (20 votes) structure, founder &amp; CEO David Baszucki holds majority voting control while taking a $0 base salary tied to long-term performance equity <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/ar/Roblox-2025-Annual-Report-and-2026-Proxy-Statement_Bookmarked.pdf" target="_blank" rel="noopener noreferrer">2026 Proxy ↗</a>.'
 },
 {
 key: 'rc_r10',
 match_zh: '作为硅谷顶级工程人才聚集地，FY2025 股权激励费用',
 zh: '作为硅谷顶级工程人才聚集地，FY2025 股权激励费用（SBC）达 $11.29 亿（占营收 23.1%）。随着自由现金流跨过十亿美元大关，董事会于 2026 年 5 月批准 $30 亿回购计划，9M26 已回购注销 1,260 万股 Class A 股票，将完全稀释股本同比增速压制在 2%（7.55 亿股） <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html" target="_blank" rel="noopener noreferrer">26Q3 Share Count ↗</a>。',
 en: 'With FY25 SBC at $1.13B (23.1% of revenue), the Board authorized a $3.0B buyback in May 2026—retiring 12.6M Class A shares ($580M) in 9M26 and capping fully diluted share growth at +2% YoY (755M shares) <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html" target="_blank" rel="noopener noreferrer">26Q3 Share Count ↗</a>.'
 },
 {
 key: 'rc_r11',
 match_zh: 'FY2025 购置物业与服务器设备资本开支为 $4.41 亿',
 zh: 'FY2025 购置物业与服务器设备资本开支为 $4.41 亿；2026 年公司一方面扩建第三座自有核心数据中心及全球边缘节点（部分 Q3 预算顺延至 Q4 集中交付约 $3.80 亿），另一方面签署自 2026 年 7 月起三年合计 $8.45 亿的云托管采购承诺以承接突发爆款洪峰 <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html" target="_blank" rel="noopener noreferrer">Hosting Commitment ↗</a>。',
 en: 'Following $441M of FY25 CapEx, Roblox is adding a third core data center (~$380M Q4\'26 CapEx shift) alongside an $845M three-year cloud hosting commitment starting July 2026 for burst elasticity <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html" target="_blank" rel="noopener noreferrer">Hosting Commitment ↗</a>.'
 },
 {
 key: 'rc_r12',
 match_zh: '面对 2024 年做空机构报告及多州总检察长',
 zh: '面对 2024 年做空机构报告及多州总检察长针对青少年安全的调查，公司在 2026 前三季度主动与阿拉巴马、密西西比、内华达、南达科他、西弗吉尼亚及堪萨斯等州达成和解并一次性计提 $1.40 亿现金义务，同步用全球 64% DAU 强制年龄核验重塑监管互信 <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html" target="_blank" rel="noopener noreferrer">Legal Accrual 10-Q ↗</a>。',
 en: 'Addressing youth-safety inquiries, Roblox accrued $140M in 9M 2026 for settlements across six states (AL, MS, NV, SD, WV, KS) while rolling out mandatory chat age-checks across 64% of global DAUs <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html" target="_blank" rel="noopener noreferrer">Legal Accrual 10-Q ↗</a>.'
 },
 {
 key: 'rc_r13',
 match_zh: '1. 回调后的估值性价比凸显：',
 zh: '<strong>1. 回调后的估值性价比凸显：</strong>股价自 52 周高点（$99.98）回撤逾半至 $47.11，剔除 $52.3 亿净现金后企业价值约 $286 亿，仅约 21 倍 FY25 自由现金流，处于上市以来最具吸引力的现金流估值带 <a class="cite-link" href="https://ir.roblox.com/financials/quarterly-results/default.aspx" target="_blank" rel="noopener noreferrer">Market Valuation ↗</a>。<br/> <strong>2. 高毛利广告与 O18 变现共振：</strong>美国已核验 O18 用户占比升至 37%（单客变现高 50%+），叠加激励视频与可跳过贴片广告放量，有望驱动利润率突破历史上限。<br/> <strong>3. 直充降本与回购双击：</strong>第一方支付渠道占比提升叠加 $24 亿剩余回购火力，持续增厚每股自由现金流（FCF/Share）。',
 en: '<strong>1. Compelling Post-Pullback Valuation:</strong> Down from a $99.98 52-week high to $47.11, Enterprise Value (~$28.6B ex-$5.23B net cash) trades at ~21x FY25 FCF—its most attractive cash-flow multiple since listing <a class="cite-link" href="https://ir.roblox.com/financials/quarterly-results/default.aspx" target="_blank" rel="noopener noreferrer">Market Valuation ↗</a>.<br/> <strong>2. High-Margin Ads + O18 Mix Shift:</strong> Verified U.S. O18 share hit 37% (50%+ higher monetization), pairing with Rewarded Video and pre-roll ads to expand long-term margins.<br/> <strong>3. Direct Billing + $2.4B Buyback Firepower:</strong> 1P payment fee leverage and ongoing share retirements compound FCF per diluted share.'
 },
 {
 key: 'rc_r14',
 match_zh: '1. 短期 Bookings 负增长与指引真空预期差：',
 zh: '<strong>1. 短期 Bookings 负增长与指引真空预期差：</strong>受 2025 下半年超级爆款高基数及 2026 年 11 月 19 日《GTA VI》发售分流影响，26Q4 Bookings 指引同比下降 10%–15%，且取消年度指引放大了季度财报日股价波动（如 26Q2/Q3 财报后单日剧烈回调） <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/8-k-roblox-corp-reports-material-event-bf64854e48ab.html" target="_blank" rel="noopener noreferrer">Q4 Outlook 8-K ↗</a>。<br/> <strong>2. 高额 SBC 与内部人例行减持争议：</strong>年均超 $11 亿的股权激励及 2024–2025 高位期间管理层按 10b5-1 计划累计逾 $10 亿的二级市场售股，曾引发中小股东对治理对齐度的质疑 <a class="cite-link" href="https://compbrief.velarion.ai/brief/rblx" target="_blank" rel="noopener noreferrer">Form 4 &amp; Comp ↗</a>。<br/> <strong>3. 未决州级诉讼与算力资本开支爬坡：</strong>除已计提的 $1.40 亿六州和解金外，其余辖区儿童保护与年龄核验披露相关集体诉讼仍可能带来额外合规成本。',
 en: '<strong>1. Near-Term Bookings Comps &amp; GTA VI Headwind:</strong> Lapping 2H25 viral peaks plus the Nov 19, 2026 launch of <em>GTA VI</em>, Q4 2026 Bookings are guided down 10%–15% YoY while dropping annual guidance increases post-earnings volatility <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/8-k-roblox-corp-reports-material-event-bf64854e48ab.html" target="_blank" rel="noopener noreferrer">Q4 Outlook 8-K ↗</a>.<br/> <strong>2. Elevated SBC &amp; 10b5-1 Insider Sales:</strong> >$1.1B annual SBC and scheduled 10b5-1 executive sales during 2025 highs remain key governance watchpoints <a class="cite-link" href="https://compbrief.velarion.ai/brief/rblx" target="_blank" rel="noopener noreferrer">Form 4 &amp; Comp ↗</a>.<br/> <strong>3. Residual Litigation &amp; AI CapEx Cycle:</strong> Unresolved state/securities matters beyond the $140M accrual and elevated data-center CapEx weigh on near-term quarterly FCF.'
 },
 {
 key: 'rc_r15',
 match_zh: '2021 年 3 月以 DPO（直接上市）登陆 NYSE',
 zh: '2021 年 3 月以 DPO（直接上市）登陆 NYSE，并于 2021 年秋利率谷底精准发行 $10 亿 3.875% 2030 年到期优先票据充实储备；经历 2022 年 FCF 短暂转负（-$5,840 万）后，于 2023 年投资人日确立“Bookings 增速跑赢固定成本”纪律，2024 年全员仅净增 0.69% 即实现 FCF 暴涨 417% 至 $6.41 亿 <a class="cite-link" href="https://ir.roblox.com/news/news-details/2025/Roblox-Reports-Fourth-Quarter-and-Full-Year-2024-Financial-Results/default.aspx" target="_blank" rel="noopener noreferrer">FY24 Turnaround ↗</a>。',
 en: 'Completed its NYSE Direct Listing in March 2021 and locked in $1.0B of 3.875% 2030 Senior Notes at rate lows; after FY22 FCF dipped to -$58.4M, strict hiring discipline (+0.69% FTEs in FY24) drove FY24 FCF up +417% to $641.3M <a class="cite-link" href="https://ir.roblox.com/news/news-details/2025/Roblox-Reports-Fourth-Quarter-and-Full-Year-2024-Financial-Results/default.aspx" target="_blank" rel="noopener noreferrer">FY24 Turnaround ↗</a>.'
 },
 {
 key: 'rc_r16',
 match_zh: 'FY2025 经营现金流突破 $18 亿大关',
 zh: 'FY2025 经营现金流突破 $18 亿大关；2025 年 6 月引入资深媒体科技 CFO Naveen Chopra，2026 年相继落地全球强制年龄核验、$30 亿首期股票回购及 AI 原生工具链（Cube 4D / Build / Universal Player），构建具备强自我修复力的成熟平台治理体系 <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/content_files/Q3-2026-Earnings-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">26Q3 Strategy ↗</a>。',
 en: 'FY2025 OCF reached $1.80B; under CFO Naveen Chopra (joined June 2025), Roblox paired global age-checks and AI platform bets (Cube 4D / Build / Universal Player) with an inaugural $3.0B share buyback <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/content_files/Q3-2026-Earnings-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">26Q3 Strategy ↗</a>.'
 },
 {
 key: 'rc_r17',
 match_zh: '在美联储激进加息前夕发行 2030 年到期固定低息票据',
 zh: '在美联储激进加息前夕发行 2030 年到期固定低息票据，随后将逾 $50 亿–$60 亿现金与投资配置于高收益美债组合，使 FY25 利息收入（$2.02 亿）接近利息支出（$4,150 万）的 5 倍 <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/q4/Q4-2025-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">Net Interest ↗</a>。',
 en: 'Issued fixed-rate 2030 notes right before Fed rate hikes and invested $5B–$6B+ of cash/float in higher-yielding securities—earning $201.6M of FY25 interest income vs. just $41.5M of interest expense <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/q4/Q4-2025-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">Net Interest ↗</a>.'
 },
 {
 key: 'rc_r18',
 match_zh: '区别于硅谷同行先盲目扩招再剧烈裁员的震荡做法',
 zh: '区别于硅谷同行先盲目扩招再剧烈裁员的震荡做法，Roblox 在 FY24 将员工总数稳控在 2,474 人（同比 +0.69%），依靠 24% 的 Bookings 自然增长释放超 620 bps 利润率改善 <a class="cite-link" href="https://bullfincher.io/companies/roblox-corporation/number-of-employees" target="_blank" rel="noopener noreferrer">Workforce Discipline ↗</a>。',
 en: 'Avoiding boom-and-bust mass layoffs, Roblox held FY24 headcount at 2,474 (+0.69% YoY) while 24% Bookings growth delivered >620 bps of operating margin improvement <a class="cite-link" href="https://bullfincher.io/companies/roblox-corporation/number-of-employees" target="_blank" rel="noopener noreferrer">Workforce Discipline ↗</a>.'
 },
 {
 key: 'rc_r19',
 match_zh: '在现金流充裕期主动将标准 DevEx 费率上调 8.5%',
 zh: '在现金流充裕期主动将标准 DevEx 费率上调 8.5% 并推出美国 O18 高阶费率（$0.0054），虽短期抬升约 140 bps 分成成本率，却锁死了全球最顶尖的原生 AI 与年轻游戏开发者生态 <a class="cite-link" href="https://create.roblox.com/docs/production/monetization/developer-exchange" target="_blank" rel="noopener noreferrer">DevEx Policy ↗</a>。',
 en: 'Reinvested scale leverage into an +8.5% DevEx hike and the $0.0054 U.S. O18 rate—trading ~140 bps of near-term margin to lock in top creator talent <a class="cite-link" href="https://create.roblox.com/docs/production/monetization/developer-exchange" target="_blank" rel="noopener noreferrer">DevEx Policy ↗</a>.'
 },
 {
 key: 'rc_r20',
 match_zh: '2026 年中股价随高基数指引回调之际',
 zh: '2026 年中股价随高基数指引回调之际，管理层迅速启用 $30 亿首期回购额度，在前三季度以约 $46/股均价注销 1,260 万股，首次向二级市场验证了逆周期资本配置能力 <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html" target="_blank" rel="noopener noreferrer">9M26 Buybacks ↗</a>。',
 en: 'Capitalizing on mid-2026 share pullbacks, management retired 12.6M shares for $580M (~$46/sh average) across 9M 2026, proving counter-cyclical capital discipline <a class="cite-link" href="https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html" target="_blank" rel="noopener noreferrer">9M26 Buybacks ↗</a>.'
 }
 ];

 var I18N_TEXT_PAIRS = [
 ['数据中心', 'Research Hub'],
 ['Roblox Corporation (RBLX) 公司基本面与投资价值研报', 'Roblox Corp (RBLX) Corporate & Equity Research Report'],
 ['Roblox 公司深度研报', 'Roblox Corp Equity Report'],
 ['负营运资本现金流机器 × $70.4亿递延收入池 × 3,065人撬动 $67.9亿 Bookings 的高杠杆双边平台', 'Negative Working Capital × $7.04B Deferred Pool × $6.79B Bookings from 3,065 FTEs'],
 ['股价 / 基础总市值', 'Price / Basic Mkt Cap'],
 ['FY25 人效 (Bookings)', 'FY25 Bookings / FTE'],
 ['3,065人 · $2.21M/人', '3,065 FTE · $2.21M'],
 ['净现金 / 剩余回购', 'Net Cash / Buyback Left'],
 ['站点与关联导航', 'Site & Related Nav'],
 ['返回数据中心首页', 'Back to Research Hub'],
 ['Roblox SEC 10-K / 10-Q 档案库', 'Roblox SEC Filings Hub'],
 ['核心研究章节 (00 – 07)', 'Report Chapters (00 – 07)'],
 ['执行摘要与公司估值快照', 'Executive Summary & Valuation'],
 ['公司架构、人效与管理治理', 'Corporate Model & Governance'],
 ['四大企业护城河与财务雷达', '4 Corporate Moats & Radar'],
 ['全球上市游戏公司估值对比', 'Public Gaming Peer Valuation'],
 ['递延会计拆解与估值模拟器', 'Deferral Accounting & DCF Sim'],
 ['公司三代演进与资本复盘', 'Corporate Evolution & Capital'],
 ['机构投资者尽调核查清单', 'Investor Due-Diligence Checklist'],
 ['SEC 监管文件与财报索引', 'SEC Filings & Primary Sources'],
 ['阅读与导出工具', 'Reading & Export Tools'],
 ['浅色外观', 'Light'],
 ['深色外观', 'Dark'],
 ['导出 HTML', 'Export HTML'],
 ['打印 / PDF', 'Print / PDF'],
 ['商业模式定评：零单作研发风险的“负营运资本云平台复利机”', 'Verdict: Zero-Hit-Risk Negative Working Capital Cloud Platform Compounder'],
 ['研究横跨：DPO 直接上市 (2021) · 现金流拐点 (2023–2025) · $30亿首期回购与资本升级 (2026 Q3+)', 'Scope: Direct Listing (2021) · FCF Inflection (2023–25) · $3B Buyback Era (Q3 2026+)'],
 ['行情基准：2026-11-19 ($47.11)', 'Market Price: Nov 19, 2026 ($47.11)'],
 ['EQUITY THESIS · $70.4亿递延浮存金 × 3,065人创造 $67.9亿 Bookings × $52.3亿净现金堡垒 × $30亿回购抵消稀释', 'EQUITY THESIS · $7.04B Deferred Float × $6.79B Bookings on 3,065 FTEs × $5.23B Net Cash × $3B Buyback'],
 ['外包内容风险的极简高人效组织', 'Outsourced Content Risk & Elite Productivity'],
 ['将高风险的“玩法创意试错”交由数百万外部创作者按结果分成（DevEx 占 Bookings 约 22%–24%），公司仅保留 3,065 名核心工程与 AI 人才，FY25 人均 Bookings 达 $2.21M。', 'Externalizes hit-or-miss game studio R&D to millions of performance-paid creators (DevEx ~22%–24% of Bookings), generating $2.21M Bookings/FTE with 3,065 staff.'],
 ['$70.4亿递延浮存金与负营运资本', '$7.04B Deferred Float & Negative Working Capital'],
 ['先收全款、后分摊确认收入的 Robux 预付机制创造庞大无息浮存金，仅利息收入在 FY25 即贡献 $2.02 亿（26Q3 单季利息收入 $6,000 万），完全覆盖 $4,150 万年债务利息。', 'Upfront Robux purchases build a massive zero-cost float—earning $201.6M in FY25 interest income ($60M in Q3 26 alone), nearly 5x annual debt interest ($41.5M).'],
 ['创始人长期主义 × $30亿回购纪律', 'Founder Super-Voting Horizon × $3B Buyback'],
 ['创始人 David Baszucki 凭 Class B（20票/股）超级投票权锁定十年级 AI 与基建投入，同时新任 CFO 启动 $30 亿常态化股票回购对冲员工股权激励（SBC）摊薄。', 'Founder David Baszucki\'s Class B (20-vote) control protects multi-year AI/infra bets while CFO Naveen Chopra executes a $3.0B buyback to offset SBC dilution.'],
 ['市值与企业价值 EV (2026.11)', 'Market Cap & EV (Nov 2026)'],
 ['股价 $47.11', 'Price $47.11'],
 ['基础市值 $338.4 亿（按 7.55 亿完全稀释股计 $355.7 亿），剔除 $52.3 亿净现金后 EV 约 $286 亿–$303 亿（约 4.2x EV/FY26E Bookings）。', '$33.84B basic market cap ($35.57B on 755M diluted shares); ex-$5.23B net cash, EV stands at ~$28.6B–$30.3B (~4.2x EV/FY26E Bookings).'],
 ['员工总数与人均 Bookings (FY25)', 'Headcount & Bookings / FTE (FY25)'],
 ['3,065 名全职员工', '3,065 Full-Time Staff'],
 ['自由现金流与转化率 (FY25)', 'Free Cash Flow & Conversion (FY25)'],
 ['净现金储备与递延蓄水池 (26Q3)', 'Net Cash & Deferred Pool (26Q3)'],
 ['递延池 $7.04B', 'Deferred $7.04B'],
 ['一、公司商业架构、人效进化与双层股权治理：3,065 人如何撬动近 70 亿美元年流水？', '1. Corporate Architecture, Workforce Leverage & Dual-Class Governance: $6.8B Bookings on 3,065 Staff'],
 ['创始人超级投票权护航十年级技术路线 × CFO 精细化支付/算力降本与股东回购闭环', 'Founder Super-Voting Long-Termism × CFO Payment/Cloud Margin Leverage & Share Buybacks'],
 ['单一全球报告分部 · 工程师密度 >60%', 'Single Global Segment · >60% Engineering Staff'],
 ['Roblox Corporation 公司治理与资本配置中枢（San Mateo, CA · Class A 1票 / Class B 20票双层股权架构）', 'Roblox Corporation Governance & Capital Hub (San Mateo, CA · Class A 1-Vote / Class B 20-Vote Structure)'],
 ['核心决策层：David Baszucki (创始人 / CEO / 董事会主席 · $0 基本年薪) × Naveen Chopra (CFO · 2025.06 履新) × Matt Kaufman (首席安全官)', 'Leadership Core: David Baszucki (Founder / CEO / Chair · $0 Base Salary) × Naveen Chopra (CFO · Joined June 2025) × Matt Kaufman (CSO)'],
 ['MONETIZATION CORE · 现金牛主业', 'MONETIZATION CORE · CASH ENGINE'],
 ['虚拟货币充值与月度订阅构成近 100% Bookings 主体；直充比例提升驱动 26Q3 渠道成本率降至 20%。', 'Robux sales & Roblox Plus drive nearly 100% of Bookings; 1P billing mix lowered Q3 26 Cost of Revenue to 20%.'],
 ['SECOND ACT · 高毛利增量业务', 'SECOND ACT · HIGH-MARGIN ADS'],
 ['超 1,000 家品牌投放激励视频与首页赞助位，正拓展可跳过贴片视频广告，释放 64% 已核验年龄流量价值。', '1,000+ brands on Rewarded Video & Homepage ads, adding skippable pre-roll video across 64% age-verified DAUs.'],
 ['INFRASTRUCTURE · 混合云底座', 'INFRASTRUCTURE · HYBRID CLOUD'],
 ['推进第三座核心数据中心建设 + 3年 $8.45亿云托管弹性扩容，77% AI 推理请求由自有集群低成本承载。', '3rd core data center + $845M 3-yr cloud burst deal; 77% of AI inference runs on low-cost self-hosted GPUs.'],
 ['CAPITAL RETURN · 资本配置闭环', 'CAPITAL RETURN · BUYBACK ENGINE'],
 ['$6.24B 流动性 + $3B 回购', '$6.24B Liquidity + $3B Buyback'],
 ['2026.05 授权 $30 亿无到期日回购对冲 SBC 摊薄，9M26 已注销 1,260 万股，剩余授权 $24 亿。', 'Inaugural $3.0B open-ended buyback launched May 2026; retired 12.6M shares in 9M26 with $2.4B remaining.'],
 ['资产端飞轮：轻内容资本开支（Zero First-Party Studio Bloat）', 'Asset-Side Flywheel: Zero First-Party Studio M&A Bloat'],
 ['无需像传统发行商每年斥资数十亿买断工作室或承担新游暴死减值，DevEx 分成随流水同向弹性浮动。', 'Avoids multi-billion studio M&A goodwill write-downs; variable DevEx payouts scale organically with Bookings.'],
 ['负债端飞轮：$70.40 亿无息递延收入池（Float Economics）', 'Liability-Side Flywheel: $7.04B Zero-Cost Deferred Revenue Float'],
 ['现金在充值日即落袋生息（9M26 利息净收益达 $1.43 亿），造就极强的抗周期流动性护垫。', 'Cash arrives upfront and earns net interest ($143M net interest income in 9M26), fortifying balance-sheet resilience.'],
 ['1. “预订额增速 > 固定成本增速”经营铁律', '1. Operating Principle: Grow Bookings Faster Than Fixed Costs'],
 ['2. 渠道去中介化破解“应用商店 30% 抽成”', '2. Payment Disintermediation Lowers App-Store Processing Fees'],
 ['3. AI 推理从公有云迁回自建 GPU 中心', '3. Repatriating AI Inference to Owned GPU Data Centers'],
 ['治理里程碑', 'GOVERNANCE MILESTONE'],
 ['视图A: GAAP 营收 vs Bookings', 'View A: GAAP Revenue vs. Bookings'],
 ['视图B: 员工规模与人均创收', 'View B: Headcount & Bookings/FTE'],
 ['双层股权结构与创始人长期绑定（Class B 20票/股）', 'Dual-Class Super-Voting Structure & Founder Alignment (Class B 20x)'],
 ['~58.8%–70% 投票权', '~58.8%–70% Vote'],
 ['优势在于彻底屏蔽激进对冲基金逼迫短视削减 AI 基建或过度压榨青少年的干扰；但投资者需关注其外部股东制衡较弱，以及高管团队通过预设 Rule 10b5-1 计划进行的二级市场例行减持节奏。', 'Shields multi-year AI and safety investments from activist short-termism, though minority investors must monitor limited voting checks and scheduled Rule 10b5-1 insider sales.'],
 ['从“高稀释成长股”到“回购对冲型平台”（Capital Allocation）', 'From High-Dilution Growth to Share-Buyback Discipline'],
 ['$3.0B 回购授权', '$3.0B Buyback Auth'],
 ['按 2026 Q3 单季回购 $2.0 亿（440 万股）的速度测算，公司仅动用约一半的当季自由现金流（$3.64 亿）即可大幅抵消员工期权行权稀释，同时保留超 $52 亿净现金用于 AI 算力投资与战略期权。', 'At Q3 2026\'s $200M buyback pace (4.4M shares), Roblox deploys ~55% of quarterly FCF ($364M) to neutralize equity grant dilution while preserving $5.23B in net cash.'],
 ['混合云基础设施与资本开支周期管理（CapEx & Hosting）', 'Hybrid Cloud Infrastructure & CapEx Cycle Management'],
 ['3年 $845M 托管协议', '3-Yr $845M Cloud Deal'],
 ['“自建核心裸金属/GPU 基座承担稳态流量 + 公有云弹性承接脉冲峰值”的混合架构，使 Roblox 避免了传统云原生 SaaS 被公有云厂商攫取高额毛利的困境。', 'Coupling owned bare-metal/GPU core data centers for baseline load with public-cloud bursting prevents hyperscaler margin compression.'],
 ['全球司法合规与声誉风险出清（Trust, Safety & Legal）', 'State Regulatory Settlements & Proactive Safety De-Risking'],
 ['$140M 州级和解计提', '$140M State Accrual'],
 ['尽管其他辖区潜在谈判仍存不确定性，但公司高达 $62.4 亿的账面流动性足以轻松吸收数亿美元量级的合规成本，而严苛的实名分龄壁垒反而抬高了后来者的准入门槛。', 'While additional state negotiations remain ongoing, $6.24B in liquidity easily absorbs settlement obligations while age-verification systems raise barriers to entry.'],
 ['二、四大公司级护城河支柱：为什么 Roblox 的现金流质量远超传统游戏大厂？', '2. Four Corporate Moat Pillars: Why Roblox Outclasses Publishers on Cash Quality'],
 ['点击左侧任一企业护城河卡片，联动查看财务机制解析与美股三大游戏科技公司五维基本面雷达图', 'Click any moat pillar card on the left to inspect financial mechanics and highlight the 5-axis corporate radar'],
 ['财务健康度：净现金 $5.23B · 无短期偿债压力（$1.0B 票据 2030 到期）', 'Balance Sheet Health: $5.23B Net Cash · Debt Maturing 2030 ($1.0B Notes)'],
 ['01 · 负营运资本与预收现金流复利（Negative Working Capital）', '01 · Negative Working Capital & Upfront Cash Float'],
 ['OCF / 营收 36.7%', 'OCF / Rev 36.7%'],
 ['玩家先付费买 Robux，创作者延后申请 DevEx 提现（26Q3 末应付创作者负债 $4.44 亿），使公司经营现金流常年大幅高于净利润，无需依赖外部债权融资即可自我造血。', 'Upfront Robux inflows paired with accrued DevEx liabilities ($444M at Q3 26) drive operating cash flow far above accounting earnings with zero debt reliance.'],
 ['02 · 免疫“单品跳票与商誉减值”黑天鹅（Zero Hit-Concentration Risk）', '02 · Immunity to Single-Title Delays & M&A Goodwill Write-Downs'],
 ['商誉仅占资产 1.6%', 'Goodwill Only 1.6%'],
 ['传统巨头常因高溢价并购减值（如 Take-Two 对 Zynga 数十亿减值）或王牌大作延期而剧烈震荡；Roblox 商誉仅 $1.63 亿，Top 10 游戏仅占约 20% 时长，彻底分散单作周期风险。', 'Unlike publishers hit by multi-billion M&A write-downs or flagship delays, Roblox carries just $163M goodwill and <20% Top-10 hour concentration.'],
 ['03 · 极致工程杠杆与超高人均产出（$2.21M Bookings / FTE）', '03 · Elite Engineering Leverage ($2.21M Bookings per Employee)'],
 ['3,065 精英编制', '3,065 Lean FTEs'],
 ['同样创造约 $67 亿–$68 亿量级的年度 Bookings，传统 3A 发行商往往需要 10,000–13,000 名内部研发人员，而 Roblox 仅用约四分之一的员工规模即达成同等商业体量。', 'Achieves ~$6.8B in annual Bookings with ~3,065 employees—roughly one-quarter the headcount required by traditional 10,000–13,000-person AAA publishers.'],
 ['04 · 铁壁资产负债表与净利息收益（Fortress Liquidity）', '04 · Fortress Net Cash & Positive Net Interest Carry'],
 ['$6.24B 现金及投资', '$6.24B Cash & Inv'],
 ['持有 $62.38 亿高流动性美债与现金资产，仅背负 2021 年低息锁定的约 $10 亿长期优先票据，在高利率环境下每年净赚逾 $1.6 亿净利息收益反哺研发。', 'Holds $6.24B in cash and marketable securities against $1.01B of low-coupon 2030 notes—generating >$160M in annual net interest income.'],
 ['美股核心游戏与引擎公司五维基本面雷达图（10分制机构评估）', '5-Axis Public Gaming & Engine Corporate Fundamentals Radar (10-Pt Scale)'],
 ['点击下方图例胶囊可单独开关对比公司，悬停顶点查看各财务维度评分', 'Click legend pills below to toggle peer curves; hover vertices for exact scores'],
 ['Roblox (RBLX · 平台现金流先锋)', 'Roblox (RBLX · Platform FCF Leader)'],
 ['Take-Two (TTWO · 顶级3A IP霸主)', 'Take-Two (TTWO · AAA Franchise Giant)'],
 ['Unity Software (U · 跨端引擎龙头)', 'Unity Software (U · Engine & Ad SaaS)'],
 ['三、全球标杆游戏与软件公司基本面及估值对比：平台溢价 vs 3A 巨头的资本选择', '3. Public Gaming & Engine Peer Valuation Matrix: Platform Multiple vs. AAA Studios'],
 ['支持按股票代码（RBLX / TTWO / EA / U）、掌舵人、核心资产或估值倍数实时搜索筛选', 'Filter or search in real time by ticker (RBLX / TTWO / EA / U), CEO, flagship IP, or valuation multiple'],
 ['全部对标公司', 'All Peers'],
 ['双边平台与引擎软件 (RBLX / U)', 'Platforms & Engines (RBLX / U)'],
 ['重研发自研发行巨头 (TTWO / EA)', 'AAA Publishers (TTWO / EA)'],
 ['公司与核心管理层', 'Company & Leadership'],
 ['核心商业模式与代表资产', 'Business Model & Key Assets'],
 ['市值 / 企业价值与估值锚', 'Mkt Cap / EV & Multiples'],
 ['营收与 Bookings 体量', 'Revenue & Bookings Scale'],
 ['自由现金流与人效特征', 'FCF & Workforce Efficiency'],
 ['相对 Roblox 的投资优劣势对比', 'Investment Comparison vs. Roblox'],
 ['Roblox Corporation 核心财务与资产负债表关键比率透视（%）', 'Roblox Corporation Key Income Statement, Cash Flow & Balance Sheet Ratios (%)'],
 ['数据来源：Roblox FY2025 年报、2026 Q3 10-Q 季报及 2026-11-19 实时市值计算', 'Sources: Roblox FY2025 10-K, Q3 2026 10-Q, and live Nov 19, 2026 market capitalization'],
 ['OCF/营收 36.7% · 净现金占市值 15.5%', 'OCF/Rev 36.7% · Net Cash/Mkt Cap 15.5%'],
 ['绿色/蓝色：现金流转化率与净现金安全垫比率', 'Green / Blue: Cash Conversion & Net Cash Cushion Ratios'],
 ['紫色/琥珀色：研发强度、股权激励（SBC）与渠道成本占比', 'Purple / Amber: R&D Intensity, SBC & Cost of Revenue Ratios'],
 ['四、穿透 GAAP 亏损假象与 5 年市值推演：如何为 Roblox 定价？', '4. Decoding Deferred GAAP Losses & 5-Year EV/FCF Valuation Simulator'],
 ['华尔街机构以 EV / Bookings 与 EV / Free Cash Flow 作为核心估值锚，而非失真的当期 GAAP 市盈率', 'Institutional investors anchor valuation on EV / Bookings and EV / Free Cash Flow rather than deferred GAAP P/E'],
 ['当前 EV ~$28.6B · ~21.1x FY25 FCF', 'Current EV ~$28.6B · ~21.1x FY25 FCF'],
 ['FY25 现金 vs 账面利润剪刀差', 'FY25 FCF VS. GAAP NET LOSS GAP'],
 ['差额', 'Spread'],
 ['FY25 自由现金流 +$13.53 亿 vs GAAP 净亏损 -$10.72 亿，核心源于 $19.35 亿递延收入净增与 $11.29 亿非现金 SBC。', '+$1.35B FY25 FCF vs. -$(1.07)B GAAP net loss—driven by +$1.94B deferred revenue build and $1.13B non-cash SBC.'],
 ['企业价值倍数 (EV / FCF)', 'ENTERPRISE VALUE / FCF'],
 ['按基础市值 $338.4 亿扣除 $52.3 亿净现金得 EV 约 $286.1 亿（按完全稀释口径 EV 约 $303.4 亿，对应 22.4x）。', '$33.84B basic market cap minus $5.23B net cash = ~$28.61B EV (~$30.34B diluted EV, or 22.4x FY25 FCF).'],
 ['9M 2026 业绩修复进度', '9M 2026 REVENUE MOMENTUM'],
 ['2026 前三季度营收增至 $44.83 亿，合并净亏损由 -$7.54 亿收窄至 -$6.63 亿，经营现金流增至 $13.42 亿。', '9M 2026 GAAP revenue rose +29% YoY to $4.48B, net loss narrowed to $(663)M, and OCF rose to $1.34B.'],
 ['管理层中长期增长目标', 'LONG-TERM GROWTH TARGET'],
 ['瞄准全球游戏内容市场 10% 份额（2025 年末为 3.4%），依靠 O18 成人破圈与广告变现持续扩张自由现金流率。', 'Targets 10% of global gaming content (up from 3.4% in FY25), compounding FCF margin via O18 and advertising scale.'],
 ['FY2022–FY2026E 真实造血能力跃迁：经营现金流 OCF ($B) 与自由现金流 FCF ($B)', 'FY2022–FY2026E Cash Generation Inflection: Operating Cash Flow ($B) & Free Cash Flow ($B)'],
 ['柱状图（左轴）为经营活动现金流净额 OCF；折线（右轴）为扣除资本开支后的自由现金流 FCF（悬停可同步对照当期 GAAP 净亏损）', 'Bars (left axis): Operating Cash Flow ($B); Line (right axis): Free Cash Flow ($B; hover to compare against GAAP Net Loss)'],
 ['FY22–FY25 OCF 增长 3.86 倍', 'FY22–FY25 OCF Up 4.86x ($0.37B → $1.80B)'],
 ['■ 左轴：经营活动现金流 OCF ($B)', '■ Left Axis: Operating Cash Flow ($B)'],
 ['● 右轴：自由现金流 Free Cash Flow ($B)', '● Right Axis: Free Cash Flow ($B)'],
 ['经营活动现金流 OCF (左轴 · $B)', 'Operating Cash Flow (Left · $B)'],
 ['自由现金流 FCF (右轴 · $B)', 'Free Cash Flow (Right · $B)'],
 ['--- $1.0B 年度自由现金流分水岭', '--- $1.0B Annual Free Cash Flow Threshold'],
 ['Roblox 五年期 EV/FCF 估值与目标股价推演模型', 'Roblox 5-Year EV/FCF Equity Valuation & Target Price Simulator'],
 ['开启常态化股票回购对冲稀释 (年净摊薄压至 0.5%)', 'Enable Ongoing Share Buyback Offset (0.5%/yr Net Dilution)'],
 ['关闭则假设按历史无回购状态下每年约 2.2% SBC 净股本摊薄', 'Unchecked assumes ~2.2%/yr unmitigated SBC diluted share growth'],
 ['① 基准情景 (Base)：20% 复合增速 + 稳态利润率', '① Base Case: 20% Bookings CAGR + Steady Margin'],
 ['② 乐观情景 (Bull)：O18 与广告放量冲击 10% 份额', '② Bull Case: O18 + Ads Scale Toward 10% Share'],
 ['③ 审慎情景 (Bear)：爆款平淡与算力/分成压制', '③ Bear Case: Slower Viral Hits & CapEx Pressure'],
 ['未来 5 年 Bookings 年化复合增速 (CAGR %)', '5-Year Bookings CAGR (%)'],
 ['第 5 年稳态 FCF / Bookings 利润率 (%)', 'Year-5 Target FCF / Bookings Margin (%)'],
 ['第 5 年目标退出估值倍数 (EV / FCF x)', 'Year-5 Exit Valuation Multiple (EV / FCF x)'],
 ['第 5 年隐含目标股价 (vs 现价 $47.11)', 'Year-5 Implied Share Price (vs. $47.11 Now)'],
 ['5 年预期股价涨幅 / 隐含年化 IRR', '5-Year Upside / Implied Equity IRR'],
 ['第 5 年预估 Bookings / 自由现金流', 'Year-5 Projected Bookings / FCF'],
 ['━ 当前设定每股内含价值轨迹 ($/股)', '━ Projected Implied Share Price Trajectory ($/sh)'],
 ['- - 无回购抵消 (2.2%/年稀释) 对照线', '- - Unmitigated Dilution Baseline (2.2%/yr SBC)'],
 ['估值基准说明：以 FY2025 实际 Bookings ($6.788B)、26Q3 完全稀释股数 (7.55亿股)、净现金 ($5.229B) 及 2026-11-19 收盘实时价 ($47.11) 为起点推演，不构成目标价承诺。', 'Model baseline: FY25 Bookings ($6.788B), Q3 26 diluted shares (755M), net cash ($5.229B), and Nov 19, 2026 live share price ($47.11). For scenario analysis only.'],
 ['核心多头逻辑与估值重估催化剂', 'Core Bull Thesis & Re-Rating Catalysts'],
 ['核心空头审视与治理风险清单', 'Core Bear Thesis & Governance Risks'],
 ['五、公司二十年资本演进与四大战略复盘：从硅谷慢公司到百亿现金流平台', '5. Twenty-Year Corporate Evolution & Capital Allocation Case Studies'],
 ['复盘 Roblox 在一级市场融资、DPO 直接上市、成本拐点与股东回报转型中的关键管理抉择', 'Reviewing Roblox\'s private compounding, 2021 Direct Listing, 2024 FCF pivot, and 2026 $3B buyback'],
 ['2004 创立 → 2021 DPO → 2026 启动 $3B 回购', '2004 Founded → 2021 DPO → 2026 $3B Buyback'],
 ['第一阶段 · 长期潜伏与底座打磨 (2004–2020) —— 拒绝短视买量，深筑云与物理引擎', 'Phase I · Private Infrastructure Compounding (2004–2020) — Building the Cloud OS'],
 ['十七年一级市场慢工细活', '17 Years of Patient R&D'],
 ['创立前十年不急于商业化收割，专注打磨多端自动同步引擎与 2013 年推出的 DevEx 创作者分成体系；2020 年居家隔离催化全球青少年社交迁移，推动公司在上市前夕即实现正向巨额经营现金流。', 'Spent its first decade perfecting cross-device physics netcode and launching DevEx (2013) rather than chasing short-term monetization—entering 2020 ready to scale cash flow explosively.'],
 ['第二阶段 · 纽交所直接上市与逆风淬炼 (2021–2024) —— 穿越元宇宙退潮与加息周期', 'Phase II · Direct Listing & Post-COVID Cost Discipline (2021–2024)'],
 ['2021.10 低息锁定 $1.0B 票据', 'Oct 2021 $1B 3.875% Notes'],
 ['第三阶段 · 现金流爆发与资本配置成熟 (2025–2026+) —— 迈向 $30亿回购与 AI 平台重估', 'Phase III · FCF Breakout & Capital Maturity (2025–2026+) — $3B Buyback Era'],
 ['FY25 FCF $1.35B · 26Q3 现金 $6.24B', 'FY25 FCF $1.35B · Cash $6.24B'],
 ['决策 01 · 2021.10', 'Decision 01 · Oct 2021'],
 ['教科书级择时发债', 'Liability Arbitrage'],
 ['零息时代锁定 $10亿 2030 长期票据实现“负债套利”', 'Locking in $1.0B 3.875% 2030 Notes Ahead of Rate Hikes'],
 ['决策 02 · 2023–2024', 'Decision 02 · 2023–2024'],
 ['经营杠杆兑现', 'Operating Leverage'],
 ['不靠大规模裁员、靠冻结净增编制重塑自由现金流', 'Restoring FCF Margins via Hiring Discipline (+0.69% FTEs) Without Mass Layoffs'],
 ['决策 03 · 2025.09–2026.06', 'Decision 03 · 2025–2026'],
 ['反哺生态长期主义', 'Ecosystem Reinvestment'],
 ['主动让利上调 DevEx 费率构筑竞争对手无法企及的供给池', 'Proactively Raising DevEx Rates (+8.5% & O18 Tier) to Widen Creator Moat'],
 ['决策 04 · 2026.05–09', 'Decision 04 · May–Sep 2026'],
 ['股东回报转折点', 'Capital Return Pivot'],
 ['逢股价回调果断执行 $5.8亿回购注销 1,260 万股', 'Retiring 12.6M Shares ($580M) Opportunistically Into Pullbacks'],
 ['估值铁律一：', 'Valuation Law 01:'],
 ['评估 Roblox 永远先看“Bookings 与每股自由现金流（FCF/Share）”，GAAP 净利润因 27 个月递延机制在高速增长期必然呈现反向失真。', 'Anchor valuation on Bookings and FCF per diluted share—27-month deferred revenue accounting systematically distorts GAAP net income during high-growth phases.'],
 ['估值铁律二：', 'Valuation Law 02:'],
 ['跟踪“第一方直充占比”与“广告/Plus 订阅渗透率”——这两大高毛利杠杆每提升 5 个百分点，即可在不伤及创作者分成的前提下大幅抬升稳态利润率。', 'Watch 1P direct billing mix and Rewarded Video / Roblox Plus adoption—each 5pp shift expands steady-state FCF margins without cutting creator payouts.'],
 ['估值铁律三：', 'Valuation Law 03:'],
 ['在 EA 以 $550 亿被财团私有化后，具备 20%+ 中长期内生增长潜力的纯正大型上市游戏平台标的在美股愈发稀缺。', 'Following EA\'s $55B take-private buyout in 2026, liquid large-cap pure-play gaming platforms compounding at 20%+ organically carry scarcity value.'],
 ['六、Roblox Corporation (RBLX) 机构投资者六维财务与治理核查清单', '6. Interactive Institutional Investor 6-Point Financial & Governance Checklist'],
 ['用于每季财报发布后逐项检验公司投资逻辑、稀释管控与估值安全边际（勾选状态自动保存在本地）', 'Quarterly post-earnings checklist for tracking cash conversion, dilution control, and valuation margin of safety'],
 ['全部勾选', 'Check All'],
 ['重置清单', 'Reset'],
 ['数据来源与一手 SEC 监管文件核验索引（SEC EDGAR & Peer Filings）', 'Primary SEC EDGAR Filings & Public Peer Disclosures Index'],
 ['本研报所有公司财务报表、股本结构、高管薪酬治理、诉讼计提、股票回购及同业对标数据均严格核验自美国证监会（SEC EDGAR Form 10-K / 10-Q / 8-K / DEF 14A）、公司投资者关系公告及 Google Finance 实时行情，仅供企业基本面与估值方法论研究参考，不构成任何证券买卖建议。', 'All financial statements, share counts, executive governance, legal accruals, buybacks, and peer benchmarks are verified against U.S. SEC EDGAR filings (10-K, 10-Q, 8-K, DEF 14A), IR releases, and live Google Finance market data. For research only; not investment advice.']
 ];

 var I18N_ATTR_PAIRS = [
 ['展开/收起章节目录', 'Toggle Chapter Sidebar'],
 ['切换目录侧边栏', 'Toggle Chapter Sidebar'],
 ['面包屑导航', 'Breadcrumb Navigation'],
 ['检索章节或财务指标…', 'Jump to chapter or financial KPI…'],
 ['快速跳转章节或指标', 'Quick jump to chapter or metric'],
 ['研究章节目录与站点导航', 'Report Chapters & Site Navigation'],
 ['站点导航与章节目录', 'Site Links & Table of Contents'],
 ['外观模式切换', 'Appearance Theme Switch'],
 ['阅读与导出工具', 'Reading & Export Tools'],
 ['导出独立 HTML 文件 (.html)', 'Export Standalone HTML File (.html)'],
 ['打印或导出 PDF 研报', 'Print or Save Report as PDF'],
 ['第一章图表视图切换', 'Chapter 01 Chart View Switch'],
 ['搜索代码 (RBLX / TTWO / EA / U)、市值、现金流或商业模式…', 'Search ticker (RBLX / TTWO / EA / U), EV, FCF or model…'],
 ['筛选对比公司', 'Filter benchmark companies'],
 ['标杆公司分类筛选', 'Peer company category filter'],
 ['全球标杆游戏与引擎公司基本面与估值横向对比表', 'Public Gaming & Engine Corporate Valuation Comparison Table'],
 ['多空估值情景预设', 'Bull / Base / Bear Valuation Presets'],
 ['核查完成度进度条', 'Checklist Completion Progress']
 ];

 var PILLAR_NOTES = [
 '<strong>当前选中支柱解读（01 负营运资本与预收现金流）：</strong>FY2025 递延收入净增加额高达 $19.35 亿，直接驱动全年经营现金流飙升至 $17.96 亿（占 GAAP 营收 36.7%），自由现金流达 $13.53 亿 <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/q4/Q4-2025-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">FY25 Cash Flow ↗</a>。',
 '<strong>当前选中支柱解读（02 免疫单品跳票与商誉减值）：</strong>对比传统巨头动辄数十亿美元的并购商誉减值，Roblox 截至 26Q3 商誉仅 $1.63 亿（占总资产 $100.45 亿的 1.6%），资产质量极度干净 <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/content_files/Q3-2026-Earnings-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">26Q3 Balance Sheet ↗</a>。',
 '<strong>当前选中支柱解读（03 极致工程杠杆与超高人效）：</strong>从 FY2022 到 FY2025，公司员工总数仅增长 44%（2,128 → 3,065 人），而同期 Bookings 暴增 136%（$28.7 亿 → $67.9 亿），人均创收跃升至 $221 万 <a class="cite-link" href="https://bullfincher.io/companies/roblox-corporation/number-of-employees" target="_blank" rel="noopener noreferrer">Productivity Leap ↗</a>。',
 '<strong>当前选中支柱解读（04 铁壁资产负债表与净利息收益）：</strong>26Q3 账面现金、短期美债与长期投资合计达 $62.38 亿（同比净增 $10 亿），单季利息收入达 $6,000 万，是单季利息支出（$1,100 万）的 5.5 倍 <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/content_files/Q3-2026-Earnings-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">26Q3 P&amp;L ↗</a>。'
 ];

 var PILLAR_NOTES_EN = [
 '<strong>Selected Moat (01 · Negative Working Capital &amp; Float):</strong> A +$1.94B net increase in FY25 deferred revenue propelled operating cash flow to $1.80B (36.7% of GAAP revenue) and free cash flow to $1.35B <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/doc_financials/2025/q4/Q4-2025-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">FY25 Cash Flow ↗</a>.',
 '<strong>Selected Moat (02 · Zero Hit-Delay or Goodwill Risk):</strong> Goodwill stands at just $163M (1.6% of $10.05B total assets as of Q3 2026), sparing shareholders from multi-billion studio M&amp;A write-downs <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/content_files/Q3-2026-Earnings-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">26Q3 Balance Sheet ↗</a>.',
 '<strong>Selected Moat (03 · Elite Engineering Productivity):</strong> Between FY22 and FY25, headcount grew just +44% (2,128 → 3,065 FTEs) while Bookings surged +136% ($2.87B → $6.79B), lifting Bookings/FTE to $2.21M <a class="cite-link" href="https://bullfincher.io/companies/roblox-corporation/number-of-employees" target="_blank" rel="noopener noreferrer">Productivity Leap ↗</a>.',
 '<strong>Selected Moat (04 · Fortress Net Cash &amp; Interest Carry):</strong> Cash, short-term, and long-term investments reached $6.24B in Q3 2026 (+$1.0B YoY), generating $60M of quarterly interest income vs. just $11M of interest expense <a class="cite-link" href="https://s27.q4cdn.com/984876518/files/content_files/Q3-2026-Earnings-Shareholder-Letter.pdf" target="_blank" rel="noopener noreferrer">26Q3 P&amp;L ↗</a>.'
 ];

 var PEER_ROWS = [
 {
 category: 'dividend',
 benchmark: true,
 company: '研究标的：Roblox Corp (NYSE: RBLX)',
 leader: 'David Baszucki (CEO) · Naveen Chopra (CFO)',
 positioning: '双边 UGC 云游戏与社交平台（零自研单作爆雷风险，预收 Robux 负营运资本模式）',
 culture: '市值 $33.8B ($47.11) · EV ~$28.6B (~4.2x EV/26E Bookings)',
 headcount: 'FY25 营收 $4.89B · Bookings $6.79B (+55%)',
 margins: 'FY25 FCF $1.35B · 3,065人 ($2.21M Bookings/人)',
 verdict: '现金流转化与人效之王：坐拥 $52.3 亿净现金与 $70.4 亿递延收入池，回调后 ~21x EV/FCF 兼具高成长与现金安全垫，但需持续监控 SBC 与季度指引波动。',
 sourceLabel: 'RBLX 26Q3 10-Q',
 sourceUrl: 'https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html'
 },
 {
 category: 'global',
 benchmark: false,
 company: 'Take-Two Interactive (NASDAQ: TTWO)',
 leader: 'Strauss Zelnick (董事长兼 CEO)',
 positioning: '美股最大纯正 3A 与手游自研发行商（Rockstar GTA VI / NBA 2K / Zynga）',
 culture: '市值 $39.8B ($213.16) · 市场高度定价 GTA VI 超级周期',
 headcount: 'FY26 净营收 $6.65B · Net Bookings $6.72B (+19%)',
 margins: 'FY26 OCF $6.24亿 / FCF $4.34亿 · 逾万名内部研发人员',
 verdict: '顶级 IP 爆发力 vs 重资产周期波动：FY27 指引随 GTA VI 冲击 $80亿–$82亿 Bookings，但此前因 Zynga 并购连续计提数十亿商誉减值，常态 FCF 率低于 Roblox。',
 sourceLabel: 'TTWO FY26 Release',
 sourceUrl: 'https://www.stocktitan.net/news/TTWO/take-two-interactive-software-inc-reports-results-for-fourth-quarter-b4smbtxrgpw8.html'
 },
 {
 category: 'global',
 benchmark: false,
 company: 'Electronic Arts 艺电 (EA · 私有化标杆)',
 leader: 'Andrew Wilson · 2026年财团全现金收购标杆',
 positioning: '全球体育年货与长青在线服务霸主（EA SPORTS FC / Madden NFL / Apex / Sims）',
 culture: '约 $550 亿全现金财团私有化估值 (~$209/股 · ~6.8x Bookings)',
 headcount: 'FY26 净营收 $7.53B · 创纪录 Net Bookings $8.03B (+9%)',
 margins: 'FY26 经营现金流 $25.53亿 · GAAP 营业利润率 15.4%',
 verdict: '并购估值锚点对照：PIF 与银湖财团以约 $550 亿买断增速 9% 的 EA，反衬出内生中长期增速 20%+、EV 仅 ~$286 亿的 Roblox 具备显著估值折价弹性。',
 sourceLabel: 'EA FY26 8-K & LBO',
 sourceUrl: 'https://www.stocktitan.net/sec-filings/EA/8-k-electronic-arts-inc-reports-material-event-0cc9ae3198af.html'
 },
 {
 category: 'dividend',
 benchmark: false,
 company: 'Unity Software Inc. (NYSE: U)',
 leader: 'Matthew Bromberg (CEO)',
 positioning: '第三方跨平台 2D/3D 游戏引擎 SaaS 订阅（Create）+ 移动广告变现网络（Grow）',
 culture: '市值 $20.7B ($46.74) · 剥离非核心业务后战略重聚焦',
 headcount: '9M 2026 营收 $1.68B (+24.5%) · 25Q4 单季营收 $5.03亿',
 margins: '9M 2026 OCF $5.01亿 · $26亿现金 vs $22亿可转债',
 verdict: '工具型软件 vs 闭环消费帝国：Unity 推进 Vector 广告重构后现金流明显修复，但缺乏自有 C 端玩家社区与预收虚拟货币浮存金，净现金厚度不及 Roblox。',
 sourceLabel: 'Unity 26Q3 10-Q',
 sourceUrl: 'https://www.stocktitan.net/sec-filings/U/'
 }
 ];

 var PEER_ROWS_EN = [
 {
 category: 'dividend',
 benchmark: true,
 company: 'Target: Roblox Corp (NYSE: RBLX)',
 leader: 'David Baszucki (CEO) · Naveen Chopra (CFO)',
 positioning: 'Two-sided UGC cloud gaming & social platform (zero 1P hit risk, upfront Robux float)',
 culture: 'Mkt Cap $33.8B ($47.11) · EV ~$28.6B (~4.2x EV/26E Bookings)',
 headcount: 'FY25 Rev $4.89B · Bookings $6.79B (+55% YoY)',
 margins: 'FY25 FCF $1.35B · 3,065 FTEs ($2.21M Bookings/FTE)',
 verdict: 'Cash conversion & productivity leader: $5.23B net cash and $7.04B deferred pool at ~21x EV/FCF, balanced against SBC and quarterly comp volatility.',
 sourceLabel: 'RBLX 26Q3 10-Q',
 sourceUrl: 'https://www.stocktitan.net/sec-filings/RBLX/10-q-roblox-corp-quarterly-earnings-report-9d9b35a9133d.html'
 },
 {
 category: 'global',
 benchmark: false,
 company: 'Take-Two Interactive (NASDAQ: TTWO)',
 leader: 'Strauss Zelnick (Chairman & CEO)',
 positioning: 'Largest U.S.-listed pure-play AAA & mobile publisher (Rockstar GTA VI / NBA 2K / Zynga)',
 culture: 'Mkt Cap $39.8B ($213.16) · Pricing in Nov 19, 2026 GTA VI super-cycle',
 headcount: 'FY26 Net Rev $6.65B · Net Bookings $6.72B (+19% YoY)',
 margins: 'FY26 OCF $624M / FCF $434M · >10,000 studio staff',
 verdict: 'Blockbuster IP upside vs. heavy studio risk: FY27 Bookings guided to $8.0B–$8.2B on GTA VI, but suffered multi-billion Zynga goodwill write-downs.',
 sourceLabel: 'TTWO FY26 Release',
 sourceUrl: 'https://www.stocktitan.net/news/TTWO/take-two-interactive-software-inc-reports-results-for-fourth-quarter-b4smbtxrgpw8.html'
 },
 {
 category: 'global',
 benchmark: false,
 company: 'Electronic Arts (EA · Buyout Benchmark)',
 leader: 'Andrew Wilson · 2026 Consortium Take-Private',
 positioning: 'Global sports & live-services powerhouse (EA SPORTS FC / Madden NFL / Apex / The Sims)',
 culture: '~$55.0B all-cash consortium LBO valuation (~$209/sh · ~6.8x Bookings)',
 headcount: 'FY26 Net Rev $7.53B · Record Net Bookings $8.03B (+9% YoY)',
 margins: 'FY26 Operating Cash Flow $2.55B · 15.4% GAAP Op Margin',
 verdict: 'Private-market valuation anchor: PIF/Silver Lake paying ~$55B (~6.8x Bookings) for single-digit grower EA highlights Roblox\'s discount at ~4.2x EV/Bookings.',
 sourceLabel: 'EA FY26 8-K & LBO',
 sourceUrl: 'https://www.stocktitan.net/sec-filings/EA/8-k-electronic-arts-inc-reports-material-event-0cc9ae3198af.html'
 },
 {
 category: 'dividend',
 benchmark: false,
 company: 'Unity Software Inc. (NYSE: U)',
 leader: 'Matthew Bromberg (CEO)',
 positioning: 'Cross-platform 2D/3D game engine SaaS (Create) + mobile ad network (Grow)',
 culture: 'Mkt Cap $20.7B ($46.74) · Post-ironSource/Supersonic portfolio reset',
 headcount: '9M 2026 Rev $1.68B (+24.5% YoY) · Q4 25 Rev $503M',
 margins: '9M 2026 OCF $501M · $2.6B cash vs. $2.2B convertibles',
 verdict: 'B2B engine vendor vs. consumer network: improving ad growth via Vector, but lacks Roblox\'s consumer social graph and $5.2B net cash fortress.',
 sourceLabel: 'Unity 26Q3 10-Q',
 sourceUrl: 'https://www.stocktitan.net/sec-filings/U/'
 }
 ];

 var CHECKLIST_ITEMS = [
 {
 tag: 'FCF / Bookings ≥20%',
 title: '1. 自由现金流转化率测试：Bookings 向自由现金流的年度转化率是否稳守 20%+？',
 desc: '剔除季度间服务器资本开支（如 26Q3 向 Q4 的 $3.8 亿顺延）扰动后，全年自由现金流占 Bookings 比重是否维持在 20% 以上并向 25% 迈进？'
 },
 {
 tag: '稀释率 ≤1%–2%',
 title: '2. 净股本摊薄与回购执行测试：回购注销力度是否有效对冲 SBC 发行？',
 desc: '跟踪每季 10-Q 完全稀释股数（26Q3 为 7.55 亿股，+2% YoY）及 $24 亿剩余回购额度执行节奏，确保每股自由现金流（FCF/Share）不被侵蚀。'
 },
 {
 tag: 'COR 持续下行',
 title: '3. 第一方支付去中介化测试：营收成本率（Cost of Revenue）是否持续改善？',
 desc: '随着网页与礼品卡直充占比提升，支付渠道费占收入/Bookings 比重是否延续 26Q3 同比下降 160 bps（至 20%）的扩利趋势？'
 },
 {
 tag: 'O18 + 广告双轮',
 title: '4. 第二增长曲线兑现测试：O18 成人用户与高毛利品牌广告是否加速贡献流水？',
 desc: '验证美国 18+ 已核验用户占比（26Q3 达 37%）与单小时预订额（Bookings/Hour +4% YoY）是否持续对冲未成年客群季节性波动。'
 },
 {
 tag: '编制杠杆纪律',
 title: '5. 固定人员与自建算力杠杆测试：Bookings 增速是否跑赢不含 SBC 人员与基建成本？',
 desc: '在加大 AI 训练/推理与第三座核心数据中心投入的同时，自托管模型（现承接 77% 请求）能否持续压降单位时长服务成本？'
 },
 {
 tag: '合规尾部出清',
 title: '6. 州级诉讼与监管风险收敛测试：未决司法调查是否可控且未伤及核心留存？',
 desc: '跟踪 $1.40 亿六州和解计提后的其余辖区谈判进展，确认强制年龄核验后的用户留存与会话时长保持历史新高水平。'
 }
 ];

 var CHECKLIST_ITEMS_EN = [
 {
 tag: 'FCF / Bookings ≥20%',
 title: '1. Free Cash Flow Conversion Test: Is annual FCF / Bookings holding ≥20%?',
 desc: 'Normalized for quarterly CapEx timing shifts (such as Q3-to-Q4 2026 data center deliveries), is full-year FCF tracking ≥20% of Bookings toward 25%?'
 },
 {
 tag: 'Net Dilution ≤2%',
 title: '2. Share Count & Buyback Offset Test: Are buybacks neutralizing SBC grants?',
 desc: 'Monitor quarterly diluted shares (755M in Q3 26, +2% YoY) and execution of the remaining $2.4B repurchase authorization to protect FCF/share.'
 },
 {
 tag: '1P Billing Leverage',
 title: '3. Direct Payment Margin Test: Is Cost of Revenue % continuing to decline?',
 desc: 'As direct web and prepaid Robux top-ups grow, is Cost of Revenue sustaining Q3 2026\'s 160 bps YoY improvement (down to 20% of revenue)?'
 },
 {
 tag: 'O18 + Ads Inflection',
 title: '4. High-Margin Ad & O18 Monetization Test: Is Bookings/Hour expanding?',
 desc: 'Verify that rising U.S. O18 verified share (37% in Q3 26) and Rewarded Video / pre-roll ads keep global Bookings per Hour growing (+4% YoY in Q3 26).'
 },
 {
 tag: 'Fixed-Cost Discipline',
 title: '5. Headcount & Self-Hosted AI Efficiency Test: Is CtS trending lower?',
 desc: 'Confirm that 77% self-hosted AI inference and disciplined engineering hiring keep multi-year Bookings growth ahead of cash opex.'
 },
 {
 tag: 'Legal Tail Containment',
 title: '6. State Regulatory & Litigation Containment Test: Are legal liabilities bounded?',
 desc: 'Track remaining state AG discussions beyond the $140M six-state accrual and verify that post-age-check retention remains at record levels.'
 }
 ];

 var QUICK_JUMP_INDEX = [
 { sec: 'sec-00', title: '00 执行摘要与公司估值快照', sub: '股价 $47.11 · 市值 $33.8B · 净现金 $5.23B · FCF $1.35B' },
 { sec: 'sec-01', title: '01 公司架构、人效与管理治理', sub: '3,065名员工人均 $2.21M Bookings · 双层股权 · CFO $3B 回购' },
 { sec: 'sec-02', title: '02 四大企业护城河与财务雷达', sub: '负营运资本 · 零商誉暴雷 · RBLX vs TTWO vs U 雷达对比' },
 { sec: 'sec-03', title: '03 全球上市游戏公司估值对比', sub: 'RBLX vs Take-Two vs EA ($55B 私有化) vs Unity 财务矩阵' },
 { sec: 'sec-04', title: '04 递延会计拆解与估值模拟器', sub: '穿透 GAAP 亏损 · 交互式 5 年 EV/FCF 目标股价推演模型' },
 { sec: 'sec-05', title: '05 公司三代演进与资本复盘', sub: '2021 DPO · 2021 低息发债套利 · 2024 成本拐点 · 2026 回购' },
 { sec: 'sec-06', title: '06 机构投资者尽调核查清单', sub: '6 项每季财报必查现金流、稀释率与合规安全边际清单' },
 { sec: 'sec-07', title: '07 SEC 监管文件与财报索引', sub: 'Form 10-K / 10-Q / 8-K / Proxy Statement 权威核验链接' }
 ];

 var QUICK_JUMP_EN = [
 { sec: 'sec-00', title: '00 Executive Summary & Valuation', sub: 'Price $47.11 · Mkt Cap $33.8B · Net Cash $5.23B · FCF $1.35B' },
 { sec: 'sec-01', title: '01 Corporate Model & Governance', sub: '3,065 FTEs ($2.21M Bookings/FTE) · Dual-Class · $3B Buyback' },
 { sec: 'sec-02', title: '02 Four Corporate Moats & Radar', sub: 'Negative Working Capital · RBLX vs. TTWO vs. Unity Radar' },
 { sec: 'sec-03', title: '03 Public Gaming Peer Valuation', sub: 'RBLX vs. Take-Two vs. EA ($55B LBO) vs. Unity Matrix' },
 { sec: 'sec-04', title: '04 Deferral Accounting & DCF Sim', sub: 'GAAP vs. FCF Gap · 5-Year EV/FCF Target Price Simulator' },
 { sec: 'sec-05', title: '05 Corporate Evolution & Capital', sub: '2021 DPO · 2030 Notes Arbitrage · 2024 Pivot · 2026 Buybacks' },
 { sec: 'sec-06', title: '06 Investor Due-Diligence Checklist', sub: '6-Point Quarterly Earnings & Governance Audit (Saved Locally)' },
 { sec: 'sec-07', title: '07 SEC Filings & Primary Sources', sub: 'Form 10-K / 10-Q / 8-K / DEF 14A Official Links' }
 ];

 var PRESETS = {
 p1: { cagr: 20, fcfMargin: 24, exitMult: 24, buybackOffset: true },
 p2: { cagr: 25, fcfMargin: 28, exitMult: 28, buybackOffset: true },
 p3: { cagr: 12, fcfMargin: 18, exitMult: 18, buybackOffset: true }
 };

 var state = {
 lang: 'zh',
 theme: 'light',
 ch1View: 'viewA',
 ch1Series: { s1: true, s2: true },
 activePillar: 0,
 radarSeries: { mo: true, pmi: true, ko: true },
 peerFilter: 'all',
 peerQuery: '',
 epsSeries: { eps: true, oci: true },
 sim: { cagr: 20, fcfMargin: 24, exitMult: 24, buybackOffset: true, preset: 'p1' },
 checks: [true, true, true, false, false, false]
 };

 /* Safe LocalStorage Helpers */
 function safeGetStorage(key) {
 try {
 return window.localStorage.getItem(key);
 } catch (err) {
 return null;
 }
 }

 function safeSetStorage(key, val) {
 try {
 window.localStorage.setItem(key, val);
 } catch (err) {
 /* Ignore storage quota/sandbox restrictions */
 }
 }

 /* Toast Notification (MUI Snackbar) */
 var toastTimer = null;
 function showToast(message) {
 var el = document.getElementById('muiSnackbar');
 if (!el) return;
 el.textContent = message;
 el.classList.add('show');
 if (toastTimer) clearTimeout(toastTimer);
 toastTimer = setTimeout(function () {
 el.classList.remove('show');
 }, 2800);
 }

 /* ======================================================================
 2. Bilingual Engine, Theme Switching & Sidebar Drawer
 ====================================================================== */
 function isEn() {
 return state.lang === 'en';
 }

 var _zhToEnText = {};
 var _enToZhText = {};
 for (var _ti = 0; _ti < I18N_TEXT_PAIRS.length; _ti++) {
 _zhToEnText[I18N_TEXT_PAIRS[_ti][0]] = I18N_TEXT_PAIRS[_ti][1];
 _enToZhText[I18N_TEXT_PAIRS[_ti][1]] = I18N_TEXT_PAIRS[_ti][0];
 }
 var _zhToEnAttr = {};
 var _enToZhAttr = {};
 for (var _ai = 0; _ai < I18N_ATTR_PAIRS.length; _ai++) {
 _zhToEnAttr[I18N_ATTR_PAIRS[_ai][0]] = I18N_ATTR_PAIRS[_ai][1];
 _enToZhAttr[I18N_ATTR_PAIRS[_ai][1]] = I18N_ATTR_PAIRS[_ai][0];
 }
 var _richMapByKey = {};
 for (var _ri = 0; _ri < I18N_RICH_LIST.length; _ri++) {
 _richMapByKey[I18N_RICH_LIST[_ri].key] = I18N_RICH_LIST[_ri];
 }

 function bindRichBlocksOnce() {
 var candidates = document.querySelectorAll('h1, p, div');
 for (var i = 0; i < candidates.length; i++) {
 var el = candidates[i];
 if (el.getAttribute('data-i18n-rich')) continue;
 if (el.id === 'pillarFocusNote' || el.closest('#pillarFocusNote')) continue;
 var normTxt = (el.textContent || '').replace(/\s+/g, ' ').trim();
 for (var j = 0; j < I18N_RICH_LIST.length; j++) {
 var item = I18N_RICH_LIST[j];
 if (normTxt.indexOf(item.match_zh) === 0 && el.children.length <= 25) {
 if (!el.querySelector('div, p, ul, table, canvas')) {
 el.setAttribute('data-i18n-rich', item.key);
 break;
 }
 }
 }
 }
 }

 function syncCh1HeaderText() {
 var titleEl = document.getElementById('ch1ChartTitle');
 var subEl = document.getElementById('ch1ChartSub');
 if (!titleEl || !subEl) return;
 if (state.ch1View === 'viewA') {
 titleEl.textContent = isEn()
 ? 'FY2022–9M2026 GAAP Recognized Revenue vs. Cash Bookings ($B · SEC 10-K/10-Q)'
 : 'FY2022–9M2026 公司 GAAP 确认营收 vs Bookings 预订额增长剪刀差（$B · SEC 10-K/10-Q）';
 subEl.textContent = isEn()
 ? 'Bookings consistently outpace GAAP revenue, building a $7.04B deferred revenue liability reservoir on the balance sheet'
 : 'Bookings 持续领跑当期 GAAP 营收，差额沉淀进入高达 $70.40 亿的资产负债表递延收入蓄水池';
 } else {
 titleEl.textContent = isEn()
 ? 'FY2022–FY2025 Full-Time Employees (k FTEs) vs. Bookings per Employee ($M/FTE)'
 : 'FY2022–FY2025 公司全职员工规模（千人）vs 人均 Bookings 创收跃升（$M/人）';
 subEl.textContent = isEn()
 ? 'Headcount rose moderately (2,128 → 3,065 FTEs) while Bookings per employee surged +64% from $1.35M to $2.21M'
 : '员工人数温和扩充（2,128 → 3,065 人），人均创造 Bookings 由 $1.35M 暴涨 64% 至 $2.21M';
 }
 }

 function syncCollapseButtonsText() {
 var btns = document.querySelectorAll('[data-collapse-target]');
 for (var i = 0; i < btns.length; i++) {
 var pid = btns[i].getAttribute('data-collapse-target');
 var panel = document.getElementById(pid);
 var isOpen = panel && panel.classList.contains('open');
 if (isEn()) {
 btns[i].innerHTML = isOpen ? '<span>Hide Governance &amp; Financial Impact</span> <span>⌃</span>' : '<span>Show Governance &amp; Financial Impact</span> <span>⌄</span>';
 } else {
 btns[i].innerHTML = isOpen ? '<span>收起治理利弊评估</span> <span>⌃</span>' : '<span>展开治理利弊评估</span> <span>⌄</span>';
 }
 }
 }

 function applyLanguage(lang, silent) {
 bindRichBlocksOnce();
 state.lang = lang === 'en' ? 'en' : 'zh';
 var en = isEn();
 document.documentElement.setAttribute('lang', en ? 'en' : 'zh-CN');
 document.documentElement.setAttribute('data-lang', state.lang);
 document.title = en ? DOC_TITLE_EN : DOC_TITLE_ZH;

 var lGrp = document.getElementById('langSwitchGroup');
 if (lGrp) lGrp.setAttribute('aria-label', en ? 'Language switcher' : '语言切换');
 var abThmBtn = document.getElementById('appbarThemeBtn');
 if (abThmBtn) {
 abThmBtn.setAttribute('title', en ? 'Toggle Light / Dark theme' : '切换浅色 / 深色主题');
 abThmBtn.setAttribute('aria-label', en ? 'Toggle color theme' : '切换深浅色主题');
 }
 var zhBtn = document.getElementById('langZhBtn');
 var enBtn = document.getElementById('langEnBtn');
 if (zhBtn && enBtn) {
 zhBtn.classList.toggle('active', !en);
 enBtn.classList.toggle('active', en);
 zhBtn.setAttribute('aria-pressed', !en ? 'true' : 'false');
 enBtn.setAttribute('aria-pressed', en ? 'true' : 'false');
 }
 var dynNavSpans = document.querySelectorAll('[data-i18n-zh][data-i18n-en]');
 for (var dn = 0; dn < dynNavSpans.length; dn++) {
 dynNavSpans[dn].textContent = en ? dynNavSpans[dn].getAttribute('data-i18n-en') : dynNavSpans[dn].getAttribute('data-i18n-zh');
 }

 /* 1. Update Rich Prose Blocks */
 var richNodes = document.querySelectorAll('[data-i18n-rich]');
 for (var r = 0; r < richNodes.length; r++) {
 var rk = richNodes[r].getAttribute('data-i18n-rich');
 var rEntry = _richMapByKey[rk];
 if (rEntry) {
 richNodes[r].innerHTML = en ? rEntry.en : rEntry.zh;
 }
 }

 /* 2. Walk Pure Text Nodes */
 var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
 var tNode;
 while ((tNode = walker.nextNode())) {
 var pEl = tNode.parentElement;
 if (!pEl) continue;
 var tag = pEl.tagName;
 if (tag === 'SCRIPT' || tag === 'STYLE') continue;
 if (pEl.closest('#langSwitchGroup') || pEl.closest('[data-i18n-rich]') || pEl.closest('#pillarFocusNote')) continue;
 var raw = tNode.nodeValue || '';
 var trimmed = raw.replace(/\s+/g, ' ').trim();
 if (!trimmed) continue;
 var mapped = en ? _zhToEnText[trimmed] : _enToZhText[trimmed];
 if (mapped) {
 var leadMatch = raw.match(/^\s*/);
 var trailMatch = raw.match(/\s*$/);
 tNode.nodeValue = (leadMatch ? leadMatch[0] : '') + mapped + (trailMatch ? trailMatch[0] : '');
 }
 }

 /* 3. Update Attributes (placeholder, title, aria-label) */
 var allEls = document.querySelectorAll('[placeholder], [title], [aria-label]');
 var attrNames = ['placeholder', 'title', 'aria-label'];
 for (var a = 0; a < allEls.length; a++) {
 if (allEls[a].closest('#langSwitchGroup')) continue;
 for (var k = 0; k < attrNames.length; k++) {
 var an = attrNames[k];
 var av = allEls[a].getAttribute(an);
 if (!av) continue;
 var nextAv = en ? _zhToEnAttr[av] : _enToZhAttr[av];
 if (nextAv) allEls[a].setAttribute(an, nextAv);
 }
 }

 /* 4. Update Dynamic Panels & Redraw All 5 High-DPI Charts */
 var pNote = document.getElementById('pillarFocusNote');
 if (pNote) {
 var notesArr = en ? PILLAR_NOTES_EN : PILLAR_NOTES;
 pNote.innerHTML = '<div>' + notesArr[state.activePillar] + '</div>';
 }
 syncCh1HeaderText();
 syncCollapseButtonsText();
 renderPeerTable();
 renderChecklist();
 updateSimulatorUI();
 renderAllCharts();
 safeSetStorage(STORAGE_LANG_KEY, state.lang);

 if (!silent) {
 showToast(en ? 'Switched to English Equity Research Edition' : '已切换至中文公司深度研报视图');
 }
 }

 function applyTheme(theme, silent) {
 state.theme = theme === 'dark' ? 'dark' : 'light';
 document.documentElement.setAttribute('data-theme', state.theme);
 var abIconEl = document.getElementById('appbarThemeIcon');
 if (abIconEl) {
 abIconEl.innerHTML = (state.theme === 'dark')
 ? '<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zm18 0h2c.55 0 1-.45 1-1s-.45-1-1-1h-2c-.55 0-1 .45-1 1s.45 1 1 1zM11 2v2c0 .55.45 1 1 1s1-.45 1-1V2c0-.55-.45-1-1-1s-1 .45-1 1zm0 18v2c0 .55.45 1 1 1s1-.45 1-1v-2c0-.55-.45-1-1-1s-1 .45-1 1zM5.99 4.58a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0s.39-1.03 0-1.41L5.99 4.58zm12.37 12.37a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0a.996.996 0 0 0 0-1.41l-1.06-1.06zm1.06-10.96a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06zM7.05 18.36a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06z"/></svg>'
 : '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3a9 9 0 1 0 9 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 0 1-4.4 2.26 5.403 5.403 0 0 1-3.14-9.8c-.44-.06-.9-.1-1.36-.1z"/></svg>';
 }
 var sDarkBtn = document.getElementById('sideThemeDarkBtn');
 var sLightBtn = document.getElementById('sideThemeLightBtn');
 if (sDarkBtn && sLightBtn) {
 void 0;
 void 0;
 }
 safeSetStorage(STORAGE_THEME_KEY, state.theme);
 renderAllCharts();
 if (!silent) {
 showToast(state.theme === 'dark' ? (isEn() ? 'Switched to Dark Obsidian Mode' : '已切换至 MUI 深海黑曜石护眼模式') : (isEn() ? 'Switched to Crisp Light Mode' : '已切换至 MUI 浅色明亮阅读模式'));
 }
 }

 function toggleSidebar() {
 if (window.innerWidth <= 1120) {
 document.body.classList.toggle('drawer-open');
 } else {
 document.body.classList.toggle('sidebar-collapsed');
 setTimeout(renderAllCharts, 60);
 }
 }

 function closeMobileDrawer() {
 document.body.classList.remove('drawer-open');
 }

 /* ======================================================================
 3. Peer Valuation Matrix Rendering & Filtering
 ====================================================================== */
 function escapeHtml(str) {
 return String(str)
 .replace(/&/g, '&amp;')
 .replace(/</g, '&lt;')
 .replace(/>/g, '&gt;')
 .replace(/"/g, '&quot;');
 }

 function highlightMatch(text, query) {
 var safe = escapeHtml(text);
 if (!query) return safe;
 var escapedQ = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
 var re = new RegExp('(' + escapedQ + ')', 'gi');
 return safe.replace(re, '<mark class="hl">$1</mark>');
 }

 function renderPeerTable() {
 var tbody = document.getElementById('peerTableBody');
 var badge = document.getElementById('peerCountBadge');
 if (!tbody) return;

 var activeRows = isEn() ? PEER_ROWS_EN : PEER_ROWS;
 var q = state.peerQuery.trim().toLowerCase();
 var filtered = activeRows.filter(function (row, idx) {
 var catOk = state.peerFilter === 'all' || row.category === state.peerFilter;
 if (!catOk) return false;
 if (!q) return true;
 var zhR = PEER_ROWS[idx] || row;
 var enR = PEER_ROWS_EN[idx] || row;
 var hay = (zhR.company + ' ' + zhR.leader + ' ' + zhR.positioning + ' ' + zhR.culture + ' ' + zhR.verdict + ' ' + enR.company + ' ' + enR.leader + ' ' + enR.positioning + ' ' + enR.culture + ' ' + enR.verdict).toLowerCase();
 return hay.indexOf(q) !== -1;
 });

 if (badge) {
 badge.textContent = isEn()
 ? ('Showing ' + filtered.length + ' / ' + activeRows.length + ' Companies')
 : ('显示 ' + filtered.length + ' / ' + activeRows.length + ' 家标杆公司');
 }

 if (!filtered.length) {
 tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:28px;">' + (isEn() ? 'No matching peer companies found. Try another ticker or reset filters.' : '未找到匹配的同业公司记录，请尝试其他股票代码或重置筛选条件。') + '</td></tr>';
 return;
 }

 var rawQ = state.peerQuery.trim();
 tbody.innerHTML = filtered.map(function (r) {
 return '<tr class="' + (r.benchmark ? 'benchmark-row' : '') + '">' +
 '<td><strong style="color:var(--text-primary);display:block;">' + highlightMatch(r.company, rawQ) + '</strong><span style="font-size:0.76rem;color:var(--text-muted);">' + highlightMatch(r.leader, rawQ) + '</span></td>' +
 '<td>' + highlightMatch(r.positioning, rawQ) + '</td>' +
 '<td class="mono" style="font-size:0.79rem;">' + highlightMatch(r.culture, rawQ) + '</td>' +
 '<td class="mono" style="font-size:0.79rem;">' + highlightMatch(r.headcount, rawQ) + '</td>' +
 '<td class="mono" style="font-size:0.79rem;color:var(--mui-primary-lighter);font-weight:700;">' + highlightMatch(r.margins, rawQ) + '</td>' +
 '<td>' + highlightMatch(r.verdict, rawQ) + ' <a class="cite-link" href="' + r.sourceUrl + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(r.sourceLabel) + ' ↗</a></td>' +
 '</tr>';
 }).join('');
 }

 /* ======================================================================
 4. 5-Year Corporate EV/FCF Valuation & Share Price Simulator
 ====================================================================== */
 function computeValuationModel() {
 var baseBookingsB = 6.7884;
 var netCashB = 5.229;
 var baseSharesB = 0.755;
 var currentPrice = 47.11;

 var cagr = state.sim.cagr / 100;
 var fcfMargin = state.sim.fcfMargin / 100;
 var exitMult = state.sim.exitMult;
 var activeDilution = state.sim.buybackOffset ? 0.005 : 0.022;
 var unmitigatedDilution = 0.022;

 var activePrices = [currentPrice];
 var unmitigatedPrices = [currentPrice];

 var y5BookingsB = baseBookingsB * Math.pow(1 + cagr, 5);
 var y5FcfB = y5BookingsB * fcfMargin;
 var y5EvB = y5FcfB * exitMult;
 var y5MktCapB = y5EvB + netCashB;

 for (var yr = 1; yr <= 5; yr++) {
 var bYr = baseBookingsB * Math.pow(1 + cagr, yr);
 /* Smoothly interpolate FCF margin from FY25 19.9% toward target Year-5 margin */
 var mYr = 0.199 + (fcfMargin - 0.199) * (yr / 5);
 var fcfYr = bYr * mYr;
 var evYr = fcfYr * exitMult;
 var mcapYr = evYr + netCashB;

 var shActive = baseSharesB * Math.pow(1 + activeDilution, yr);
 var shRaw = baseSharesB * Math.pow(1 + unmitigatedDilution, yr);

 activePrices.push(mcapYr / shActive);
 unmitigatedPrices.push(mcapYr / shRaw);
 }

 var finalPrice = activePrices[5];
 var upsidePct = ((finalPrice / currentPrice) - 1) * 100;
 var irrPct = (Math.pow(finalPrice / currentPrice, 1 / 5) - 1) * 100;

 return {
 cagr: state.sim.cagr,
 fcfMargin: state.sim.fcfMargin,
 exitMult: exitMult,
 y5BookingsB: y5BookingsB,
 y5FcfB: y5FcfB,
 y5MktCapB: y5MktCapB,
 finalPrice: finalPrice,
 upsidePct: upsidePct,
 irrPct: irrPct,
 activePrices: activePrices,
 unmitigatedPrices: unmitigatedPrices
 };
 }

 function updateSimulatorUI() {
 var m = computeValuationModel();

 document.getElementById('simPrincipalLabel').textContent = m.cagr + '%';
 document.getElementById('simYearsLabel').textContent = m.fcfMargin + '%';
 document.getElementById('simCagrLabel').textContent = m.exitMult + 'x';

 document.getElementById('simEndingVal').textContent = '$' + m.finalPrice.toFixed(2);
 var upSign = m.upsidePct >= 0 ? '+' : '';
 var irrSign = m.irrPct >= 0 ? '+' : '';
 document.getElementById('simMoicVal').textContent = upSign + m.upsidePct.toFixed(1) + '% · ' + irrSign + m.irrPct.toFixed(1) + '%';
 document.getElementById('simNetGainVal').textContent = '$' + m.y5BookingsB.toFixed(2) + 'B / $' + m.y5FcfB.toFixed(2) + 'B';
 document.getElementById('simMidLabel').textContent = isEn() ? 'Year-5 Implied Market Cap (incl. Net Cash)' : '第 5 年隐含总市值 (含 $5.23B 净现金)';
 document.getElementById('simMidVal').textContent = '$' + m.y5MktCapB.toFixed(2) + 'B';

 var presetBtns = document.querySelectorAll('[data-preset]');
 for (var i = 0; i < presetBtns.length; i++) {
 presetBtns[i].classList.toggle('active', presetBtns[i].getAttribute('data-preset') === state.sim.preset);
 }

 drawSimChart();
 }

 /* ======================================================================
 5. Interactive Checklist
 ====================================================================== */
 function renderChecklist() {
 var container = document.getElementById('checklistContainer');
 var chip = document.getElementById('checklistScoreChip');
 var bar = document.getElementById('checklistProgressBar');
 if (!container) return;

 var itemsList = isEn() ? CHECKLIST_ITEMS_EN : CHECKLIST_ITEMS;
 var doneCount = state.checks.filter(Boolean).length;
 var pct = Math.round((doneCount / itemsList.length) * 100);
 if (chip) {
 chip.textContent = isEn()
 ? ('Verified ' + doneCount + ' / ' + itemsList.length + ' (' + pct + '%)')
 : ('已核查 ' + doneCount + ' / ' + itemsList.length + ' 项 (' + pct + '%)');
 }
 if (bar) {
 bar.style.width = pct + '%';
 }

 container.innerHTML = itemsList.map(function (item, idx) {
 var isChecked = !!state.checks[idx];
 return '<label class="check-card ' + (isChecked ? 'checked' : '') + '" data-check-idx="' + idx + '">' +
 '<input type="checkbox" data-check-input="' + idx + '" ' + (isChecked ? 'checked' : '') + ' />' +
 '<div style="flex:1;">' +
 '<div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:6px;margin-bottom:4px;">' +
 '<span class="check-title">' + escapeHtml(item.title) + '</span>' +
 '<span class="mui-chip mono">' + escapeHtml(item.tag) + '</span>' +
 '</div>' +
 '<p class="check-desc">' + escapeHtml(item.desc) + '</p>' +
 '</div>' +
 '</label>';
 }).join('');
 }

 /* ======================================================================
 6. Built-In Zero-Dependency MUI X Charts-Style High-DPI Engine
 ====================================================================== */
 var hitRegions = {
 chartCh1: [],
 chartRadar: [],
 chartBars: [],
 chartEps: [],
 chartSim: []
 };

 var hoverState = {
 chartCh1: -1,
 chartRadar: -1,
 chartBars: -1,
 chartEps: -1,
 chartSim: -1
 };

 function getPalette() {
 var cs = getComputedStyle(document.documentElement);
 var isDark = state.theme === 'dark';
 return {
 isDark: isDark,
 grid: cs.getPropertyValue('--chart-grid').trim() || (isDark ? 'rgba(148,163,184,0.13)' : 'rgba(100,116,139,0.16)'),
 tick: cs.getPropertyValue('--chart-tick').trim() || '#94A3B8',
 text: cs.getPropertyValue('--text-primary').trim() || '#F3F6F9',
 sub: cs.getPropertyValue('--text-secondary').trim() || '#B2BAC2',
 pillBg: isDark ? 'rgba(9, 13, 22, 0.88)' : 'rgba(255, 255, 255, 0.94)',
 pillBorder: isDark ? 'rgba(51, 153, 255, 0.28)' : 'rgba(0, 115, 230, 0.24)',
 trackBg: isDark ? 'rgba(148, 163, 184, 0.10)' : 'rgba(15, 25, 36, 0.06)',
 hoverBand: isDark ? 'rgba(51, 153, 255, 0.07)' : 'rgba(0, 115, 230, 0.05)',
 c1: cs.getPropertyValue('--chart-c1').trim() || '#3399FF',
 c2: cs.getPropertyValue('--chart-c2').trim() || '#22C55E',
 c3: cs.getPropertyValue('--chart-c3').trim() || '#FFB74D',
 c4: cs.getPropertyValue('--chart-c4').trim() || '#A78BFA'
 };
 }

 function prepareCanvas(id) {
 var canvas = document.getElementById(id);
 if (!canvas || !canvas.parentElement) return null;
 var stage = canvas.parentElement;
 var rect = stage.getBoundingClientRect();
 var w = Math.max(240, Math.floor(rect.width));
 var h = Math.max(170, Math.floor(rect.height));
 var dpr = Math.min(window.devicePixelRatio || 1, 2.5);
 canvas.style.width = w + 'px';
 canvas.style.height = h + 'px';
 var targetW = Math.floor(w * dpr);
 var targetH = Math.floor(h * dpr);
 if (canvas.width !== targetW) canvas.width = targetW;
 if (canvas.height !== targetH) canvas.height = targetH;
 var ctx = canvas.getContext('2d');
 ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
 ctx.clearRect(0, 0, w, h);
 return { ctx: ctx, w: w, h: h, canvas: canvas };
 }

 function roundRectPath(ctx, x, y, w, h, r) {
 if (w <= 0 || h <= 0) return;
 var radius = Math.min(r, w / 2, h / 2);
 ctx.beginPath();
 ctx.moveTo(x + radius, y);
 ctx.lineTo(x + w - radius, y);
 ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
 ctx.lineTo(x + w, y + h - radius);
 ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
 ctx.lineTo(x + radius, y + h);
 ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
 ctx.lineTo(x, y + radius);
 ctx.quadraticCurveTo(x, y, x + radius, y);
 ctx.closePath();
 }

 function topRoundedBar(ctx, x, y, w, h, r) {
 if (w <= 0 || h <= 0) return;
 var rad = Math.min(r, w / 2, h);
 ctx.beginPath();
 ctx.moveTo(x, y + h);
 ctx.lineTo(x, y + rad);
 ctx.quadraticCurveTo(x, y, x + rad, y);
 ctx.lineTo(x + w - rad, y);
 ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
 ctx.lineTo(x + w, y + h);
 ctx.closePath();
 }

 function drawValueBadge(ctx, text, cx, cy, fgColor, pal) {
 ctx.save();
 ctx.font = '700 11px "IBM Plex Mono", system-ui, sans-serif';
 var tw = ctx.measureText(text).width + 10;
 var th = 18;
 var bx = cx - tw / 2;
 var by = cy - th / 2;
 ctx.fillStyle = pal.pillBg;
 roundRectPath(ctx, bx, by, tw, th, 5);
 ctx.fill();
 ctx.strokeStyle = pal.pillBorder;
 ctx.lineWidth = 1;
 ctx.stroke();
 ctx.fillStyle = fgColor;
 ctx.textAlign = 'center';
 ctx.textBaseline = 'middle';
 ctx.fillText(text, cx, cy + 0.5);
 ctx.restore();
 }

 function drawSmoothLine(ctx, pts) {
 if (!pts.length) return;
 ctx.beginPath();
 ctx.moveTo(pts[0].x, pts[0].y);
 for (var i = 0; i < pts.length - 1; i++) {
 var xc = (pts[i].x + pts[i + 1].x) / 2;
 ctx.bezierCurveTo(xc, pts[i].y, xc, pts[i + 1].y, pts[i + 1].x, pts[i + 1].y);
 }
 }

 /* Chart 1: View A (GAAP Revenue vs Bookings) & View B (Headcount vs Bookings/FTE) */
 function drawCh1Chart() {
 var env = prepareCanvas('chartCh1');
 if (!env) return;
 var ctx = env.ctx, w = env.w, h = env.h;
 var pal = getPalette();
 hitRegions.chartCh1 = [];

 var metaEl = document.getElementById('ch1AxisMeta');
 var leg1 = document.getElementById('ch1Leg1');
 var leg2 = document.getElementById('ch1Leg2');

 if (state.ch1View === 'viewA') {
 if (metaEl) {
 metaEl.innerHTML = isEn()
 ? '<span style="color:var(--chart-c1);">■ Left Bar: GAAP Recognized Revenue ($B)</span><span style="color:var(--chart-c2);">■ Right Bar: Cash Bookings ($B)</span>'
 : '<span style="color:var(--chart-c1);">■ 左柱：GAAP 确认营收 Revenue ($B)</span><span style="color:var(--chart-c2);">■ 右柱：当期现金预订额 Bookings ($B)</span>';
 }
 if (leg1) leg1.textContent = isEn() ? 'GAAP Recognized Revenue ($B)' : 'GAAP 确认营收 Revenue ($B)';
 if (leg2) leg2.textContent = isEn() ? 'Cash Bookings ($B)' : '当期预订额 Bookings ($B)';

 var padA = { top: 26, right: 20, bottom: 44, left: 48 };
 var pwA = w - padA.left - padA.right;
 var phA = h - padA.top - padA.bottom;
 var labelsA = ['FY2022', 'FY2023', 'FY2024', 'FY2025', '9M 2026'];
 var revB = [2.23, 2.80, 3.60, 4.89, 4.48];
 var bkB = [2.87, 3.52, 4.37, 6.79, 4.96];
 var maxY = 7.6;

 for (var g = 0; g <= 4; g++) {
 var val = (maxY / 4) * g;
 var gy = padA.top + phA - (g / 4) * phA;
 ctx.strokeStyle = pal.grid;
 ctx.lineWidth = 1;
 ctx.beginPath();
 ctx.moveTo(padA.left, gy);
 ctx.lineTo(padA.left + pwA, gy);
 ctx.stroke();

 ctx.fillStyle = pal.tick;
 ctx.font = '11px "IBM Plex Mono", sans-serif';
 ctx.textAlign = 'right';
 ctx.textBaseline = 'middle';
 ctx.fillText('$' + val.toFixed(1) + 'B', padA.left - 8, gy);
 }

 var stepA = pwA / labelsA.length;
 var barW = Math.min(38, Math.max(18, stepA * 0.27));

 for (var i = 0; i < labelsA.length; i++) {
 var cx = padA.left + stepA * (i + 0.5);
 if (hoverState.chartCh1 === i) {
 ctx.fillStyle = pal.hoverBand;
 roundRectPath(ctx, padA.left + stepA * i + 5, padA.top, stepA - 10, phA, 8);
 ctx.fill();
 }

 if (state.ch1Series.s1) {
 var h1 = (revB[i] / maxY) * phA;
 var x1 = state.ch1Series.s2 ? (cx - barW - 4) : (cx - barW / 2);
 var y1 = padA.top + phA - h1;
 var grad1 = ctx.createLinearGradient(0, y1, 0, padA.top + phA);
 grad1.addColorStop(0, '#3399FF');
 grad1.addColorStop(1, '#0066CC');
 ctx.fillStyle = grad1;
 topRoundedBar(ctx, x1, y1, barW, h1, 5);
 ctx.fill();
 drawValueBadge(ctx, '$' + revB[i].toFixed(2) + 'B', x1 + barW / 2, y1 - 12, pal.c1, pal);
 }

 if (state.ch1Series.s2) {
 var h2 = (bkB[i] / maxY) * phA;
 var x2 = state.ch1Series.s1 ? (cx + 4) : (cx - barW / 2);
 var y2 = padA.top + phA - h2;
 var grad2 = ctx.createLinearGradient(0, y2, 0, padA.top + phA);
 grad2.addColorStop(0, '#34D399');
 grad2.addColorStop(1, '#16A34A');
 ctx.fillStyle = grad2;
 topRoundedBar(ctx, x2, y2, barW, h2, 5);
 ctx.fill();
 drawValueBadge(ctx, '$' + bkB[i].toFixed(2) + 'B', x2 + barW / 2, y2 - 12, pal.c2, pal);
 }

 var diffB = bkB[i] - revB[i];
 ctx.fillStyle = pal.text;
 ctx.font = '700 11.5px system-ui, sans-serif';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'alphabetic';
 ctx.fillText(labelsA[i], cx, padA.top + phA + 19);
 ctx.fillStyle = pal.tick;
 ctx.font = '10px "IBM Plex Mono", sans-serif';
 ctx.fillText((isEn() ? 'Defer +$' : '递延净增 +$') + diffB.toFixed(2) + 'B', cx, padA.top + phA + 34);

 hitRegions.chartCh1.push({
 idx: i,
 x: padA.left + stepA * i, y: padA.top, w: stepA, h: phA + 36,
 html: isEn()
 ? ('<strong>' + labelsA[i] + ' Top-Line Reconciliation</strong><br/>' +
 '• GAAP Revenue: <strong>$' + revB[i].toFixed(2) + 'B</strong><br/>' +
 '• Cash Bookings: <strong>$' + bkB[i].toFixed(2) + 'B</strong><br/>' +
 '• Unrecognized Deferred Addition: <strong style="color:#22C55E;">+$' + diffB.toFixed(2) + 'B</strong>')
 : ('<strong>' + labelsA[i] + ' 营收与预订额差额调节</strong><br/>' +
 '• GAAP 确认营收：<strong>$' + revB[i].toFixed(2) + 'B</strong><br/>' +
 '• 现金预订额 Bookings：<strong>$' + bkB[i].toFixed(2) + 'B</strong><br/>' +
 '• 当期未确认递延沉淀：<strong style="color:#22C55E;">+$' + diffB.toFixed(2) + 'B</strong>')
 });
 }
 } else {
 if (metaEl) {
 metaEl.innerHTML = isEn()
 ? '<span style="color:var(--chart-c1);">■ Left Axis: Full-Time Employees (k FTEs)</span><span style="color:var(--chart-c2);">● Right Axis: Bookings per Employee ($M/FTE)</span>'
 : '<span style="color:var(--chart-c1);">■ 左轴：全职员工总数 (千人)</span><span style="color:var(--chart-c2);">● 右轴：人均 Bookings 创收 ($M/人)</span>';
 }
 if (leg1) leg1.textContent = isEn() ? 'Full-Time Employees (Left Axis · k FTEs)' : '全职员工人数 Full-Time Staff (左轴 · 千人)';
 if (leg2) leg2.textContent = isEn() ? 'Bookings per Employee (Right Axis · $M/FTE)' : '人均预订额创收 Bookings/Employee (右轴 · $M)';

 var padB = { top: 28, right: 50, bottom: 38, left: 46 };
 var pwB = w - padB.left - padB.right;
 var phB = h - padB.top - padB.bottom;
 var labelsB = ['FY2022', 'FY2023', 'FY2024', 'FY2025'];
 var empK = [2.128, 2.457, 2.474, 3.065];
 var bkPerEmp = [1.35, 1.43, 1.77, 2.21];
 var maxEmp = 5.0;
 var minRev = 1.0, maxRev = 2.5;

 for (var j = 0; j <= 4; j++) {
 var r = j / 4;
 var yGrid = padB.top + phB - r * phB;
 ctx.strokeStyle = pal.grid;
 ctx.lineWidth = 1;
 ctx.beginPath();
 ctx.moveTo(padB.left, yGrid);
 ctx.lineTo(padB.left + pwB, yGrid);
 ctx.stroke();

 ctx.font = '11px "IBM Plex Mono", sans-serif';
 ctx.textBaseline = 'middle';
 ctx.fillStyle = pal.tick;
 ctx.textAlign = 'right';
 ctx.fillText((maxEmp * r).toFixed(1) + 'k', padB.left - 7, yGrid);

 ctx.fillStyle = pal.c2;
 ctx.textAlign = 'left';
 ctx.fillText('$' + (minRev + r * (maxRev - minRev)).toFixed(2) + 'M', padB.left + pwB + 7, yGrid);
 }

 var stepB = pwB / labelsB.length;
 var bWidth = Math.min(48, Math.max(24, stepB * 0.36));
 var pts = [];

 for (var k = 0; k < labelsB.length; k++) {
 var centerX = padB.left + stepB * (k + 0.5);
 if (hoverState.chartCh1 === k) {
 ctx.fillStyle = pal.hoverBand;
 roundRectPath(ctx, padB.left + stepB * k + 6, padB.top, stepB - 12, phB, 6);
 ctx.fill();
 }

 if (state.ch1Series.s1) {
 var bH = (empK[k] / maxEmp) * phB;
 var bX = centerX - bWidth / 2;
 var bY = padB.top + phB - bH;
 var bGrad = ctx.createLinearGradient(0, bY, 0, padB.top + phB);
 if (pal.isDark) {
 bGrad.addColorStop(0, 'rgba(51, 153, 255, 0.72)');
 bGrad.addColorStop(1, 'rgba(0, 115, 230, 0.26)');
 } else {
 bGrad.addColorStop(0, '#1985F1');
 bGrad.addColorStop(1, '#0066CC');
 }
 ctx.fillStyle = bGrad;
 topRoundedBar(ctx, bX, bY, bWidth, bH, 5);
 ctx.fill();

 ctx.fillStyle = '#FFFFFF';
 ctx.font = '700 10.5px "IBM Plex Mono", sans-serif';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'alphabetic';
 ctx.fillText(Math.round(empK[k] * 1000).toLocaleString(), centerX, bY + 17);
 }

 var lY = padB.top + phB - ((bkPerEmp[k] - minRev) / (maxRev - minRev)) * phB;
 pts.push({ x: centerX, y: lY, val: bkPerEmp[k] });

 ctx.fillStyle = pal.text;
 ctx.font = '700 12px system-ui, sans-serif';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'alphabetic';
 ctx.fillText(labelsB[k], centerX, padB.top + phB + 22);

 hitRegions.chartCh1.push({
 idx: k,
 x: padB.left + stepB * k, y: padB.top, w: stepB, h: phB + 28,
 html: isEn()
 ? ('<strong>' + labelsB[k] + ' Workforce Productivity (10-K)</strong><br/>' +
 '• Full-Time Employees: <strong>' + Math.round(empK[k] * 1000).toLocaleString() + ' FTEs</strong><br/>' +
 '• Bookings / Employee: <strong>$' + bkPerEmp[k].toFixed(2) + 'M / FTE</strong>')
 : ('<strong>' + labelsB[k] + ' 组织人效明细 (10-K)</strong><br/>' +
 '• 年末全职员工：<strong>' + Math.round(empK[k] * 1000).toLocaleString() + ' 人</strong><br/>' +
 '• 人均 Bookings 创收：<strong>$' + bkPerEmp[k].toFixed(2) + 'M / 人</strong>')
 });
 }

 if (state.ch1Series.s2) {
 ctx.save();
 drawSmoothLine(ctx, pts);
 ctx.strokeStyle = pal.c2;
 ctx.lineWidth = 2.8;
 ctx.stroke();
 ctx.restore();

 for (var n = 0; n < pts.length; n++) {
 ctx.fillStyle = pal.pillBg;
 ctx.beginPath();
 ctx.arc(pts[n].x, pts[n].y, 6, 0, Math.PI * 2);
 ctx.fill();
 ctx.fillStyle = pal.c2;
 ctx.beginPath();
 ctx.arc(pts[n].x, pts[n].y, 4.2, 0, Math.PI * 2);
 ctx.fill();
 drawValueBadge(ctx, '$' + pts[n].val.toFixed(2) + 'M', pts[n].x, pts[n].y - 16, pal.c2, pal);
 }
 }
 }
 }

 /* Chart 2: 5-Dimension Corporate Fundamentals Radar Chart */
 function drawRadarChart() {
 var env = prepareCanvas('chartRadar');
 if (!env) return;
 var ctx = env.ctx, w = env.w, h = env.h;
 var pal = getPalette();
 hitRegions.chartRadar = [];

 var axes = isEn()
 ? ['FCF Conversion', 'Bookings / FTE', 'Low Hit-Delay Risk', 'Net Cash Fortress', 'Organic CAGR']
 : ['自由现金流转化', '人均创收杠杆', '免疫单作跳票风险', '净现金安全垫', '内生复合增速'];

 var pillarAxisMap = [0, 2, 1, 3];
 var highlightedAxis = hoverState.chartRadar >= 0 ? hoverState.chartRadar : pillarAxisMap[state.activePillar];

 var series = [
 { key: 'mo', name: 'Roblox (RBLX)', color: pal.c1, fill: 'rgba(51, 153, 255, 0.24)', vals: [9.3, 9.7, 9.6, 9.5, 9.4] },
 { key: 'pmi', name: 'Take-Two (TTWO)', color: pal.c2, fill: 'rgba(34, 197, 94, 0.16)', vals: [6.8, 6.5, 5.8, 6.4, 8.6] },
 { key: 'ko', name: 'Unity (U)', color: pal.c3, fill: 'rgba(255, 183, 77, 0.14)', vals: [7.6, 7.2, 8.5, 7.0, 7.5] }
 ];

 var cx = w / 2;
 var cy = h / 2 + 8;
 var sidePad = w < 420 ? 86 : 104;
 var radius = Math.max(62, Math.min((w - sidePad * 2) / 2, h * 0.35));
 var total = axes.length;

 for (var ring = 2; ring <= 10; ring += 2) {
 var r = (ring / 10) * radius;
 ctx.strokeStyle = pal.grid;
 ctx.lineWidth = ring === 10 ? 1.3 : 1;
 ctx.beginPath();
 for (var i = 0; i < total; i++) {
 var ang = -Math.PI / 2 + (i * 2 * Math.PI) / total;
 var px = cx + Math.cos(ang) * r;
 var py = cy + Math.sin(ang) * r;
 if (i === 0) ctx.moveTo(px, py);
 else ctx.lineTo(px, py);
 }
 ctx.closePath();
 ctx.stroke();

 ctx.fillStyle = pal.tick;
 ctx.font = '600 9.5px "IBM Plex Mono", sans-serif';
 ctx.textAlign = 'left';
 ctx.textBaseline = 'middle';
 ctx.fillText(String(ring), cx + 4, cy - r);
 }

 for (var a = 0; a < total; a++) {
 var angle = -Math.PI / 2 + (a * 2 * Math.PI) / total;
 var ax = cx + Math.cos(angle) * radius;
 var ay = cy + Math.sin(angle) * radius;
 var isHi = a === highlightedAxis;

 ctx.strokeStyle = isHi ? pal.c1 : pal.grid;
 ctx.lineWidth = isHi ? 1.8 : 1;
 ctx.beginPath();
 ctx.moveTo(cx, cy);
 ctx.lineTo(ax, ay);
 ctx.stroke();

 var lx = cx + Math.cos(angle) * (radius + 14);
 var ly = cy + Math.sin(angle) * (radius + 15);
 ctx.fillStyle = isHi ? pal.c1 : pal.text;
 ctx.font = (isHi ? '800 ' : '600 ') + (w < 420 ? '10.5px' : '11.5px') + ' system-ui, sans-serif';
 ctx.textBaseline = 'middle';
 if (Math.abs(Math.cos(angle)) < 0.2) ctx.textAlign = 'center';
 else if (Math.cos(angle) > 0) ctx.textAlign = 'left';
 else ctx.textAlign = 'right';
 ctx.fillText(axes[a], lx, ly);

 hitRegions.chartRadar.push({
 idx: a,
 x: Math.min(ax, lx) - 36, y: Math.min(ay, ly) - 22, w: 72 + Math.abs(lx - ax), h: 44,
 html: isEn()
 ? ('<strong>' + axes[a] + ' (10-Pt Scale)</strong><br/>' +
 '• Roblox (RBLX): <strong>' + series[0].vals[a].toFixed(1) + '</strong><br/>' +
 '• Take-Two (TTWO): <strong>' + series[1].vals[a].toFixed(1) + '</strong><br/>' +
 '• Unity Software (U): <strong>' + series[2].vals[a].toFixed(1) + '</strong>')
 : ('<strong>' + axes[a] + ' (10分制机构评估)</strong><br/>' +
 '• Roblox (RBLX)：<strong>' + series[0].vals[a].toFixed(1) + ' 分</strong><br/>' +
 '• Take-Two (TTWO)：<strong>' + series[1].vals[a].toFixed(1) + ' 分</strong><br/>' +
 '• Unity Software (U)：<strong>' + series[2].vals[a].toFixed(1) + ' 分</strong>')
 });
 }

 for (var s = 0; s < series.length; s++) {
 var item = series[s];
 if (!state.radarSeries[item.key]) continue;
 ctx.beginPath();
 for (var idx = 0; idx < total; idx++) {
 var theta = -Math.PI / 2 + (idx * 2 * Math.PI) / total;
 var dist = (item.vals[idx] / 10) * radius;
 var vx = cx + Math.cos(theta) * dist;
 var vy = cy + Math.sin(theta) * dist;
 if (idx === 0) ctx.moveTo(vx, vy);
 else ctx.lineTo(vx, vy);
 }
 ctx.closePath();
 ctx.fillStyle = item.fill;
 ctx.fill();
 ctx.strokeStyle = item.color;
 ctx.lineWidth = 2.4;
 ctx.stroke();

 for (var pIdx = 0; pIdx < total; pIdx++) {
 var pTheta = -Math.PI / 2 + (pIdx * 2 * Math.PI) / total;
 var pDist = (item.vals[pIdx] / 10) * radius;
 var pX = cx + Math.cos(pTheta) * pDist;
 var pY = cy + Math.sin(pTheta) * pDist;
 ctx.fillStyle = pal.pillBg;
 ctx.beginPath();
 ctx.arc(pX, pY, 5.2, 0, Math.PI * 2);
 ctx.fill();
 ctx.fillStyle = item.color;
 ctx.beginPath();
 ctx.arc(pX, pY, 3.6, 0, Math.PI * 2);
 ctx.fill();
 }
 }
 }

 /* Chart 3: Two-Deck Full-Width Corporate Financial Ratios Chart */
 function drawHorizontalBars() {
 var env = prepareCanvas('chartBars');
 if (!env) return;
 var ctx = env.ctx, w = env.w, h = env.h;
 var pal = getPalette();
 hitRegions.chartBars = [];

 var items = isEn() ? [
 { label: 'Operating Cash Flow / GAAP Revenue Margin (FY25)', val: 36.7, cStart: '#34D399', cEnd: '#16A34A', sub: '$1,796M / $4,891M', note: 'Upfront Robux cash inflows yield elite cash conversion relative to GAAP revenue' },
 { label: 'Free Cash Flow / Cash Bookings Conversion (FY25)', val: 19.9, cStart: '#3399FF', cEnd: '#0073E6', sub: '$1,353M / $6,788M', note: 'Nearly 20 cents of every Robux dollar booked converted into pure free cash flow' },
 { label: 'Net Cash Fortress / Basic Market Cap Cushion (26Q3)', val: 15.5, cStart: '#60A5FA', cEnd: '#2563EB', sub: '$5.23B / $33.84B', note: '$6.24B cash & investments minus $1.01B 2030 notes provides 15.5% valuation floor' },
 { label: 'R&D Expense / GAAP Revenue Intensity (FY25)', val: 32.1, cStart: '#A78BFA', cEnd: '#7C3AED', sub: '$1,568M / $4,891M', note: 'Heavy platform investment in Cube 3D/4D, Studio AI, SLIM & Universal Player' },
 { label: 'Stock-Based Compensation (SBC) / GAAP Revenue (FY25)', val: 23.1, cStart: '#FBBF24', cEnd: '#D97706', sub: '$1,129M / $4,891M (16.6% of Bk)', note: 'Primary non-cash expense item now actively offset via $3.0B share repurchase plan' },
 { label: 'Cost of Revenue (Payment Fees) / GAAP Revenue (26Q3)', val: 20.2, cStart: '#38BDF8', cEnd: '#0284C7', sub: '$318M / $1,572M (-160 bps YoY)', note: 'Direct web and prepaid card billing steadily reduces app-store fee drag' }
 ] : [
 { label: '经营活动现金流 / GAAP 营收利润率 (FY25)', val: 36.7, cStart: '#34D399', cEnd: '#16A34A', sub: '$1,796M / $4,891M', note: '预收现金机制驱动经营现金流远超传统软件与游戏发行商' },
 { label: '自由现金流 FCF / Bookings 现金转化率 (FY25)', val: 19.9, cStart: '#3399FF', cEnd: '#0073E6', sub: '$1,353M / $6,788M', note: '每 $100 美元玩家充值预订额即可沉淀近 $20 美元自由现金流' },
 { label: '账面净现金储备 / 基础总市值安全垫占比 (26Q3)', val: 15.5, cStart: '#60A5FA', cEnd: '#2563EB', sub: '$5.23B / $33.84B', note: '$62.4亿现金及投资扣除 $10.1亿长债，构筑坚实下行估值护垫' },
 { label: '研发费用 R&D / GAAP 营收投入强度 (FY25)', val: 32.1, cStart: '#A78BFA', cEnd: '#7C3AED', sub: '$1,568M / $4,891M', note: '重仓投入近 400 个自研 AI 模型、跨端引擎与混合云架构' },
 { label: '股权激励费用 SBC / GAAP 营收比重 (FY25)', val: 23.1, cStart: '#FBBF24', cEnd: '#D97706', sub: '$1,129M / $4,891M (占Bk 16.6%)', note: '账面亏损核心非现金项，现已通过 $30 亿股票回购机制直接对冲' },
 { label: '营收成本（支付渠道抽成）占 GAAP 营收比重 (26Q3)', val: 20.2, cStart: '#38BDF8', cEnd: '#0284C7', sub: '$318M / $1,572M (同比 -160 bps)', note: '引导第一方网页与礼品卡直充显著降低移动应用商店过路费' }
 ];

 var pad = { top: 10, right: 18, bottom: 26, left: 18 };
 var pw = w - pad.left - pad.right;
 var ph = h - pad.top - pad.bottom;
 var maxX = 45;

 for (var g = 0; g <= 3; g++) {
 var xVal = g * 15;
 var gx = pad.left + (xVal / maxX) * pw;
 ctx.strokeStyle = pal.grid;
 ctx.lineWidth = 1;
 ctx.beginPath();
 ctx.moveTo(gx, pad.top);
 ctx.lineTo(gx, pad.top + ph);
 ctx.stroke();

 ctx.fillStyle = pal.tick;
 ctx.font = '10.5px "IBM Plex Mono", sans-serif';
 ctx.textAlign = g === 0 ? 'left' : (g === 3 ? 'right' : 'center');
 ctx.textBaseline = 'alphabetic';
 ctx.fillText(xVal + '%', gx, pad.top + ph + 18);
 }

 var rowH = ph / items.length;

 for (var i = 0; i < items.length; i++) {
 var rowTop = pad.top + rowH * i;
 var isHovered = hoverState.chartBars === i;
 if (isHovered) {
 ctx.fillStyle = pal.hoverBand;
 roundRectPath(ctx, pad.left - 6, rowTop + 2, pw + 12, rowH - 4, 8);
 ctx.fill();
 }

 var labelY = rowTop + Math.max(15, rowH * 0.34);
 var barY = rowTop + Math.max(22, rowH * 0.50);
 var barH = Math.min(15, Math.max(11, rowH * 0.26));
 var bw = Math.max(8, (items[i].val / maxX) * pw);

 ctx.fillStyle = pal.text;
 ctx.font = '600 ' + (w < 460 ? '11px' : '12px') + ' system-ui, sans-serif';
 ctx.textAlign = 'left';
 ctx.textBaseline = 'alphabetic';
 ctx.fillText(items[i].label, pad.left, labelY);

 var valStr = items[i].val.toFixed(1) + '%';
 ctx.font = '800 12.5px "IBM Plex Mono", sans-serif';
 ctx.fillStyle = pal.isDark ? items[i].cStart : items[i].cEnd;
 ctx.textAlign = 'right';
 ctx.fillText(valStr, pad.left + pw, labelY);

 if (w >= 580) {
 var valW = ctx.measureText(valStr).width + 10;
 ctx.font = '500 11px "IBM Plex Mono", system-ui, sans-serif';
 ctx.fillStyle = pal.tick;
 ctx.fillText(items[i].sub, pad.left + pw - valW, labelY);
 }

 ctx.fillStyle = pal.trackBg;
 roundRectPath(ctx, pad.left, barY, pw, barH, barH / 2);
 ctx.fill();

 var barGrad = ctx.createLinearGradient(pad.left, 0, pad.left + bw, 0);
 barGrad.addColorStop(0, items[i].cStart);
 barGrad.addColorStop(1, items[i].cEnd);
 ctx.fillStyle = barGrad;
 roundRectPath(ctx, pad.left, barY, bw, barH, barH / 2);
 ctx.fill();

 hitRegions.chartBars.push({
 idx: i,
 x: pad.left, y: rowTop, w: pw, h: rowH,
 html: isEn()
 ? ('<strong>' + items[i].label + ': ' + items[i].val.toFixed(1) + '%</strong><br/>• Basis: ' + items[i].sub + '<br/>• Takeaway: ' + items[i].note)
 : ('<strong>' + items[i].label + '：' + items[i].val.toFixed(1) + '%</strong><br/>• 计算口径：' + items[i].sub + '<br/>• 财务解读：' + items[i].note)
 });
 }
 }

 /* Chart 4: FY2022–FY2026E Operating Cash Flow ($B) & Free Cash Flow ($B) */
 function drawEpsComboChart() {
 var env = prepareCanvas('chartEps');
 if (!env) return;
 var ctx = env.ctx, w = env.w, h = env.h;
 var pal = getPalette();
 hitRegions.chartEps = [];

 var years = ['FY2022', 'FY2023', 'FY2024', 'FY2025', 'FY2026E'];
 var subYears = isEn() ? ['(CapEx Build)', '(Inflection)', '(+79% OCF)', '(+118% OCF)', '(9M+Q4 Mid)'] : ['(基建投入期)', '(现金流转正)', '(OCF +79%)', '(OCF +118%)', '(前三季+Q4指引)'];
 var ocf = [0.37, 0.46, 0.82, 1.80, 1.57];
 var fcf = [-0.06, 0.12, 0.64, 1.35, 1.11];
 var gaapLoss = [-0.93, -1.16, -0.94, -1.07, -1.06];

 var pad = { top: 26, right: 54, bottom: 44, left: 48 };
 var pw = w - pad.left - pad.right;
 var ph = h - pad.top - pad.bottom;

 var minO = 0.0, maxO = 2.2;
 var minF = -0.2, maxF = 1.8;

 for (var g = 0; g <= 4; g++) {
 var ratio = g / 4;
 var gy = pad.top + ph - ratio * ph;
 ctx.strokeStyle = pal.grid;
 ctx.lineWidth = 1;
 ctx.beginPath();
 ctx.moveTo(pad.left, gy);
 ctx.lineTo(pad.left + pw, gy);
 ctx.stroke();

 var oTick = minO + ratio * (maxO - minO);
 var fTick = minF + ratio * (maxF - minF);
 ctx.font = '11px "IBM Plex Mono", sans-serif';
 ctx.textBaseline = 'middle';
 ctx.fillStyle = pal.tick;
 ctx.textAlign = 'right';
 ctx.fillText('$' + oTick.toFixed(2) + 'B', pad.left - 7, gy);
 ctx.textAlign = 'left';
 ctx.fillStyle = pal.c2;
 ctx.fillText((fTick < 0 ? '-$' + Math.abs(fTick).toFixed(2) : '$' + fTick.toFixed(2)) + 'B', pad.left + pw + 7, gy);
 }

 /* $1.0B FCF Milestone Line */
 var targetY = pad.top + ph - ((1.00 - minF) / (maxF - minF)) * ph;
 ctx.save();
 ctx.setLineDash([5, 5]);
 ctx.strokeStyle = pal.c3;
 ctx.lineWidth = 1.5;
 ctx.beginPath();
 ctx.moveTo(pad.left, targetY);
 ctx.lineTo(pad.left + pw, targetY);
 ctx.stroke();
 ctx.restore();

 var step = pw / years.length;
 var barW = Math.min(46, Math.max(24, step * 0.42));
 var linePts = [];

 for (var i = 0; i < years.length; i++) {
 var cx = pad.left + step * (i + 0.5);
 if (hoverState.chartEps === i) {
 ctx.fillStyle = pal.hoverBand;
 roundRectPath(ctx, pad.left + step * i + 4, pad.top, step - 8, ph, 6);
 ctx.fill();
 }

 if (state.epsSeries.eps) {
 var bh = ((ocf[i] - minO) / (maxO - minO)) * ph;
 var bx = cx - barW / 2;
 var by = pad.top + ph - bh;
 var eGrad = ctx.createLinearGradient(0, by, 0, pad.top + ph);
 if (i === 4) {
 eGrad.addColorStop(0, '#66B2FF');
 eGrad.addColorStop(1, '#1985F1');
 } else {
 eGrad.addColorStop(0, '#3399FF');
 eGrad.addColorStop(1, '#0066CC');
 }
 ctx.fillStyle = eGrad;
 topRoundedBar(ctx, bx, by, barW, bh, 6);
 ctx.fill();

 if (bh > 22) {
 ctx.fillStyle = '#FFFFFF';
 ctx.font = '700 10.5px "IBM Plex Mono", sans-serif';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'alphabetic';
 ctx.fillText('$' + ocf[i].toFixed(2) + 'B', cx, by + 17);
 }
 }

 var oy = pad.top + ph - ((fcf[i] - minF) / (maxF - minF)) * ph;
 linePts.push({ x: cx, y: oy, fcf: fcf[i] });

 ctx.fillStyle = pal.text;
 ctx.font = '700 11.5px system-ui, sans-serif';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'alphabetic';
 ctx.fillText(years[i], cx, pad.top + ph + 19);
 if (subYears[i]) {
 ctx.fillStyle = pal.tick;
 ctx.font = '10px system-ui, sans-serif';
 ctx.fillText(subYears[i], cx, pad.top + ph + 33);
 }

 var fcfStr = fcf[i] < 0 ? ('-$' + Math.abs(fcf[i]).toFixed(2) + 'B') : ('+$' + fcf[i].toFixed(2) + 'B');
 hitRegions.chartEps.push({
 idx: i,
 x: pad.left + step * i, y: pad.top, w: step, h: ph + 36,
 html: isEn()
 ? ('<strong>' + years[i] + ' Cash vs. GAAP Comparison</strong><br/>' +
 '• Operating Cash Flow: <strong>+$' + ocf[i].toFixed(2) + 'B</strong><br/>' +
 '• Free Cash Flow: <strong style="color:#22C55E;">' + fcfStr + '</strong><br/>' +
 '• GAAP Consolidated Net Loss: -$' + Math.abs(gaapLoss[i]).toFixed(2) + 'B')
 : ('<strong>' + years[i] + ' 真实造血 vs 账面损益对照</strong><br/>' +
 '• 经营活动现金流 OCF：<strong>+$' + ocf[i].toFixed(2) + 'B</strong><br/>' +
 '• 自由现金流 FCF：<strong style="color:#22C55E;">' + fcfStr + '</strong><br/>' +
 '• 同期 GAAP 合并净亏损：-$' + Math.abs(gaapLoss[i]).toFixed(2) + 'B')
 });
 }

 if (w >= 460) {
 drawValueBadge(ctx, isEn() ? 'FCF $1.0B Line' : 'FCF $1.0B 分水岭', pad.left + pw * 0.28, targetY - 12, pal.c3, pal);
 }

 if (state.epsSeries.oci) {
 ctx.save();
 drawSmoothLine(ctx, linePts);
 ctx.strokeStyle = pal.c2;
 ctx.lineWidth = 2.8;
 ctx.stroke();
 ctx.restore();

 for (var m = 0; m < linePts.length; m++) {
 ctx.fillStyle = pal.pillBg;
 ctx.beginPath();
 ctx.arc(linePts[m].x, linePts[m].y, 6, 0, Math.PI * 2);
 ctx.fill();
 ctx.fillStyle = pal.c2;
 ctx.beginPath();
 ctx.arc(linePts[m].x, linePts[m].y, 4.2, 0, Math.PI * 2);
 ctx.fill();
 var bTxt = linePts[m].fcf < 0 ? ('-$' + Math.abs(linePts[m].fcf).toFixed(2) + 'B') : ('$' + linePts[m].fcf.toFixed(2) + 'B');
 drawValueBadge(ctx, bTxt, linePts[m].x, linePts[m].y - 16, pal.c2, pal);
 }
 }
 }

 /* Chart 5: 5-Year Implied Share Price Trajectory Simulator Chart */
 function drawSimChart() {
 var env = prepareCanvas('chartSim');
 if (!env) return;
 var ctx = env.ctx, w = env.w, h = env.h;
 var pal = getPalette();
 hitRegions.chartSim = [];

 var m = computeValuationModel();
 var yrs = 5;
 var activeP = m.activePrices;
 var rawP = m.unmitigatedPrices;

 var maxVal = Math.max.apply(null, activeP.concat(rawP, [65])) * 1.12;
 var pad = { top: 20, right: 20, bottom: 28, left: 54 };
 var pw = w - pad.left - pad.right;
 var ph = h - pad.top - pad.bottom;

 for (var g = 0; g <= 3; g++) {
 var v = (maxVal / 3) * g;
 var gy = pad.top + ph - (g / 3) * ph;
 ctx.strokeStyle = pal.grid;
 ctx.lineWidth = 1;
 ctx.beginPath();
 ctx.moveTo(pad.left, gy);
 ctx.lineTo(pad.left + pw, gy);
 ctx.stroke();

 ctx.fillStyle = pal.tick;
 ctx.font = '10.5px "IBM Plex Mono", sans-serif';
 ctx.textAlign = 'right';
 ctx.textBaseline = 'middle';
 ctx.fillText('$' + Math.round(v), pad.left - 7, gy);
 }

 var stepX = pw / yrs;

 /* Unmitigated dilution dashed curve */
 ctx.save();
 ctx.setLineDash([4, 4]);
 ctx.strokeStyle = pal.tick;
 ctx.lineWidth = 1.7;
 ctx.beginPath();
 for (var i = 0; i <= yrs; i++) {
 var px = pad.left + (i / yrs) * pw;
 var py = pad.top + ph - (rawP[i] / maxVal) * ph;
 if (i === 0) ctx.moveTo(px, py);
 else ctx.lineTo(px, py);
 }
 ctx.stroke();
 ctx.restore();

 /* Active trajectory + area fill */
 ctx.beginPath();
 for (var j = 0; j <= yrs; j++) {
 var tx = pad.left + (j / yrs) * pw;
 var ty = pad.top + ph - (activeP[j] / maxVal) * ph;
 if (j === 0) ctx.moveTo(tx, ty);
 else ctx.lineTo(tx, ty);

 var buybackGain = activeP[j] - rawP[j];
 hitRegions.chartSim.push({
 idx: j,
 x: tx - Math.max(10, stepX * 0.5), y: pad.top, w: Math.max(20, stepX), h: ph + 24,
 html: isEn()
 ? ('<strong>Year ' + j + (j === 0 ? ' (Current Spot)' : ' Projected Valuation') + '</strong><br/>' +
 '• Implied Share Price: <strong>$' + activeP[j].toFixed(2) + '</strong><br/>' +
 '• Ex-Buyback (2.2%/yr Dilution): $' + rawP[j].toFixed(2) + '<br/>' +
 '• Buyback Anti-Dilution Accretion: <strong style="color:#22C55E;">+$' + buybackGain.toFixed(2) + '/sh</strong>')
 : ('<strong>第 ' + j + ' 年' + (j === 0 ? ' (当前现价基准)' : ' 隐含每股价值') + '</strong><br/>' +
 '• 当前设定隐含股价：<strong>$' + activeP[j].toFixed(2) + ' / 股</strong><br/>' +
 '• 未对冲稀释 (2.2%/年) 股价：$' + rawP[j].toFixed(2) + ' / 股<br/>' +
 '• 回购注销每股增厚效应：<strong style="color:#22C55E;">+$' + buybackGain.toFixed(2) + ' / 股</strong>')
 });
 }
 ctx.strokeStyle = pal.c1;
 ctx.lineWidth = 2.8;
 ctx.stroke();

 ctx.lineTo(pad.left + pw, pad.top + ph);
 ctx.lineTo(pad.left, pad.top + ph);
 ctx.closePath();
 var grad = ctx.createLinearGradient(0, pad.top, 0, pad.top + ph);
 grad.addColorStop(0, 'rgba(0, 115, 230, 0.30)');
 grad.addColorStop(1, 'rgba(0, 115, 230, 0.01)');
 ctx.fillStyle = grad;
 ctx.fill();

 if (hoverState.chartSim >= 0 && hoverState.chartSim <= yrs) {
 var hi = hoverState.chartSim;
 var hx = pad.left + (hi / yrs) * pw;
 var hy1 = pad.top + ph - (activeP[hi] / maxVal) * ph;
 var hy2 = pad.top + ph - (rawP[hi] / maxVal) * ph;
 ctx.save();
 ctx.setLineDash([3, 3]);
 ctx.strokeStyle = pal.c1;
 ctx.lineWidth = 1.2;
 ctx.beginPath();
 ctx.moveTo(hx, pad.top);
 ctx.lineTo(hx, pad.top + ph);
 ctx.stroke();
 ctx.restore();

 ctx.fillStyle = pal.tick;
 ctx.beginPath();
 ctx.arc(hx, hy2, 4, 0, Math.PI * 2);
 ctx.fill();
 ctx.fillStyle = pal.c1;
 ctx.beginPath();
 ctx.arc(hx, hy1, 5.5, 0, Math.PI * 2);
 ctx.fill();
 }

 for (var ky = 0; ky <= yrs; ky++) {
 var kx = pad.left + (ky / yrs) * pw;
 var kyY = pad.top + ph - (activeP[ky] / maxVal) * ph;
 ctx.fillStyle = pal.pillBg;
 ctx.beginPath();
 ctx.arc(kx, kyY, 5, 0, Math.PI * 2);
 ctx.fill();
 ctx.fillStyle = pal.c1;
 ctx.beginPath();
 ctx.arc(kx, kyY, 3.5, 0, Math.PI * 2);
 ctx.fill();
 }

 var endX = pad.left + pw;
 var endY = pad.top + ph - (activeP[yrs] / maxVal) * ph;
 drawValueBadge(ctx, '$' + activeP[yrs].toFixed(2), Math.min(w - 38, endX - 22), Math.max(pad.top + 12, endY - 14), pal.c1, pal);

 ctx.fillStyle = pal.tick;
 ctx.font = '10.5px "IBM Plex Mono", sans-serif';
 ctx.textBaseline = 'alphabetic';
 ctx.textAlign = 'left';
 ctx.fillText(isEn() ? 'Now ($47.11)' : '现价 ($47.11)', pad.left, pad.top + ph + 19);
 ctx.textAlign = 'center';
 ctx.fillText((isEn() ? 'Year 3 ($' : '第 3 年 ($') + activeP[3].toFixed(1) + ')', pad.left + 0.6 * pw, pad.top + ph + 19);
 ctx.textAlign = 'right';
 ctx.fillText(isEn() ? 'Year 5' : '第 5 年', pad.left + pw, pad.top + ph + 19);
 }

 var redrawMap = {
 chartCh1: drawCh1Chart,
 chartRadar: drawRadarChart,
 chartBars: drawHorizontalBars,
 chartEps: drawEpsComboChart,
 chartSim: drawSimChart
 };

 function renderAllCharts() {
 drawCh1Chart();
 drawRadarChart();
 drawHorizontalBars();
 drawEpsComboChart();
 drawSimChart();
 }

 /* ======================================================================
 7. Hover & Touch Tooltips + Active Crosshair Redraw
 ====================================================================== */
 function wireCanvasTooltip(canvasId) {
 var canvas = document.getElementById(canvasId);
 var tip = document.getElementById('chartTooltip');
 if (!canvas || !tip) return;

 function handlePointer(clientX, clientY) {
 var rect = canvas.getBoundingClientRect();
 var mx = clientX - rect.left;
 var my = clientY - rect.top;
 var regions = hitRegions[canvasId] || [];
 var found = null;
 for (var i = 0; i < regions.length; i++) {
 var r = regions[i];
 if (mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h) {
 found = r;
 break;
 }
 }
 var nextIdx = found && typeof found.idx === 'number' ? found.idx : -1;
 if (hoverState[canvasId] !== nextIdx) {
 hoverState[canvasId] = nextIdx;
 if (redrawMap[canvasId]) redrawMap[canvasId]();
 }
 if (found) {
 tip.innerHTML = found.html;
 tip.style.display = 'block';
 var tipW = tip.offsetWidth || 250;
 var tipH = tip.offsetHeight || 72;
 var leftPos = clientX + 14;
 if (leftPos + tipW > window.innerWidth - 12) {
 leftPos = Math.max(12, clientX - tipW - 14);
 }
 var topPos = Math.max(12, Math.min(window.innerHeight - tipH - 12, clientY - 18));
 tip.style.left = leftPos + 'px';
 tip.style.top = topPos + 'px';
 } else {
 tip.style.display = 'none';
 }
 }

 canvas.addEventListener('mousemove', function (e) {
 handlePointer(e.clientX, e.clientY);
 });

 canvas.addEventListener('touchstart', function (e) {
 if (e.touches && e.touches[0]) {
 handlePointer(e.touches[0].clientX, e.touches[0].clientY);
 }
 }, { passive: true });

 canvas.addEventListener('mouseleave', function () {
 if (hoverState[canvasId] !== -1) {
 hoverState[canvasId] = -1;
 if (redrawMap[canvasId]) redrawMap[canvasId]();
 }
 tip.style.display = 'none';
 });
 }

 /* ======================================================================
 8. Standalone HTML Download Export
 ====================================================================== */
 function exportStandaloneHtml() {
 var doctype = '<!DOCTYPE html>\n';
 var htmlContent = doctype + document.documentElement.outerHTML;
 var blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
 var url = URL.createObjectURL(blob);
 var link = document.createElement('a');
 link.href = url;
 link.download = 'Roblox_Company_Analysis.html';
 document.body.appendChild(link);
 link.click();
 document.body.removeChild(link);
 setTimeout(function () {
 URL.revokeObjectURL(url);
 }, 1500);
 showToast(isEn() ? 'Exported standalone file: Roblox_Company_Analysis.html' : '已导出独立网页 Roblox_Company_Analysis.html');
 }

 /* ======================================================================
 9. Event Listeners & Initialization
 ====================================================================== */
 function init() {
 var rawTheme = safeGetStorage(STORAGE_THEME_KEY);
 var savedTheme = rawTheme ? String(rawTheme).replace(/^"|"$/g, '') : '';
 if (savedTheme === 'light' || savedTheme === 'dark') {
 state.theme = savedTheme;
 }
 var rawLang = safeGetStorage(STORAGE_LANG_KEY);
 var savedLang = rawLang ? String(rawLang).replace(/^"|"$/g, '') : '';
 if (savedLang === 'zh' || savedLang === 'en') {
 state.lang = savedLang;
 }
 window.addEventListener('storage', function (ev) {
 if (ev.key === STORAGE_THEME_KEY && ev.newValue) {
 var nt = String(ev.newValue).replace(/^"|"$/g, '');
 if ((nt === 'light' || nt === 'dark') && nt !== state.theme) applyTheme(nt, true);
 } else if (ev.key === STORAGE_LANG_KEY && ev.newValue) {
 var nl = String(ev.newValue).replace(/^"|"$/g, '');
 if ((nl === 'zh' || nl === 'en') && nl !== state.lang) applyLanguage(nl, true);
 }
 });
 var savedChecks = safeGetStorage(STORAGE_CHECK_KEY);
 if (savedChecks) {
 try {
 var parsed = JSON.parse(savedChecks);
 if (Array.isArray(parsed) && parsed.length === CHECKLIST_ITEMS.length) {
 state.checks = parsed.map(Boolean);
 }
 } catch (e) {
 /* Ignore malformed storage */
 }
 }

 applyTheme(state.theme, true);
 applyLanguage(state.lang, true);

 document.getElementById('langZhBtn').addEventListener('click', function () { applyLanguage('zh', false); });
 document.getElementById('langEnBtn').addEventListener('click', function () { applyLanguage('en', false); });
 var abThm = document.getElementById('appbarThemeBtn');
 if (abThm) {
 abThm.addEventListener('click', function () { applyTheme(state.theme === 'dark' ? 'light' : 'dark', false); });
 }

 /* Sidebar & Theme Controls */
 document.getElementById('sidebarToggleBtn').addEventListener('click', toggleSidebar);
 document.getElementById('drawerBackdrop').addEventListener('click', closeMobileDrawer);
 void 0;
 void 0;

 /* Sidebar Export & Print Buttons */
 void 0;
 void 0;

 /* Close mobile drawer on TOC click */
 var tocLinks = document.querySelectorAll('#tocNavList .mui-nav-link');
 for (var t = 0; t < tocLinks.length; t++) {
 tocLinks[t].addEventListener('click', closeMobileDrawer);
 }

 /* Quick Jump Search (Ctrl+K / Cmd+K) */
 var jumpInput = document.getElementById('quickJumpInput');
 var jumpPop = document.getElementById('quickJumpPopover');
 function renderJumpList(q) {
 var kw = (q || '').trim().toLowerCase();
 var activeJump = isEn() ? QUICK_JUMP_EN : QUICK_JUMP_INDEX;
 var list = activeJump.filter(function (item, idx) {
 var zhIt = QUICK_JUMP_INDEX[idx] || item;
 var enIt = QUICK_JUMP_EN[idx] || item;
 return !kw || (zhIt.title + ' ' + zhIt.sub + ' ' + enIt.title + ' ' + enIt.sub).toLowerCase().indexOf(kw) !== -1;
 });
 if (!list.length) {
 jumpPop.innerHTML = '<div style="padding:10px;font-size:0.78rem;color:var(--text-muted);">' + (isEn() ? 'No matching section' : '未匹配到对应章节') + '</div>';
 } else {
 jumpPop.innerHTML = list.map(function (item) {
 return '<button type="button" class="quick-jump-item" data-jump-sec="' + item.sec + '">' +
 '<span class="quick-jump-item-title">' + escapeHtml(item.title) + '</span>' +
 '<span class="quick-jump-item-sub">' + escapeHtml(item.sub) + '</span>' +
 '</button>';
 }).join('');
 }
 jumpPop.classList.add('open');
 }

 jumpInput.addEventListener('focus', function () { renderJumpList(jumpInput.value); });
 jumpInput.addEventListener('input', function () { renderJumpList(jumpInput.value); });
 jumpPop.addEventListener('click', function (e) {
 var btn = e.target.closest('[data-jump-sec]');
 if (!btn) return;
 var targetId = btn.getAttribute('data-jump-sec');
 var secEl = document.getElementById(targetId);
 if (secEl) secEl.scrollIntoView({ behavior: 'smooth' });
 jumpPop.classList.remove('open');
 });
 document.addEventListener('click', function (e) {
 if (!e.target.closest('.quick-search-wrap')) {
 jumpPop.classList.remove('open');
 }
 });
 document.addEventListener('keydown', function (e) {
 if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
 e.preventDefault();
 jumpInput.focus();
 } else if (e.key === 'Escape') {
 jumpPop.classList.remove('open');
 closeMobileDrawer();
 }
 });

 /* Ch 01 View A / View B Tabs */
 var ch1Btns = document.querySelectorAll('[data-ch1-view]');
 for (var c = 0; c < ch1Btns.length; c++) {
 ch1Btns[c].addEventListener('click', function () {
 state.ch1View = this.getAttribute('data-ch1-view');
 document.getElementById('ch1TabA').classList.toggle('active', state.ch1View === 'viewA');
 document.getElementById('ch1TabB').classList.toggle('active', state.ch1View === 'viewB');
 syncCh1HeaderText();
 drawCh1Chart();
 });
 }

 /* Expandable Matrix Card Collapses */
 var collapseBtns = document.querySelectorAll('[data-collapse-target]');
 for (var m = 0; m < collapseBtns.length; m++) {
 collapseBtns[m].addEventListener('click', function () {
 var panelId = this.getAttribute('data-collapse-target');
 var panel = document.getElementById(panelId);
 if (!panel) return;
 panel.classList.toggle('open');
 syncCollapseButtonsText();
 });
 }

 /* Ch 02 Pillar Selection & Radar Legend Toggles */
 var pillarCards = document.querySelectorAll('[data-pillar]');
 for (var p = 0; p < pillarCards.length; p++) {
 pillarCards[p].addEventListener('click', function () {
 var idx = parseInt(this.getAttribute('data-pillar'), 10) || 0;
 state.activePillar = idx;
 for (var k = 0; k < pillarCards.length; k++) {
 pillarCards[k].classList.toggle('active', k === idx);
 }
 document.getElementById('pillarFocusNote').innerHTML = '<div>' + (isEn() ? PILLAR_NOTES_EN : PILLAR_NOTES)[idx] + '</div>';
 drawRadarChart();
 });
 }

 var radarPills = document.querySelectorAll('[data-radar-key]');
 for (var r = 0; r < radarPills.length; r++) {
 radarPills[r].addEventListener('click', function () {
 var key = this.getAttribute('data-radar-key');
 state.radarSeries[key] = !state.radarSeries[key];
 if (!state.radarSeries.mo && !state.radarSeries.pmi && !state.radarSeries.ko) {
 state.radarSeries[key] = true;
 }
 this.classList.toggle('muted', !state.radarSeries[key]);
 drawRadarChart();
 });
 }

 /* Ch 03 Peer Search & Filter */
 document.getElementById('peerSearchInput').addEventListener('input', function () {
 state.peerQuery = this.value;
 renderPeerTable();
 });
 var peerFilterBtns = document.querySelectorAll('[data-peer-filter]');
 for (var pf = 0; pf < peerFilterBtns.length; pf++) {
 peerFilterBtns[pf].addEventListener('click', function () {
 state.peerFilter = this.getAttribute('data-peer-filter');
 for (var x = 0; x < peerFilterBtns.length; x++) {
 peerFilterBtns[x].classList.toggle('active', peerFilterBtns[x] === this);
 }
 renderPeerTable();
 });
 }

 /* Ch 04 Valuation Simulator Controls */
 var pSlider = document.getElementById('simPrincipalSlider');
 var ySlider = document.getElementById('simYearsSlider');
 var cSlider = document.getElementById('simCagrSlider');
 var dToggle = document.getElementById('simDripToggle');

 pSlider.addEventListener('input', function () {
 state.sim.cagr = parseFloat(this.value) || 20;
 state.sim.preset = '';
 updateSimulatorUI();
 });
 ySlider.addEventListener('input', function () {
 state.sim.fcfMargin = parseFloat(this.value) || 24;
 state.sim.preset = '';
 updateSimulatorUI();
 });
 cSlider.addEventListener('input', function () {
 state.sim.exitMult = parseFloat(this.value) || 24;
 state.sim.preset = '';
 updateSimulatorUI();
 });
 dToggle.addEventListener('change', function () {
 state.sim.buybackOffset = !!this.checked;
 updateSimulatorUI();
 });

 var presetBtns = document.querySelectorAll('[data-preset]');
 for (var pb = 0; pb < presetBtns.length; pb++) {
 presetBtns[pb].addEventListener('click', function () {
 var key = this.getAttribute('data-preset');
 var cfg = PRESETS[key];
 if (!cfg) return;
 state.sim.cagr = cfg.cagr;
 state.sim.fcfMargin = cfg.fcfMargin;
 state.sim.exitMult = cfg.exitMult;
 state.sim.buybackOffset = cfg.buybackOffset;
 state.sim.preset = key;
 pSlider.value = String(cfg.cagr);
 ySlider.value = String(cfg.fcfMargin);
 cSlider.value = String(cfg.exitMult);
 dToggle.checked = cfg.buybackOffset;
 updateSimulatorUI();
 });
 }

 /* Ch 06 Checklist Controls */
 document.getElementById('checklistContainer').addEventListener('change', function (e) {
 var input = e.target.closest('[data-check-input]');
 if (!input) return;
 var idx = parseInt(input.getAttribute('data-check-input'), 10);
 state.checks[idx] = !!input.checked;
 safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
 renderChecklist();
 });
 document.getElementById('checkAllBtn').addEventListener('click', function () {
 state.checks = [true, true, true, true, true, true];
 safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
 renderChecklist();
 showToast(isEn() ? 'Checked all 6 institutional due-diligence criteria' : '已勾选全部 6 项机构投资者尽调核查指标');
 });
 document.getElementById('resetCheckBtn').addEventListener('click', function () {
 state.checks = [true, true, true, false, false, false];
 safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
 renderChecklist();
 showToast(isEn() ? 'Checklist reset to default baseline (50%)' : '尽调核查清单已恢复默认基准状态 (50%)');
 });

 /* Reading Progress & Scroll-Spy */
 function updateScrollProgress() {
 var docEl = document.documentElement;
 var scrollTop = window.scrollY || docEl.scrollTop || 0;
 var maxScroll = Math.max(1, docEl.scrollHeight - window.innerHeight);
 var pct = Math.min(100, Math.max(0, (scrollTop / maxScroll) * 100));
 document.getElementById('readingProgressBar').style.width = pct + '%';
 }
 window.addEventListener('scroll', updateScrollProgress, { passive: true });
 updateScrollProgress();

 if ('IntersectionObserver' in window) {
 var secObserver = new IntersectionObserver(function (entries) {
 entries.forEach(function (entry) {
 if (entry.isIntersecting) {
 var id = entry.target.id;
 for (var i = 0; i < tocLinks.length; i++) {
 tocLinks[i].classList.toggle('active', tocLinks[i].getAttribute('data-sec') === id);
 }
 }
 });
 }, { rootMargin: '-18% 0px -68% 0px', threshold: 0.02 });

 for (var s = 0; s <= 7; s++) {
 var secNode = document.getElementById('sec-0' + s);
 if (secNode) secObserver.observe(secNode);
 }
 }

 /* Wire Tooltips & Resize Redraw */
 wireCanvasTooltip('chartCh1');
 wireCanvasTooltip('chartRadar');
 wireCanvasTooltip('chartBars');
 wireCanvasTooltip('chartEps');
 wireCanvasTooltip('chartSim');

 /* Wire Ch1 & Ch4 Legend Series Toggles */
 var ch1SeriesBtns = document.querySelectorAll('[data-ch1-series]');
 for (var csIdx = 0; csIdx < ch1SeriesBtns.length; csIdx++) {
 ch1SeriesBtns[csIdx].addEventListener('click', function () {
 var sk = this.getAttribute('data-ch1-series');
 state.ch1Series[sk] = !state.ch1Series[sk];
 if (!state.ch1Series.s1 && !state.ch1Series.s2) state.ch1Series[sk] = true;
 this.classList.toggle('muted', !state.ch1Series[sk]);
 drawCh1Chart();
 });
 }

 var epsSeriesBtns = document.querySelectorAll('[data-eps-series]');
 for (var esIdx = 0; esIdx < epsSeriesBtns.length; esIdx++) {
 epsSeriesBtns[esIdx].addEventListener('click', function () {
 var ek = this.getAttribute('data-eps-series');
 state.epsSeries[ek] = !state.epsSeries[ek];
 if (!state.epsSeries.eps && !state.epsSeries.oci) state.epsSeries[ek] = true;
 this.classList.toggle('muted', !state.epsSeries[ek]);
 drawEpsComboChart();
 });
 }

 var resizeTimer = null;
 function scheduleRedraw() {
 if (resizeTimer) clearTimeout(resizeTimer);
 resizeTimer = setTimeout(renderAllCharts, 60);
 }
 window.addEventListener('resize', scheduleRedraw);
 if ('ResizeObserver' in window) {
 var mainEl = document.querySelector('.main-content');
 if (mainEl) {
 var ro = new ResizeObserver(scheduleRedraw);
 ro.observe(mainEl);
 }
 }
 }

 if (document.readyState === 'loading') {
 document.addEventListener('DOMContentLoaded', init);
 } else {
 init();
 }
 })();
 