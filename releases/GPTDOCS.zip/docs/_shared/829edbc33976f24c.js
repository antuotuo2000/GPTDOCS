
    (function () {
      'use strict';

      var STORAGE_THEME_KEY = 'mui_portal_theme_v4';
      var STORAGE_LANG_KEY = 'mui_portal_lang_v1';
      var STORAGE_CHECK_KEY = 'sj_analysis_checklist_v2';
      var DOC_TITLE_ZH = '史蒂夫·乔布斯 Steve Jobs (1955–2011) 深度商业与产品战略研究报告 | 数据中心';
      var DOC_TITLE_EN = 'Steve Jobs (1955–2011) Strategic & Product Monograph | Research Hub';

      var I18N_RICH_LIST = [{"key": "sj_r00", "match_zh": "史蒂夫·乔布斯 Steve Jobs (1955–2011) 深度研究报告：", "zh": "史蒂夫·乔布斯 Steve Jobs (1955–2011) 深度研究报告：<span class=\"gradient-accent\">绝境救亡宗师、端到端垂直整合霸权与跨世纪商业复利遗产</span>", "en": "Steve Jobs (1955–2011) Strategic Monograph: <span class=\"gradient-accent\">Turnaround Architect, End-to-End Integration &amp; Multi-Industry Compounding Legacy</span>"}, {"key": "sj_r01", "match_zh": "商业史上极少有创始人能在同一生中缔造两家重塑人类文化与技术范式的旗舰企业", "zh": "商业史上极少有创始人能在同一生中缔造两家重塑人类文化与技术范式的旗舰企业。1997 年 7 月，当史蒂夫·乔布斯重返距离破产清算仅剩 <a class=\"cite-link\" href=\"https://www.meritshot.com/case-studies/apple-case-study\" target=\"_blank\" rel=\"noopener noreferrer\">90 天现金流 ↗</a>、年度净亏损高达 <a class=\"cite-link\" href=\"https://d18rn0p25nwr6d.cloudfront.net/CIK-0000320193/05f33405-0995-465d-9e1d-9fb882bb5124.xls\" target=\"_blank\" rel=\"noopener noreferrer\">$10.45亿 ↗</a> 的苹果时，他以冷酷的 <a class=\"cite-link\" href=\"https://www.jerrycards.com/news/apple-at-50-part5-the-greatest-comeback-1997-2001\" target=\"_blank\" rel=\"noopener noreferrer\">2×2 四象限减法 ↗</a> 砍掉逾 70% 冗余产品线，并在随后 14 年间连续推出 <strong>iMac、iPod、iTunes Store、iPhone、App Store 与 iPad</strong>。至 2011 年谢幕之年，苹果年营收跃升 <strong>15.3 倍至 $1,082.49亿</strong>、净利润达 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">$259.22亿 ↗</a>，并于 2011 年 8 月超越埃克森美孚登顶 <a class=\"cite-link\" href=\"https://www.geekwire.com/2011/steve-jobs-apple-tops-exxon-mobil-claim-valuable-company-title/\" target=\"_blank\" rel=\"noopener noreferrer\">全球市值第一（~$3,500亿） ↗</a>；与此同时，他早年以 $1,000 万收购并苦撑十年的 <strong>皮克斯（Pixar）</strong> 以 <a class=\"cite-link\" href=\"https://thewaltdisneycompany.com/press-releases/disney-to-acquire-pixar/\" target=\"_blank\" rel=\"noopener noreferrer\">$74亿全股票交易 ↗</a> 并入华特迪士尼，使他成为迪士尼最大个人股东。", "en": "Few founders in business history have built two paradigm-shifting companies in one lifetime. Returning in July 1997 to an Apple just <a class=\"cite-link\" href=\"https://www.meritshot.com/case-studies/apple-case-study\" target=\"_blank\" rel=\"noopener noreferrer\">90 days from insolvency ↗</a> with a <a class=\"cite-link\" href=\"https://d18rn0p25nwr6d.cloudfront.net/CIK-0000320193/05f33405-0995-465d-9e1d-9fb882bb5124.xls\" target=\"_blank\" rel=\"noopener noreferrer\">$1.045B net loss ↗</a>, Steve Jobs applied a ruthless <a class=\"cite-link\" href=\"https://www.jerrycards.com/news/apple-at-50-part5-the-greatest-comeback-1997-2001\" target=\"_blank\" rel=\"noopener noreferrer\">2×2 product-grid purge ↗</a>—axing over 70% of SKUs—and over the next 14 years launched <strong>iMac, iPod, iTunes Store, iPhone, App Store, and iPad</strong>. By FY2011, Apple's revenue had expanded <strong>15.3x to $108.25B</strong> with <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">$25.92B net income ↗</a>, surpassing ExxonMobil in Aug 2011 as the <a class=\"cite-link\" href=\"https://www.geekwire.com/2011/steve-jobs-apple-tops-exxon-mobil-claim-valuable-company-title/\" target=\"_blank\" rel=\"noopener noreferrer\">world's most valuable company (~$350B) ↗</a>. Meanwhile, <strong>Pixar</strong>—acquired for $10M and funded for a decade—merged into Walt Disney in a <a class=\"cite-link\" href=\"https://thewaltdisneycompany.com/press-releases/disney-to-acquire-pixar/\" target=\"_blank\" rel=\"noopener noreferrer\">$7.4B all-stock deal ↗</a>, making Jobs Disney's largest individual shareholder."}, {"key": "sj_r02", "match_zh": "从 1997 年约 $30亿低谷跃居全球第一", "zh": "从 1997 年约 $30亿低谷跃居全球第一；拆股调整股价由 ~$0.13 涨至卸任日 ~$13.44 <a class=\"cite-link\" href=\"https://gulfnews.com/business/markets/how-steve-jobs-and-tim-cook-turned-apple-into-a-48-trillion-giant-1.500664931\" target=\"_blank\" rel=\"noopener noreferrer\">Gulf News ↗</a>。", "en": "Vaulted from ~$3B in 1997 to #1 globally (~$350B); split-adjusted stock rose from ~$0.13 to ~$13.44 at resignation <a class=\"cite-link\" href=\"https://gulfnews.com/business/markets/how-steve-jobs-and-tim-cook-turned-apple-into-a-48-trillion-giant-1.500664931\" target=\"_blank\" rel=\"noopener noreferrer\">Gulf News ↗</a>."}, {"key": "sj_r03", "match_zh": "对比 FY1997 营收 $7.08B", "zh": "对比 FY1997 营收 $7.08B 与净亏损 -$1.045B，14 年间实现营收 15.3 倍扩张与高盈利反转 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">Apple 2011 10-K ↗</a>。", "en": "Compared with FY1997 sales of $7.08B and -$1.045B net loss, delivering 15.3x revenue expansion in 14 years <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">Apple 2011 10-K ↗</a>."}, {"key": "sj_r04", "match_zh": "1986 年出资 $1,000万收购卢卡斯", "zh": "1986 年出资 $1,000万收购卢卡斯电脑动画部，2006 年并入迪士尼换得 1.38 亿股 DIS 股票 <a class=\"cite-link\" href=\"https://www.cbsnews.com/sanfrancisco/news/steve-jobs-4-6b-in-disney-shares-go-to-trust/\" target=\"_blank\" rel=\"noopener noreferrer\">CBS News ↗</a>。", "en": "Acquired Lucasfilm's graphics unit for $10M in 1986; merged into Disney in 2006 for 138M DIS shares <a class=\"cite-link\" href=\"https://www.cbsnews.com/sanfrancisco/news/steve-jobs-4-6b-in-disney-shares-go-to-trust/\" target=\"_blank\" rel=\"noopener noreferrer\">CBS News ↗</a>."}, {"key": "sj_r05", "match_zh": "生前署名 346 项美国专利", "zh": "生前署名 346 项美国专利及逝后追授 141 项 <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Steve_Jobs\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia ↗</a>；Apple Store 坪效远超珠宝巨头 Tiffany <a class=\"cite-link\" href=\"https://www.macworld.com/article/211968/applestoresinancials.html\" target=\"_blank\" rel=\"noopener noreferrer\">Macworld ↗</a>。", "en": "Named on 346 U.S. patents in life plus 141 posthumously <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Steve_Jobs\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia ↗</a>; Apple Store sales/ft² far outpaced Tiffany <a class=\"cite-link\" href=\"https://www.macworld.com/article/211968/applestoresinancials.html\" target=\"_blank\" rel=\"noopener noreferrer\">Macworld ↗</a>."}, {"key": "sj_r06", "match_zh": "1997 年回归首季即叫停 Newton", "zh": "1997 年回归首季即叫停 Newton、Pippin 游戏机、打印机与克隆授权，将 350+ 混乱 SKU 压缩至“消费/专业 × 台式/便携”仅 4 款核心电脑，使苹果在 FY1998 迅速扭亏为盈 <a class=\"cite-link\" href=\"https://www.jerrycards.com/news/apple-at-50-part5-the-greatest-comeback-1997-2001\" target=\"_blank\" rel=\"noopener noreferrer\">JerryCards ↗</a>。", "en": "In his first quarter back in 1997, he terminated Newton, Pippin, printers, and Mac clones—shrinking 350+ SKUs into 4 core computers (Consumer/Pro × Desktop/Portable) and returning Apple to profit in FY98 <a class=\"cite-link\" href=\"https://www.jerrycards.com/news/apple-at-50-part5-the-greatest-comeback-1997-2001\" target=\"_blank\" rel=\"noopener noreferrer\">JerryCards ↗</a>."}, {"key": "sj_r07", "match_zh": "2001–2003 年借 iPod + iTunes Store", "zh": "2001–2003 年借 iPod + iTunes Store（兼容 Windows）打破 Mac 小众圈层；2007–2008 年借 iPhone + App Store 将硬件一次销售升级为全球开发者生态税底座 <a class=\"cite-link\" href=\"https://www.moomoo.com/community/feed/1980-to-now-the-journey-of-apple-s-market-cap-112088738562453\" target=\"_blank\" rel=\"noopener noreferrer\">Moomoo ↗</a>。", "en": "2001–2003 iPod + iTunes Store (Windows-compatible) broke Mac's niche ceiling; 2007–2008 iPhone + App Store transformed one-off hardware sales into a global developer ecosystem <a class=\"cite-link\" href=\"https://www.moomoo.com/community/feed/1980-to-now-the-journey-of-apple-s-market-cap-112088738562453\" target=\"_blank\" rel=\"noopener noreferrer\">Moomoo ↗</a>."}, {"key": "sj_r08", "match_zh": "2005 年 iPod 已占据全美便携音乐播放器", "zh": "2005 年 iPod 已占据全美便携音乐播放器 76% 垄断份额 <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/History_of_Apple_Inc.\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia ↗</a>，乔布斯仍坚决把音乐模块装入手机：FY2011 iPod 营收降 10% 至 $74.5亿，iPhone 却暴增 87% 至 $470.6亿 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC 10-K ↗</a>。", "en": "Even when iPod held a 76% U.S. portable player monopoly in 2005 <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/History_of_Apple_Inc.\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia ↗</a>, Jobs cannibalized it with iPhone: in FY11 iPod fell 10% to $7.45B while iPhone surged 87% to $47.06B <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC 10-K ↗</a>."}, {"key": "sj_r09", "match_zh": "2007 年公司更名里程碑：", "zh": "<strong>2007 年公司更名里程碑：去掉“Computer”更名为 Apple Inc.</strong> —— 标志着苹果从单纯个人电脑制造商正式蜕变为覆盖手机、数字媒体与零售体验的消费科技平台帝国 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">Apple 10-K ↗</a>。", "en": "<strong>2007 Corporate Rename Milestone: Dropping \"Computer\" to become Apple Inc.</strong> — Signaling the decisive leap from a niche PC maker to a multi-device consumer-tech &amp; digital ecosystem powerhouse <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">Apple 10-K ↗</a>."}, {"key": "sj_r10", "match_zh": "2007 年初代 iPhone 以电容式 Multi-Touch", "zh": "2007 年初代 iPhone 以电容式 Multi-Touch 淘汰物理键盘，FY2011 销量达 7,200 万台、营收达 $470.57亿（同比 +87%）；2010 年发布的 iPad 第二财年营收狂飙 +311% 至 $203.58亿（占总营收 18.8%），连同 iPod（$74.53亿）构成移动帝国铁三角 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">Apple FY11 10-K ↗</a>。", "en": "In 2007, iPhone's capacitive Multi-Touch obsoleted physical keyboards, reaching 72M units and $47.06B (+87% YoY) in FY11; 2010's iPad surged +311% to $20.36B in its second year (18.8% of revenue), alongside iPod ($7.45B) <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">Apple FY11 10-K ↗</a>."}, {"key": "sj_r11", "match_zh": "1985 年被迫离开苹果后，乔布斯创办 NeXT", "zh": "1985 年被迫离开苹果后，乔布斯创办 NeXT 打造出基于 UNIX 的面向对象系统 NeXTSTEP（蒂姆·伯纳斯-李正是在 NeXT 上发明了万维网首个浏览器）。1997 年苹果以 $4.29亿现金 + 150万股收购 NeXT <a class=\"cite-link\" href=\"https://computerhistory.org/blog/next-steve-jobs-dot-com-ipo-that-never-happened/\" target=\"_blank\" rel=\"noopener noreferrer\">CHM ↗</a>，其架构直接演化为 Mac OS X 与 iOS 的统一地基 <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/NeXTSTEP\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia ↗</a>。", "en": "After leaving Apple in 1985, Jobs founded NeXT and built the UNIX-based NeXTSTEP OS (where Tim Berners-Lee created the first web browser). Apple acquired NeXT in 1997 for $429M cash + 1.5M shares <a class=\"cite-link\" href=\"https://computerhistory.org/blog/next-steve-jobs-dot-com-ipo-that-never-happened/\" target=\"_blank\" rel=\"noopener noreferrer\">CHM ↗</a>, forming the foundation of OS X and iOS <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/NeXTSTEP\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia ↗</a>."}, {"key": "sj_r12", "match_zh": "线上端，2003 年 iTunes Store", "zh": "线上端，2003 年 iTunes Store 以 $0.99 单曲重塑音乐产业，2008 年 App Store 确立三七分成应用经济（FY11 相关营收达 $63.14亿）；线下端，乔布斯顶住质疑力推直营店，至 FY2011 全球 357 家 Apple Store 平均单店营收高达 $4,330万，坪效冠绝全美 <a class=\"cite-link\" href=\"https://www.scribd.com/presentation/76521529/Apple-Supply-Chain\" target=\"_blank\" rel=\"noopener noreferrer\">Apple 10-K Retail ↗</a>。", "en": "Online, 2003's iTunes Store ($0.99 tracks) and 2008's App Store (70/30 split) reached $6.31B in FY11; offline, Jobs championed Apple Store against Wall Street skepticism—scaling to 357 stores averaging $43.3M per store in FY11 <a class=\"cite-link\" href=\"https://www.scribd.com/presentation/76521529/Apple-Supply-Chain\" target=\"_blank\" rel=\"noopener noreferrer\">Apple 10-K Retail ↗</a>."}, {"key": "sj_r13", "match_zh": "1986 年乔布斯出资 $1,000万买下乔治·卢卡斯", "zh": "1986 年乔布斯出资 $1,000万买下乔治·卢卡斯旗下电脑图形部门并先后个人垫资约 $5,000万支撑研发。1995 年《玩具总动员》上映一周后 Pixar 登陆纳斯达克（估值 $15亿） <a class=\"cite-link\" href=\"https://fortune.com/article/how-did-apple-cofounder-steve-jobs-become-billionaire-pixar-success/\" target=\"_blank\" rel=\"noopener noreferrer\">Fortune ↗</a>；2006 年迪士尼以 $74亿收购 Pixar，乔布斯成为迪士尼最大个人股东 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/1001039/000119312506010897/dex991.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC Exhibit 99.1 ↗</a>。", "en": "In 1986, Jobs bought Lucasfilm's graphics division for $10M and invested ~$50M personally. A week after Toy Story's 1995 debut, Pixar IPO'd at a $1.5B valuation <a class=\"cite-link\" href=\"https://fortune.com/article/how-did-apple-cofounder-steve-jobs-become-billionaire-pixar-success/\" target=\"_blank\" rel=\"noopener noreferrer\">Fortune ↗</a>; in 2006 Disney acquired Pixar for $7.4B, making Jobs Disney's largest individual shareholder <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/1001039/000119312506010897/dex991.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC Exhibit 99.1 ↗</a>."}, {"key": "sj_r14", "match_zh": "1. 商业史最伟大的绝地反击样本：", "zh": "<strong>1. 商业史最伟大的绝地反击样本：</strong>未依赖大规模举债或财务工程，纯粹依靠产品定义力将濒死企业打造为全球市值第一巨头。<br/><strong>2. 先于用户洞察未被言说的需求：</strong>不用焦点小组替未来投票，而是把图形界面（Mac）、口袋千首音乐（iPod）与指尖互联网（iPhone）变为大众直觉工具。<br/><strong>3. 搭建超越生命周期的继任体系：</strong>2008 年创办 Apple University 沉淀决策案例，并选定蒂姆·库克接班打破“人亡政息”魔咒。", "en": "<strong>1. Greatest Turnaround in Business History:</strong> Transformed a near-bankrupt PC maker into the world's #1 market cap via product definition without financial engineering.<br/><strong>2. Anticipating Unspoken Needs:</strong> Rejected focus groups to turn GUIs (Mac), 1,000 songs in your pocket (iPod), and mobile internet (iPhone) into mass intuition.<br/><strong>3. Institutionalized Succession:</strong> Founded Apple University in 2008 and tapped Tim Cook, ensuring multi-trillion compounding beyond the founder."}, {"key": "sj_r15", "match_zh": "1. “现实扭曲力场”的组织磨损：", "zh": "<strong>1. “现实扭曲力场”的组织磨损：</strong>二元化的“天才/蠢货”严苛评判虽激发出极限潜能，但也造成极高员工高压与 1985 年前组织剧烈动荡。<br/><strong>2. 围墙花园（Walled Garden）的反垄断双刃剑：</strong>严密闭环确保体验一致，但也使 App Store 抽成在十年后成为欧美反垄断核心靶心。<br/><strong>3. 云服务与社交基因相对薄弱：</strong>相较硬件交互封神，任内推出的 MobileMe 与音乐社交 Ping 均告折戟。", "en": "<strong>1. \"Reality Distortion Field\" Attrition:</strong> Binary \"genius vs. bozo\" feedback unlocked breakthroughs but drove extreme burnout and pre-1985 turmoil.<br/><strong>2. Walled-Garden Antitrust Friction:</strong> Tight integration secured quality yet made App Store fees a prime global regulatory target a decade later.<br/><strong>3. Cloud &amp; Social Blind Spots:</strong> Unlike hardware brilliance, MobileMe and Ping faltered, proving large-scale cloud services were not his native forte."}, {"key": "sj_r16", "match_zh": "21 岁与沃兹尼亚克在车库创立苹果", "zh": "21 岁与沃兹尼亚克在车库创立苹果，凭 Apple II 引爆个人电脑商业化；1984 年发布划时代图形界面 Macintosh，但因硬件性能受限、定价高昂及与 CEO 约翰·斯卡利爆发路线冲突，于 30 岁被剥夺管理权遗憾出走 <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Steve_Jobs\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia ↗</a>。", "en": "Co-founded Apple at 21 with Steve Wozniak, sparking the PC era with Apple II; launched the 1984 Macintosh GUI, but high pricing and clashes with CEO John Sculley led to his ouster at age 30 <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Steve_Jobs\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia ↗</a>."}, {"key": "sj_r17", "match_zh": "NeXT 高价硬件遭遇冷遇，逼迫乔布斯", "zh": "NeXT 高价硬件遭遇冷遇，逼迫乔布斯转向软件架构深耕（OpenStep / WebObjects）；同时在 Pixar 学会放权赋能艾德·卡特姆与约翰·拉塞特，苦熬十年迎来《玩具总动员》与 1995 年 $15亿估值 IPO，完成从任性创业者到战略投资家的蜕变 <a class=\"cite-link\" href=\"https://www.southampton.ac.uk/news/2020/11/malcolm-cook-toy-story-25.page\" target=\"_blank\" rel=\"noopener noreferrer\">Univ. of Southampton ↗</a>。", "en": "NeXT's slow hardware sales forced a pivot to software excellence (OpenStep/WebObjects); meanwhile at Pixar, empowering Ed Catmull and John Lasseter through a 10-year drought yielded Toy Story and a $1.5B IPO in 1995 <a class=\"cite-link\" href=\"https://www.southampton.ac.uk/news/2020/11/malcolm-cook-toy-story-25.page\" target=\"_blank\" rel=\"noopener noreferrer\">Univ. of Southampton ↗</a>."}, {"key": "sj_r18", "match_zh": "重掌苹果后将顶级审美、供应链铁腕", "zh": "重掌苹果后将顶级审美、供应链铁腕（延揽库克将库存周期压缩至数天）与平台战略融会贯通，14 年连推 iMac、iPod、iPhone、iPad 四代现象级产品，使苹果从 $30亿濒危股成长为今日 ~$4.7万亿–$4.8万亿商业巨擘 <a class=\"cite-link\" href=\"https://en.oninvest.com/article/tim-cook-is-stepping-down-as-apple-s-ceo-what-were-his-major-successes-and-failures-over-the-past-15-years\" target=\"_blank\" rel=\"noopener noreferrer\">Oninvest ↗</a>。", "en": "Back at Apple, Jobs fused world-class industrial design, Tim Cook's lean supply chain, and platform lock-in—launching iMac, iPod, iPhone, and iPad to turn a $3B turnaround into today's ~$4.7T–$4.8T titan <a class=\"cite-link\" href=\"https://en.oninvest.com/article/tim-cook-is-stepping-down-as-apple-s-ceo-what-were-his-major-successes-and-failures-over-the-past-15-years\" target=\"_blank\" rel=\"noopener noreferrer\">Oninvest ↗</a>."}];
      var I18N_TEXT_PAIRS = [["数据中心", "Research Hub"], ["史蒂夫·乔布斯 (Steve Jobs) 深度商业研究报告", "Steve Jobs Strategic & Product Monograph"], ["史蒂夫·乔布斯研报", "Steve Jobs Monograph"], ["科技与人文十字路口的架构师 · Apple / Pixar / NeXT 跨产业商业复盘与 15 倍逆转奇迹", "Architect at the Intersection of Technology & Liberal Arts · Apple / Pixar / NeXT"], ["二次执掌市值跃升", "Turnaround Market Cap"], ["苹果 FY11 营收/净利", "FY11 Apple Rev / NI"], ["Pixar 并购与专利数", "Pixar Deal & Patents"], ["450+ 专利", "450+ Patents"], ["$7.4B · 450+ 专利", "$7.4B · 450+ Patents"], ["里程碑", "MILESTONE"], ["站点与关联导航", "Site & Related Reports"], ["返回数据中心首页", "Back to Research Hub"], ["核心研究章节 (00 – 07)", "Report Chapters (00 – 07)"], ["执行摘要与核心指标", "Executive Summary & KPIs"], ["商业版图与产品架构", "Business Empire & Product Matrix"], ["产品哲学与四重护城河", "Philosophy & 4 Economic Moats"], ["传奇科技领袖横向对比", "Iconic Tech Founders Matrix"], ["商业回报与价值复利推演", "Financials & Value Simulator"], ["三幕演进与管理遗产复盘", "3-Act Evolution & Case Lessons"], ["乔布斯法则核查清单", "Steve Jobs Diagnostic Checklist"], ["数据来源与监管核验索引", "Primary Filings & Sources"], ["阅读与导出工具", "Reading & Export Tools"], ["浅色外观", "Light"], ["深色外观", "Dark"], ["导出 HTML", "Export HTML"], ["打印 / PDF", "Print / PDF"], ["商业史定评：现代消费科技第一架构师", "Verdict: Modern Consumer Tech's Premier Architect"], ["研究横跨：Apple (1976–1985 / 1997–2011) · NeXT · Pixar", "Scope: Apple (1976–85 / 1997–2011) · NeXT · Pixar"], ["数据基准：SEC 10-K (1997–2011) / 2026 回溯", "Baseline: SEC 10-K (1997–2011) / 2026 Review"], ["CORE THESIS · 2×2 极简战略减法 × 软硬芯云垂直整合 × 连续重塑六大现代产业", "CORE THESIS · 2×2 Product Grid × End-to-End Integration × Six Industries Transformed"], ["极致研发杠杆与毛利护城河", "Extreme R&D Leverage & Gross Margin Moat"], ["FY2011 仅用 2.2% 研发费率（$24.3亿）撬动 $1,082.5亿营收、40.5% 毛利率与 31.2% 营业利润率。", "Just 2.2% R&D intensity ($2.43B) powered $108.25B revenue, 40.5% gross margin, and 31.2% operating margin in FY11."], ["零负债 $815.7亿 现金堡垒", "Zero-Debt $81.57B Cash Fortress"], ["告别 1997 年 90 天现金流危机，2011 财年末苹果账面现金及有价证券高达 $815.70亿且零长期债务。", "Erased the 1997 90-day cash crunch—ending FY2011 with $81.57B in cash & securities and zero long-term debt."], ["跨代际制度与生态复利", "Multi-Generational Ecosystem Compounding"], ["其奠定的 iPhone + App Store + Apple Store 飞轮，支撑苹果在库克时代向 ~$4.7万亿–$4.8万亿市值演进。", "The iPhone + App Store + Apple Store flywheel powered Apple's post-2011 ascent toward ~$4.7T–$4.8T valuation."], ["二次回归市值跃迁 (1997–2011)", "Turnaround Market Cap (1997–2011)"], [">100x 回报", ">100x Return"], ["FY2011 苹果营收与净利润", "FY2011 Apple Revenue & Net Income"], ["净利 $25.92B", "NI $25.92B"], ["皮克斯 (Pixar) 跨界资本传奇", "Pixar Cross-Industry Capital Legend"], ["迪士尼 7.7% 股权", "7.7% Disney Stake"], ["署名专利资产与直营店坪效", "Named Patents & Store Sales/ft²"], ["坪效 ~$4,032/ft²", "~$4,032/ft²"], ["一、商业版图与产品架构：从 2×2 救亡四宫格到千亿美元多终端数字帝国", "1. Business Empire & Product Architecture: From 2×2 Rescue Grid to $108B Ecosystem"], ["前沿产品独立定义（iPhone / iPad / Mac） × 软硬芯云一体闭环 × 皮克斯跨界协同", "Focused Product Matrix (iPhone / iPad / Mac) × Whole-Widget Integration × Pixar Synergy"], ["FY11 移动终端占比 69.2%", "Mobile Devices 69.2% of FY11"], ["Steve Jobs 跨产业战略架构中枢（Apple 1 Infinite Loop · 2×2 聚焦减法 · Whole Widget 垂直整合）", "Steve Jobs Cross-Industry Architecture Hub (1 Infinite Loop · 2×2 Focus Grid · Whole-Widget Integration)"], ["核心战略演进：1997 削减 70% SKU 救亡 → 2007 去“Computer”更名为 Apple Inc. → 2011 登顶全球市值第一", "Strategic Arc: 1997 70% SKU Purge → 2007 Apple Inc. Rename → Aug 2011 #1 Global Market Cap"], ["MOBILE · 占 FY11 营收 69.2%", "MOBILE · 69.2% OF FY11 REV"], ["iPhone + iPad + iPod 移动铁三角；FY11 营收 $74.87B，iPhone 单季/全年同比暴增 +87%。", "iPhone + iPad + iPod mobile triad; $74.87B FY11 revenue with iPhone surging +87% YoY."], ["COMPUTING · 占 FY11 营收 20.1%", "COMPUTING · 20.1% OF FY11 REV"], ["Mac 台式与便携矩阵 + $429M 收购的 NeXTSTEP 内核，演化为 OS X 与 iOS 统一底座。", "Mac desktop/portable line + $429M NeXTSTEP kernel powering OS X and iOS."], ["ECOSYSTEM · 单店年营收 $43.3M", "ECOSYSTEM · $43.3M / STORE"], ["iTunes + App Store 三七分成（$6.31B）+ 全球 357 家 Apple Store 体验店，坪效 $4,032/ft²。", "iTunes + App Store 70/30 economy ($6.31B) + 357 Apple Stores averaging $4,032/ft²."], ["ANIMATION · $10M → $7.4B", "ANIMATION · $10M → $7.4B"], ["1986 年买下卢卡斯图形部，历经十年《玩具总动员》破局，2006 年 $74B 并入迪士尼。", "Bought Lucasfilm unit in 1986; Toy Story broke through in 1995; merged into Disney for $7.4B in 2006."], ["2×2 四象限产品减法纪律（Consumer / Pro × Desktop / Portable）", "2×2 Four-Quadrant Product Discipline (Consumer / Pro × Desktop / Portable)"], ["砍掉 350+ 冗余 SKU、Newton 与克隆机授权，让全公司顶级工程与营销资源只聚焦 4 条清晰主线。", "Axed 350+ SKUs, Newton, and Mac clones—channeling top talent into just 4 crystal-clear product lines."], ["端到端全栈闭环（Whole Widget：芯片 + 系统 + 硬件 + 云 + 零售）", "End-to-End Whole-Widget Integration (Silicon + OS + Hardware + Cloud + Retail)"], ["从 P.A. Semi 自研芯片、NeXTSTEP 内核到 Apple Store 开箱交付，彻底掌控用户体验与 40.5% 毛利。", "From in-house A-series silicon and NeXTSTEP to Apple Store delivery, locking in UX and 40.5% gross margin."], ["1. 2×2 极简手术：砍掉 70% 失血产品线", "1. 2×2 Rescue Surgery: Cutting 70% of Bleeding SKUs"], ["2. 从 Mac 中枢跃升至 iOS 生态税底座", "2. From Mac Digital Hub to iOS App Economy"], ["3. 铁血“自我蚕食”：iPhone 主动颠覆 iPod", "3. Fearless Self-Cannibalization: iPhone vs. iPod"], ["视图A: FY11 产品矩阵拆解", "View A: FY11 Product Mix"], ["视图B: 1997–2011 逆转轨迹", "View B: 1997–2011 Turnaround"], ["1. 移动多点触控革命（iPhone + iPad + iPod）", "1. Multi-Touch Mobile Revolution (iPhone + iPad + iPod)"], ["合计营收 $74.87B", "Total $74.87B"], ["展开微观执行机制", "Show Execution Mechanics"], ["收起微观执行机制", "Hide Execution Mechanics"], ["2007 年初代 iPhone 淘汰物理键盘，2010 年 iPad 开创平板品类；乔布斯拒绝盲从焦点小组，坚持用硬件+多点触控直觉创造尚未被用户言说的需求。", "2007's iPhone eliminated physical keyboards and 2010's iPad created modern tablets—built on Jobs's refusal to outsource vision to focus groups."], ["2. 个人计算基石与系统内核（Mac + NeXTSTEP / OS X）", "2. Personal Computing & OS Kernel (Mac + NeXTSTEP / OS X)"], ["Mac 营收 $21.78B", "Mac Rev $21.78B"], ["1997 年收购 NeXT 不仅买回 UNIX 面向对象内核，更将乔布斯本人与 Avie Tevanian 等系统架构宗师迎回苹果，彻底终结老旧 System 7/Mac OS 8 的崩溃噩梦。", "Acquiring NeXT in 1997 brought back both an object-oriented UNIX kernel and Jobs alongside systems architects like Avie Tevanian, ending legacy Mac OS instability."], ["3. 数字分发与实体零售神殿（App Store + Apple Store）", "3. Digital Distribution & Retail Temples (App Store + Apple Store)"], ["单店年均 $43.3M", "$43.3M / Store"], ["乔布斯聘请 Ron Johnson 并亲自把关第五大道玻璃立方体与 Genius Bar 设计，将原本被华尔街看衰的实体零售店打造成全美坪效最高的品牌体验神殿。", "Partnering with Ron Johnson on Genius Bars and flagship glass cubes, Jobs turned Wall Street's most doubted retail bet into America's highest sales-per-square-foot stores."], ["4. 皮克斯动画工作室与华特迪士尼（Pixar & Disney）", "4. Pixar Animation Studios & Walt Disney (Pixar & Disney)"], ["$10M → $7.4B 退出", "$10M → $7.4B Exit"], ["皮克斯经历长达九年硬件滞销与亏损，乔布斯顶住压力持续注资约 $5,000万并充分信任 Ed Catmull 与 John Lasseter 创意团队，最终铸就连续票房神话与 $74亿迪士尼并购。", "Through nine years of losses, Jobs funded Pixar (~$50M) while empowering Ed Catmull and John Lasseter—culminating in consecutive blockbusters and the $7.4B Disney merger."], ["二、产品哲学与四重核心护城河：“Whole Widget”全栈闭环与 2.2% 极简研发杠杆", "2. Product Philosophy & Four Economic Moats: 'Whole Widget' & 2.2% R&D Leverage"], ["点击左侧任一护城河支柱卡片，联动查看乔布斯战略原则与五维创始人能力画像", "Click any moat card on the left to inspect Jobs's execution principles and the 5-axis founder radar"], ["护城河定性：极宽 (Wide Moat · 品牌溢价 + OS 转换成本 + 双边网络)", "Moat Rating: Wide Moat (Brand Premium + OS Switching Cost + Two-Sided Ecosystem)"], ["01 · “Whole Widget”软硬芯云垂直整合", "01 · 'Whole Widget' End-to-End Integration"], ["Whole Widget 闭环", "Whole Widget Loop"], ["坚持同步自研工业硬件（2008 年收购 P.A. Semi 自研 A4 芯片）、OS X/iOS 系统与云同步，在消费电子杀价战中稳守 40.5% 高毛利率。", "In-house silicon (via P.A. Semi in 2008), OS X/iOS, and hardware co-design defended a 40.5% gross margin against commoditized rivals."], ["02 · 对 100 个好点子说“不”的研发杠杆", "02 · Saying 'No' to 100 Good Ideas (2.2% R&D)"], ["2.2% 极致研发费率", "2.2% R&D Intensity"], ["按职能划分而非事业部割据，FY2011 研发费用仅 $24.3亿（占营收 2.2%），却以极精锐团队创造出远超同业的爆品命中率。", "Functional org structure avoided divisional duplication—generating $108.25B revenue on just $2.43B R&D (2.2% of sales) in FY11."], ["03 · 禅宗极简审美与工业设计定价霸权", "03 · Zen Minimalism & Design Pricing Power"], ["200+ 设计专利", "200+ Design Patents"], ["与 Jony Ive 联名逾 200 项工业设计专利（从果冻色 iMac 到一体成型铝制机身），将科技硬件升维为具有文化图腾属性的情感奢侈品。", "Over 200 joint design patents with Jony Ive elevated consumer electronics from beige commodities into cultural icons."], ["04 · 生态转换壁垒与供应链预付款护城河", "04 · Ecosystem Lock-In & Supply-Chain Prepayments"], ["$81.57B 零债现金", "$81.57B Cash Fortress"], ["iTunes 媒体库、App Store 与 iCloud 锁定用户留存；手握 $815.7亿零负债现金向全球供应链提前锁死数年独家先进产能。", "iTunes, App Store, and iCloud locked in users while $81.57B in debt-free cash prepaid and locked up global component capacity."], ["传奇科技创始人五维商业能力模型对比（10分制标杆评估）", "5-Axis Iconic Tech Founder Capability Radar (10-Point Scale)"], ["点击下方图例胶囊可单独开关对比曲线，悬停顶点查看各维度评分", "Click legend pills below to toggle founder curves; hover vertices for exact scores"], ["史蒂夫·乔布斯 (Apple / Pixar)", "Steve Jobs (Apple / Pixar)"], ["比尔·盖茨 (Microsoft)", "Bill Gates (Microsoft)"], ["杰夫·贝索斯 (Amazon)", "Jeff Bezos (Amazon)"], ["三、传奇科技领袖横向对比：五种商业范式与零售坪效统治力", "3. Iconic Tech Founders Benchmark: Five Paradigms & Retail Sales Density"], ["支持按创始人、企业、核心产品或商业范式关键词实时筛选对比", "Filter or search in real time by founder, company, flagship product, or strategic paradigm"], ["显示 5 / 5 位科技宗师", "Showing 5 / 5 Founders"], ["全部宗师", "All Founders"], ["软件与云生态派", "Software & Cloud Platforms"], ["硬科技与算力全栈派", "Hard-Tech & Full-Stack"], ["创始人与缔造企业", "Founder & Enterprise"], ["核心商业护城河范式", "Core Moat Paradigm"], ["标志性市值/财富里程碑", "Valuation / Wealth Milestone"], ["代表性利润率特征", "Margin Profile"], ["组织与战略方法论", "Org & Strategy Playbook"], ["与乔布斯商业模式的异同评估", "Comparative Assessment vs. Jobs"], ["把门店当产品打磨：乔布斯时代 Apple Store 年坪效 vs 全美零售标杆（$/平方英尺）", "Treating Stores as Products: Apple Store Sales/ft² vs. U.S. Retail Benchmarks ($/sq ft)"], ["2001 年外界普遍嘲讽苹果自建门店必败，但凭借极简体验桌与 Genius Bar，Apple Store 坪效超越奢侈珠宝巨头 Tiffany 逾 50%（Fortune/Macworld 口径）", "Doubters predicted Apple's 2001 retail entry would flop; instead, Genius Bars and experiential tables beat Tiffany & Co. by >50% (Fortune/Macworld)"], ["$4,032/ft² 登顶全美零售王", "$4,032/ft² #1 in U.S. Retail"], ["蓝色/琥珀色：各零售标杆年度单位面积销售额 ($/平方英尺)", "Amber / Blue: Annual Retail Sales per Square Foot ($/ft²)"], ["四、商业回报与价值复利推演：$816亿零负债现金池与跨周期股东回报", "4. Financial Turnaround & Value Compounding: $81.57B Cash Pool & Multi-Cycle Returns"], ["从 1997 年净亏损 -$10.45亿到 2011 年净赚 $259.22亿的教科书级财务反转", "Textbook financial reversal from -$1.045B net loss in FY97 to $25.92B net income in FY11"], ["14年营收扩张 15.3x", "14-Yr Rev Expansion 15.3x"], ["在 PC 与手机同质化竞争中斩获 40.5% 毛利率与 31.2% 营业利润率。", "Achieved 40.5% gross margin and 31.2% operating margin amid commoditized PC/phone rivals."], ["$81.57B ($0债)", "$81.57B ($0 Debt)"], ["铭记 1997 断流教训，5 年将现金储备从 $153.9亿推升至 $815.7亿且零长债。", "Never forgot 1997's cash crunch—scaling cash from $15.39B to $81.57B with zero long-term debt."], ["印证“创新与研发经费多少无关”：精简 SKU 分摊研发，产出傲视同业。", "Proved innovation isn't about R&D spend alone—concentrated SKUs maximized return on every R&D dollar."], ["$4.60B 信托", "$4.60B Trust"], ["持有的 1.38 亿股迪士尼股票在 2011 年价值约 $46亿，展现顶级耐心资本眼光。", "His 138M Disney shares were worth ~$4.6B in 2011—exceeding his Apple stake at the time."], ["FY2007–FY2011 iPhone 黄金五年：苹果现金及有价证券储备 vs 年度净利润爆发曲线（SEC 10-K）", "FY2007–FY2011 iPhone Golden Five Years: Cash & Securities vs. Net Income Surge (SEC 10-K)"], ["自 2007 年初代 iPhone 问世起，短短 4 个财年内年度净利润暴增 7.4 倍，账面现金扩张 5.3 倍", "In just four fiscal years after the 2007 iPhone launch, net income surged 7.4x and cash grew 5.3x"], ["4年净利 CAGR +65.0%", "4-Yr NI CAGR +65.0%"], ["■ 左轴：现金及有价证券储备 ($B)", "■ Left Axis: Cash & Securities ($B)"], ["● 右轴：苹果年度净利润 ($B)", "● Right Axis: Annual Net Income ($B)"], ["现金及有价证券储备 (左轴 · $B)", "Cash & Marketable Securities (Left · $B)"], ["苹果年度净利润 Net Income (右轴 · $B)", "Apple Annual Net Income (Right · $B)"], ["乔布斯创新周期价值复利模拟器（历史真实周期 vs 自定义）", "Steve Jobs Innovation Cycle Value Compounding Simulator"], ["叠加生态成熟期股息再投 (+0.8%/年)", "Add Mature Ecosystem Dividend Reinvestment (+0.8%/yr)"], ["模拟 2012 年后苹果开启分红回购阶段的股息再投资复利增益", "Models incremental compounding from post-2012 dividend reinvestment"], ["① 1997–2011 苹果二次回归周期", "① 1997–2011 Apple Turnaround Era"], ["14年 · 39.3%", "14Y · 39.3%"], ["② 1986–2006 皮克斯耐心资本周期", "② 1986–2006 Pixar Patient Capital Era"], ["20年 · 24.2%", "20Y · 24.2%"], ["③ 1997–2026 苹果全生态延续周期", "③ 1997–2026 Full Ecosystem Legacy"], ["29年 · 31.0%", "29Y · 31.0%"], ["初始投入本金 (USD)", "Initial Principal (USD)"], ["长期持有年限 (Years)", "Holding Horizon (Years)"], ["年化复合回报率 (CAGR %)", "Annualized Compound Return (CAGR %)"], ["期末预计总资产市值 (Ending Value)", "Projected Ending Value"], ["本金增值倍数 (MOIC) / 有效年化", "Total MOIC / Effective CAGR"], ["累计净资本利得 (Net Gain)", "Cumulative Net Capital Gain"], ["━ 含当前设定总资产复利曲线", "━ Active Total Wealth Trajectory"], ["- - 基础年化对照基准 (不含股息)", "- - Base CAGR Benchmark (Ex-Div)"], ["悬停曲线可逐年对比历史复利加速轨迹与翻倍周期。", "Hover along the curve to inspect year-by-year compounding acceleration."], ["正向商业遗产定评", "Enduring Business & Cultural Legacy"], ["客观局限与管理争议反思", "Critical Lens & Organizational Tensions"], ["五、三幕人生演进与管理复盘：从孤傲少年天才到成熟商业帝国统帅", "5. Three-Act Career Evolution & Management Lessons: From Maverick to Empire Builder"], ["理解乔布斯的关键：1985–1997 年十二年“荒野流放”才是其商业心智质变的熔炉", "The key to Jobs: his 12-year wilderness exile (1985–1997) forged his mature strategic discipline"], ["1976–2011+ 三幕跨越", "1976–2011+ Three Acts"], ["第一幕 · 拓荒与折戟 (1976–1985) —— Apple II 崛起与 Mac 阵痛", "Act I · Garage Origins & Ouster (1976–1985) — Apple II & Macintosh Pains"], ["30岁遗憾出走", "Ousted at Age 30"], ["第二幕 · 荒野淬炼 (1985–1997) —— NeXT 炼内功 · Pixar 封神", "Act II · Wilderness Crucible (1985–1997) — NeXT Architecture & Pixar IPO"], ["“被解雇是最好的事”", "'Getting Fired Was Best'"], ["第三幕 · 登峰与永续 (1997–2011+) —— 王者归来与万亿基业", "Act III · Triumphant Return & Legacy (1997–2011+) — World's #1 Enterprise"], ["15.3x 营收飞跃", "15.3x Revenue Leap"], ["教训 01 · Apple Lisa / NeXT Cube", "Lesson 01 · Apple Lisa / NeXT Cube"], ["价格甜点纪律", "Price-Sweet-Spot Discipline"], ["脱离大众购买力的过度完美主义", "Over-Engineering Beyond Mass Price Points"], ["早年 Lisa 与 NeXT 工作站虽技术惊艳却因高昂售价销量惨淡；回归后乔布斯让 iMac ($1,299) 与初代 iPad ($499 起) 精准卡位主流甜点价位，直接击碎竞品生存空间。", "Early Lisa and NeXT workstations were technical marvels priced out of reach; back at Apple, Jobs nailed mass sweet spots ($1,299 iMac, $499 iPad) to crush rivals."], ["教训 02 · iTunes for Windows", "Lesson 02 · iTunes for Windows"], ["跨平台破圈", "Cross-Platform Reach"], ["孤岛封闭与跨平台引流的辩证统一", "Balancing Walled Gardens with Mass On-Ramps"], ["2003 年乔布斯放下洁癖向数亿 Windows 用户开放 iTunes（自嘲“给地狱里的人递一杯冰水”），彻底引爆 iPod 销量并带来光环效应反哺 Mac 与 iPhone。", "In 2003, Jobs swallowed his pride to ship iTunes for Windows ('giving a glass of ice water to someone in hell'), igniting iPod and halo-effect Mac demand."], ["教训 03 · 2007 Web App → 2008 App Store", "Lesson 03 · 2007 Web App → 2008 App Store"], ["迅速修正执念", "Rapid Course Correction"], ["从排斥第三方原生应用到拥抱 App Store", "From Rejecting Native Apps to Launching App Store"], ["2007 年初代 iPhone 曾拒绝开放原生第三方 App；但在高管与开发者力谏下仅隔数月便推出 iOS SDK 与 App Store，开启数万亿美元移动互联网时代。", "Initially refusing third-party native apps on the 2007 iPhone, Jobs reversed course within months to launch the iOS SDK and App Store."], ["教训 04 · Jobs × Tim Cook 双核", "Lesson 04 · Jobs × Tim Cook"], ["远见配对运营", "Vision + Execution"], ["创客浪漫主义必须配对世界级运营家", "Pairing Product Vision with Supply-Chain Mastery"], ["早年 Mac 工厂曾因自动化执念积压亏损；1998 年挖来蒂姆·库克重塑全球外包制造与零库存周转，形成“极致产品远见 + 极致精密运营”的黄金双核。", "After early Mac factory over-automation losses, recruiting Tim Cook in 1998 forged a golden duo of product intuition and world-class supply-chain execution."], ["法则一：", "Law 01:"], ["聚焦不是对一件事说“是”，而是对百件事说“不” —— 把 A 级人才死磕在 1–3 款定义品类的旗舰上。", "Focus isn't saying yes to one thing—it's saying no to 100 good ideas and concentrating A-players on 1–3 flagship bets."], ["法则二：", "Law 02:"], ["寻找拥有“硬件入口 + 系统粘性 + 服务税”闭环的标的，才能长期维持超额毛利率与自由现金流。", "Seek businesses owning the 'hardware entry + OS stickiness + recurring service tax' loop to sustain superior margins."], ["法则三：", "Law 03:"], ["利润是极致产品的副产品，始终由懂产品的灵魂人物掌握终审权，是科技股长牛的头号领先指标。", "Profit is the byproduct of great products—keeping product-obsessed leaders in charge is tech's #1 leading indicator."], ["六、“乔布斯法则”企业与产品评估交互式核查清单", "6. Interactive 'Steve Jobs Rules' Product & Enterprise Diagnostic Checklist"], ["用于审视任何科技公司、创业项目或新产品矩阵是否具备“乔布斯式”长期护城河（勾选状态自动保存在本地）", "Audit whether any tech firm or product portfolio possesses a Jobs-caliber long-term moat (saved locally)"], ["全部勾选", "Check All"], ["重置清单", "Reset"], ["数据来源与监管/历史档案核验索引（SEC EDGAR & Official Archives）", "Primary Regulatory Filings & Historical Archives Index (SEC EDGAR & USPTO)"], ["本深度报告所有财务与历史指标均严格核验自美国证监会（SEC EDGAR）公开披露的 Apple Inc. Form 10-K (1997–2012)、迪士尼收购皮克斯联合公告、美国专利商标局（USPTO）及权威商业媒体公开资料，仅供商业史与战略研究参考，不构成任何具体证券买卖建议。", "All financial and historical metrics are verified against U.S. SEC EDGAR Apple Inc. Form 10-K filings (1997–2012), Walt Disney/Pixar merger disclosures, USPTO patent records, and authoritative business archives. For strategic research only; not investment advice."]];
      var I18N_ATTR_PAIRS = [["展开/收起章节目录", "Toggle Chapter Sidebar"], ["切换目录侧边栏", "Toggle Chapter Sidebar"], ["面包屑导航", "Breadcrumb Navigation"], ["检索章节或指标…", "Jump to chapter or KPI…"], ["快速跳转章节或指标", "Quick jump to chapter or metric"], ["研究章节目录与站点导航", "Report Chapters & Site Navigation"], ["站点导航与章节目录", "Site Links & Table of Contents"], ["外观模式切换", "Appearance Theme Switch"], ["阅读与导出工具", "Reading & Export Tools"], ["导出独立 HTML 文件 (.html)", "Export Standalone HTML File (.html)"], ["打印或导出 PDF 研报", "Print or Save Report as PDF"], ["第一章图表视图切换", "Chapter 01 Chart View Switch"], ["搜索人物、企业、产品或范式关键词…", "Search founder, company, product, or paradigm…"], ["筛选对比领袖", "Filter benchmark founders"], ["标杆领袖分类筛选", "Founder category filter"], ["传奇科技领袖商业范式横向对比表", "Iconic Tech Founders Comparative Matrix"], ["历史创新周期预设", "Historical Innovation Presets"], ["核查完成度进度条", "Checklist Completion Progress"]];
      var PILLAR_NOTES = ["<strong>当前选中支柱解读（01 Whole Widget 垂直闭环）：</strong>自研芯片（A4起）、NeXTSTEP/iOS 系统与硬件设计联合调优，使苹果在 FY2011 稳守 40.5% 毛利率与 31.2% 营业利润率 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">Apple FY11 10-K ↗</a>。", "<strong>当前选中支柱解读（02 2.2% 极简研发杠杆）：</strong>拒绝事业部内耗，将研发资源集中于少数旗舰单品：FY2011 仅投入 $24.3亿研发费用即撬动 $1,082.5亿年营收 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312512444068/d411355d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC FY12 10-K ↗</a>。", "<strong>当前选中支柱解读（03 禅宗极简设计霸权）：</strong>乔布斯生前署名 346 项专利（逝后追授 141 项），与 Jony Ive 联名逾 200 项工业设计专利，将科技产品转化为情感图腾 <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Steve_Jobs\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia ↗</a>。", "<strong>当前选中支柱解读（04 现金堡垒与生态锁死）：</strong>2011 财年末手握 $815.7亿零长期债务现金池，既能预付锁死全球先进屏幕与闪存产能，又借 iCloud 与 App Store 构建高转换壁垒 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC 10-K ↗</a>。"];
      var PILLAR_NOTES_EN = ["<strong>Selected Pillar (01 · Whole Widget Integration):</strong> Co-designing in-house A-series silicon, NeXTSTEP/iOS software, and hardware sustained a 40.5% gross margin and 31.2% operating margin in FY11 <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">Apple FY11 10-K ↗</a>.", "<strong>Selected Pillar (02 · 2.2% R&amp;D Leverage):</strong> Rejecting divisional silos allowed just $2.43B in FY11 R&amp;D (2.2% of sales) to power $108.25B in revenue <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312512444068/d411355d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC FY12 10-K ↗</a>.", "<strong>Selected Pillar (03 · Zen Industrial Design):</strong> Named on 346 U.S. patents in life (plus 141 posthumously) and >200 joint design patents with Jony Ive, turning hardware into cultural icons <a class=\"cite-link\" href=\"https://en.wikipedia.org/wiki/Steve_Jobs\" target=\"_blank\" rel=\"noopener noreferrer\">Wikipedia ↗</a>.", "<strong>Selected Pillar (04 · Cash Fortress &amp; Lock-In):</strong> $81.57B in debt-free cash locked up global component capacity while iTunes, App Store, and iCloud raised switching costs <a class=\"cite-link\" href=\"https://www.sec.gov/Archives/edgar/data/320193/000119312511282113/d220209d10k.htm\" target=\"_blank\" rel=\"noopener noreferrer\">SEC 10-K ↗</a>."];
      var PEER_ROWS = [{"category": "core", "benchmark": true, "company": "研究基准：史蒂夫·乔布斯", "leader": "Apple / Pixar / NeXT", "positioning": "软硬芯云垂直闭环 + 人文设计溢价", "culture": "职能型组织 + 2×2 极简聚焦", "headcount": "2011登顶 ~$350B (今~$4.8T)", "margins": "毛利 40.5% / 营业 31.2%", "verdict": "消费科技终极标杆：唯一横跨个人电脑、数字动画电影、音乐、手机、平板与实体零售六大产业均登顶的创始人。", "sourceLabel": "Gulf News", "sourceUrl": "https://gulfnews.com/business/markets/how-steve-jobs-and-tim-cook-turned-apple-into-a-48-trillion-giant-1.500664931"}, {"category": "platform", "benchmark": false, "company": "比尔·盖茨 (Bill Gates)", "leader": "Microsoft (Windows / Office)", "positioning": "水平操作系统授权 + B2B 企业软件标准", "culture": "OEM 广度绑定 + 开发者生态", "headcount": "1999首破 $500B (今~$3.8T)", "margins": "巅峰净利率 ~40.0%", "verdict": "一生竞合镜像：1980–90年代盖茨凭水平授权击败封闭 Mac（1997注资$1.5亿和解），但移动时代乔布斯凭软硬一体反超。", "sourceLabel": "LA Times", "sourceUrl": "https://www.latimes.com/archives/la-xpm-1999-jul-17-fi-56769-story.html"}, {"category": "platform", "benchmark": false, "company": "杰夫·贝索斯 (Jeff Bezos)", "leader": "Amazon / AWS / Blue Origin", "positioning": "无限选品规模飞轮 + AWS 云基础设施", "culture": "Day 1 机制 + 六页纸备忘录", "headcount": "2021卸任市值 $1.7T–$1.9T", "margins": "零售 1–2% / AWS 25–30%", "verdict": "做加法 vs 做减法：乔布斯靠极少高毛利精品取胜，贝索斯靠海量 SKU 让利与底层云设施实现 225,233% 股价涨幅。", "sourceLabel": "Fortune", "sourceUrl": "https://fortune.com/2021/02/02/jeff-bezos-steps-down-amazon-stock-net-worth-andy-jassy/"}, {"category": "hardtech", "benchmark": false, "company": "黄仁勋 (Jensen Huang)", "leader": "NVIDIA (GPU + CUDA AI 全栈)", "positioning": "芯片 + 网络 + CUDA 软件栈端到端协同", "culture": "扁平直管数十高管 + 零帝国化", "headcount": "AI算力时代全球市值领跑", "margins": "毛利 71–75% / 营业 ~65.2%", "verdict": "AI 时代的“全栈门徒”：与乔布斯一样拒绝事业部制、坚持职能扁平架构与软硬全栈垂直整合，复刻垄断级毛利。", "sourceLabel": "Business Quant", "sourceUrl": "https://businessquant.com/metrics/nvda/gross-margin"}, {"category": "hardtech", "benchmark": false, "company": "埃隆·马斯克 (Elon Musk)", "leader": "Tesla / SpaceX / xAI", "positioning": "第一性原理极限工程制造与产线垂直化", "culture": "五步工程法 + 极限时间线驱动", "headcount": "2026福布斯个人身家 ~$839B", "margins": "重资产制造波动周期", "verdict": "重工业版现实扭曲力场：共享极致直觉与高压执行力，但乔布斯采用轻资产外包制造，马斯克亲自深入重资产工厂。", "sourceLabel": "Forbes 2026", "sourceUrl": "https://www.forbes.com/billionaires/"}];
      var PEER_ROWS_EN = [{"category": "core", "benchmark": true, "company": "Benchmark: Steve Jobs", "leader": "Apple / Pixar / NeXT", "positioning": "Whole-Widget Vertical Integration + Design Premium", "culture": "Functional Org + 2×2 Extreme Focus", "headcount": "2011 #1 ~$350B (Now ~$4.8T)", "margins": "40.5% Gross / 31.2% Operating", "verdict": "Consumer-tech archetype: the only founder to transform PCs, digital animation, music, smartphones, tablets, and retail.", "sourceLabel": "Gulf News", "sourceUrl": "https://gulfnews.com/business/markets/how-steve-jobs-and-tim-cook-turned-apple-into-a-48-trillion-giant-1.500664931"}, {"category": "platform", "benchmark": false, "company": "Bill Gates", "leader": "Microsoft (Windows / Office)", "positioning": "Horizontal OS Licensing + B2B Enterprise Standard", "culture": "Broad OEM Bundling + Developer Ecosystem", "headcount": "1999 >$500B (Now ~$3.8T)", "margins": "Peak Net Margin ~40.0%", "verdict": "Lifelong mirror rival: Gates won the 1980s–90s PC OS war via horizontal licensing, while Jobs's integrated iPhone led mobile.", "sourceLabel": "LA Times", "sourceUrl": "https://www.latimes.com/archives/la-xpm-1999-jul-17-fi-56769-story.html"}, {"category": "platform", "benchmark": false, "company": "Jeff Bezos", "leader": "Amazon / AWS / Blue Origin", "positioning": "Infinite-Selection Flywheel + AWS Cloud", "culture": "Day 1 Mentality + 6-Page Narratives", "headcount": "2021 Exit Cap $1.7T–$1.9T", "margins": "Retail 1–2% / AWS 25–30%", "verdict": "Addition vs. Subtraction: Jobs won via ultra-curated high-margin hits; Bezos compounded 225,233% via scale and AWS.", "sourceLabel": "Fortune", "sourceUrl": "https://fortune.com/2021/02/02/jeff-bezos-steps-down-amazon-stock-net-worth-andy-jassy/"}, {"category": "hardtech", "benchmark": false, "company": "Jensen Huang", "leader": "NVIDIA (GPU + CUDA Full Stack)", "positioning": "Silicon + Networking + CUDA Software Co-Design", "culture": "Flat Direct-Report Structure + Zero Silos", "headcount": "AI Compute Market Cap Leader", "margins": "71–75% Gross / ~65.2% Op", "verdict": "AI-era full-stack disciple: mirrors Jobs's functional org and hardware-software vertical integration in AI compute.", "sourceLabel": "Business Quant", "sourceUrl": "https://businessquant.com/metrics/nvda/gross-margin"}, {"category": "hardtech", "benchmark": false, "company": "Elon Musk", "leader": "Tesla / SpaceX / xAI", "positioning": "First-Principles Engineering + Factory Verticalization", "culture": "5-Step Algorithm + Extreme Timelines", "headcount": "2026 Forbes Net Worth ~$839B", "margins": "Capex-Heavy Mfg Cycles", "verdict": "Industrial reality-distortion field: shares intense drive, though Jobs outsourced assembly while Musk owns the factories.", "sourceLabel": "Forbes 2026", "sourceUrl": "https://www.forbes.com/billionaires/"}];
      var CHECKLIST_ITEMS = [{"tag": "极简战略锚", "title": "1. 2×2 四宫格清晰度测试：30秒能否向朋友讲清买哪款？", "desc": "检验企业产品线是否存在定位重叠、型号繁杂内耗；优秀的矩阵每个象限只保留一款无可争议的拳头产品。"}, {"tag": "垂直整合壁垒", "title": "2. “Whole Widget”端到端掌控力：核心体验是否受制于人？", "desc": "核查企业是否掌握关键底层技术（芯片/内核/算法）与前端交互的联合调优权，而非沦为公版方案组装商。"}, {"tag": "反创新者窘境", "title": "3. 主动自我蚕食勇气：是否敢于亲手颠覆存量现金牛？", "desc": "观察管理层是否因保护旧业务利润而对新技术畏首畏尾，抑或像 iPhone 取代 iPod 般果断拥抱下一代计算范式。"}, {"tag": "组织杠杆指标", "title": "4. A 级人才密度与研发转化效率（警惕盲目堆砌研发费）", "desc": "对标苹果 FY11 仅 2.2% 研发费率创造 $1,082.5亿营收，检验研发支出是否真正转化为爆款单品与高毛利回报。"}, {"tag": "品牌溢价检验", "title": "5. 科技与人文交叉点的品牌定价权（毛利率跑赢同行）", "desc": "检验用户在无需补贴折扣的前提下是否愿为工业设计、开箱体验与情感共鸣支付显著高于竞品的溢价。"}, {"tag": "执行与韧性锚", "title": "6. DRI 直接责任人机制与零有息负债现金安全垫", "desc": "每项关键任务是否有明确唯一责任人（DRI），资产负债表是否留有抵御技术代际突变的充沛净现金储备。"}];
      var CHECKLIST_ITEMS_EN = [{"tag": "2×2 Focus Anchor", "title": "1. 2×2 Grid Clarity Test: Can you explain which model to buy in 30 seconds?", "desc": "Tests whether the product lineup avoids overlapping SKU bloat—keeping one indisputable flagship per quadrant."}, {"tag": "Whole-Widget Moat", "title": "2. End-to-End Integration Test: Does the firm control its core UX stack?", "desc": "Checks ownership of key silicon, OS kernel, and UI co-optimization rather than relying on generic commodity stacks."}, {"tag": "Anti-Innovator's Dilemma", "title": "3. Self-Cannibalization Courage: Will leadership disrupt its own cash cow?", "desc": "Verifies whether management protects legacy margins or boldly launches the next paradigm like iPhone replacing iPod."}, {"tag": "2.2% R&D Leverage", "title": "4. A-Player Density & R&D Efficiency Test (avoiding unfocused bloat)", "desc": "Benchmarks R&D conversion against Apple's FY11 2.2% R&D ratio generating $108.25B in revenue."}, {"tag": "Design Pricing Power", "title": "5. Tech × Humanities Pricing Power Test (Gross margin outperformance)", "desc": "Checks whether customers willingly pay a durable premium for industrial design and unboxing craft without discounts."}, {"tag": "DRI & Cash Cushion", "title": "6. DRI Accountability & Zero-Debt Cash Fortress Test", "desc": "Confirms every mission-critical deliverable has a single Directly Responsible Individual (DRI) and ample net cash."}];
      var QUICK_JUMP_INDEX = [{"sec": "sec-00", "title": "00 执行摘要与核心指标", "sub": "~$350B 登顶 · FY11 $108.25B 营收 · Pixar $7.4B · 450+ 专利"}, {"sec": "sec-01", "title": "01 商业版图与产品架构", "sub": "2×2 四宫格 · iPhone/iPad/Mac · Apple Store · FY11 营收拆解图"}, {"sec": "sec-02", "title": "02 产品哲学与四重护城河", "sub": "Whole Widget · 2.2% 研发 · 200+ 设计专利 · 五维能力雷达图"}, {"sec": "sec-03", "title": "03 传奇科技领袖横向对比", "sub": "乔布斯 vs 盖茨 vs 贝索斯 vs 黄仁勋 vs 马斯克 · Apple Store 坪效"}, {"sec": "sec-04", "title": "04 商业回报与价值复利推演", "sub": "$81.57B 现金池 · iPhone 黄金五年 · 创新周期复利模拟器"}, {"sec": "sec-05", "title": "05 三幕演进与管理遗产复盘", "sub": "1976–1985 · 1985–1997 NeXT/Pixar · 1997–2011+ · 四大教训"}, {"sec": "sec-06", "title": "06 乔布斯法则核查清单", "sub": "6 项产品与企业护城河自测与本地持久化评分"}, {"sec": "sec-07", "title": "07 数据来源与监管核验索引", "sub": "Apple SEC 10-K · Disney/Pixar · USPTO 权威档案"}];
      var QUICK_JUMP_EN = [{"sec": "sec-00", "title": "00 Executive Summary & KPIs", "sub": "~$350B Peak · FY11 $108.25B Rev · Pixar $7.4B · 450+ Patents"}, {"sec": "sec-01", "title": "01 Business Empire & Product Matrix", "sub": "2×2 Grid · iPhone/iPad/Mac · Apple Store · FY11 Revenue Chart"}, {"sec": "sec-02", "title": "02 Philosophy & 4 Economic Moats", "sub": "Whole Widget · 2.2% R&D · Design Patents · 5-Axis Founder Radar"}, {"sec": "sec-03", "title": "03 Iconic Tech Founders Matrix", "sub": "Jobs vs. Gates vs. Bezos vs. Huang vs. Musk · Retail Sales/ft²"}, {"sec": "sec-04", "title": "04 Financials & Value Simulator", "sub": "$81.57B Cash · iPhone 5-Yr Surge · Interactive Compounding Sim"}, {"sec": "sec-05", "title": "05 Three-Act Evolution & Case Lessons", "sub": "1976–85 · 1985–97 NeXT/Pixar · 1997–2011+ · 4 Key Lessons"}, {"sec": "sec-06", "title": "06 Steve Jobs Diagnostic Checklist", "sub": "6-Point Product & Moat Audit (Saved Locally)"}, {"sec": "sec-07", "title": "07 Primary Filings & Sources Index", "sub": "Apple SEC 10-K · Disney/Pixar · USPTO Records"}];

      var PRESETS = {
        p1: { principal: 10000, years: 14, priceCagr: 39.3, div: false },
        p2: { principal: 10000, years: 20, priceCagr: 24.2, div: false },
        p3: { principal: 1000,  years: 29, priceCagr: 31.0, div: false }
      };

      var state = {
        lang: 'zh',
        theme: 'light',
        ch1View: 'viewA',
        activePillar: 0,
        radarSeries: { jobs: true, gates: true, bezos: true },
        ch1Series: { s1: true, s2: true },
        epsSeries: { cash: true, ni: true },
        peerFilter: 'all',
        peerQuery: '',
        sim: { principal: 10000, years: 14, priceCagr: 39.3, div: false, preset: 'p1' },
        checks: [true, true, true, false, false, false]
      };

      function safeGetStorage(key) { try { return window.localStorage.getItem(key); } catch (e) { return null; } }
      function safeSetStorage(key, val) { try { window.localStorage.setItem(key, val); } catch (e) {} }

      var toastTimer = null;
      function showToast(msg) {
        var el = document.getElementById('muiSnackbar');
        if (!el) return;
        el.textContent = msg;
        el.classList.add('show');
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(function () { el.classList.remove('show'); }, 2800);
      }

      function isEn() { return state.lang === 'en'; }
      var _zhToEnText = {}, _enToZhText = {};
      for (var _ti = 0; _ti < I18N_TEXT_PAIRS.length; _ti++) {
        _zhToEnText[I18N_TEXT_PAIRS[_ti][0]] = I18N_TEXT_PAIRS[_ti][1];
        _enToZhText[I18N_TEXT_PAIRS[_ti][1]] = I18N_TEXT_PAIRS[_ti][0];
      }
      var _zhToEnAttr = {}, _enToZhAttr = {};
      for (var _ai = 0; _ai < I18N_ATTR_PAIRS.length; _ai++) {
        _zhToEnAttr[I18N_ATTR_PAIRS[_ai][0]] = I18N_ATTR_PAIRS[_ai][1];
        _enToZhAttr[I18N_ATTR_PAIRS[_ai][1]] = I18N_ATTR_PAIRS[_ai][0];
      }
      var _richMapByKey = {};
      for (var _ri = 0; _ri < I18N_RICH_LIST.length; _ri++) _richMapByKey[I18N_RICH_LIST[_ri].key] = I18N_RICH_LIST[_ri];

      function bindRichBlocksOnce() {
        var candidates = document.querySelectorAll('h1, p, div');
        for (var i = 0; i < candidates.length; i++) {
          var el = candidates[i];
          if (el.getAttribute('data-i18n-rich')) continue;
          if (el.id === 'pillarFocusNote' || el.closest('#pillarFocusNote')) continue;
          var normTxt = (el.textContent || '').replace(/\s+/g, ' ').trim();
          for (var j = 0; j < I18N_RICH_LIST.length; j++) {
            var item = I18N_RICH_LIST[j];
            if (normTxt.indexOf(item.match_zh) === 0 && el.children.length <= 25 && !el.querySelector('div, p, ul, table, canvas')) {
              el.setAttribute('data-i18n-rich', item.key);
              break;
            }
          }
        }
      }

      function syncCh1HeaderText() {
        var tEl = document.getElementById('ch1ChartTitle'), sEl = document.getElementById('ch1ChartSub');
        if (!tEl || !sEl) return;
        if (state.ch1View === 'viewA') {
          tEl.textContent = isEn() ? 'FY2010 vs FY2011 Apple Net Sales by Product Line ($B · SEC 10-K)' : 'FY2010 vs FY2011 苹果六大业务线净营收结构拆解（$B · SEC 10-K）';
          sEl.textContent = isEn() ? 'iPhone ($47.06B, +87%) and iPad ($20.36B, +311%) surged while proactively cannibalizing iPod (-10%)' : 'iPhone ($47.06B, +87%) 与 iPad ($20.36B, +311%) 爆发式接棒，主动完成对 iPod (-10%) 的自我迭代';
        } else {
          tEl.textContent = isEn() ? 'FY1997 Turnaround to FY2011 Peak: 15.3x Revenue & Net Income Reversal ($B)' : 'FY1997 回归低谷至 FY2011 谢幕巅峰：苹果营收 15.3 倍与净利反转曲线';
          sEl.textContent = isEn() ? 'Reversed from -$1.05B net loss in FY97 to $25.92B net income in FY11 across the 2008 financial crisis' : '从 1997 财年净亏损 -$1.05B 逆转至 2011 财年净利润 $25.92B，跨越 2008 金融危机持续加速增长';
        }
      }

      function syncCollapseButtonsText() {
        var btns = document.querySelectorAll('[data-collapse-target]');
        for (var i = 0; i < btns.length; i++) {
          var p = document.getElementById(btns[i].getAttribute('data-collapse-target'));
          var open = p && p.classList.contains('open');
          btns[i].innerHTML = isEn()
            ? (open ? '<span>Hide Execution Mechanics</span> <span>⌃</span>' : '<span>Show Execution Mechanics</span> <span>⌄</span>')
            : (open ? '<span>收起微观执行机制</span> <span>⌃</span>' : '<span>展开微观执行机制</span> <span>⌄</span>');
        }
      }

      function applyLanguage(lang, silent) {
        bindRichBlocksOnce();
        state.lang = lang === 'en' ? 'en' : 'zh';
        var en = isEn();
        document.documentElement.setAttribute('lang', en ? 'en' : 'zh-CN');
        document.documentElement.setAttribute('data-lang', state.lang);
        document.title = en ? DOC_TITLE_EN : DOC_TITLE_ZH;

        var zhB = document.getElementById('langZhBtn'), enB = document.getElementById('langEnBtn');
        if (zhB && enB) {
          zhB.classList.toggle('active', !en); enB.classList.toggle('active', en);
          zhB.setAttribute('aria-pressed', !en ? 'true' : 'false'); enB.setAttribute('aria-pressed', en ? 'true' : 'false');
        }
        var lGrp = document.getElementById('langSwitchGroup');
        if (lGrp) lGrp.setAttribute('aria-label', en ? 'Language switcher' : '语言切换');
        var abThmBtn = document.getElementById('appbarThemeBtn');
        if (abThmBtn) {
          abThmBtn.setAttribute('title', en ? 'Toggle Light / Dark theme' : '切换浅色 / 深色主题');
          abThmBtn.setAttribute('aria-label', en ? 'Toggle color theme' : '切换深浅色主题');
        }
        var dynNav = document.querySelectorAll('[data-i18n-zh][data-i18n-en]');
        for (var dn = 0; dn < dynNav.length; dn++) {
          dynNav[dn].textContent = en ? dynNav[dn].getAttribute('data-i18n-en') : dynNav[dn].getAttribute('data-i18n-zh');
        }

        var richNodes = document.querySelectorAll('[data-i18n-rich]');
        for (var r = 0; r < richNodes.length; r++) {
          var rEntry = _richMapByKey[richNodes[r].getAttribute('data-i18n-rich')];
          if (rEntry) richNodes[r].innerHTML = en ? rEntry.en : rEntry.zh;
        }

        var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
        var tNode;
        while ((tNode = walker.nextNode())) {
          var pEl = tNode.parentElement;
          if (!pEl || pEl.tagName === 'SCRIPT' || pEl.tagName === 'STYLE') continue;
          if (pEl.closest('#langSwitchGroup') || pEl.closest('[data-i18n-rich]') || pEl.closest('#pillarFocusNote')) continue;
          var raw = tNode.nodeValue || '', trimmed = raw.replace(/\s+/g, ' ').trim();
          if (!trimmed) continue;
          var mapped = en ? _zhToEnText[trimmed] : _enToZhText[trimmed];
          if (mapped) {
            var lead = raw.match(/^\s*/), trail = raw.match(/\s*$/);
            tNode.nodeValue = (lead ? lead[0] : '') + mapped + (trail ? trail[0] : '');
          }
        }

        var allEls = document.querySelectorAll('[placeholder], [title], [aria-label]');
        var attrs = ['placeholder', 'title', 'aria-label'];
        for (var a = 0; a < allEls.length; a++) {
          if (allEls[a].closest('#langSwitchGroup')) continue;
          for (var k = 0; k < attrs.length; k++) {
            var av = allEls[a].getAttribute(attrs[k]);
            if (!av) continue;
            var nx = en ? _zhToEnAttr[av] : _enToZhAttr[av];
            if (nx) allEls[a].setAttribute(attrs[k], nx);
          }
        }

        var pNote = document.getElementById('pillarFocusNote');
        if (pNote) pNote.innerHTML = '<div>' + (en ? PILLAR_NOTES_EN : PILLAR_NOTES)[state.activePillar] + '</div>';
        syncCh1HeaderText();
        syncCollapseButtonsText();
        renderPeerTable();
        renderChecklist();
        updateSimulatorUI();
        renderAllCharts();
        safeSetStorage(STORAGE_LANG_KEY, state.lang);
        if (!silent) showToast(en ? 'Switched to English Research Edition' : '已切换至中文深度研报视图');
      }

      function applyTheme(theme, silent) {
        state.theme = theme === 'dark' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', state.theme);
        var abIcon = document.getElementById('appbarThemeIcon');
        if (abIcon) abIcon.innerHTML = (state.theme === 'dark')
          ? '<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zm18 0h2c.55 0 1-.45 1-1s-.45-1-1-1h-2c-.55 0-1 .45-1 1s.45 1 1 1zM11 2v2c0 .55.45 1 1 1s1-.45 1-1V2c0-.55-.45-1-1-1s-1 .45-1 1zm0 18v2c0 .55.45 1 1 1s1-.45 1-1v-2c0-.55-.45-1-1-1s-1 .45-1 1zM5.99 4.58a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0s.39-1.03 0-1.41L5.99 4.58zm12.37 12.37a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0a.996.996 0 0 0 0-1.41l-1.06-1.06zm1.06-10.96a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06zM7.05 18.36a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06z"/></svg>'
          : '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3a9 9 0 1 0 9 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 0 1-4.4 2.26 5.403 5.403 0 0 1-3.14-9.8c-.44-.06-.9-.1-1.36-.1z"/></svg>';
        var sD = document.getElementById('sideThemeDarkBtn'), sL = document.getElementById('sideThemeLightBtn');
        if (sD && sL) { void 0; void 0; }
        safeSetStorage(STORAGE_THEME_KEY, state.theme);
        renderAllCharts();
        if (!silent) showToast(state.theme === 'dark' ? (isEn() ? 'Switched to Dark Mode' : '已切换至 MUI 深海黑曜石护眼模式') : (isEn() ? 'Switched to Light Mode' : '已切换至 MUI 浅色明亮阅读模式'));
      }

      function toggleSidebar() {
        if (window.innerWidth <= 1120) document.body.classList.toggle('drawer-open');
        else { document.body.classList.toggle('sidebar-collapsed'); setTimeout(renderAllCharts, 60); }
      }
      function closeMobileDrawer() { document.body.classList.remove('drawer-open'); }
      function escapeHtml(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
      function highlightMatch(t, q) {
        var safe = escapeHtml(t);
        if (!q) return safe;
        return safe.replace(new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi'), '<mark class="hl">$1</mark>');
      }

      function renderPeerTable() {
        var tbody = document.getElementById('peerTableBody'), badge = document.getElementById('peerCountBadge');
        if (!tbody) return;
        var rows = isEn() ? PEER_ROWS_EN : PEER_ROWS;
        var q = state.peerQuery.trim().toLowerCase();
        var filtered = rows.filter(function (row, idx) {
          if (!(state.peerFilter === 'all' || row.category === 'core' || row.category === state.peerFilter)) return false;
          if (!q) return true;
          var zhR = PEER_ROWS[idx] || row, enR = PEER_ROWS_EN[idx] || row;
          return (zhR.company + ' ' + zhR.leader + ' ' + zhR.positioning + ' ' + zhR.culture + ' ' + zhR.verdict + ' ' + enR.company + ' ' + enR.leader + ' ' + enR.positioning + ' ' + enR.culture + ' ' + enR.verdict).toLowerCase().indexOf(q) !== -1;
        });
        if (badge) badge.textContent = isEn() ? ('Showing ' + filtered.length + ' / ' + rows.length + ' Founders') : ('显示 ' + filtered.length + ' / ' + rows.length + ' 位科技宗师');
        if (!filtered.length) {
          tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:28px;">' + (isEn() ? 'No matching benchmark founders found.' : '未找到匹配的领袖记录，请尝试清空搜索词或切换分类。') + '</td></tr>';
          return;
        }
        var rq = state.peerQuery.trim();
        tbody.innerHTML = filtered.map(function (r) {
          return '<tr class="' + (r.benchmark ? 'benchmark-row' : '') + '">' +
            '<td><strong style="color:var(--text-primary);display:block;">' + highlightMatch(r.company, rq) + '</strong><span style="font-size:0.76rem;color:var(--text-muted);">' + highlightMatch(r.leader, rq) + '</span></td>' +
            '<td>' + highlightMatch(r.positioning, rq) + '</td>' +
            '<td>' + highlightMatch(r.culture, rq) + '</td>' +
            '<td class="mono" style="font-size:0.79rem;">' + highlightMatch(r.headcount, rq) + '</td>' +
            '<td class="mono" style="font-size:0.79rem;color:var(--mui-primary-lighter);font-weight:700;">' + highlightMatch(r.margins, rq) + '</td>' +
            '<td>' + highlightMatch(r.verdict, rq) + ' <a class="cite-link" href="' + r.sourceUrl + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(r.sourceLabel) + ' ↗</a></td>' +
          '</tr>';
        }).join('');
      }

      function formatCurrency(v) { return '$' + Math.round(v).toLocaleString('en-US'); }

      function updateSimulatorUI() {
        var p = state.sim.principal, yrs = state.sim.years, cagr = state.sim.priceCagr;
        var totalRate = (cagr + (state.sim.div ? 0.8 : 0.0)) / 100;
        var endVal = p * Math.pow(1 + totalRate, yrs), moic = endVal / p, netGain = endVal - p;
        var midYear = Math.max(1, Math.floor(yrs / 2)), midVal = p * Math.pow(1 + totalRate, midYear);

        document.getElementById('simPrincipalLabel').textContent = formatCurrency(p);
        document.getElementById('simYearsLabel').textContent = yrs + (isEn() ? ' yrs' : ' 年');
        document.getElementById('simCagrLabel').textContent = cagr.toFixed(1) + '%';
        document.getElementById('simEndingVal').textContent = formatCurrency(endVal);
        document.getElementById('simMoicVal').textContent = (moic >= 100 ? moic.toFixed(1) : moic.toFixed(2)) + 'x · ' + (totalRate * 100).toFixed(2) + '%';
        document.getElementById('simNetGainVal').textContent = formatCurrency(netGain);
        document.getElementById('simMidLabel').textContent = isEn() ? ('Year ' + midYear + ' Midpoint Value') : ('第 ' + midYear + ' 年中期资产节点');
        document.getElementById('simMidVal').textContent = formatCurrency(midVal);

        var pBtns = document.querySelectorAll('[data-preset]');
        for (var i = 0; i < pBtns.length; i++) pBtns[i].classList.toggle('active', pBtns[i].getAttribute('data-preset') === state.sim.preset);
        drawSimChart();
      }

      function renderChecklist() {
        var cont = document.getElementById('checklistContainer'), chip = document.getElementById('checklistScoreChip'), bar = document.getElementById('checklistProgressBar');
        if (!cont) return;
        var items = isEn() ? CHECKLIST_ITEMS_EN : CHECKLIST_ITEMS;
        var done = state.checks.filter(Boolean).length, pct = Math.round((done / items.length) * 100);
        if (chip) chip.textContent = isEn() ? ('Verified ' + done + ' / ' + items.length + ' (' + pct + '%)') : ('已核查 ' + done + ' / ' + items.length + ' 项 (' + pct + '%)');
        if (bar) bar.style.width = pct + '%';
        cont.innerHTML = items.map(function (it, idx) {
          var ck = !!state.checks[idx];
          return '<label class="check-card ' + (ck ? 'checked' : '') + '" data-check-idx="' + idx + '">' +
            '<input type="checkbox" data-check-input="' + idx + '" ' + (ck ? 'checked' : '') + ' />' +
            '<div style="flex:1;"><div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:6px;margin-bottom:4px;">' +
            '<span class="check-title">' + escapeHtml(it.title) + '</span><span class="mui-chip mono">' + escapeHtml(it.tag) + '</span></div>' +
            '<p class="check-desc">' + escapeHtml(it.desc) + '</p></div></label>';
        }).join('');
      }

      /* High-DPI Canvas Engine */
      var hitRegions = { chartCh1: [], chartRadar: [], chartBars: [], chartEps: [], chartSim: [] };
      var hoverState = { chartCh1: -1, chartRadar: -1, chartBars: -1, chartEps: -1, chartSim: -1 };

      function getPalette() {
        var cs = getComputedStyle(document.documentElement), isDark = state.theme === 'dark';
        return {
          isDark: isDark,
          grid: cs.getPropertyValue('--chart-grid').trim() || (isDark ? 'rgba(148,163,184,0.13)' : 'rgba(100,116,139,0.16)'),
          tick: cs.getPropertyValue('--chart-tick').trim() || '#94A3B8',
          text: cs.getPropertyValue('--text-primary').trim() || '#F3F6F9',
          pillBg: isDark ? 'rgba(9, 13, 22, 0.88)' : 'rgba(255, 255, 255, 0.94)',
          pillBorder: isDark ? 'rgba(51, 153, 255, 0.28)' : 'rgba(0, 115, 230, 0.24)',
          trackBg: isDark ? 'rgba(148, 163, 184, 0.10)' : 'rgba(15, 25, 36, 0.06)',
          hoverBand: isDark ? 'rgba(51, 153, 255, 0.07)' : 'rgba(0, 115, 230, 0.05)',
          c1: cs.getPropertyValue('--chart-c1').trim() || '#3399FF',
          c2: cs.getPropertyValue('--chart-c2').trim() || '#22C55E',
          c3: cs.getPropertyValue('--chart-c3').trim() || '#FFB74D'
        };
      }

      function prepareCanvas(id) {
        var cv = document.getElementById(id);
        if (!cv || !cv.parentElement) return null;
        var rect = cv.parentElement.getBoundingClientRect();
        var w = Math.max(240, Math.floor(rect.width)), h = Math.max(170, Math.floor(rect.height));
        var dpr = Math.min(window.devicePixelRatio || 1, 2.5);
        cv.style.width = w + 'px'; cv.style.height = h + 'px';
        if (cv.width !== Math.floor(w * dpr)) cv.width = Math.floor(w * dpr);
        if (cv.height !== Math.floor(h * dpr)) cv.height = Math.floor(h * dpr);
        var ctx = cv.getContext('2d');
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, w, h);
        return { ctx: ctx, w: w, h: h };
      }

      function roundRectPath(ctx, x, y, w, h, r) {
        if (w <= 0 || h <= 0) return;
        var rad = Math.min(r, w / 2, h / 2);
        ctx.beginPath(); ctx.moveTo(x + rad, y); ctx.lineTo(x + w - rad, y); ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
        ctx.lineTo(x + w, y + h - rad); ctx.quadraticCurveTo(x + w, y + h, x + w - rad, y + h);
        ctx.lineTo(x + rad, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - rad);
        ctx.lineTo(x, y + rad); ctx.quadraticCurveTo(x, y, x + rad, y); ctx.closePath();
      }

      function topRoundedBar(ctx, x, y, w, h, r) {
        if (w <= 0 || h <= 0) return;
        var rad = Math.min(r, w / 2, h);
        ctx.beginPath(); ctx.moveTo(x, y + h); ctx.lineTo(x, y + rad); ctx.quadraticCurveTo(x, y, x + rad, y);
        ctx.lineTo(x + w - rad, y); ctx.quadraticCurveTo(x + w, y, x + w, y + rad); ctx.lineTo(x + w, y + h); ctx.closePath();
      }

      function drawValueBadge(ctx, text, cx, cy, fg, pal) {
        ctx.save();
        ctx.font = '700 10.5px "IBM Plex Mono", system-ui, sans-serif';
        var tw = ctx.measureText(text).width + 10, th = 18;
        ctx.fillStyle = pal.pillBg;
        roundRectPath(ctx, cx - tw / 2, cy - th / 2, tw, th, 5);
        ctx.fill();
        ctx.strokeStyle = pal.pillBorder; ctx.lineWidth = 1; ctx.stroke();
        ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(text, cx, cy + 0.5);
        ctx.restore();
      }

      function drawSmoothLine(ctx, pts) {
        if (!pts.length) return;
        ctx.beginPath(); ctx.moveTo(pts[0].x, pts[0].y);
        for (var i = 0; i < pts.length - 1; i++) {
          var xc = (pts[i].x + pts[i + 1].x) / 2;
          ctx.bezierCurveTo(xc, pts[i].y, xc, pts[i + 1].y, pts[i + 1].x, pts[i + 1].y);
        }
      }

      function drawCh1Chart() {
        var env = prepareCanvas('chartCh1');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h, pal = getPalette();
        hitRegions.chartCh1 = [];
        var metaEl = document.getElementById('ch1AxisMeta'), leg1 = document.getElementById('ch1Leg1'), leg2 = document.getElementById('ch1Leg2');

        if (state.ch1View === 'viewA') {
          if (metaEl) metaEl.innerHTML = isEn()
            ? '<span style="color:var(--chart-c1);">■ Left Axis: Product Line Net Sales ($B)</span><span style="color:var(--text-muted);">FY2011 Total Net Sales $108.25B</span>'
            : '<span style="color:var(--chart-c1);">■ 左轴：产品线净营收 ($B)</span><span style="color:var(--text-muted);">FY2011 全公司总净营收 $108.25B</span>';
          if (leg1) leg1.textContent = isEn() ? 'FY2010 Net Sales ($B)' : 'FY2010 净营收 ($B)';
          if (leg2) leg2.textContent = isEn() ? 'FY2011 Net Sales ($B · $108.25B Total)' : 'FY2011 净营收 ($B · 总计 $108.25B)';

          var pad = { top: 26, right: 18, bottom: 44, left: 48 };
          var pw = w - pad.left - pad.right, ph = h - pad.top - pad.bottom;
          var labels = isEn() ? ['iPhone', 'Mac', 'iPad', 'iPod', 'iTunes/Apps', 'Other'] : ['iPhone', 'Mac', 'iPad', 'iPod', 'iTunes/应用', '软件及外设'];
          var fy10 = [25.18, 17.48, 4.96, 8.27, 4.95, 4.39];
          var fy11 = [47.06, 21.78, 20.36, 7.45, 6.31, 5.28];
          var maxY = 52;

          for (var g = 0; g <= 4; g++) {
            var v = (maxY / 4) * g, gy = pad.top + ph - (g / 4) * ph;
            ctx.strokeStyle = pal.grid; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(pad.left, gy); ctx.lineTo(pad.left + pw, gy); ctx.stroke();
            ctx.fillStyle = pal.tick; ctx.font = '11px "IBM Plex Mono", sans-serif'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
            ctx.fillText('$' + v.toFixed(0) + 'B', pad.left - 8, gy);
          }

          var step = pw / labels.length, barW = Math.min(30, Math.max(12, step * 0.28));
          for (var i = 0; i < labels.length; i++) {
            var cx = pad.left + step * (i + 0.5);
            if (hoverState.chartCh1 === i) {
              ctx.fillStyle = pal.hoverBand; roundRectPath(ctx, pad.left + step * i + 4, pad.top, step - 8, ph, 8); ctx.fill();
            }
            if (state.ch1Series.s1) {
              var h1 = (fy10[i] / maxY) * ph, x1 = state.ch1Series.s2 ? (cx - barW - 3) : (cx - barW / 2), y1 = pad.top + ph - h1;
              ctx.fillStyle = pal.isDark ? 'rgba(148,163,184,0.45)' : 'rgba(100,116,139,0.55)';
              topRoundedBar(ctx, x1, y1, barW, h1, 5); ctx.fill();
            }
            if (state.ch1Series.s2) {
              var h2 = (fy11[i] / maxY) * ph, x2 = state.ch1Series.s1 ? (cx + 3) : (cx - barW / 2), y2 = pad.top + ph - h2;
              var g2 = ctx.createLinearGradient(0, y2, 0, pad.top + ph);
              g2.addColorStop(0, '#3399FF'); g2.addColorStop(1, '#0066CC');
              ctx.fillStyle = g2; topRoundedBar(ctx, x2, y2, barW, h2, 5); ctx.fill();
              drawValueBadge(ctx, '$' + fy11[i].toFixed(1) + 'B', x2 + barW / 2, y2 - 12, pal.c1, pal);
            }
            ctx.fillStyle = pal.text; ctx.font = '700 11px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
            ctx.fillText(labels[i], cx, pad.top + ph + 20);
            var yoy = ((fy11[i] - fy10[i]) / fy10[i] * 100);
            ctx.fillStyle = yoy >= 0 ? pal.c2 : '#EF4444'; ctx.font = '10px "IBM Plex Mono", sans-serif';
            ctx.fillText((yoy >= 0 ? '+' : '') + yoy.toFixed(0) + '% YoY', cx, pad.top + ph + 34);

            hitRegions.chartCh1.push({
              idx: i, x: pad.left + step * i, y: pad.top, w: step, h: ph + 36,
              html: '<strong>' + labels[i] + '</strong><br/>• FY2010: $' + fy10[i].toFixed(2) + 'B<br/>• FY2011: <strong>$' + fy11[i].toFixed(2) + 'B</strong> (' + (yoy >= 0 ? '+' : '') + yoy.toFixed(1) + '%)'
            });
          }
        } else {
          if (metaEl) metaEl.innerHTML = isEn()
            ? '<span style="color:var(--chart-c1);">■ Left Axis: Annual Net Sales ($B)</span><span style="color:var(--chart-c2);">● Right Axis: Annual Net Income ($B)</span>'
            : '<span style="color:var(--chart-c1);">■ 左轴：苹果年度净营收 ($B)</span><span style="color:var(--chart-c2);">● 右轴：苹果年度净利润 ($B)</span>';
          if (leg1) leg1.textContent = isEn() ? 'Annual Net Sales (Left · $B)' : '苹果年度净营收 Net Sales (左轴 · $B)';
          if (leg2) leg2.textContent = isEn() ? 'Annual Net Income (Right · $B)' : '苹果年度净利润 Net Income (右轴 · $B)';

          var padB = { top: 28, right: 50, bottom: 38, left: 48 };
          var pwB = w - padB.left - padB.right, phB = h - padB.top - padB.bottom;
          var yrs = ['FY97', 'FY07', 'FY08', 'FY09', 'FY10', 'FY11'];
          var rev = [7.08, 24.58, 37.49, 42.91, 65.23, 108.25];
          var ni = [-1.05, 3.50, 6.12, 8.24, 14.01, 25.92];
          var maxR = 120, minN = -4, maxN = 28;

          for (var j = 0; j <= 4; j++) {
            var r = j / 4, yG = padB.top + phB - r * phB;
            ctx.strokeStyle = pal.grid; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(padB.left, yG); ctx.lineTo(padB.left + pwB, yG); ctx.stroke();
            ctx.font = '11px "IBM Plex Mono", sans-serif'; ctx.textBaseline = 'middle';
            ctx.fillStyle = pal.tick; ctx.textAlign = 'right'; ctx.fillText('$' + (maxR * r).toFixed(0) + 'B', padB.left - 7, yG);
            ctx.fillStyle = pal.c2; ctx.textAlign = 'left'; ctx.fillText('$' + (minN + r * (maxN - minN)).toFixed(0) + 'B', padB.left + pwB + 7, yG);
          }

          var stepB = pwB / yrs.length, bW = Math.min(36, Math.max(18, stepB * 0.42)), pts = [];
          for (var k = 0; k < yrs.length; k++) {
            var cxB = padB.left + stepB * (k + 0.5);
            if (hoverState.chartCh1 === k) { ctx.fillStyle = pal.hoverBand; roundRectPath(ctx, padB.left + stepB * k + 3, padB.top, stepB - 6, phB, 6); ctx.fill(); }
            if (state.ch1Series.s1) {
              var bH = (rev[k] / maxR) * phB, bY = padB.top + phB - bH;
              var bg = ctx.createLinearGradient(0, bY, 0, padB.top + phB);
              bg.addColorStop(0, '#3399FF'); bg.addColorStop(1, '#0066CC');
              ctx.fillStyle = bg; topRoundedBar(ctx, cxB - bW / 2, bY, bW, bH, 5); ctx.fill();
            }
            var lY = padB.top + phB - ((ni[k] - minN) / (maxN - minN)) * phB;
            pts.push({ x: cxB, y: lY, val: ni[k] });
            ctx.fillStyle = pal.text; ctx.font = '700 11px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
            ctx.fillText(yrs[k], cxB, padB.top + phB + 22);
            hitRegions.chartCh1.push({
              idx: k, x: padB.left + stepB * k, y: padB.top, w: stepB, h: phB + 28,
              html: '<strong>' + yrs[k] + '</strong><br/>• Net Sales: <strong>$' + rev[k].toFixed(2) + 'B</strong><br/>• Net Income: <strong>$' + ni[k].toFixed(2) + 'B</strong>'
            });
          }
          if (state.ch1Series.s2) {
            drawSmoothLine(ctx, pts); ctx.strokeStyle = pal.c2; ctx.lineWidth = 2.8; ctx.stroke();
            for (var n = 0; n < pts.length; n++) {
              ctx.fillStyle = pal.pillBg; ctx.beginPath(); ctx.arc(pts[n].x, pts[n].y, 5.5, 0, Math.PI * 2); ctx.fill();
              ctx.fillStyle = pal.c2; ctx.beginPath(); ctx.arc(pts[n].x, pts[n].y, 3.8, 0, Math.PI * 2); ctx.fill();
              drawValueBadge(ctx, '$' + pts[n].val.toFixed(1) + 'B', pts[n].x, pts[n].y - 16, pal.c2, pal);
            }
          }
        }
      }

      function drawRadarChart() {
        var env = prepareCanvas('chartRadar');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h, pal = getPalette();
        hitRegions.chartRadar = [];
        var axes = isEn() ? ['UX & Design', '2×2 Focus', 'Platform Lock-In', 'Multi-Industry', 'Cloud & Logistics'] : ['产品美学与体验', '战略极简减法', '双边生态锁定', '跨产业颠覆力', '云与物流纵深'];
        var pillarAxisMap = [0, 1, 3, 2];
        var hiAxis = hoverState.chartRadar >= 0 ? hoverState.chartRadar : pillarAxisMap[state.activePillar];
        var series = [
          { key: 'jobs', color: pal.c1, fill: 'rgba(51, 153, 255, 0.24)', vals: [9.9, 9.8, 9.4, 9.7, 8.2] },
          { key: 'gates', color: pal.c2, fill: 'rgba(34, 197, 94, 0.16)', vals: [6.8, 7.2, 9.8, 7.6, 8.5] },
          { key: 'bezos', color: pal.c3, fill: 'rgba(255, 183, 77, 0.14)', vals: [7.8, 6.4, 9.5, 9.2, 9.9] }
        ];
        var cx = w / 2, cy = h / 2 + 8, sidePad = w < 420 ? 86 : 104, radius = Math.max(62, Math.min((w - sidePad * 2) / 2, h * 0.35)), total = axes.length;

        for (var ring = 2; ring <= 10; ring += 2) {
          var r = (ring / 10) * radius;
          ctx.strokeStyle = pal.grid; ctx.lineWidth = ring === 10 ? 1.3 : 1; ctx.beginPath();
          for (var i = 0; i < total; i++) {
            var ang = -Math.PI / 2 + (i * 2 * Math.PI) / total;
            var px = cx + Math.cos(ang) * r, py = cy + Math.sin(ang) * r;
            if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
          }
          ctx.closePath(); ctx.stroke();
          ctx.fillStyle = pal.tick; ctx.font = '600 9.5px "IBM Plex Mono", sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
          ctx.fillText(String(ring), cx + 4, cy - r);
        }

        for (var a = 0; a < total; a++) {
          var angle = -Math.PI / 2 + (a * 2 * Math.PI) / total;
          var ax = cx + Math.cos(angle) * radius, ay = cy + Math.sin(angle) * radius, isHi = a === hiAxis;
          ctx.strokeStyle = isHi ? pal.c1 : pal.grid; ctx.lineWidth = isHi ? 1.8 : 1; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(ax, ay); ctx.stroke();
          var lx = cx + Math.cos(angle) * (radius + 14), ly = cy + Math.sin(angle) * (radius + 15);
          ctx.fillStyle = isHi ? pal.c1 : pal.text; ctx.font = (isHi ? '800 ' : '600 ') + '11px system-ui, sans-serif'; ctx.textBaseline = 'middle';
          ctx.textAlign = Math.abs(Math.cos(angle)) < 0.2 ? 'center' : (Math.cos(angle) > 0 ? 'left' : 'right');
          ctx.fillText(axes[a], lx, ly);
          hitRegions.chartRadar.push({
            idx: a, x: Math.min(ax, lx) - 36, y: Math.min(ay, ly) - 22, w: 72 + Math.abs(lx - ax), h: 44,
            html: '<strong>' + axes[a] + '</strong><br/>• Steve Jobs: <strong>' + series[0].vals[a].toFixed(1) + '</strong><br/>• Bill Gates: <strong>' + series[1].vals[a].toFixed(1) + '</strong><br/>• Jeff Bezos: <strong>' + series[2].vals[a].toFixed(1) + '</strong>'
          });
        }

        for (var s = 0; s < series.length; s++) {
          var item = series[s];
          if (!state.radarSeries[item.key]) continue;
          ctx.beginPath();
          for (var idx = 0; idx < total; idx++) {
            var th = -Math.PI / 2 + (idx * 2 * Math.PI) / total, d = (item.vals[idx] / 10) * radius;
            var vx = cx + Math.cos(th) * d, vy = cy + Math.sin(th) * d;
            if (idx === 0) ctx.moveTo(vx, vy); else ctx.lineTo(vx, vy);
          }
          ctx.closePath(); ctx.fillStyle = item.fill; ctx.fill(); ctx.strokeStyle = item.color; ctx.lineWidth = 2.4; ctx.stroke();
        }
      }

      function drawHorizontalBars() {
        var env = prepareCanvas('chartBars');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h, pal = getPalette();
        hitRegions.chartBars = [];
        var items = isEn() ? [
          { label: 'Apple Store (Jobs Experiential Retail Paradigm)', val: 4032, cStart: '#3399FF', cEnd: '#0073E6', sub: '#1 in U.S. Retail · Genius Bar + Flagship Cubes' },
          { label: 'Tiffany & Co. (Luxury Jewelry Retail Benchmark)', val: 2666, cStart: '#34D399', cEnd: '#16A34A', sub: 'Traditional High-Ticket Luxury Leader' },
          { label: 'Best Buy (Consumer Electronics Big-Box Leader)', val: 930, cStart: '#38BDF8', cEnd: '#0284C7', sub: 'Multi-Brand Electronics Retail Benchmark' },
          { label: 'Walmart (Mass-Market Supercenter Giant)', val: 400, cStart: '#FBBF24', cEnd: '#D97706', sub: 'High-Volume Everyday Low Price Model' },
          { label: 'Saks Fifth Avenue (Upscale Department Store)', val: 362, cStart: '#A78BFA', cEnd: '#7C3AED', sub: 'Traditional Luxury Department Store' }
        ] : [
          { label: 'Apple Store 直营店 (乔布斯体验零售范式)', val: 4032, cStart: '#3399FF', cEnd: '#0073E6', sub: '全美零售坪效第一 · Genius Bar + 玻璃立方体' },
          { label: 'Tiffany & Co. 蒂芙尼 (传统奢侈珠宝标杆)', val: 2666, cStart: '#34D399', cEnd: '#16A34A', sub: '传统高客单奢侈品零售标杆' },
          { label: 'Best Buy 百思买 (传统消费电子大卖场龙头)', val: 930, cStart: '#38BDF8', cEnd: '#0284C7', sub: '综合消费电子卖场基准' },
          { label: 'Walmart 沃尔玛 (大众综合商超巨头)', val: 400, cStart: '#FBBF24', cEnd: '#D97706', sub: '高周转平价大众零售模型' },
          { label: 'Saks Fifth Avenue 萨克斯第五大道 (高端百货)', val: 362, cStart: '#A78BFA', cEnd: '#7C3AED', sub: '传统高端奢侈百货' }
        ];

        var pad = { top: 10, right: 18, bottom: 26, left: 18 }, pw = w - pad.left - pad.right, ph = h - pad.top - pad.bottom, maxX = 4500;
        for (var g = 0; g <= 4; g++) {
          var xv = Math.round((maxX / 4) * g), gx = pad.left + (xv / maxX) * pw;
          ctx.strokeStyle = pal.grid; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(gx, pad.top); ctx.lineTo(gx, pad.top + ph); ctx.stroke();
          ctx.fillStyle = pal.tick; ctx.font = '10.5px "IBM Plex Mono", sans-serif';
          ctx.textAlign = g === 0 ? 'left' : (g === 4 ? 'right' : 'center'); ctx.textBaseline = 'alphabetic';
          ctx.fillText('$' + xv.toLocaleString('en-US'), gx, pad.top + ph + 18);
        }

        var rowH = ph / items.length;
        for (var i = 0; i < items.length; i++) {
          var rTop = pad.top + rowH * i;
          if (hoverState.chartBars === i) { ctx.fillStyle = pal.hoverBand; roundRectPath(ctx, pad.left - 6, rTop + 2, pw + 12, rowH - 4, 8); ctx.fill(); }
          var lY = rTop + Math.max(15, rowH * 0.34), bY = rTop + Math.max(24, rowH * 0.52), bH = Math.min(15, Math.max(11, rowH * 0.25));
          var bw = Math.max(8, (items[i].val / maxX) * pw);

          ctx.fillStyle = pal.text; ctx.font = '600 12px system-ui, sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
          ctx.fillText(items[i].label, pad.left, lY);
          var valStr = '$' + items[i].val.toLocaleString('en-US') + '/ft²';
          ctx.font = '800 12.5px "IBM Plex Mono", sans-serif'; ctx.fillStyle = pal.isDark ? items[i].cStart : items[i].cEnd; ctx.textAlign = 'right';
          ctx.fillText(valStr, pad.left + pw, lY);

          ctx.fillStyle = pal.trackBg; roundRectPath(ctx, pad.left, bY, pw, bH, bH / 2); ctx.fill();
          var bg = ctx.createLinearGradient(pad.left, 0, pad.left + bw, 0);
          bg.addColorStop(0, items[i].cStart); bg.addColorStop(1, items[i].cEnd);
          ctx.fillStyle = bg; roundRectPath(ctx, pad.left, bY, bw, bH, bH / 2); ctx.fill();

          hitRegions.chartBars.push({
            idx: i, x: pad.left, y: rTop, w: pw, h: rowH,
            html: '<strong>' + items[i].label + '</strong><br/>• Sales/ft²: <strong>' + valStr + '</strong><br/>• ' + items[i].sub
          });
        }
      }

      function drawEpsComboChart() {
        var env = prepareCanvas('chartEps');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h, pal = getPalette();
        hitRegions.chartEps = [];
        var years = ['FY2007', 'FY2008', 'FY2009', 'FY2010', 'FY2011'];
        var cash = [15.39, 24.49, 33.99, 51.01, 81.57];
        var ni = [3.50, 6.12, 8.24, 14.01, 25.92];
        var pad = { top: 26, right: 50, bottom: 38, left: 48 }, pw = w - pad.left - pad.right, ph = h - pad.top - pad.bottom;
        var maxC = 90, maxN = 30;

        for (var g = 0; g <= 4; g++) {
          var ratio = g / 4, gy = pad.top + ph - ratio * ph;
          ctx.strokeStyle = pal.grid; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(pad.left, gy); ctx.lineTo(pad.left + pw, gy); ctx.stroke();
          ctx.font = '11px "IBM Plex Mono", sans-serif'; ctx.textBaseline = 'middle';
          ctx.fillStyle = pal.tick; ctx.textAlign = 'right'; ctx.fillText('$' + (maxC * ratio).toFixed(0) + 'B', pad.left - 7, gy);
          ctx.fillStyle = pal.c2; ctx.textAlign = 'left'; ctx.fillText('$' + (maxN * ratio).toFixed(1) + 'B', pad.left + pw + 7, gy);
        }

        var step = pw / years.length, barW = Math.min(46, Math.max(24, step * 0.42)), pts = [];
        for (var i = 0; i < years.length; i++) {
          var cx = pad.left + step * (i + 0.5);
          if (hoverState.chartEps === i) { ctx.fillStyle = pal.hoverBand; roundRectPath(ctx, pad.left + step * i + 4, pad.top, step - 8, ph, 6); ctx.fill(); }
          if (state.epsSeries.cash) {
            var bh = (cash[i] / maxC) * ph, by = pad.top + ph - bh;
            var eg = ctx.createLinearGradient(0, by, 0, pad.top + ph);
            eg.addColorStop(0, '#3399FF'); eg.addColorStop(1, '#0066CC');
            ctx.fillStyle = eg; topRoundedBar(ctx, cx - barW / 2, by, barW, bh, 6); ctx.fill();
            ctx.fillStyle = '#FFFFFF'; ctx.font = '700 10.5px "IBM Plex Mono", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
            ctx.fillText('$' + cash[i].toFixed(1) + 'B', cx, by + 16);
          }
          var ny = pad.top + ph - (ni[i] / maxN) * ph;
          pts.push({ x: cx, y: ny, val: ni[i] });
          ctx.fillStyle = pal.text; ctx.font = '700 11.5px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
          ctx.fillText(years[i], cx, pad.top + ph + 20);
          hitRegions.chartEps.push({
            idx: i, x: pad.left + step * i, y: pad.top, w: step, h: ph + 30,
            html: '<strong>' + years[i] + '</strong><br/>• Cash &amp; Securities: <strong>$' + cash[i].toFixed(2) + 'B</strong><br/>• Net Income: <strong>$' + ni[i].toFixed(2) + 'B</strong>'
          });
        }
        if (state.epsSeries.ni) {
          drawSmoothLine(ctx, pts); ctx.strokeStyle = pal.c2; ctx.lineWidth = 2.8; ctx.stroke();
          for (var m = 0; m < pts.length; m++) {
            ctx.fillStyle = pal.pillBg; ctx.beginPath(); ctx.arc(pts[m].x, pts[m].y, 6, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = pal.c2; ctx.beginPath(); ctx.arc(pts[m].x, pts[m].y, 4.2, 0, Math.PI * 2); ctx.fill();
            drawValueBadge(ctx, '$' + pts[m].val.toFixed(2) + 'B', pts[m].x, pts[m].y - 16, pal.c2, pal);
          }
        }
      }

      function drawSimChart() {
        var env = prepareCanvas('chartSim');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h, pal = getPalette();
        hitRegions.chartSim = [];
        var p = state.sim.principal, yrs = state.sim.years, baseRate = state.sim.priceCagr / 100, totalRate = (state.sim.priceCagr + (state.sim.div ? 0.8 : 0)) / 100;
        var totS = [], baseS = [];
        for (var y = 0; y <= yrs; y++) { totS.push(p * Math.pow(1 + totalRate, y)); baseS.push(p * Math.pow(1 + baseRate, y)); }
        var maxVal = Math.max(totS[yrs], baseS[yrs], p * 1.2) * 1.08;
        var pad = { top: 20, right: 20, bottom: 28, left: 62 }, pw = w - pad.left - pad.right, ph = h - pad.top - pad.bottom;

        for (var g = 0; g <= 3; g++) {
          var v = (maxVal / 3) * g, gy = pad.top + ph - (g / 3) * ph;
          ctx.strokeStyle = pal.grid; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(pad.left, gy); ctx.lineTo(pad.left + pw, gy); ctx.stroke();
          ctx.fillStyle = pal.tick; ctx.font = '10.5px "IBM Plex Mono", sans-serif'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
          var ls = v >= 1000000 ? ('$' + (v / 1000000).toFixed(2) + 'M') : ('$' + Math.round(v / 1000) + 'k');
          ctx.fillText(ls, pad.left - 7, gy);
        }

        ctx.save(); ctx.setLineDash([4, 4]); ctx.strokeStyle = pal.tick; ctx.lineWidth = 1.6; ctx.beginPath();
        for (var i = 0; i <= yrs; i++) {
          var px = pad.left + (i / yrs) * pw, py = pad.top + ph - (baseS[i] / maxVal) * ph;
          if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.stroke(); ctx.restore();

        var stepX = pw / yrs;
        ctx.beginPath();
        for (var j = 0; j <= yrs; j++) {
          var tx = pad.left + (j / yrs) * pw, ty = pad.top + ph - (totS[j] / maxVal) * ph;
          if (j === 0) ctx.moveTo(tx, ty); else ctx.lineTo(tx, ty);
          hitRegions.chartSim.push({
            idx: j, x: tx - Math.max(6, stepX * 0.5), y: pad.top, w: Math.max(12, stepX), h: ph + 24,
            html: '<strong>' + (isEn() ? 'Year ' + j : '第 ' + j + ' 年') + '</strong><br/>• Active Value: <strong>' + formatCurrency(totS[j]) + '</strong><br/>• Base Curve: ' + formatCurrency(baseS[j])
          });
        }
        ctx.strokeStyle = pal.c1; ctx.lineWidth = 2.8; ctx.stroke();
        ctx.lineTo(pad.left + pw, pad.top + ph); ctx.lineTo(pad.left, pad.top + ph); ctx.closePath();
        var grad = ctx.createLinearGradient(0, pad.top, 0, pad.top + ph);
        grad.addColorStop(0, 'rgba(0, 115, 230, 0.30)'); grad.addColorStop(1, 'rgba(0, 115, 230, 0.01)');
        ctx.fillStyle = grad; ctx.fill();

        var endY = pad.top + ph - (totS[yrs] / maxVal) * ph;
        drawValueBadge(ctx, formatCurrency(totS[yrs]), Math.min(w - 48, pad.left + pw - 24), Math.max(pad.top + 12, endY - 14), pal.c1, pal);
        ctx.fillStyle = pal.tick; ctx.font = '10.5px "IBM Plex Mono", sans-serif'; ctx.textBaseline = 'alphabetic';
        ctx.textAlign = 'left'; ctx.fillText(isEn() ? 'Year 0' : '第 0 年', pad.left, pad.top + ph + 19);
        ctx.textAlign = 'right'; ctx.fillText(isEn() ? ('Year ' + yrs) : ('第 ' + yrs + ' 年'), pad.left + pw, pad.top + ph + 19);
      }

      var redrawMap = { chartCh1: drawCh1Chart, chartRadar: drawRadarChart, chartBars: drawHorizontalBars, chartEps: drawEpsComboChart, chartSim: drawSimChart };
      function renderAllCharts() { drawCh1Chart(); drawRadarChart(); drawHorizontalBars(); drawEpsComboChart(); drawSimChart(); }

      function wireCanvasTooltip(cid) {
        var cv = document.getElementById(cid), tip = document.getElementById('chartTooltip');
        if (!cv || !tip) return;
        function handle(cx, cy) {
          var rect = cv.getBoundingClientRect(), mx = cx - rect.left, my = cy - rect.top, regs = hitRegions[cid] || [], found = null;
          for (var i = 0; i < regs.length; i++) if (mx >= regs[i].x && mx <= regs[i].x + regs[i].w && my >= regs[i].y && my <= regs[i].y + regs[i].h) { found = regs[i]; break; }
          var ni = found && typeof found.idx === 'number' ? found.idx : -1;
          if (hoverState[cid] !== ni) { hoverState[cid] = ni; if (redrawMap[cid]) redrawMap[cid](); }
          if (found) {
            tip.innerHTML = found.html; tip.style.display = 'block';
            var tw = tip.offsetWidth || 250, th = tip.offsetHeight || 72, lp = cx + 14;
            if (lp + tw > window.innerWidth - 12) lp = Math.max(12, cx - tw - 14);
            tip.style.left = lp + 'px'; tip.style.top = Math.max(12, Math.min(window.innerHeight - th - 12, cy - 18)) + 'px';
          } else tip.style.display = 'none';
        }
        cv.addEventListener('mousemove', function (e) { handle(e.clientX, e.clientY); });
        cv.addEventListener('mouseleave', function () { if (hoverState[cid] !== -1) { hoverState[cid] = -1; if (redrawMap[cid]) redrawMap[cid](); } tip.style.display = 'none'; });
      }

      function exportStandaloneHtml() {
        var blob = new Blob(['<!DOCTYPE html>\n' + document.documentElement.outerHTML], { type: 'text/html;charset=utf-8' });
        var url = URL.createObjectURL(blob), a = document.createElement('a');
        a.href = url; a.download = 'Steve_Jobs_Analysis.html'; document.body.appendChild(a); a.click(); document.body.removeChild(a);
        setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
        showToast(isEn() ? 'Exported standalone file: Steve_Jobs_Analysis.html' : '已导出独立网页 Steve_Jobs_Analysis.html');
      }

      function init() {
        var rt = safeGetStorage(STORAGE_THEME_KEY);
        if (rt) { rt = String(rt).replace(/^"|"$/g, ''); if (rt === 'light' || rt === 'dark') state.theme = rt; }
        var rl = safeGetStorage(STORAGE_LANG_KEY);
        if (rl) { rl = String(rl).replace(/^"|"$/g, ''); if (rl === 'zh' || rl === 'en') state.lang = rl; }
        window.addEventListener('storage', function (ev) {
          if (ev.key === STORAGE_THEME_KEY && ev.newValue) {
            var nt = String(ev.newValue).replace(/^"|"$/g, '');
            if ((nt === 'light' || nt === 'dark') && nt !== state.theme) applyTheme(nt, true);
          } else if (ev.key === STORAGE_LANG_KEY && ev.newValue) {
            var nl = String(ev.newValue).replace(/^"|"$/g, '');
            if ((nl === 'zh' || nl === 'en') && nl !== state.lang) applyLanguage(nl, true);
          }
        });
        var sc = safeGetStorage(STORAGE_CHECK_KEY);
        if (sc) { try { var p = JSON.parse(sc); if (Array.isArray(p) && p.length === CHECKLIST_ITEMS.length) state.checks = p.map(Boolean); } catch (e) {} }

        applyTheme(state.theme, true);
        applyLanguage(state.lang, true);
        document.getElementById('langZhBtn').addEventListener('click', function () { applyLanguage('zh', false); });
        document.getElementById('langEnBtn').addEventListener('click', function () { applyLanguage('en', false); });
        document.getElementById('appbarThemeBtn').addEventListener('click', function () { applyTheme(state.theme === 'dark' ? 'light' : 'dark', false); });
        document.getElementById('sidebarToggleBtn').addEventListener('click', toggleSidebar);
        document.getElementById('drawerBackdrop').addEventListener('click', closeMobileDrawer);
        void 0;
        void 0;
        void 0;
        void 0;

        var tocLinks = document.querySelectorAll('#tocNavList .mui-nav-link');
        for (var t = 0; t < tocLinks.length; t++) tocLinks[t].addEventListener('click', closeMobileDrawer);

        var jumpInput = document.getElementById('quickJumpInput'), jumpPop = document.getElementById('quickJumpPopover');
        function renderJumpList(q) {
          var kw = (q || '').trim().toLowerCase(), active = isEn() ? QUICK_JUMP_EN : QUICK_JUMP_INDEX;
          var list = active.filter(function (it, idx) {
            var z = QUICK_JUMP_INDEX[idx] || it, e = QUICK_JUMP_EN[idx] || it;
            return !kw || (z.title + ' ' + z.sub + ' ' + e.title + ' ' + e.sub).toLowerCase().indexOf(kw) !== -1;
          });
          jumpPop.innerHTML = list.length ? list.map(function (it) {
            return '<button type="button" class="quick-jump-item" data-jump-sec="' + it.sec + '"><span class="quick-jump-item-title">' + escapeHtml(it.title) + '</span><span class="quick-jump-item-sub">' + escapeHtml(it.sub) + '</span></button>';
          }).join('') : '<div style="padding:10px;font-size:0.78rem;color:var(--text-muted);">' + (isEn() ? 'No matching section' : '未匹配到对应章节') + '</div>';
          jumpPop.classList.add('open');
        }
        jumpInput.addEventListener('focus', function () { renderJumpList(jumpInput.value); });
        jumpInput.addEventListener('input', function () { renderJumpList(jumpInput.value); });
        jumpPop.addEventListener('click', function (e) {
          var b = e.target.closest('[data-jump-sec]');
          if (!b) return;
          var s = document.getElementById(b.getAttribute('data-jump-sec'));
          if (s) s.scrollIntoView({ behavior: 'smooth' });
          jumpPop.classList.remove('open');
        });
        document.addEventListener('click', function (e) { if (!e.target.closest('.quick-search-wrap')) jumpPop.classList.remove('open'); });
        document.addEventListener('keydown', function (e) {
          if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); jumpInput.focus(); }
          else if (e.key === 'Escape') { jumpPop.classList.remove('open'); closeMobileDrawer(); }
        });

        var ch1Btns = document.querySelectorAll('[data-ch1-view]');
        for (var c = 0; c < ch1Btns.length; c++) ch1Btns[c].addEventListener('click', function () {
          state.ch1View = this.getAttribute('data-ch1-view');
          document.getElementById('ch1TabA').classList.toggle('active', state.ch1View === 'viewA');
          document.getElementById('ch1TabB').classList.toggle('active', state.ch1View === 'viewB');
          syncCh1HeaderText(); drawCh1Chart();
        });

        var colBtns = document.querySelectorAll('[data-collapse-target]');
        for (var m = 0; m < colBtns.length; m++) colBtns[m].addEventListener('click', function () {
          var p = document.getElementById(this.getAttribute('data-collapse-target'));
          if (p) { p.classList.toggle('open'); syncCollapseButtonsText(); }
        });

        var pilCards = document.querySelectorAll('[data-pillar]');
        for (var p = 0; p < pilCards.length; p++) pilCards[p].addEventListener('click', function () {
          var idx = parseInt(this.getAttribute('data-pillar'), 10) || 0;
          state.activePillar = idx;
          for (var k = 0; k < pilCards.length; k++) pilCards[k].classList.toggle('active', k === idx);
          document.getElementById('pillarFocusNote').innerHTML = '<div>' + (isEn() ? PILLAR_NOTES_EN : PILLAR_NOTES)[idx] + '</div>';
          drawRadarChart();
        });

        var radPills = document.querySelectorAll('[data-radar-key]');
        for (var r = 0; r < radPills.length; r++) radPills[r].addEventListener('click', function () {
          var key = this.getAttribute('data-radar-key');
          state.radarSeries[key] = !state.radarSeries[key];
          if (!state.radarSeries.jobs && !state.radarSeries.gates && !state.radarSeries.bezos) state.radarSeries[key] = true;
          this.classList.toggle('muted', !state.radarSeries[key]);
          drawRadarChart();
        });

        document.getElementById('peerSearchInput').addEventListener('input', function () { state.peerQuery = this.value; renderPeerTable(); });
        var pfBtns = document.querySelectorAll('[data-peer-filter]');
        for (var pf = 0; pf < pfBtns.length; pf++) pfBtns[pf].addEventListener('click', function () {
          state.peerFilter = this.getAttribute('data-peer-filter');
          for (var x = 0; x < pfBtns.length; x++) pfBtns[x].classList.toggle('active', pfBtns[x] === this);
          renderPeerTable();
        });

        var pSlider = document.getElementById('simPrincipalSlider'), ySlider = document.getElementById('simYearsSlider'), cSlider = document.getElementById('simCagrSlider'), dToggle = document.getElementById('simDivToggle');
        pSlider.addEventListener('input', function () { state.sim.principal = parseFloat(this.value) || 10000; state.sim.preset = ''; updateSimulatorUI(); });
        ySlider.addEventListener('input', function () { state.sim.years = parseInt(this.value, 10) || 14; state.sim.preset = ''; updateSimulatorUI(); });
        cSlider.addEventListener('input', function () { state.sim.priceCagr = parseFloat(this.value) || 5; state.sim.preset = ''; updateSimulatorUI(); });
        dToggle.addEventListener('change', function () { state.sim.div = !!this.checked; updateSimulatorUI(); });

        var preBtns = document.querySelectorAll('[data-preset]');
        for (var pb = 0; pb < preBtns.length; pb++) preBtns[pb].addEventListener('click', function () {
          var cfg = PRESETS[this.getAttribute('data-preset')];
          if (!cfg) return;
          state.sim.principal = cfg.principal; state.sim.years = cfg.years; state.sim.priceCagr = cfg.priceCagr; state.sim.div = cfg.div; state.sim.preset = this.getAttribute('data-preset');
          pSlider.value = String(cfg.principal); ySlider.value = String(cfg.years); cSlider.value = String(cfg.priceCagr); dToggle.checked = cfg.div;
          updateSimulatorUI();
        });

        document.getElementById('checklistContainer').addEventListener('change', function (e) {
          var inp = e.target.closest('[data-check-input]');
          if (!inp) return;
          state.checks[parseInt(inp.getAttribute('data-check-input'), 10)] = !!inp.checked;
          safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
          renderChecklist();
        });
        document.getElementById('checkAllBtn').addEventListener('click', function () {
          state.checks = [true, true, true, true, true, true]; safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks)); renderChecklist();
          showToast(isEn() ? 'Checked all 6 Steve Jobs diagnostic criteria' : '已勾选全部 6 项乔布斯法则核查指标');
        });
        document.getElementById('resetCheckBtn').addEventListener('click', function () {
          state.checks = [true, true, true, false, false, false]; safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks)); renderChecklist();
          showToast(isEn() ? 'Checklist reset to default baseline (50%)' : '核查清单已恢复默认基准状态 (50%)');
        });

        function updateScrollProgress() {
          var docEl = document.documentElement, st = window.scrollY || docEl.scrollTop || 0, ms = Math.max(1, docEl.scrollHeight - window.innerHeight);
          document.getElementById('readingProgressBar').style.width = Math.min(100, Math.max(0, (st / ms) * 100)) + '%';
        }
        window.addEventListener('scroll', updateScrollProgress, { passive: true });
        updateScrollProgress();

        if ('IntersectionObserver' in window) {
          var obs = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
              if (en.isIntersecting) for (var i = 0; i < tocLinks.length; i++) tocLinks[i].classList.toggle('active', tocLinks[i].getAttribute('data-sec') === en.target.id);
            });
          }, { rootMargin: '-18% 0px -68% 0px', threshold: 0.02 });
          for (var s = 0; s <= 7; s++) { var sn = document.getElementById('sec-0' + s); if (sn) obs.observe(sn); }
        }

        wireCanvasTooltip('chartCh1'); wireCanvasTooltip('chartRadar'); wireCanvasTooltip('chartBars'); wireCanvasTooltip('chartEps'); wireCanvasTooltip('chartSim');
        var ch1S = document.querySelectorAll('[data-ch1-series]');
        for (var csIdx = 0; csIdx < ch1S.length; csIdx++) ch1S[csIdx].addEventListener('click', function () {
          var sk = this.getAttribute('data-ch1-series');
          state.ch1Series[sk] = !state.ch1Series[sk];
          if (!state.ch1Series.s1 && !state.ch1Series.s2) state.ch1Series[sk] = true;
          this.classList.toggle('muted', !state.ch1Series[sk]); drawCh1Chart();
        });
        var epsS = document.querySelectorAll('[data-eps-series]');
        for (var esIdx = 0; esIdx < epsS.length; esIdx++) epsS[esIdx].addEventListener('click', function () {
          var ek = this.getAttribute('data-eps-series');
          state.epsSeries[ek] = !state.epsSeries[ek];
          if (!state.epsSeries.cash && !state.epsSeries.ni) state.epsSeries[ek] = true;
          this.classList.toggle('muted', !state.epsSeries[ek]); drawEpsComboChart();
        });

        var resizeTimer = null;
        window.addEventListener('resize', function () { if (resizeTimer) clearTimeout(resizeTimer); resizeTimer = setTimeout(renderAllCharts, 60); });
      }

      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
      else init();
    })();
  