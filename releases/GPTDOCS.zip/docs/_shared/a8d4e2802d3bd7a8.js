
 (function () {
 'use strict';

 /* ======================================================================
 1. Grounded Datasets & State Model
 ====================================================================== */
 var STORAGE_THEME_KEY = 'mui_portal_theme_v4';
 var STORAGE_LANG_KEY = 'mui_portal_lang_v1';
 var STORAGE_CHECK_KEY = 'mui_gta6_checks_v1';

 var DOC_TITLE_ZH = '侠盗猎车手6 Grand Theft Auto VI (GTA 6) 产品架构与商业价值深度研报 | 数据中心';
 var DOC_TITLE_EN = 'Grand Theft Auto VI (GTA 6) Product Architecture & Commercial Moat Deep Dive | Research Hub';

 var I18N_RICH_LIST = [
 {
 key: 'gta_r00',
 match_zh: '侠盗猎车手6 Grand Theft Auto VI (GTA 6) 产品与商业价值深度研究报告：',
 zh: '侠盗猎车手6 Grand Theft Auto VI (GTA 6) 产品与商业价值深度研究报告：<span class="gradient-accent">RAGE第九世代工业奇点、99分神作壁垒与百亿美元生态飞轮</span>',
 en: 'Grand Theft Auto VI (GTA 6) Product &amp; Commercial Moat Deep Dive: <span class="gradient-accent">RAGE Gen-9 Singularity, 99-Metascore Craft &amp; Multi-Billion Ecosystem Flywheel</span>'
 },
 {
 key: 'gta_r01',
 match_zh: '阔别前作《GTA V》长达十三年',
 zh: '阔别前作《GTA V》长达十三年，为什么《侠盗猎车手6》（Grand Theft Auto VI）仅凭数字预售便打破全球电子游戏历史纪录，并在媒体解禁当日斩获 <strong>Metacritic 99 分</strong>（追平 1998 年《塞尔达传说：时之笛》并列历史最高分，亦是 <strong>21 世纪唯一一部 99 分游戏</strong>） <a class="cite-link" href="https://mlq.ai/news/gta-vi-scores-99-on-metacritic-a-day-before-launch-tying-the-sites-all-time-high-and-take-two-shares-rise-premarket/" target="_blank" rel="noopener noreferrer">MLQ / Metacritic ↗</a>？ 答案在于 Rockstar Games 拒绝生成式 AI 捷径与半成品抢发，将全球研发团队从《荒野大镖客：救赎2》时期的 2,441 人扩编近一倍至 <strong>12 大工作室共 4,711 名开发者</strong>，历时两轮延期精雕细琢，于 <strong>2026 年 11 月 19 日</strong>正式登陆 PlayStation 5 与 Xbox Series X|S <a class="cite-link" href="https://www.rockstargames.com/newswire/article/ak3ak31a49a221/grand-theft-auto-vi-is-now-set-to-launch-november-19-2026" target="_blank" rel="noopener noreferrer">Rockstar Newswire ↗</a>。 在产品端，游戏以现代佛罗里达为蓝本构建了面积约为《大镖客2》可玩区域 <strong>3 倍</strong>的<strong>雷奥奈达州（State of Leonida）</strong>六大生态区，塑造了系列首位正统女性主角<strong>露西娅·卡米诺斯（Lucia Caminos）</strong>与退伍军人<strong>杰森·杜瓦尔（Jason Duval）</strong>的“雌雄大盗”双主角叙事，并搭载超 <strong>600,000 组</strong>独立 NPC 动画与实时光追全局光照（RTGI） <a class="cite-link" href="https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">GTA VI Overview ↗</a>。 在商业端，自 2026 年 6 月 25 日开启预购（标准版 <strong>$79.99</strong> / 终极版 <strong>$99.99</strong>）以来，发售前数字预购量突破 <strong>1,900 万份</strong>、预售总收入超 <strong>$18 亿美元</strong>，直接支撑母公司 Take-Two 创纪录的 <strong>$80 亿–$82 亿美元</strong> FY2027 净预订额（Net Bookings）指引 <a class="cite-link" href="https://ir.take2games.com/static-files/a43ab8e3-c03a-4b7e-a6a8-f3cd2485e2df" target="_blank" rel="noopener noreferrer">TTWO 2Q27 Release ↗</a>。',
 en: 'Thirteen years after <em>GTA V</em>, how did <em>Grand Theft Auto VI</em> shatter global pre-order records before launch and debut at a <strong>99 Metascore on Metacritic</strong>—tying 1998\'s <em>The Legend of Zelda: Ocarina of Time</em> for the highest score ever recorded and standing as the <strong>only 21st-century game to reach 99</strong> <a class="cite-link" href="https://mlq.ai/news/gta-vi-scores-99-on-metacritic-a-day-before-launch-tying-the-sites-all-time-high-and-take-two-shares-rise-premarket/" target="_blank" rel="noopener noreferrer">MLQ / Metacritic ↗</a>? Rockstar Games rejected generative AI shortcuts and rushed shipping, nearly doubling its global development workforce from 2,441 (<em>Red Dead Redemption 2</em>) to <strong>4,711 developers across 12 studios</strong> through two deliberate polish delays before launching worldwide on <strong>November 19, 2026</strong> on PlayStation 5 and Xbox Series X|S <a class="cite-link" href="https://www.rockstargames.com/newswire/article/ak3ak31a49a221/grand-theft-auto-vi-is-now-set-to-launch-november-19-2026" target="_blank" rel="noopener noreferrer">Rockstar Newswire ↗</a>. On the product side, GTA VI builds the <strong>State of Leonida</strong>—spanning six seamless biomes roughly <strong>3x</strong> <em>RDR2</em>\'s playable area—around Bonnie-and-Clyde dual protagonists <strong>Lucia Caminos</strong> (the series\' first canon female lead) and <strong>Jason Duval</strong>, powered by <strong>600,000+</strong> handcrafted NPC animations and ray-traced global illumination (RTGI) <a class="cite-link" href="https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">GTA VI Overview ↗</a>. Commercially, since pre-orders opened June 25, 2026 (<strong>$79.99</strong> Standard / <strong>$99.99</strong> Ultimate Edition), digital pre-orders surpassed <strong>19 million copies</strong> and <strong>&gt;$1.8B</strong> in pre-launch revenue, anchoring Take-Two\'s reiterated <strong>$8.0B–$8.2B</strong> FY2027 Net Bookings outlook <a class="cite-link" href="https://ir.take2games.com/static-files/a43ab8e3-c03a-4b7e-a6a8-f3cd2485e2df" target="_blank" rel="noopener noreferrer">TTWO 2Q27 Release ↗</a>.'
 },
 {
 key: 'gta_r02',
 match_zh: '未发售即创造超 $18 亿美元数字预售收入',
 zh: '未发售即创造超 $18 亿美元数字预售收入，逾 2.3 倍刷新《赛博朋克2077》原 800 万份历史预购纪录 <a class="cite-link" href="https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">Wikipedia ↗</a>。',
 en: 'Generated &gt;$1.8B in pre-launch digital revenue alone, beating <em>Cyberpunk 2077</em>\'s prior 8M pre-order record by &gt;2.3x <a class="cite-link" href="https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">Wikipedia ↗</a>.'
 },
 {
 key: 'gta_r03',
 match_zh: '2026年11月18日解禁即斩获 99 分',
 zh: '2026年11月18日解禁即斩获 99 分，追平 1998 年《时之笛》并成为 21 世纪唯一 99 分殿堂级游戏 <a class="cite-link" href="https://www.forbes.com/sites/paultassi/2026/11/18/the-gta-6-metacritic-review-score-is-in-and-ties-an-all-time-record/" target="_blank" rel="noopener noreferrer">Forbes ↗</a>。',
 en: 'Debuted at 99 across 125+ critic reviews on Nov 18, 2026—tying 1998\'s <em>Ocarina of Time</em> as the sole 21st-century 99-rated title <a class="cite-link" href="https://www.forbes.com/sites/paultassi/2026/11/18/the-gta-6-metacritic-review-score-is-in-and-ties-an-all-time-record/" target="_blank" rel="noopener noreferrer">Forbes ↗</a>.'
 },
 {
 key: 'gta_r04',
 match_zh: '研发人数较《大镖客2》(2,441人) 翻倍',
 zh: '研发人数较《大镖客2》(2,441人) 翻倍，手工打造超 60 万组 NPC 独立动画（较 GTA V 跃升 10.9 倍） <a class="cite-link" href="https://www.bolderapps.com/blog-posts/gta-statistics" target="_blank" rel="noopener noreferrer">GTA Stats ↗</a>。',
 en: 'Headcount nearly doubled vs. <em>RDR2</em> (2,441), crafting 600,000+ unique NPC animations (10.9x <em>GTA V</em>\'s 55,000) <a class="cite-link" href="https://www.bolderapps.com/blog-posts/gta-statistics" target="_blank" rel="noopener noreferrer">GTA Stats ↗</a>.'
 },
 {
 key: 'gta_r05',
 match_zh: '标准版 $79.99 / 终极版 $99.99',
 zh: '标准版 $79.99 / 终极版 $99.99（多数预购选终极版）；PS5 预载容量达 210 GB、Xbox 达 225 GB <a class="cite-link" href="https://www.xbox.com/en-us/games/store/grand-theft-auto-vi/9nl3wwnzlzzn" target="_blank" rel="noopener noreferrer">Xbox Store ↗</a>。',
 en: '$79.99 Standard / $99.99 Ultimate Edition (majority of pre-orders); 210 GB PS5 / 225 GB Xbox install footprint <a class="cite-link" href="https://www.xbox.com/en-us/games/store/grand-theft-auto-vi/9nl3wwnzlzzn" target="_blank" rel="noopener noreferrer">Xbox Store ↗</a>.'
 },
 {
 key: 'gta_r06',
 match_zh: '2023 年专门在洛杉矶新建工作室负责 NPC',
 zh: '2023 年专门在洛杉矶新建工作室负责 NPC 研发与喜剧台词编写，每位路人按街区属性、目击记忆与玩家互动实时反应，彻底弃用程序化随机拼凑 <a class="cite-link" href="https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">Development &amp; Tech ↗</a>。',
 en: 'Founded Rockstar Los Angeles in 2023 specifically for handcrafted NPC behavior and open-world comedy writing—each citizen reacts to neighborhood context, player memory, and actions without procedural filler <a class="cite-link" href="https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">Development &amp; Tech ↗</a>.'
 },
 {
 key: 'gta_r07',
 match_zh: '引入体重增减、熬夜面部疲态',
 zh: '引入体重增减、熬夜面部疲态、双主武器随车携带与“犯罪档案（Criminal Profile）”声望追踪，但果断砍掉“安全屋买菜塞冰箱”等繁琐设定以保障游玩流畅度 <a class="cite-link" href="https://gta.fandom.com/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">Gameplay Mechanics ↗</a>。',
 en: 'Integrates dynamic weight shifts, visible sleep deprivation, vehicle-trunk 2-primary weapon loadouts, and Criminal Profile reputation—while cutting tedious safehouse grocery chores to preserve pacing <a class="cite-link" href="https://gta.fandom.com/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">Gameplay Mechanics ↗</a>.'
 },
 {
 key: 'gta_r08',
 match_zh: '法国电子乐传奇 Justice 谱写 3 小时原创配乐',
 zh: '法国电子乐传奇 Justice 谱写 3 小时原创配乐，Bad Bunny、Lana Del Rey、Morgan Wallen 等巨星主持电台，游戏内手机首次支持下车随时收听播客与刷短视频 <a class="cite-link" href="https://www.rockstargames.com/VI" target="_blank" rel="noopener noreferrer">Rockstar VI ↗</a>。',
 en: 'Features a 3-hour original score by Justice, celebrity radio hosts (Bad Bunny, Lana Del Rey, Morgan Wallen), and on-foot smartphone podcasts plus Snapmatic short-form video <a class="cite-link" href="https://www.rockstargames.com/VI" target="_blank" rel="noopener noreferrer">Rockstar VI ↗</a>.'
 },
 {
 key: 'gta_r09',
 match_zh: '标准版 PS5 实机画面即预告品质：',
 zh: '<strong>标准版 PS5 实机画面即预告品质：</strong>Rockstar 官方确认第二支预告片与 2026 年 10 月上市预告片全部截取自基础款 PlayStation 5（非 PS5 Pro），主机端锁定 30 FPS 榨干 Zen 2 CPU 的高密度 AI 与光追渲染算力 <a class="cite-link" href="https://www.vice.com/en/article/gta-6-launch-trailer-jason-lucia-story-details/" target="_blank" rel="noopener noreferrer">VICE Tech Report ↗</a>。',
 en: '<strong>Base PS5 Captures Match Trailer Fidelity:</strong> Rockstar confirmed both Trailer 2 and the Oct 2026 Launch Trailer were captured on a standard PlayStation 5 (not PS5 Pro), targeting a locked 30 FPS to maximize Zen 2 NPC AI density and RTGI <a class="cite-link" href="https://www.vice.com/en/article/gta-6-launch-trailer-jason-lucia-story-details/" target="_blank" rel="noopener noreferrer">VICE Tech Report ↗</a>.'
 },
 {
 key: 'gta_r10',
 match_zh: '首次在没有联合创始人 Dan Houser',
 zh: '首次在没有联合创始人 Dan Houser（2020年离职）执笔下由 Rupert Humphries 等叙事核心操刀，借鉴《大镖客2》章节体结构与营地情感纽带，让玩家自由选择双人同行作案或分头探索雷奥奈达州 <a class="cite-link" href="https://blog.playstation.com/2026/11/18/grand-theft-auto-vi-launches-tomorrow-november-19/" target="_blank" rel="noopener noreferrer">PlayStation Blog ↗</a>。',
 en: 'Written under narrative VP Rupert Humphries (the first mainline entry after Dan Houser\'s 2020 departure), combining <em>RDR2</em>-style chapter storytelling and safehouse bonds with free-roam choice to act together or split up <a class="cite-link" href="https://blog.playstation.com/2026/11/18/grand-theft-auto-vi-launches-tomorrow-november-19/" target="_blank" rel="noopener noreferrer">PlayStation Blog ↗</a>.'
 },
 {
 key: 'gta_r11',
 match_zh: '面对高矮胖瘦各异的多样化市民模型',
 zh: '面对高矮胖瘦各异的多样化市民模型，工程团队研发了“实时动态骨骼动画重定向系统（On-the-Fly Animation Retargeting）”，在不成倍挤占主机内存的前提下消除不同身高角色互动错位 <a class="cite-link" href="https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">RAGE Tech ↗</a>。',
 en: 'To animate diverse body heights and builds within console RAM budgets, engineers built real-time on-the-fly animation retargeting across 600,000+ motion clips without visual misalignment <a class="cite-link" href="https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">RAGE Tech ↗</a>.'
 },
 {
 key: 'gta_r12',
 match_zh: '宣发跳出传统游戏圈层：2025 年 5 月第二支预告片',
 zh: '宣发跳出传统游戏圈层：2025 年 5 月第二支预告片创下 24 小时全平台 4.75 亿次观看纪录；2026 年 8 月携手 Netflix 全球首映加长实机演示，11 月更直接点亮迈阿密热火主场球馆顶棚并打造 NBA“罪恶都市之夜” <a class="cite-link" href="https://dotesports.com/gta/news/gta-6" target="_blank" rel="noopener noreferrer">Dot Esports ↗</a>。',
 en: 'Transcended gaming marketing: Trailer 2 hit a record 475M cross-platform views in 24h (May 2025), followed by a Netflix global gameplay premiere (Aug 2026) and an NBA Miami Heat "A Night in Vice City" court/jersey takeover on Nov 18 <a class="cite-link" href="https://dotesports.com/gta/news/gta-6" target="_blank" rel="noopener noreferrer">Dot Esports ↗</a>.'
 },
 {
 key: 'gta_r13',
 match_zh: '为杜绝偷跑泄密与二手盘分流',
 zh: '为杜绝偷跑泄密与二手盘分流，11 月 12 日上架的实体盒装版采用“无光盘数字兑换码”配合 11 月 10 日提前预载；同时早在 2023 年 8 月正式收购 FiveM/RedM 研发团队 Cfx.re，布局长线角色扮演 UGC 生态 <a class="cite-link" href="https://www.rockstargames.com/newswire/article/8971o8789584a4/roleplay-community-update" target="_blank" rel="noopener noreferrer">Cfx.re Official ↗</a>。',
 en: 'To prevent early disc leaks and used-game erosion, Nov 12 retail boxes shipped with digital codes ahead of Nov 10 pre-loading—while Rockstar\'s Aug 2023 acquisition of Cfx.re (FiveM/RedM) positions official roleplay UGC for the decade ahead <a class="cite-link" href="https://www.rockstargames.com/newswire/article/8971o8789584a4/roleplay-community-update" target="_blank" rel="noopener noreferrer">Cfx.re Official ↗</a>.'
 },
 {
 key: 'gta_r14',
 match_zh: '1. 首发即收回巨额沉没成本：',
 zh: '<strong>1. 首发即收回巨额沉没成本：</strong>市场传闻总预算逾 $10–$15 亿美元（Rockstar 否认超 $15 亿），而发售前仅数字预购流水已突破 $18 亿美元，上市首日即跨越盈亏平衡线。<br/> <strong>2. 提价顺畅且口碑零反噬：</strong>$79.99 标准版与 $99.99 终极版在无首发微交易策略配合下赢得 99 分媒体盛赞，成功上移 3A 旗舰定价天花板。<br/> <strong>3. 硬件换机潮与跨平台二次收割：</strong>拉动 PS5 Pro 与次世代主机硬件升级，未来 PC 版与第十世代主机复刻具备极高确定性。',
 en: '<strong>1. Instant Pre-Launch Payback:</strong> Even against rumored $1B+ production scale (Rockstar denied &gt;$1.5B), &gt;$1.8B in pre-launch digital pre-orders cleared break-even before Day 1.<br/> <strong>2. Frictionless $79.99/$99.99 Pricing Power:</strong> Pairing zero launch microtransactions with 99-Metascore quality lifted blended ASP without review backlash.<br/> <strong>3. Multi-Generation Double-Dip Runway:</strong> Catalyzes PS5 Pro upgrades today while reserving PC and Gen-10 console editions as high-margin catalysts.'
 },
 {
 key: 'gta_r15',
 match_zh: '1. 劳资关系与保密高压摩擦：',
 zh: '<strong>1. 劳资关系与保密高压摩擦：</strong>2024 年 4 月强制全员返岗办公及 2025 年 10 月因涉密讨论解雇 34 名员工引发英国工会（IWGB）争议，1,600 名英国员工工会投票于 2026 年 11 月 26 日截止。<br/> <strong>2. 主机端 30 FPS 锁帧与无光盘实体盒争议：</strong>为保光追与 AI 密度锁定 30 帧，且实体盒仅附数字下载码而无实体光盘，引发部分物理收藏玩家与零售商批评。<br/> <strong>3. PC 版与独立在线模式节奏未官宣：</strong>首发仅聚焦 PS5/Xbox 单机体验，后续多人在线模式接棒速度将决定 FY2028+ 经常性消费收入斜率。',
 en: '<strong>1. Labor &amp; Secrecy Friction:</strong> April 2024 return-to-office mandates and Oct 2025 dismissal of 34 staff over confidentiality triggered IWGB union disputes, with a 1,600-worker UK union vote closing Nov 26, 2026.<br/> <strong>2. 30 FPS Console Cap &amp; Code-in-Box Debate:</strong> Targeting 30 FPS on consoles and shipping physical boxes without discs drew pushback from frame-rate purists and physical-media retailers.<br/> <strong>3. Unannounced PC &amp; Online Cadence:</strong> Launch focuses purely on PS5/Xbox single-player; FY2028+ recurring bookings depend on online &amp; PC rollout timing.'
 },
 {
 key: 'gta_r16',
 match_zh: '2014 年 GTA V 发售后启动早期构思',
 zh: '2014 年 GTA V 发售后启动早期构思，2015 年起派团队赴迈阿密实地调研；因《荒野大镖客：救赎2》集结全球工作室全力攻坚而暂缓并行推进。2019 年底正式确立杰森与露西娅“雌雄大盗”双主角故事骨架，并着手消除过往加班文化（Crunch），推行加班带薪调休补偿机制 <a class="cite-link" href="https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">Production History ↗</a>。',
 en: 'Preliminary concepts began in 2014 with Miami field research starting in 2015, pausing parallel production so all studios could finish <em>RDR2</em>. By late 2019, Rockstar locked in the Jason &amp; Lucia Bonnie-and-Clyde outline and reformed studio crunch with paid time-off and overtime pay <a class="cite-link" href="https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">Production History ↗</a>.'
 },
 {
 key: 'gta_r17',
 match_zh: '2020 年进入主制作阶段',
 zh: '2020 年进入主制作阶段，2022 年抽调重制版与 Red Dead Online 资源全力保驾；面对 2022 年 9 月早期开发视频泄露事件，团队迅速稳住阵脚并于 2023 年 8 月收购 Cfx.re、同年 12 月发布首支预告片（两天破 1.01 亿播放）；2025 年 5 月发布第二支预告片斩获首日 4.75 亿全平台观看，同年 11 月宣布定档 2026 年 11 月 19 日以兑现终极打磨品质 <a class="cite-link" href="https://www.rockstargames.com/newswire/article/3928aaa9471o3a/grand-theft-auto-vi-watch-trailer-2-now" target="_blank" rel="noopener noreferrer">Trailer 2 Milestone ↗</a>。',
 en: 'Entered full production in 2020 and reallocated studio resources in 2022. Weathering the Sep 2022 dev-footage leak, Rockstar acquired Cfx.re (Aug 2023), dropped Trailer 1 (101M YouTube views in 48h, Dec 2023) and Trailer 2 (475M all-platform views in 24h, May 2025), and set the Nov 19, 2026 polish date <a class="cite-link" href="https://www.rockstargames.com/newswire/article/3928aaa9471o3a/grand-theft-auto-vi-watch-trailer-2-now" target="_blank" rel="noopener noreferrer">Trailer 2 Milestone ↗</a>.'
 },
 {
 key: 'gta_r18',
 match_zh: '2026 年 6 月 25 日开启预购引爆全球主机商店',
 zh: '2026 年 6 月 25 日开启预购引爆全球主机商店，8 月登陆 Netflix 首映深度实机，11 月 10 日开启 210GB+ 预载，11 月 18 日媒体解禁以 99 分追平历史最高纪录，并于 11 月 19 日正式面向全球 PS5 与 Xbox Series X|S 玩家解锁 <a class="cite-link" href="https://www.take2games.com/ir" target="_blank" rel="noopener noreferrer">Take-Two IR ↗</a>。',
 en: 'Pre-orders went live June 25, 2026 to record demand, followed by the Aug 27 Netflix extended gameplay premiere, Nov 10 pre-loading (210 GB+), Nov 18 Metacritic 99 embargo lift, and global console launch on Nov 19, 2026 <a class="cite-link" href="https://www.take2games.com/ir" target="_blank" rel="noopener noreferrer">Take-Two IR ↗</a>.'
 },
 {
 key: 'gta_r19',
 match_zh: '从原定 2025 秋季推迟至 2026 年 5 月 26 日',
 zh: '从原定 2025 秋季推迟至 2026 年 5 月 26 日、再定档 11 月 19 日，管理层宁可承受股价单日波动也绝不重蹈同行半成品翻车覆辙，最终换来 21 世纪唯一 Metacritic 99 分口碑 <a class="cite-link" href="https://www.aljazeera.com/news/2026/11/19/grand-theft-auto-vi-launches-to-rave-reviews-after-13-year-wait" target="_blank" rel="noopener noreferrer">Al Jazeera ↗</a>。',
 en: 'Shifting from Fall 2025 to May 26, 2026 and finally Nov 19, 2026, Rockstar absorbed short-term stock volatility rather than ship unfinished code—earning the century\'s sole 99 Metascore <a class="cite-link" href="https://www.aljazeera.com/news/2026/11/19/grand-theft-auto-vi-launches-to-rave-reviews-after-13-year-wait" target="_blank" rel="noopener noreferrer">Al Jazeera ↗</a>.'
 },
 {
 key: 'gta_r20',
 match_zh: '2015 年曾视第三方 RP 服务器为违规程序',
 zh: '2015 年曾视第三方 RP 服务器为违规程序，而在目睹 GTA RP 统治 Twitch 直播榜多年后，Rockstar 于 2023 年果断将 Cfx.re 纳入麾下，把外部社区创造力转化为官方长期生态引擎 <a class="cite-link" href="https://www.gamesindustry.biz/rockstar-acquires-roleplay-modding-team-cfxre" target="_blank" rel="noopener noreferrer">GamesIndustry ↗</a>。',
 en: 'Once banning FiveM creators in 2015, Rockstar pivoted after seeing RP dominate Twitch viewership—acquiring Cfx.re in Aug 2023 to bring creator-economy servers in-house <a class="cite-link" href="https://www.gamesindustry.biz/rockstar-acquires-roleplay-modding-team-cfxre" target="_blank" rel="noopener noreferrer">GamesIndustry ↗</a>.'
 },
 {
 key: 'gta_r21',
 match_zh: '打破行业对突破 $70 定价天花板的顾虑',
 zh: '打破行业对突破 $70 定价天花板的顾虑，凭扎实内容体量驱动绝大部分核心玩家直奔 $99.99 终极版，双双刷新 PlayStation Store 与 Microsoft Store 历史预购峰值 <a class="cite-link" href="https://www.benzinga.com/markets/prediction-markets/26/11/63248840/gta-6-preorders" target="_blank" rel="noopener noreferrer">Store Records ↗</a>。',
 en: 'Broke past the industry\'s $70 price ceiling with overwhelming content density, steering most early buyers into the $99.99 Ultimate Edition and setting all-time PlayStation and Microsoft Store pre-order records <a class="cite-link" href="https://www.benzinga.com/markets/prediction-markets/26/11/63248840/gta-6-preorders" target="_blank" rel="noopener noreferrer">Store Records ↗</a>.'
 }
 ];

 var I18N_TEXT_PAIRS = [
 ["数据中心", "Research Hub"],
 ["侠盗猎车手6 (GTA VI) 产品与商业深度研报", "Grand Theft Auto VI Product & Commercial Report"],
 ["2026.11.19 全球首发 · MC 99", "Nov 19, 2026 Launch · MC 99"],
 ["GTA 6 产品深度研报", "GTA VI Product Monograph"],
 ["雷奥奈达六大生态区 × RAGE 第九世代光追引擎 × 1,900万+ 预购与 Metacritic 99 分的超级娱乐奇点", "Leonida 6 Biomes × RAGE Gen-9 RTGI × 19M+ Pre-Orders & 99 Metascore Singularity"],
 ["全球正式发售日", "Global Launch"],
 ["发售前数字预购", "Digital Pre-Orders"],
 [">19M份 / >$1.8B", ">19M / >$1.8B"],
 ["Metacritic 媒体分", "Metacritic Score"],
 ["99 / 100 (世纪唯一)", "99 / 100 (Sole 21st C.)"],
 ["核心研究章节 (00 – 07)", "Report Chapters (00 – 07)"],
 ["执行摘要与首发核心指标", "Executive Summary & Launch KPIs"],
 ["雷奥奈达世界与RAGE引擎", "Leonida World & RAGE Gen-9"],
 ["四大产品支柱与口碑护城河", "4 Product Pillars & Moat Radar"],
 ["全球3A开放世界巨制对比", "Global AAA Blockbuster Matrix"],
 ["定价经济学与全周期变现测算", "Unit Economics & ROI Simulator"],
 ["十二年研发演进与关键战役", "12-Year Timeline & Key Battles"],
 ["超级文化IP护城河核查清单", "Mega-IP Moat Diagnostic Checklist"],
 ["数据来源与官方信源索引", "Primary Sources & Official Index"],
 ["阅读与导出工具", "Reading & Export Tools"],
 ["浅色外观", "Light"],
 ["深色外观", "Dark"],
 ["导出 HTML", "Export HTML"],
 ["打印 / PDF", "Print / PDF"],
 ["产业史定评：全球互动娱乐工业天花板与十年期超级文化基础设施", "Verdict: Pinnacle of Interactive Entertainment Engineering & Decade Cultural Tentpole"],
 ["研究横跨：立项与预研 (2014–2019) · 全面量产与两次打磨 (2020–2026) · 2026.11.19 全球首发", "Scope: Pre-Production (2014–19) · Full Build & Polish (2020–26) · Nov 19, 2026 Launch"],
 ["数据基准：2026-11-19 首发日实况", "Baseline: Nov 19, 2026 Launch Day"],
 ["CORE THESIS · 雷奥奈达六大生态区 × 4,711人纯手工打磨 × $79.99/$99.99双阶定价 × Cfx.re创作者经济期权", "CORE THESIS · Leonida 6 Biomes × 4,711 Handcrafted Devs × $79.99/$99.99 Tiers × Cfx.re Creator Optionality"],
 ["反工业快餐化的“手工极客壁垒”", "Anti-Formulaic Handcrafted Engineering Moat"],
 ["零生成式 AI 填充，专设 Rockstar 洛杉矶工作室手工雕琢高密度差异化市民生态，60 万+ 组实时比例重定向动画构筑竞品难以逾越的十年技术代差。", "Zero generative AI filler: Rockstar LA handcrafts diverse neighborhood NPCs with 600,000+ real-time retargeted animations, forging a decade-wide technical gap."],
 ["$79.99/$99.99 分层定价与零内购首发", "$79.99/$99.99 Tiered Pricing & Zero Launch MTX"],
 ["依托无可替代的 IP 号召力跃升至 $79.99 标准锚点，且多数预购玩家主动选择 $99.99 终极版，单机首发坚持零微交易以锁定 99 分神作口碑。", "Steps up to a $79.99 base price while steering most pre-orders to the $99.99 Ultimate Edition—paired with zero launch microtransactions to lock in a 99 Metascore."],
 ["跨世代买断制 + Cfx.re 创作者生态飞轮", "Multi-Gen Box Sales + Cfx.re Creator Flywheel"],
 ["承接前作 GTA V 近 2.35 亿份销量与超 $100 亿营收基本盘，提前收购 FiveM/RedM 母团队 Cfx.re，为后续在线模式与角色扮演（RP）UGC 经济埋下伏笔。", "Builds on GTA V's ~235M units and >$10B revenue base while integrating Cfx.re (FiveM/RedM) to power next-gen roleplay and creator-economy monetization."],
 ["发售前数字预购规模", "Pre-Launch Digital Pre-Orders"],
 ["影娱史最高预购", "All-Time Record"],
 [">19.0M 份", ">19.0M Units"],
 ["Metacritic 权威媒体均分", "Metacritic Critic Score"],
 ["125+ 评测解禁", "125+ Critic Reviews"],
 ["全球研发编制与动画库", "Global Studio Staff & Animations"],
 ["12 大工作室协同", "12 Global Studios"],
 ["4,711 人", "4,711 Devs"],
 ["双版本定价与安装体量", "Edition Pricing & Install Size"],
 ["一、雷奥奈达世界架构与 RAGE 引擎：4,711 名开发者如何重构开放世界物理边界？", "1. Leonida World Architecture & RAGE Gen-9 Engine: Redefining Open-World Physics with 4,711 Developers"],
 ["六大无缝地貌生态区（3倍大镖客2面积） × 雌雄大盗双主角系统 × 第九世代原生光追与实时动画重定向", "Six Seamless Biomes (~3x RDR2 Area) × Dual Protagonists × Gen-9 RTGI & On-the-Fly Animation Retargeting"],
 ["Zero Generative AI · 100% 手工雕琢", "Zero Generative AI · 100% Handcrafted"],
 ["State of Leonida 雷奥奈达州全域沙盒中枢（以现代佛罗里达为原型 · 面积约为 RDR2 可玩区域 3 倍）", "State of Leonida Open-World Sandbox Hub (Modern Florida Satire · ~3x RDR2 Playable Area)"],
 ["双主角核心驱动：Lucia Caminos（系列首位正统女主） × Jason Duval（退伍军人 · 动态关系与犯罪档案系统）", "Dual-Lead Core: Lucia Caminos (First Canon Female Lead) × Jason Duval (Ex-Army · Dynamic Relationship & Criminal Profile)"],
 ["URBAN CORE · 霓虹都会核心", "URBAN CORE · METROPOLIS"],
 ["Vice City 罪恶都市", "Vice City"],
 ["致敬当代迈阿密，50+ 街头艺术家定制涂鸦壁画，融合海滩酒店、夜店帝国与网红短视频讽刺生态。", "Modern Miami satire featuring 50+ commissioned street-art murals, oceanfront hotels, nightclub empires, and influencer culture."],
 ["TROPICAL ARCHIPELAGO · 群岛海域", "TROPICAL ARCHIPELAGO · KEYS"],
 ["Leonida Keys 雷奥奈达群岛", "Leonida Keys"],
 ["对应佛罗里达礁岛群，杰森故事起点与走私航道，支持水肺潜水、皮划艇与跨海高速追逐。", "Inspired by the Florida Keys—Jason's smuggling home turf supporting scuba diving, kayaking, and ocean chases."],
 ["WETLANDS · 沼泽湿地生态", "WETLANDS · EVERGLADES BIOME"],
 ["Grassrivers 大草河湿地", "Grassrivers"],
 ["还原大沼泽地红树林与鳄鱼栖息水域，气垫船穿梭其间，呈现局部热带暴雨与持久积水物理反馈。", "Untamed mangroves and gator-filled wetlands navigated by airboats with localized storms and persistent water physics."],
 ["INDUSTRIAL COAST · 工业港城", "INDUSTRIAL COAST · GRITTY PORT"],
 ["Port Gellhorn 盖尔霍恩港", "Port Gellhorn"],
 ["褪色度假海岸与地下经济交汇带，汽车旅馆、典当行与高风险街头劫案密集分布，考验警察识别系统。", "Forgotten coastal strip of motels, pawn shops, and high-stakes robberies testing the expanded police identification system."],
 ["HEARTLAND · 内陆工业心脏", "HEARTLAND · SUGAR BELT"],
 ["Ambrosia 安布罗西亚", "Ambrosia"],
 ["内陆糖业精炼厂与飞车党盘踞重镇，展现当代美国腹地蓝领社区与亚文化帮派冲突。", "Inland sugar-refinery hub and biker gang stronghold capturing contemporary American heartland tensions."],
 ["WILDERNESS · 北境高山林地", "WILDERNESS · NORTHERN PARK"],
 ["Mount Kalaga 卡拉加山国家公园", "Mount Kalaga National Park"],
 ["继承《大镖客2》自然荒野精髓，提供越野摩托、跳伞、狩猎垂钓及偏远生存主义据点探索。", "Carries forward RDR2's wilderness mastery with dirt-biking, skydiving, hunting, fishing, and off-grid mysticism."],
 ["RAGE Gen-9 实时光追与热带飓风物理底座（PS5 / Xbox Series X|S 原生构建）", "RAGE Gen-9 Real-Time RTGI & Tropical Hurricane Physics (Built Natively for PS5 / Xbox Series X|S)"],
 ["全场景光追全局光照（RTGI）、体积云局部雷暴/热带风暴模拟，PS5 Pro 额外独占 PSSR 超分与光追阴影。", "Full ray-traced global illumination (RTGI), localized volumetric storms/hurricanes, plus PS5 Pro PSSR upscaling & RT shadows."],
 ["Rockstar Los Angeles 专属 NPC 工坊 + 车载移动武器库与 Snapmatic 社交系统", "Rockstar LA Dedicated NPC Studio + Vehicle Trunk Loadouts & Snapmatic Social App"],
 ["超 600,000 组独立动画按身高体型实时重定向；沿用大镖客2“双主武器+双副武器”后备箱挂载与动态体型睡眠反馈。", "600,000+ animations retargeted dynamically across body heights; 2-primary + 2-sidearm trunk storage and dynamic physique/fatigue."],
 ["1. “无背景板路人”的手工市民社会", "1. Zero 'Background' NPCs: Handcrafted Citizenry"],
 ["2. 沉浸拟真与爽快易用性的克制平衡", "2. Calibrated Realism vs. Playability Balance"],
 ["3. 影游音一体的流行文化基础设施", "3. Music, Podcast & Pop-Culture Tentpole"],
 ["技术验证", "TECH VERIFIED"],
 ["视图A: 三代工业规模与动画跃迁", "View A: Studio Scale & Animations"],
 ["视图B: 预告片全球破圈播放纪录", "View B: Record Trailer Velocity"],
 ["“邦妮与克莱德”式双主角羁绊与章节叙事（Lucia & Jason）", "Bonnie & Clyde Dual-Protagonist Arc & Chapter Structure (Lucia & Jason)"],
 ["自由分合漫游", "Split / Co-Op Roam"],
 ["展开微观机制拆解", "Show Design Mechanics"],
 ["收起微观机制拆解", "Hide Design Mechanics"],
 ["角色各自拥有独立的“犯罪档案（Criminal Profile）”评级系统——不评判传统善恶，而是追踪作案专业度与是否滥用暴力，直接改变警方围捕策略、黑市人脉反应与两人之间的可选感情走向。", "Each lead carries an independent Criminal Profile tracking heist professionalism vs. reckless violence—dynamically altering police pursuit tactics, underworld reactions, and their optional romance arc."],
 ["实时骨骼比例重定向与局部热带飓风模拟（RAGE 9 引擎）", "Real-Time Animation Retargeting & Localized Hurricanes (RAGE Gen-9)"],
 ["600,000+ 动画组", "600,000+ Animations"],
 ["天气引擎在《大镖客2》体积云基础上实现“局部持续性气象”：玩家可目睹远方云团生成热带风暴与飓风，暴雨后屋檐与灯柱水流倾泻、路面形成真实反射积水并在特定光照下折射彩虹。", "Upgrades RDR2 volumetric clouds into localized tropical storms and hurricanes—leaving persistent reflective puddles, roof runoff, and physically accurate post-storm rainbows."],
 ["现实城市接管与跨界超级事件营销（Cultural Tentpole）", "Real-World Miami Takeover & Cultural Tentpole Marketing"],
 ["Trailer 2 首日 4.75亿", "475M 24h Views"],
 ["迈阿密戴德县主动向 Rockstar 提案城市联动：从斥资 $97.5 万点亮 Kaseya Center 屋顶巨幅灯牌、夜店 E11even 变身游戏内 Nine1Nine，到 11 月 21 日举办 Travis Scott、Cardi B、Justice 参演的线下音乐节，实现现实与虚拟双向复刻。", "Miami-Dade pitched Rockstar directly: from a $975k Kaseya Center rooftop sign and E11even club rebranding into Nine1Nine to a Nov 21 Mana Wynwood live festival featuring Travis Scott, Cardi B, and Justice."],
 ["防剧透数字码实体盒策略与 Cfx.re 创作者生态储备", "Anti-Leak Code-in-Box Retail & Cfx.re Creator Reserve"],
 ["FiveM 官方收编", "Cfx.re In-House"],
 ["在单机首发期坚持“零内购微交易”优先兑现 99 分口碑资产，待主机装机渗透成熟后，即可沿用 GTA V 三代主机复刻 + PC 高配光追版 + GTA+ 订阅与官方 RP 创作者分成梯次释放十年现金流。", "Prioritizes a zero-microtransaction single-player launch to cement 99-score goodwill before unlocking multi-year PC ports, GTA+ subscriptions, and official Cfx.re roleplay creator monetization."],
 ["二、四大产品核心支柱：为什么全球大厂砸下数亿美元仍造不出“GTA 竞品”？", "2. Four Core Product Pillars: Why Hundreds of Millions Still Cannot Replicate a 'GTA Competitor'"],
 ["点击左侧任一产品支柱卡片，联动高亮右侧开放世界五维竞争力雷达图与深度机制解读", "Click any pillar card on the left to highlight the corresponding axis on the 5-Axis Product Moat Radar"],
 ["护城河定性：垄断级 (Monopoly-Like · 4.8亿系列底盘 + RAGE引擎 + 99分信任资产)", "Moat Rating: Monopoly-Like (~480M Franchise Base + RAGE Engine + 99-Score Brand Trust)"],
 ["01 · 超高密度鲜活社会模拟（Living World Density）", "01 · Ultra-Dense Handcrafted Social Simulation"],
 ["3x RDR2 版图", "3x RDR2 Map"],
 ["从 2015 年起派驻迈阿密田野调查组访谈执法人员、夜店推手与街头艺人，将当代美国短视频网红文化、执法记录仪视角与多元地貌浓缩进无缝开放世界。", "Backed by Miami field research since 2015 with police, club promoters, and street artists—distilling 2020s social media, bodycam realism, and 6 distinct biomes into one living world."],
 ["02 · 自研引擎代差与算力极限压榨（RAGE Gen-9 Mastery）", "02 · Proprietary RAGE Gen-9 Engine Mastery"],
 ["RTGI + 骨骼重定向", "RTGI + Retargeting"],
 ["历经 2022 年 GTA V 次世代移植练手后原生定制 RAGE 第九世代管线，不仅兑现主机端实时光追全局光照，更为未来十年新项目沉淀复用工具链以缩短后续研发周期。", "Built natively for Gen-9 consoles after testing hardware limits on GTA V's 2022 port—delivering real-time RTGI while laying reusable RAGE tooling to shorten future studio cycles."],
 ["03 · “宁可跳票绝不妥协”的首发品控铁律（99-Score Polish）", "03 · Uncompromising Polish Discipline (99 Metascore)"],
 ["在全行业频现 3A 大作首发崩溃翻车的背景下，Rockstar 顶住资本市场短期波动压力两度推迟发售窗口打磨细节，最终以 125+ 媒体 99 分均分捍卫金字招牌。", "In an era of buggy AAA launches, Rockstar absorbed two release delays to polish animations, lighting, and AI—securing a historic 99 Metascore across 125+ reviews."],
 ["04 · 十年尺度跨平台与创作者经济飞轮（Decade Flywheel）", "04 · Decade-Long Multi-Platform & Creator Flywheel"],
 ["单作品生命周期横跨 10–13 年：首波收割 PS5/Xbox 高客单价买断收入，后续衔接 PC 端、下一代主机升级、在线服务更新及 FiveM 级创作者 UGC 生态。", "Engineered for a 10–13 year lifespan: front-loaded PS5/Xbox premium box sales followed by PC editions, next-gen console upgrades, GTA+, and Cfx.re RP creator ecosystems."],
 ["开放世界旗舰五维产品力对比雷达图（10分制机构评估）", "5-Axis Open-World Blockbuster Product Moat Radar (10-Point Scale)"],
 ["点击下方图例胶囊可单独开关对比曲线，悬停顶点查看精确评分明细", "Click legend pills below to toggle benchmark titles; hover vertices for exact scores"],
 ["GTA VI (2026 · MC 99 世代新标杆)", "GTA VI (2026 · MC 99 Gen-9 Benchmark)"],
 ["GTA V (2013 · 2.35亿销量长青王)", "GTA V (2013 · ~235M Evergreen Icon)"],
 ["赛博朋克 2077 (首发期→2.0修复参照)", "Cyberpunk 2077 (Launch -> 2.0 Recovery)"],
 ["三、全球现象级 3A 开放世界巨制横向对比：工业投入、口碑密度与长尾变现", "3. Global AAA Open-World Blockbuster Matrix: Production Scale, Critical Acclaim & Longevity"],
 ["支持按作品名、研发商（Rockstar / CDPR / Nintendo）、引擎或商业指标关键词实时检索与分类筛选", "Search or filter in real time by title, studio (Rockstar / CDPR / Nintendo), engine, or commercial record"],
 ["全部标杆大作", "All Blockbusters"],
 ["Rockstar 自研旗舰矩阵", "Rockstar Flagships"],
 ["外部顶级开放世界参照", "External AAA Benchmarks"],
 ["作品与研发工作室", "Title & Developer"],
 ["首发时间、平台与引擎", "Launch, Platforms & Engine"],
 ["研发投入规模与世界特征", "Production Scale & World"],
 ["首发定价与预售/开局爆发力", "ASP & Launch Velocity"],
 ["Metacritic 与累计销量", "Metascore & Lifetime Units"],
 ["相对 GTA 6 的代差与商业启示", "Comparative Takeaway vs. GTA VI"],
 ["GTA 6 媒体口碑高度、高客单价版本占比与主机平台份额拆解（0–100 标尺）", "GTA VI Critical Score, Ultimate Edition Mix & Console Share Breakdown (0–100 Scale)"],
 ["数据核验自 Metacritic（2026-11-18）、TechPowerUp 预购版本结构估算及 Alinea Analytics 主机平台销量监测", "Verified via Metacritic (Nov 18, 2026), TechPowerUp Ultimate Edition mix estimates, and Alinea Analytics platform data"],
 ["MC 99.0 · 终极版占比 ~77%", "MC 99.0 · ~77% Ultimate Mix"],
 ["绿色/蓝色：Metacritic 权威媒体评分对比 (虚线为 95 分殿堂神作线)", "Green / Blue: Metacritic Scores (dashed = 95 Must-Play Hall of Fame)"],
 ["紫色/琥珀色：$99.99 终极版预购估算占比与 PS5 主机生态份额", "Purple / Amber: Est. $99.99 Ultimate Mix & PS5 Ecosystem Share"],
 ["四、单品定价经济学与全生命周期变现推演：从 $18亿预售到十年百亿美元宇宙", "4. Unit Economics & Lifecycle Monetization Simulator: From $1.8B Pre-Sales to a Multi-Billion Universe"],
 ["拆解“高单价买断制首发回本 + 多平台梯次发售 + 在线服务与创作者经济高毛利复利”三级火箭模型", "Three-stage rocket: Premium upfront payback + Staggered PC/Gen-10 ports + High-margin Online & Creator UGC"],
 ["支撑 TTWO FY27 净预订额 $8.0B–$8.2B", "Anchors TTWO FY27 Bookings $8.0B–$8.2B"],
 ["未正式解锁即凭 >1,900 万份数字预购实现超 $18 亿美元流水，超越 GTA V 首三日 $10 亿纪录。", "Surpassed >$1.8B from >19M digital pre-orders before launch day—already beating GTA V's $1.0B 3-day launch record."],
 ["标准版较传统 $69.99 上移 $10（计入通胀仍具高性价比），终极版热销显著抬升混合客单价 ASP。", "Moves base price to $79.99 (still historically low adjusted for inflation) while strong $99.99 Ultimate uptake lifts ASP."],
 ["前作 GTA V 横跨三代主机与 PC 累计售出近 2.35 亿份、总收入超 $100 亿，验证超长尾变现曲线。", "GTA V sold ~235M units and >$10B across three console generations and PC—proving Rockstar's decade-long tail."],
 ["(预售)", "(Pre-Sales)"],
 ["~480M 份", "~480M Units"],
 ["截至 2026 年 11 月 GTA 全系列累计销量逼近 4.8 亿份，沉淀全球最庞大的开放世界付费用户池。", "Franchise lifetime sales approached 480M units by Nov 2026—forming gaming's deepest open-world user base."],
 ["现象级开放世界大作首发/预售爆发力对比：销量规模（百万份）vs Metacritic 评分", "Open-World Blockbuster Launch / Pre-Order Velocity (Million Units) vs. Metacritic Score"],
 ["柱状图（左轴）对比各作官方/权威统计的预售或首周窗口销量；折线（右轴）对比 Metacritic 权威媒体均分", "Bars (left axis): verified pre-order or opening-window unit sales (M); Line (right axis): Metacritic Metascore"],
 ["GTA VI 仅数字预购即超 1,900 万份", "GTA VI Digital Pre-Orders >19.0M Alone"],
 ["■ 左轴：首发窗口 / 预购销量 (百万份)", "■ Left Axis: Launch / Pre-Order Units (M)"],
 ["● 右轴：Metacritic 媒体综合评分 (分)", "● Right Axis: Metacritic Score (pts)"],
 ["首发窗口 / 发售前预购销量 (左轴 · M份)", "Launch / Pre-Order Units (Left · M)"],
 ["Metacritic 媒体综合均分 (右轴 · 分)", "Metacritic Score (Right · pts)"],
 ["--- 95.0 分殿堂级神作红线", "--- 95.0 Hall-of-Fame Threshold"],
 ["GTA 6 全生命周期总流水与研发 ROI 交互测算器", "GTA VI Lifecycle Gross Bookings & ROI Simulator"],
 ["开启 PC 版移植 + Cfx.re 创作者生态乘数 (+22% 留存转化)", "Enable PC Port + Cfx.re Creator Ecosystem Multiplier (+22% Retention Lift)"],
 ["模拟后续登陆 PC Steam 与官方角色扮演 UGC 服务器带来的二次销量与长尾活跃加成", "Simulates secondary PC/Steam double-dip demand and official FiveM-style roleplay server retention lift"],
 ["① 主机世代稳健防守情景 (对标大镖客2加强版)", "① Conservative Console-Led Case (RDR2+ Scale)"],
 ["1.10亿份 · 5年", "110M · 5 Yrs"],
 ["② 双端+次世代在线核心基准情景 (Base Case)", "② Multi-Platform + Online 2.0 Base Case"],
 ["1.75亿份 · 8年", "175M · 8 Yrs"],
 ["③ Cfx.re 创作者经济十年超级周期 (Bull Case)", "③ Cfx.re Creator Supercycle Bull Case"],
 ["2.40亿份 · 10年", "240M · 10 Yrs"],
 ["全周期累计买断制销量 (Million Units)", "Cumulative Full-Game Units Sold (M)"],
 ["全周期混合平均客单价 Blended ASP (USD)", "Lifecycle Blended ASP (USD / Copy)"],
 ["在线模式与 GTA+ 年均单活跃用户变现 (USD/年)", "Online & GTA+ Annual Live ARPU (USD/yr)"],
 ["运营测算周期 (Years)", "Lifecycle Horizon (Years)"],
 ["预估全周期累计总流水 (Total Bookings)", "Projected Cumulative Gross Bookings"],
 ["相对 $1.5B 研发宣发成本基准 ROI", "ROI Multiple vs. $1.5B Cost Benchmark"],
 ["买断制本体累计销售收入 (Full-Game)", "Cumulative Full-Game Box Revenue"],
 ["━ 买断本体 + 在线服务/UGC 累计总流水", "━ Full-Game + Online/UGC Cumulative Bookings"],
 ["- - 仅单机买断制本体累计收入基准", "- - Full-Game Box Revenue Only"],
 ["悬停曲线可逐年对比“单机买断制收入”与叠加“在线模式 + GTA+ 订阅 + Cfx.re 生态”后的累计总流水剪刀差。", "Hover along the trajectory to inspect year-by-year full-game sales vs. total cumulative bookings with Online & Cfx.re UGC."],
 ["核心商业优势与正向确定性定评", "Enduring Commercial Strengths & Catalysts"],
 ["客观风险、争议张力与跟踪要点", "Key Risks, Controversies & Watchpoints"],
 ["五、十二年磨一剑演进史与四大标志性节点复盘：从 Project Americas 到全球发售", "5. Twelve-Year Production Evolution & Key Case Studies: From Project Americas to Global Launch"],
 ["历经核心主笔更迭、黑客泄露危机与两度延期打磨的超级工程管理样本", "Managing writer transition, cyber-leak crisis, and two polish delays across 12 global studios"],
 ["2014 概念预研 → 2026.11.19 全球解锁", "2014 Concept -> Nov 19, 2026 Launch"],
 ["第一幕 · 田野采风与代号立项 (2014–2019) —— 让路大镖客2与叙事定调", "Act I · Miami Fieldwork & Project Americas (2014–2019) — Prioritizing RDR2 & Story Core"],
 ["代号 Project Americas", "Code: Project Americas"],
 ["第二幕 · 全面量产、危机韧性与破圈首秀 (2020–2025) —— 顶住泄密冲击创纪录", "Act II · Full Production, Leak Resilience & Record Trailers (2020–2025)"],
 ["员工 2,441 → 4,711人", "Staff 2,441 -> 4,711"],
 ["第三幕 · 现象级预售与 99 分登顶发售 (2026.06–2026.11.19) —— 加冕世代之王", "Act III · Record Pre-Orders & 99-Metascore Launch (Jun–Nov 19, 2026)"],
 [">$1.8B 预售 · MC 99", ">$1.8B Pre-Sales · MC 99"],
 ["战役 01 · 2022–2025", "Case 01 · 2022–2025"],
 ["信息安全堡垒化", "OpSec Lockdown"],
 ["黑客泄露反击战与爱丁堡研发中心防窥升级", "Cyber-Leak Recovery & Edinburgh Anti-Drone Lockdown"],
 ["经历 2022 年“teapotuberhacker”泄露后，Rockstar North 爱丁堡总部窗户加装防无人机偷拍隐私膜、全面封禁个人设备接入内网与外接 U 盘，确保核心剧情与地图惊喜在发售前完好无损。", "After the 2022 hacker breach, Rockstar North installed anti-drone window privacy film in Edinburgh, blocked personal devices from studio networks, and banned USB drives to protect story surprises."],
 ["战役 02 · 2025.05–11", "Case 02 · May–Nov 2025"],
 ["长期主义定力", "Quality Over Deadlines"],
 ["两次主动推迟发售：用半年时间换取 99 分神作护城河", "Two Deliberate Polish Delays: Trading Months for a 99 Metascore"],
 ["战役 03 · 2023.08", "Case 03 · Aug 2023"],
 ["化野生模组为护城河", "UGC Co-Optation"],
 ["从封禁对抗到全资收编：Cfx.re (FiveM) 的战略转身", "From Banning Modders to Acquiring Cfx.re (FiveM / RedM)"],
 ["战役 04 · 2026.06–11", "Case 04 · Jun–Nov 2026"],
 ["客单价跃迁验证", "ASP Expansion"],
 ["$79.99 / $99.99 定价破冰与超 $18 亿预售大捷", "Breaking the $70 Ceiling: $79.99/$99.99 Pricing & >$1.8B Pre-Orders"],
 ["铁律一：", "Law 01:"],
 ["在注意力极度稀缺的时代，“十年磨一剑的绝对品质垄断”比“年货式流水线铺量”拥有更高定价权与更低宣发获客成本。", "In an attention-scarce era, once-a-decade quality monopoly commands far stronger pricing power and organic virality than annualized sequels."],
 ["铁律二：", "Law 02:"],
 ["顶尖开放世界的护城河不在地图平方公里数，而在手工打磨的“单位面积叙事交互密度（60万+动画组）”与自研引擎工具链。", "An open-world moat is defined not by empty square kilometers, but by handcrafted interaction density (600k+ animations) and proprietary engine tooling."],
 ["铁律三：", "Law 03:"],
 ["“零内购神作级单机买断引流 + 在线服务与创作者 UGC 社区长尾复利”是超级娱乐 IP 穿越两代硬件周期的最优商业范式。", "Zero-MTX prestige single-player acquisition paired with multi-year online and creator-economy UGC is the ultimate cross-generation IP flywheel."],
 ["六、“GTA 6 现象级法则”超级娱乐 IP 与产品护城河交互式核查清单", "6. Interactive 'GTA VI Blockbuster Laws' Mega-IP Moat Diagnostic Checklist"],
 ["用于评估任何旗舰级游戏或数字内容资产是否具备跨周期垄断商业潜力（勾选状态自动保存在本地）", "Evaluate whether a flagship game or entertainment IP possesses decade-spanning monopoly economics (saved locally)"],
 ["全部勾选", "Check All"],
 ["重置清单", "Reset"],
 ["数据来源与一手官方公告/评测核验索引（Rockstar Games · Take-Two IR · Industry Benchmarks）", "Primary Official Announcements & Benchmark Verification Index (Rockstar · Take-Two IR · Metacritic)"],
 ["本报告所有产品规格、发售时间线、版本定价、研发编制、预告片播放量、Metacritic 媒体评分及同业销量数据均严格核验自 Rockstar Games 官方新闻专线、Take-Two Interactive 投资者关系公告、微软/索尼官方商店及权威行业数据库，仅供产品战略与商业模式研究参考，不构成任何证券投资建议。", "All product specs, release milestones, edition prices, studio headcount, trailer view records, Metacritic scores, and peer unit figures are verified against Rockstar Games Newswire, Take-Two IR filings, official console storefronts, and authoritative trackers. For product and business research only; not investment advice."]
 ];

 var I18N_ATTR_PAIRS = [
 ["展开/收起章节目录", "Toggle Chapter Sidebar"],
 ["切换目录侧边栏", "Toggle Chapter Sidebar"],
 ["面包屑导航", "Breadcrumb Navigation"],
 ["检索章节或指标…", "Jump to chapter or KPI…"],
 ["快速跳转章节或指标", "Quick jump to chapter or metric"],
 ["研究章节目录与站点导航", "Report Chapters & Site Navigation"],
 ["站点导航与章节目录", "Site Links & Table of Contents"],
 ["外观模式切换", "Appearance Theme Switch"],
 ["阅读与导出工具", "Reading & Export Tools"],
 ["导出独立 HTML 文件 (.html)", "Export Standalone HTML File (.html)"],
 ["打印或导出 PDF 研报", "Print or Save Report as PDF"],
 ["第一章图表视图切换", "Chapter 01 Chart View Switch"],
 ["搜索作品、工作室 (Rockstar / CDPR / 任天堂)、评分或销量纪录…", "Search title, studio (Rockstar / CDPR / Nintendo), score or sales…"],
 ["筛选对比作品", "Filter benchmark titles"],
 ["标杆作品分类筛选", "Benchmark category filter"],
 ["全球现象级3A开放世界巨制横向对比表", "Global AAA Open-World Blockbuster Comparison Matrix"],
 ["商业变现情景预设", "Commercial Monetization Presets"],
 ["核查完成度进度条", "Checklist Completion Progress"]
 ];

 var PILLAR_NOTES = [
 '<strong>当前选中支柱解读（01 超高密度鲜活社会模拟）：</strong>不同于同类开放世界在城市外围出现“空旷荒漠感”，雷奥奈达将卡拉加山、大草河湿地与盖尔霍恩港填充了独立叙事事件与差异化街区 NPC 行为逻辑 <a class="cite-link" href="https://www.redbull.com/us-en/gta-6-locations-ranked" target="_blank" rel="noopener noreferrer">Leonida Regions ↗</a>。',
 '<strong>当前选中支柱解读（02 自研引擎代差与算力极限压榨）：</strong>研发主管 Phil Hooker 与艺术总监 Aaron Garbut 指出，为 GTA VI 打造的 RAGE 第九世代底层技术将直接复用于后续作品，显著缩短未来大作间隔周期 <a class="cite-link" href="https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">RAGE Platform ↗</a>。',
 '<strong>当前选中支柱解读（03 “宁可跳票绝不妥协”的品控铁律）：</strong>媒体解禁日 125+ 篇权威评测打出 99 分均分，成为自 1998 年《时之笛》后 28 年来首部触及 99 分的电子游戏，彻底引爆首周口碑裂变 <a class="cite-link" href="https://mlq.ai/news/gta-vi-scores-99-on-metacritic-a-day-before-launch-tying-the-sites-all-time-high-and-take-two-shares-rise-premarket/" target="_blank" rel="noopener noreferrer">Metacritic 99 ↗</a>。',
 '<strong>当前选中支柱解读（04 十年尺度跨平台与创作者经济飞轮）：</strong>前作 GTA V 在发售 13 年后的 2026 年单季仍能售出数百万份并保持 1,600 万月活，Cfx.re 团队并入后将为 GTA VI 注入官方角色扮演服务器生态 <a class="cite-link" href="https://www.rockstargames.com/newswire/article/8971o8789584a4/roleplay-community-update" target="_blank" rel="noopener noreferrer">Cfx.re Update ↗</a>。'
 ];

 var PILLAR_NOTES_EN = [
 '<strong>Selected Pillar (01 · Ultra-Dense Social Simulation):</strong> Unlike open worlds with barren countryside, Leonida packs Mount Kalaga, Grassrivers, and Port Gellhorn with bespoke random encounters and district-specific handcrafted NPC personalities <a class="cite-link" href="https://www.redbull.com/us-en/gta-6-locations-ranked" target="_blank" rel="noopener noreferrer">Leonida Regions ↗</a>.',
 '<strong>Selected Pillar (02 · Proprietary RAGE Gen-9 Mastery):</strong> Development heads Phil Hooker and Aaron Garbut noted that GTA VI\'s RAGE Gen-9 rendering and animation retargeting foundation is designed to shorten production timelines on future Rockstar titles <a class="cite-link" href="https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI" target="_blank" rel="noopener noreferrer">RAGE Platform ↗</a>.',
 '<strong>Selected Pillar (03 · Uncompromising Polish Discipline):</strong> Debuting at 99 across 125+ critic reviews on Nov 18, 2026, GTA VI became the first game in 28 years since 1998\'s <em>Ocarina of Time</em> to reach a 99 Metascore <a class="cite-link" href="https://mlq.ai/news/gta-vi-scores-99-on-metacritic-a-day-before-launch-tying-the-sites-all-time-high-and-take-two-shares-rise-premarket/" target="_blank" rel="noopener noreferrer">Metacritic 99 ↗</a>.',
 '<strong>Selected Pillar (04 · Decade Multi-Platform &amp; Creator Flywheel):</strong> Even 13 years post-launch, GTA V still logged 16M monthly active users in Nov 2026—while in-house Cfx.re positions GTA VI to capture official RP creator economics <a class="cite-link" href="https://www.rockstargames.com/newswire/article/8971o8789584a4/roleplay-community-update" target="_blank" rel="noopener noreferrer">Cfx.re Update ↗</a>.'
 ];

 var PEER_ROWS = [
 {
 category: 'rockstar',
 benchmark: true,
 company: '研究标的：侠盗猎车手6 (GTA VI)',
 leader: 'Rockstar Games (Rob Nelson / Sam Houser)',
 positioning: '2026-11-19 · PS5 / Xbox Series X|S · 自研 RAGE 第九世代引擎',
 culture: '12大工作室 4,711人 · 雷奥奈达六大区 (~3x RDR2) · 60万+ NPC动画',
 headcount: '$79.99 标准 / $99.99 终极 · 数字预购 >1,900万份 (>$18亿)',
 margins: 'Metacritic 99分 (世纪唯一) · 支撑 TTWO FY27 $80–$82亿预订额',
 verdict: '世代绝对统治者：未发售仅数字预售即破 $18 亿美元，99 分神作口碑叠加后续 PC 与 Cfx.re 在线生态，确立未来十年超级现金牛地位。',
 sourceLabel: 'Wikipedia / TTWO IR',
 sourceUrl: 'https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI'
 },
 {
 category: 'rockstar',
 benchmark: false,
 company: '侠盗猎车手5 (GTA V & GTA Online)',
 leader: 'Rockstar North (1,000+ 跨工作室团队)',
 positioning: '2013-09-17 · 横跨 PS3/PS4/PS5 三代主机与 PC · RAGE 引擎',
 culture: '估算研发宣发总预算 ~$2.65亿 · 洛圣都三主角叙事 · 5.5万组动画',
 headcount: '$59.99 首发 · 首24h 售 1,121万份 ($8.16亿) / 首3日破 $10亿',
 margins: 'Metacritic 97分 · 累计近 2.35亿份 · 总营收超 $100亿美元',
 verdict: '商业模式验证原型：证明“顶级单机买断 + 跨三代主机升级 + 在线持续更新”可跑出超 $100 亿美元营收，为 GTA 6 提供庞大存量转化池。',
 sourceLabel: 'GTA V Records',
 sourceUrl: 'https://en.wikipedia.org/wiki/Grand_Theft_Auto_V'
 },
 {
 category: 'rockstar',
 benchmark: false,
 company: '荒野大镖客：救赎2 (Red Dead Redemption 2)',
 leader: 'Rockstar Studios 全球联合研发',
 positioning: '2018-10-26 · PS4 / Xbox One / PC · RAGE 第八世代引擎',
 culture: '2,441名员工 · 极致西部自然生态与章节叙事 · 30万组 NPC动画',
 headcount: '$59.99 首发 · 首周末3日狂揽 $7.25亿 / 首13天出货 1,700万份',
 margins: 'Metacritic 97分 · 累计突破 8,900万份 (截至 2026.09)',
 verdict: '技术与叙事跳板：GTA 6 的章节情感结构、双主武器随车载具挂载及体积云天气系统均直接继承并升级自大镖客2，且现代题材受众更广。',
 sourceLabel: 'Tbreak Q2 FY27',
 sourceUrl: 'https://tbreak.com/red-dead-redemption-2-sales-89-million/'
 },
 {
 category: 'external',
 benchmark: false,
 company: '赛博朋克 2077 (Cyberpunk 2077)',
 leader: 'CD Projekt Red (波兰华沙总部)',
 positioning: '2020-12-10 · PC / 主机跨世代 · REDengine 4',
 culture: '总成本 $4.36亿–$4.40亿 (含宣发、2.0重构与《往日之影》DLC)',
 headcount: '$59.99 首发 · 发售前预购 800万份 (GTA 6 前的历史预购纪录)',
 margins: 'PC首发 MC 86分 (PS4曾下架修复) · 累计突破 4,000万份 (2026.07)',
 verdict: '抢发翻车与长线救赎镜鉴：印证超大型开放世界一旦妥协品控抢发将遭受严重商誉折损，反衬 Rockstar 两次延期死磕 99 分的战略正确性。',
 sourceLabel: 'CP2077 Benchmark',
 sourceUrl: 'https://en.wikipedia.org/wiki/Cyberpunk_2077'
 },
 {
 category: 'external',
 benchmark: false,
 company: '塞尔达传说：王国之泪 (Tears of the Kingdom)',
 leader: '任天堂企划制作本部 (Nintendo EPD)',
 positioning: '2023-05-12 (Switch) / 2025-06-05 (Switch 2 强化版)',
 culture: '6年打磨 · 空岛/地表/地底三层物理化学涌现式交互设计',
 headcount: '$69.99 (美版首次破冰 $70) · 首3日全球销量破 1,000万份',
 margins: 'Metacritic 96分 · 单一硬件生态第一方护城河标杆',
 verdict: '高定价破冰先行者：任天堂以 $69.99 验证顶尖品质提价零阻力，而 GTA 6 凭借跨平台装机量与写实都市社交属性具备数倍级商业体量上限。',
 sourceLabel: 'Nintendo / TotK',
 sourceUrl: 'https://en.wikipedia.org/wiki/The_Legend_of_Zelda:_Tears_of_the_Kingdom'
 }
 ];

 var PEER_ROWS_EN = [
 {
 category: 'rockstar',
 benchmark: true,
 company: 'Subject: Grand Theft Auto VI (GTA 6)',
 leader: 'Rockstar Games (Rob Nelson / Sam Houser)',
 positioning: 'Nov 19, 2026 · PS5 / Xbox Series X|S · RAGE Gen-9 Engine',
 culture: '4,711 staff (12 studios) · 6 Leonida biomes (~3x RDR2) · 600k+ NPC anims',
 headcount: '$79.99 Std / $99.99 Ult · >19M digital pre-orders (>$1.8B pre-launch)',
 margins: 'Metacritic 99 (Sole 21st-C. 99) · Anchors TTWO FY27 $8.0B–$8.2B',
 verdict: 'Generational category king: >$1.8B pre-launch revenue alone, 99-score critical moat, and multi-year PC + Cfx.re live-service runway.',
 sourceLabel: 'Wikipedia / TTWO IR',
 sourceUrl: 'https://en.wikipedia.org/wiki/Grand_Theft_Auto_VI'
 },
 {
 category: 'rockstar',
 benchmark: false,
 company: 'Grand Theft Auto V & GTA Online',
 leader: 'Rockstar North (1,000+ cross-studio devs)',
 positioning: 'Sep 17, 2013 · PS3 / PS4 / PS5 & PC · RAGE Engine',
 culture: '~$265M est. dev+mktg budget · 3-protagonist Los Santos · 55k NPC anims',
 headcount: '$59.99 launch · 11.21M Day-1 ($815.7M) / $1.0B in 3 days',
 margins: 'Metacritic 97 · ~235M lifetime units · >$10B total revenue',
 verdict: 'Proven blueprint: validated three-generation console re-releases + live-service compounding, creating a massive active user funnel for GTA VI.',
 sourceLabel: 'GTA V Records',
 sourceUrl: 'https://en.wikipedia.org/wiki/Grand_Theft_Auto_V'
 },
 {
 category: 'rockstar',
 benchmark: false,
 company: 'Red Dead Redemption 2 (RDR2)',
 leader: 'Rockstar Studios Global Collective',
 positioning: 'Oct 26, 2018 · PS4 / Xbox One / PC · RAGE Gen-8 Engine',
 culture: '2,441 Rockstar staff · Deep frontier ecology & chapters · 300k NPC anims',
 headcount: '$59.99 launch · $725M 3-day opening weekend / 17M in 13 days',
 margins: 'Metacritic 97 · 89M+ lifetime units (as of Sep 30, 2026)',
 verdict: 'Technical & narrative stepping stone: directly informed GTA VI\'s chapter structure, trunk weapon loadout, and volumetric weather physics.',
 sourceLabel: 'Tbreak Q2 FY27',
 sourceUrl: 'https://tbreak.com/red-dead-redemption-2-sales-89-million/'
 },
 {
 category: 'external',
 benchmark: false,
 company: 'Cyberpunk 2077 (CD Projekt Red)',
 leader: 'CD Projekt Red (Warsaw)',
 positioning: 'Dec 10, 2020 · PC / Cross-Gen Consoles · REDengine 4',
 culture: '$436M–$440M total dev, marketing, Patch 2.0 & Phantom Liberty cost',
 headcount: '$59.99 launch · 8.0M pre-orders (prior all-time pre-order record)',
 margins: 'PC Launch MC 86 (PS4 delisted) · 40M+ lifetime copies (Jul 2026)',
 verdict: 'Cautionary launch contrast: proves shipping an unpolished mega-open-world severely damages launch equity—validating Rockstar\'s two polish delays.',
 sourceLabel: 'CP2077 Benchmark',
 sourceUrl: 'https://en.wikipedia.org/wiki/Cyberpunk_2077'
 },
 {
 category: 'external',
 benchmark: false,
 company: 'Zelda: Tears of the Kingdom',
 leader: 'Nintendo EPD',
 positioning: 'May 12, 2023 (Switch) / Jun 5, 2025 (Switch 2 Edition)',
 culture: '6-year polish cycle · 3-layer sky/surface/depths physics sandbox',
 headcount: '$69.99 (Nintendo\'s first $70 flagship) · >10M sold in 3 days',
 margins: 'Metacritic 96 · First-party single-platform benchmark',
 verdict: 'Premium-price trailblazer: proved 96+ quality absorbs higher ASP effortlessly, while GTA VI scales across multi-console + live-service economics.',
 sourceLabel: 'Nintendo / TotK',
 sourceUrl: 'https://en.wikipedia.org/wiki/The_Legend_of_Zelda:_Tears_of_the_Kingdom'
 }
 ];

 var CHECKLIST_ITEMS = [
 {
 tag: 'MC 99 · 两次打磨',
 title: '1. “口碑零妥协”品控测试：是否宁可推迟档期也绝不交付半成品？',
 desc: '面对季度财报压力，工作室是否具备推迟发售直至帧率、光追与任务脚本达到 97–99 分殿堂水准的绝对话语权？'
 },
 {
 tag: '60万+ 手工动画',
 title: '2. 单位面积交互密度测试：开放世界是否摆脱“公式化清据点”疲劳？',
 desc: '非主线漫游区域是否具备手工打磨的差异化街区 NPC 反应、动态天气反馈与高自由度突发事件，而非空旷贴图？'
 },
 {
 tag: '$79.99 / $99.99',
 title: '3. 超额定价权与版本升级测试：提价能否在不伤口碑下提升混合 ASP？',
 desc: '核心受众是否心甘情愿为 $79.99 标准版及 $99.99 终极版买单（且单机首发无恶性内购逼氪），实现预售即覆盖成本？'
 },
 {
 tag: '4.75亿首日播放',
 title: '4. 零买量自然破圈力测试：单支预告片是否具备全球流行文化事件属性？',
 desc: '无需依赖高昂渠道买量分成，仅凭官方社媒与跨界文化联动（如 Netflix、NBA 热火）即可席卷数亿级自然流量？'
 },
 {
 tag: 'RAGE 自研工具链',
 title: '5. 底层自研引擎复用测试：巨额研发投入能否沉淀为跨项目技术资产？',
 desc: '自研引擎的光追全局光照、实时骨骼动画重定向与 AI 管线能否复用于后续作品并构建外部无法采购的技术壁垒？'
 },
 {
 tag: 'GTA+ & Cfx.re',
 title: '6. 十年跨世代与 UGC 飞轮测试：买断通关后是否有长尾在线与创作者生态？',
 desc: '是否具备跨 PC / 下一代主机二次销售潜力，并通过收编 FiveM (Cfx.re) 级角色扮演社区将玩家创造力转化为持续现金流？'
 }
 ];

 var CHECKLIST_ITEMS_EN = [
 {
 tag: 'MC 99 · Polish First',
 title: '1. Uncompromising Launch Polish Test: Will management delay rather than ship unpolished?',
 desc: 'Does the studio hold authority to delay past quarterly windows until lighting, AI, and quests hit 97–99 Metascore quality?'
 },
 {
 tag: '600k+ Animations',
 title: '2. Handcrafted Interaction Density Test: Does the world avoid procedural open-world fatigue?',
 desc: 'Are non-story zones populated with handcrafted neighborhood NPC reactions, localized weather physics, and emergent events?'
 },
 {
 tag: '$79.99 / $99.99',
 title: '3. Premium Pricing & Edition Mix Test: Can ASP step up without review backlash?',
 desc: 'Do players willingly embrace $79.99 Standard and $99.99 Ultimate tiers (with zero launch MTX) to clear break-even pre-launch?'
 },
 {
 tag: '475M 24h Views',
 title: '4. Organic Cultural Tentpole Test: Is each trailer a global pop-culture event?',
 desc: 'Can a single drop command hundreds of millions of organic views and Netflix/NBA partnerships without heavy user-acquisition spend?'
 },
 {
 tag: 'RAGE Gen-9 Stack',
 title: '5. Proprietary Engine Reusability Test: Does R&D compound into reusable studio tooling?',
 desc: 'Do in-house RTGI, volumetric weather, and real-time animation retargeting create non-licensable advantages for future titles?'
 },
 {
 tag: 'GTA+ & Cfx.re UGC',
 title: '6. Decade Multi-Gen & Creator Flywheel Test: Is there a 10-year post-campaign engine?',
 desc: 'Can the IP compound via staggered PC/Gen-10 editions, GTA+ subscriptions, and official Cfx.re (FiveM) roleplay creator servers?'
 }
 ];

 var QUICK_JUMP_INDEX = [
 { sec: 'sec-00', title: '00 执行摘要与首发核心指标', sub: '>1,900万份预购 (>$18亿) · Metacritic 99分 · 4,711人团队' },
 { sec: 'sec-01', title: '01 雷奥奈达世界与RAGE引擎', sub: '六大生态区蓝图 · 60万+动画 · 工业规模与预告播放双视图' },
 { sec: 'sec-02', title: '02 四大产品支柱与口碑护城河', sub: '手工市民生态 · RAGE光追 · 99分品控 · 五维产品力雷达图' },
 { sec: 'sec-03', title: '03 全球3A开放世界巨制对比', sub: 'GTA VI vs GTA V vs 大镖客2 vs 赛博朋克2077 vs 王国之泪' },
 { sec: 'sec-04', title: '04 定价经济学与全周期变现测算', sub: '$79.99/$99.99定价 · 交互式全周期总流水与 ROI 测算器' },
 { sec: 'sec-05', title: '05 十二年研发演进与关键战役', sub: '2014预研 → 防泄密升级 → 两次跳票打磨 → 2026.11.19首发' },
 { sec: 'sec-06', title: '06 超级文化IP护城河核查清单', sub: '6 项现象级大作产品与商业飞轮自测清单 (本地自动保存)' },
 { sec: 'sec-07', title: '07 数据来源与官方信源索引', sub: 'Rockstar Newswire · Take-Two IR · Metacritic 权威链接' }
 ];

 var QUICK_JUMP_EN = [
 { sec: 'sec-00', title: '00 Executive Summary & Launch KPIs', sub: '>19M Pre-Orders (>$1.8B) · Metacritic 99 · 4,711 Devs' },
 { sec: 'sec-01', title: '01 Leonida World & RAGE Gen-9 Engine', sub: '6 Leonida Biomes · 600k+ Animations · Scale & Trailer Charts' },
 { sec: 'sec-02', title: '02 Four Product Pillars & Moat Radar', sub: 'Handcrafted NPCs · RAGE RTGI · 99 Polish · 5-Axis Radar' },
 { sec: 'sec-03', title: '03 Global AAA Blockbuster Matrix', sub: 'GTA VI vs. GTA V vs. RDR2 vs. Cyberpunk 2077 vs. Zelda TotK' },
 { sec: 'sec-04', title: '04 Unit Economics & ROI Simulator', sub: '$79.99/$99.99 Tiers · Interactive Lifecycle Bookings Simulator' },
 { sec: 'sec-05', title: '05 Twelve-Year Timeline & Key Battles', sub: 'Project Americas -> Leak Defense -> Two Delays -> Nov 19 Launch' },
 { sec: 'sec-06', title: '06 Mega-IP Moat Diagnostic Checklist', sub: '6-Point Blockbuster Flywheel Assessment (Saved Locally)' },
 { sec: 'sec-07', title: '07 Primary Sources & Official Index', sub: 'Rockstar Newswire · Take-Two IR · Metacritic Benchmarks' }
 ];

 var PRESETS = {
 p1: { units: 110, asp: 74, liveArpu: 18, years: 5, pcUgc: true },
 p2: { units: 175, asp: 76, liveArpu: 26, years: 8, pcUgc: true },
 p3: { units: 240, asp: 79, liveArpu: 36, years: 10, pcUgc: true }
 };

 var state = {
 lang: 'zh',
 theme: 'light',
 ch1View: 'viewA',
 activePillar: 0,
 radarSeries: { gta6: true, gta5: true, cp2077: true },
 peerFilter: 'all',
 peerQuery: '',
 sim: { units: 175, asp: 76, liveArpu: 26, years: 8, pcUgc: true, preset: 'p2' },
 checks: [true, true, true, true, false, false]
 };

 /* Safe LocalStorage Helpers */
 function safeGetStorage(key) {
 try {
 return window.localStorage.getItem(key);
 } catch (err) {
 return null;
 }
 }

 function safeSetStorage(key, val) {
 try {
 window.localStorage.setItem(key, val);
 } catch (err) {
 /* Ignore storage quota/sandbox restrictions */
 }
 }

 /* Toast Notification (MUI Snackbar) */
 var toastTimer = null;
 function showToast(message) {
 var el = document.getElementById('muiSnackbar');
 if (!el) return;
 el.textContent = message;
 el.classList.add('show');
 if (toastTimer) clearTimeout(toastTimer);
 toastTimer = setTimeout(function () {
 el.classList.remove('show');
 }, 2800);
 }

 /* ======================================================================
 2. Bilingual (中文 | EN) & Theme Switching + Sidebar Drawer
 ====================================================================== */
 function isEn() {
 return state.lang === 'en';
 }

 var _zhToEnText = {};
 var _enToZhText = {};
 for (var _ti = 0; _ti < I18N_TEXT_PAIRS.length; _ti++) {
 _zhToEnText[I18N_TEXT_PAIRS[_ti][0]] = I18N_TEXT_PAIRS[_ti][1];
 _enToZhText[I18N_TEXT_PAIRS[_ti][1]] = I18N_TEXT_PAIRS[_ti][0];
 }
 var _zhToEnAttr = {};
 var _enToZhAttr = {};
 for (var _ai = 0; _ai < I18N_ATTR_PAIRS.length; _ai++) {
 _zhToEnAttr[I18N_ATTR_PAIRS[_ai][0]] = I18N_ATTR_PAIRS[_ai][1];
 _enToZhAttr[I18N_ATTR_PAIRS[_ai][1]] = I18N_ATTR_PAIRS[_ai][0];
 }
 var _richMapByKey = {};
 for (var _ri = 0; _ri < I18N_RICH_LIST.length; _ri++) {
 _richMapByKey[I18N_RICH_LIST[_ri].key] = I18N_RICH_LIST[_ri];
 }

 function bindRichBlocksOnce() {
 var candidates = document.querySelectorAll('h1, p, div');
 for (var i = 0; i < candidates.length; i++) {
 var el = candidates[i];
 if (el.getAttribute('data-i18n-rich')) continue;
 if (el.id === 'pillarFocusNote' || el.closest('#pillarFocusNote')) continue;
 var normTxt = (el.textContent || '').replace(/\s+/g, ' ').trim();
 for (var j = 0; j < I18N_RICH_LIST.length; j++) {
 var item = I18N_RICH_LIST[j];
 if (normTxt.indexOf(item.match_zh) === 0 && el.children.length <= 25) {
 if (!el.querySelector('div, p, ul, table, canvas')) {
 el.setAttribute('data-i18n-rich', item.key);
 break;
 }
 }
 }
 }
 }

 function syncCh1HeaderText() {
 var titleEl = document.getElementById('ch1ChartTitle');
 var subEl = document.getElementById('ch1ChartSub');
 if (!titleEl || !subEl) return;
 if (state.ch1View === 'viewA') {
 titleEl.textContent = isEn()
 ? 'Rockstar Mainline Trilogy Production Leap: Studio Headcount vs. Unique NPC Animations'
 : 'Rockstar 三代开放世界旗舰工业规模跃迁：研发团队人数 vs 独立 NPC 动画库';
 subEl.textContent = isEn()
 ? 'From GTA V (2013) to GTA VI (2026), dev team expanded >4.7x (4,711 staff) while handcrafted NPC animations surged 10.9x to 600,000+'
 : '从 GTA V (2013) 到 GTA VI (2026)，研发编制扩张逾 4.7 倍，手工 NPC 独立动画组数激增 10.9 倍至 60 万+';
 } else {
 titleEl.textContent = isEn()
 ? 'Global Cultural Virality: GTA VI Trailer First-Day/48h Surge vs. Cumulative YouTube Views (M)'
 : '全球文化破圈统治力：GTA VI 预告片首日/48h 爆发量 vs YouTube 单平台累计播放量（百万次）';
 subEl.textContent = isEn()
 ? 'Trailer 1 hit 101M YouTube views in 48h (302.6M cumulative); Trailer 2 shattered entertainment history with 475M cross-platform views in 24h'
 : 'Trailer 1 两天破 1.01 亿播放（累计达 3.03 亿）；Trailer 2 首日全平台狂揽 4.75 亿次观看刷新影娱史纪录';
 }
 }

 function syncCollapseButtonsText() {
 var btns = document.querySelectorAll('[data-collapse-target]');
 for (var i = 0; i < btns.length; i++) {
 var pid = btns[i].getAttribute('data-collapse-target');
 var panel = document.getElementById(pid);
 var isOpen = panel && panel.classList.contains('open');
 if (isEn()) {
 btns[i].innerHTML = isOpen ? '<span>Hide Design Mechanics</span> <span>⌃</span>' : '<span>Show Design Mechanics</span> <span>⌄</span>';
 } else {
 btns[i].innerHTML = isOpen ? '<span>收起微观机制拆解</span> <span>⌃</span>' : '<span>展开微观机制拆解</span> <span>⌄</span>';
 }
 }
 }

 function applyLanguage(lang, silent) {
 bindRichBlocksOnce();
 state.lang = lang === 'en' ? 'en' : 'zh';
 var en = isEn();
 document.documentElement.setAttribute('lang', en ? 'en' : 'zh-CN');
 document.documentElement.setAttribute('data-lang', state.lang);
 document.title = en ? DOC_TITLE_EN : DOC_TITLE_ZH;

 var lGrp = document.getElementById('langSwitchGroup');
 if (lGrp) lGrp.setAttribute('aria-label', en ? 'Language switcher' : '语言切换');
 var abThmBtn = document.getElementById('appbarThemeBtn');
 if (abThmBtn) {
 abThmBtn.setAttribute('title', en ? 'Toggle Light / Dark theme' : '切换浅色 / 深色主题');
 abThmBtn.setAttribute('aria-label', en ? 'Toggle color theme' : '切换深浅色主题');
 }

 var zhBtn = document.getElementById('langZhBtn');
 var enBtn = document.getElementById('langEnBtn');
 if (zhBtn && enBtn) {
 zhBtn.classList.toggle('active', !en);
 enBtn.classList.toggle('active', en);
 zhBtn.setAttribute('aria-pressed', !en ? 'true' : 'false');
 enBtn.setAttribute('aria-pressed', en ? 'true' : 'false');
 }

 var dynNavSpans = document.querySelectorAll('[data-i18n-zh][data-i18n-en]');
 for (var dn = 0; dn < dynNavSpans.length; dn++) {
 dynNavSpans[dn].textContent = en ? dynNavSpans[dn].getAttribute('data-i18n-en') : dynNavSpans[dn].getAttribute('data-i18n-zh');
 }

 /* 1. Update Rich Prose Blocks */
 var richNodes = document.querySelectorAll('[data-i18n-rich]');
 for (var r = 0; r < richNodes.length; r++) {
 var rk = richNodes[r].getAttribute('data-i18n-rich');
 var rEntry = _richMapByKey[rk];
 if (rEntry) {
 richNodes[r].innerHTML = en ? rEntry.en : rEntry.zh;
 }
 }

 /* 2. Walk Pure Text Nodes */
 var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
 var tNode;
 while ((tNode = walker.nextNode())) {
 var pEl = tNode.parentElement;
 if (!pEl) continue;
 var tag = pEl.tagName;
 if (tag === 'SCRIPT' || tag === 'STYLE') continue;
 if (pEl.closest('#langSwitchGroup') || pEl.closest('[data-i18n-rich]') || pEl.closest('#pillarFocusNote')) continue;
 var raw = tNode.nodeValue || '';
 var trimmed = raw.replace(/\s+/g, ' ').trim();
 if (!trimmed) continue;
 var mapped = en ? _zhToEnText[trimmed] : _enToZhText[trimmed];
 if (mapped) {
 var leadMatch = raw.match(/^\s*/);
 var trailMatch = raw.match(/\s*$/);
 tNode.nodeValue = (leadMatch ? leadMatch[0] : '') + mapped + (trailMatch ? trailMatch[0] : '');
 }
 }

 /* 3. Update Attributes (placeholder, title, aria-label) */
 var allEls = document.querySelectorAll('[placeholder], [title], [aria-label]');
 var attrNames = ['placeholder', 'title', 'aria-label'];
 for (var a = 0; a < allEls.length; a++) {
 if (allEls[a].closest('#langSwitchGroup')) continue;
 for (var k = 0; k < attrNames.length; k++) {
 var an = attrNames[k];
 var av = allEls[a].getAttribute(an);
 if (!av) continue;
 var nextAv = en ? _zhToEnAttr[av] : _enToZhAttr[av];
 if (nextAv) allEls[a].setAttribute(an, nextAv);
 }
 }

 /* 4. Update Dynamic Panels & Redraw All 5 High-DPI Charts */
 var pNote = document.getElementById('pillarFocusNote');
 if (pNote) {
 var notesArr = en ? PILLAR_NOTES_EN : PILLAR_NOTES;
 pNote.innerHTML = '<div>' + notesArr[state.activePillar] + '</div>';
 }
 syncCh1HeaderText();
 syncCollapseButtonsText();
 renderPeerTable();
 renderChecklist();
 updateSimulatorUI();
 renderAllCharts();
 safeSetStorage(STORAGE_LANG_KEY, state.lang);

 if (!silent) {
 showToast(en ? 'Switched to English Research Edition' : '已切换至中文深度研报视图');
 }
 }

 function applyTheme(theme, silent) {
 state.theme = theme === 'dark' ? 'dark' : 'light';
 document.documentElement.setAttribute('data-theme', state.theme);
 var abIconEl = document.getElementById('appbarThemeIcon');
 if (abIconEl) {
 abIconEl.innerHTML = (state.theme === 'dark')
 ? '<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zm18 0h2c.55 0 1-.45 1-1s-.45-1-1-1h-2c-.55 0-1 .45-1 1s.45 1 1 1zM11 2v2c0 .55.45 1 1 1s1-.45 1-1V2c0-.55-.45-1-1-1s-1 .45-1 1zm0 18v2c0 .55.45 1 1 1s1-.45 1-1v-2c0-.55-.45-1-1-1s-1 .45-1 1zM5.99 4.58a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0s.39-1.03 0-1.41L5.99 4.58zm12.37 12.37a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0a.996.996 0 0 0 0-1.41l-1.06-1.06zm1.06-10.96a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06zM7.05 18.36a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06z"/></svg>'
 : '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3a9 9 0 1 0 9 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 0 1-4.4 2.26 5.403 5.403 0 0 1-3.14-9.8c-.44-.06-.9-.1-1.36-.1z"/></svg>';
 }
 var sDarkBtn = document.getElementById('sideThemeDarkBtn');
 var sLightBtn = document.getElementById('sideThemeLightBtn');
 if (sDarkBtn && sLightBtn) {
 void 0;
 void 0;
 }
 safeSetStorage(STORAGE_THEME_KEY, state.theme);
 renderAllCharts();
 if (!silent) {
 showToast(state.theme === 'dark' ? (isEn() ? 'Switched to MUI Dark Obsidian Mode' : '已切换至 MUI 深海黑曜石护眼模式') : (isEn() ? 'Switched to MUI Light Mode' : '已切换至 MUI 浅色明亮阅读模式'));
 }
 }

 function toggleSidebar() {
 if (window.innerWidth <= 1120) {
 document.body.classList.toggle('drawer-open');
 } else {
 document.body.classList.toggle('sidebar-collapsed');
 setTimeout(renderAllCharts, 60);
 }
 }

 function closeMobileDrawer() {
 document.body.classList.remove('drawer-open');
 }

 /* ======================================================================
 3. AAA Blockbuster Comparison Table Rendering & Filtering
 ====================================================================== */
 function escapeHtml(str) {
 return String(str)
 .replace(/&/g, '&amp;')
 .replace(/</g, '&lt;')
 .replace(/>/g, '&gt;')
 .replace(/"/g, '&quot;');
 }

 function highlightMatch(text, query) {
 var safe = escapeHtml(text);
 if (!query) return safe;
 var escapedQ = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
 var re = new RegExp('(' + escapedQ + ')', 'gi');
 return safe.replace(re, '<mark class="hl">$1</mark>');
 }

 function renderPeerTable() {
 var tbody = document.getElementById('peerTableBody');
 var badge = document.getElementById('peerCountBadge');
 if (!tbody) return;

 var activeRows = isEn() ? PEER_ROWS_EN : PEER_ROWS;
 var q = state.peerQuery.trim().toLowerCase();
 var filtered = activeRows.filter(function (row, idx) {
 var catOk = state.peerFilter === 'all' || row.category === state.peerFilter;
 if (!catOk) return false;
 if (!q) return true;
 var zhR = PEER_ROWS[idx] || row;
 var enR = PEER_ROWS_EN[idx] || row;
 var hay = (zhR.company + ' ' + zhR.leader + ' ' + zhR.positioning + ' ' + zhR.culture + ' ' + zhR.headcount + ' ' + zhR.margins + ' ' + zhR.verdict + ' ' + enR.company + ' ' + enR.leader + ' ' + enR.positioning + ' ' + enR.culture + ' ' + enR.verdict).toLowerCase();
 return hay.indexOf(q) !== -1;
 });

 if (badge) {
 badge.textContent = isEn()
 ? ('Showing ' + filtered.length + ' / ' + activeRows.length + ' Blockbusters')
 : ('显示 ' + filtered.length + ' / ' + activeRows.length + ' 部现象级巨制');
 }

 if (!filtered.length) {
 tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:28px;">' + (isEn() ? 'No matching blockbuster titles found. Try another keyword or reset filters.' : '未找到匹配的标杆作品记录，请尝试其他关键词或重置筛选条件。') + '</td></tr>';
 return;
 }

 var rawQ = state.peerQuery.trim();
 tbody.innerHTML = filtered.map(function (r) {
 return '<tr class="' + (r.benchmark ? 'benchmark-row' : '') + '">' +
 '<td><strong style="color:var(--text-primary);display:block;">' + highlightMatch(r.company, rawQ) + '</strong><span style="font-size:0.76rem;color:var(--text-muted);">' + highlightMatch(r.leader, rawQ) + '</span></td>' +
 '<td>' + highlightMatch(r.positioning, rawQ) + '</td>' +
 '<td>' + highlightMatch(r.culture, rawQ) + '</td>' +
 '<td class="mono" style="font-size:0.79rem;">' + highlightMatch(r.headcount, rawQ) + '</td>' +
 '<td class="mono" style="font-size:0.79rem;color:var(--mui-primary-lighter);font-weight:700;">' + highlightMatch(r.margins, rawQ) + '</td>' +
 '<td>' + highlightMatch(r.verdict, rawQ) + ' <a class="cite-link" href="' + r.sourceUrl + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(r.sourceLabel) + ' ↗</a></td>' +
 '</tr>';
 }).join('');
 }

 /* ======================================================================
 4. Lifecycle Commercial Monetization & ROI Simulator
 ====================================================================== */
 function computeLifecycleSeries() {
 var totalUnitsM = state.sim.units;
 var asp = state.sim.asp;
 var liveArpu = state.sim.liveArpu;
 var yrs = state.sim.years;
 var pcUgcMult = state.sim.pcUgc ? 1.22 : 1.0;

 /* Front-loaded box sales curve + compounding installed-base live/UGC bookings */
 var weights = [];
 var weightSum = 0;
 for (var k = 1; k <= yrs; k++) {
 /* Year 1 captures ~38%-46% launch wave; Year 2 gets PC/next-gen bump if enabled */
 var w = k === 1 ? 2.6 : (k === 2 && state.sim.pcUgc ? 1.35 : Math.pow(0.76, k - 1));
 weights.push(w);
 weightSum += w;
 }

 var cumBoxB = [0];
 var cumTotalB = [0];
 var cumInstalledM = 0;

 for (var y = 1; y <= yrs; y++) {
 var yrUnitsM = totalUnitsM * (weights[y - 1] / weightSum);
 cumInstalledM += yrUnitsM;
 var yrBoxB = (yrUnitsM * asp) / 1000;
 /* Active online + RP creator cohort retention ratio */
 var activeRate = (0.34 * pcUgcMult) * Math.pow(0.95, Math.max(0, y - 2));
 var activeUsersM = cumInstalledM * Math.min(0.55, activeRate);
 var yrLiveB = (activeUsersM * liveArpu) / 1000;

 cumBoxB.push(cumBoxB[y - 1] + yrBoxB);
 cumTotalB.push(cumTotalB[y - 1] + yrBoxB + yrLiveB);
 }

 return {
 yrs: yrs,
 cumBoxB: cumBoxB,
 cumTotalB: cumTotalB,
 totalBoxB: cumBoxB[yrs],
 totalLiveB: cumTotalB[yrs] - cumBoxB[yrs],
 grandTotalB: cumTotalB[yrs]
 };
 }

 function formatBillions(valB) {
 return '$' + valB.toFixed(2) + 'B';
 }

 function updateSimulatorUI() {
 var res = computeLifecycleSeries();
 var costBaseB = 1.50;
 var roiMultiple = res.grandTotalB / costBaseB;
 var liveSharePct = res.grandTotalB > 0 ? Math.round((res.totalLiveB / res.grandTotalB) * 100) : 0;

 document.getElementById('simPrincipalLabel').textContent = state.sim.units + (isEn() ? 'M Units' : 'M 份');
 document.getElementById('simCagrLabel').textContent = '$' + state.sim.asp + (isEn() ? ' / copy' : ' / 份');
 document.getElementById('simLiveArpuLabel').textContent = '$' + state.sim.liveArpu + (isEn() ? ' / yr' : ' / 年');
 document.getElementById('simYearsLabel').textContent = state.sim.years + (isEn() ? ' yrs' : ' 年');

 document.getElementById('simEndingVal').textContent = formatBillions(res.grandTotalB);
 document.getElementById('simMoicVal').textContent = roiMultiple.toFixed(2) + 'x · ' + (isEn() ? ('Live ' + liveSharePct + '%') : ('在线占 ' + liveSharePct + '%'));
 document.getElementById('simNetGainVal').textContent = formatBillions(res.totalBoxB);
 document.getElementById('simMidLabel').textContent = isEn() ? 'Cumulative Online & UGC Bookings' : '在线服务与 UGC 累计增量流水';
 document.getElementById('simMidVal').textContent = formatBillions(res.totalLiveB);

 var presetBtns = document.querySelectorAll('[data-preset]');
 for (var i = 0; i < presetBtns.length; i++) {
 presetBtns[i].classList.toggle('active', presetBtns[i].getAttribute('data-preset') === state.sim.preset);
 }

 drawSimChart();
 }

 /* ======================================================================
 5. Interactive Checklist
 ====================================================================== */
 function renderChecklist() {
 var container = document.getElementById('checklistContainer');
 var chip = document.getElementById('checklistScoreChip');
 var bar = document.getElementById('checklistProgressBar');
 if (!container) return;

 var itemsList = isEn() ? CHECKLIST_ITEMS_EN : CHECKLIST_ITEMS;
 var doneCount = state.checks.filter(Boolean).length;
 var pct = Math.round((doneCount / itemsList.length) * 100);
 if (chip) {
 chip.textContent = isEn()
 ? ('Verified ' + doneCount + ' / ' + itemsList.length + ' (' + pct + '%)')
 : ('已核查 ' + doneCount + ' / ' + itemsList.length + ' 项 (' + pct + '%)');
 }
 if (bar) {
 bar.style.width = pct + '%';
 }

 container.innerHTML = itemsList.map(function (item, idx) {
 var isChecked = !!state.checks[idx];
 return '<label class="check-card ' + (isChecked ? 'checked' : '') + '" data-check-idx="' + idx + '">' +
 '<input type="checkbox" data-check-input="' + idx + '" ' + (isChecked ? 'checked' : '') + ' />' +
 '<div style="flex:1;">' +
 '<div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:6px;margin-bottom:4px;">' +
 '<span class="check-title">' + escapeHtml(item.title) + '</span>' +
 '<span class="mui-chip mono">' + escapeHtml(item.tag) + '</span>' +
 '</div>' +
 '<p class="check-desc">' + escapeHtml(item.desc) + '</p>' +
 '</div>' +
 '</label>';
 }).join('');
 }

 /* ======================================================================
 6. Built-In Zero-Dependency MUI X Charts-Style High-DPI Engine
 ====================================================================== */
 state.ch1Series = { s1: true, s2: true };
 state.epsSeries = { rev: true, oci: true };

 var hitRegions = {
 chartCh1: [],
 chartRadar: [],
 chartBars: [],
 chartEps: [],
 chartSim: []
 };

 var hoverState = {
 chartCh1: -1,
 chartRadar: -1,
 chartBars: -1,
 chartEps: -1,
 chartSim: -1
 };

 function getPalette() {
 var cs = getComputedStyle(document.documentElement);
 var isDark = state.theme === 'dark';
 return {
 isDark: isDark,
 grid: cs.getPropertyValue('--chart-grid').trim() || (isDark ? 'rgba(148,163,184,0.13)' : 'rgba(100,116,139,0.16)'),
 tick: cs.getPropertyValue('--chart-tick').trim() || '#94A3B8',
 text: cs.getPropertyValue('--text-primary').trim() || '#F3F6F9',
 sub: cs.getPropertyValue('--text-secondary').trim() || '#B2BAC2',
 pillBg: isDark ? 'rgba(9, 13, 22, 0.88)' : 'rgba(255, 255, 255, 0.94)',
 pillBorder: isDark ? 'rgba(51, 153, 255, 0.28)' : 'rgba(0, 115, 230, 0.24)',
 trackBg: isDark ? 'rgba(148, 163, 184, 0.10)' : 'rgba(15, 25, 36, 0.06)',
 hoverBand: isDark ? 'rgba(51, 153, 255, 0.07)' : 'rgba(0, 115, 230, 0.05)',
 c1: cs.getPropertyValue('--chart-c1').trim() || '#3399FF',
 c2: cs.getPropertyValue('--chart-c2').trim() || '#22C55E',
 c3: cs.getPropertyValue('--chart-c3').trim() || '#FFB74D',
 c4: cs.getPropertyValue('--chart-c4').trim() || '#A78BFA'
 };
 }

 function prepareCanvas(id) {
 var canvas = document.getElementById(id);
 if (!canvas || !canvas.parentElement) return null;
 var stage = canvas.parentElement;
 var rect = stage.getBoundingClientRect();
 var w = Math.max(240, Math.floor(rect.width));
 var h = Math.max(170, Math.floor(rect.height));
 var dpr = Math.min(window.devicePixelRatio || 1, 2.5);
 canvas.style.width = w + 'px';
 canvas.style.height = h + 'px';
 var targetW = Math.floor(w * dpr);
 var targetH = Math.floor(h * dpr);
 if (canvas.width !== targetW) canvas.width = targetW;
 if (canvas.height !== targetH) canvas.height = targetH;
 var ctx = canvas.getContext('2d');
 ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
 ctx.clearRect(0, 0, w, h);
 return { ctx: ctx, w: w, h: h, canvas: canvas };
 }

 function roundRectPath(ctx, x, y, w, h, r) {
 if (w <= 0 || h <= 0) return;
 var radius = Math.min(r, w / 2, h / 2);
 ctx.beginPath();
 ctx.moveTo(x + radius, y);
 ctx.lineTo(x + w - radius, y);
 ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
 ctx.lineTo(x + w, y + h - radius);
 ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
 ctx.lineTo(x + radius, y + h);
 ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
 ctx.lineTo(x, y + radius);
 ctx.quadraticCurveTo(x, y, x + radius, y);
 ctx.closePath();
 }

 function topRoundedBar(ctx, x, y, w, h, r) {
 if (w <= 0 || h <= 0) return;
 var rad = Math.min(r, w / 2, h);
 ctx.beginPath();
 ctx.moveTo(x, y + h);
 ctx.lineTo(x, y + rad);
 ctx.quadraticCurveTo(x, y, x + rad, y);
 ctx.lineTo(x + w - rad, y);
 ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
 ctx.lineTo(x + w, y + h);
 ctx.closePath();
 }

 function drawValueBadge(ctx, text, cx, cy, fgColor, pal) {
 ctx.save();
 ctx.font = '700 11px "IBM Plex Mono", system-ui, sans-serif';
 var tw = ctx.measureText(text).width + 10;
 var th = 18;
 var bx = cx - tw / 2;
 var by = cy - th / 2;
 ctx.fillStyle = pal.pillBg;
 roundRectPath(ctx, bx, by, tw, th, 5);
 ctx.fill();
 ctx.strokeStyle = pal.pillBorder;
 ctx.lineWidth = 1;
 ctx.stroke();
 ctx.fillStyle = fgColor;
 ctx.textAlign = 'center';
 ctx.textBaseline = 'middle';
 ctx.fillText(text, cx, cy + 0.5);
 ctx.restore();
 }

 function drawSmoothLine(ctx, pts) {
 if (!pts.length) return;
 ctx.beginPath();
 ctx.moveTo(pts[0].x, pts[0].y);
 for (var i = 0; i < pts.length - 1; i++) {
 var xc = (pts[i].x + pts[i + 1].x) / 2;
 ctx.bezierCurveTo(xc, pts[i].y, xc, pts[i + 1].y, pts[i + 1].x, pts[i + 1].y);
 }
 }

 /* Chart 1: View A (Rockstar Trilogy Headcount vs NPC Animations) & View B (Trailer View Records) */
 function drawCh1Chart() {
 var env = prepareCanvas('chartCh1');
 if (!env) return;
 var ctx = env.ctx, w = env.w, h = env.h;
 var pal = getPalette();
 hitRegions.chartCh1 = [];

 var metaEl = document.getElementById('ch1AxisMeta');
 var leg1 = document.getElementById('ch1Leg1');
 var leg2 = document.getElementById('ch1Leg2');

 if (state.ch1View === 'viewA') {
 if (metaEl) {
 metaEl.innerHTML = isEn()
 ? '<span style="color:var(--chart-c1);">■ Left Axis: Global Dev Team Size (Staff)</span><span style="color:var(--chart-c2);">● Right Axis: Unique NPC Animations (k)</span>'
 : '<span style="color:var(--chart-c1);">■ 左轴：全球研发人数 (人)</span><span style="color:var(--chart-c2);">● 右轴：独立 NPC 动画库 (千组)</span>';
 }
 if (leg1) leg1.textContent = isEn() ? 'Global Rockstar Development Headcount (Left · Staff)' : 'Rockstar 全球参与研发人数 (左轴 · 人)';
 if (leg2) leg2.textContent = isEn() ? 'Handcrafted Unique NPC Animations (Right · k clips)' : '手工独立 NPC 动画组数 (右轴 · 千组)';

 var padA = { top: 28, right: 54, bottom: 44, left: 52 };
 var pwA = w - padA.left - padA.right;
 var phA = h - padA.top - padA.bottom;
 var labelsA = ['GTA V (2013)', 'Red Dead 2 (2018)', 'GTA VI (2026)'];
 var subA = isEn() ? ['PS3/360 Era', '8th-Gen Unified', '12 Studios · Gen-9'] : ['PS3世代起点', '全球工作室合流', '12大工作室 · 含LA'];
 var devs = [1000, 2441, 4711];
 var animsK = [55, 300, 600];
 var maxDevs = 5600;
 var maxAnims = 680;

 for (var g = 0; g <= 4; g++) {
 var r = g / 4;
 var gy = padA.top + phA - r * phA;
 ctx.strokeStyle = pal.grid;
 ctx.lineWidth = 1;
 ctx.beginPath();
 ctx.moveTo(padA.left, gy);
 ctx.lineTo(padA.left + pwA, gy);
 ctx.stroke();

 ctx.font = '11px "IBM Plex Mono", sans-serif';
 ctx.textBaseline = 'middle';
 ctx.fillStyle = pal.tick;
 ctx.textAlign = 'right';
 ctx.fillText(Math.round(maxDevs * r).toLocaleString(), padA.left - 8, gy);

 ctx.fillStyle = pal.c2;
 ctx.textAlign = 'left';
 ctx.fillText(Math.round(maxAnims * r) + 'k', padA.left + pwA + 8, gy);
 }

 var stepA = pwA / labelsA.length;
 var barW = Math.min(64, Math.max(28, stepA * 0.34));
 var pts = [];

 for (var i = 0; i < labelsA.length; i++) {
 var cx = padA.left + stepA * (i + 0.5);
 if (hoverState.chartCh1 === i) {
 ctx.fillStyle = pal.hoverBand;
 roundRectPath(ctx, padA.left + stepA * i + 8, padA.top, stepA - 16, phA, 8);
 ctx.fill();
 }

 if (state.ch1Series.s1) {
 var bh = (devs[i] / maxDevs) * phA;
 var bx = cx - barW / 2;
 var by = padA.top + phA - bh;
 var grad1 = ctx.createLinearGradient(0, by, 0, padA.top + phA);
 grad1.addColorStop(0, '#3399FF');
 grad1.addColorStop(1, '#0066CC');
 ctx.fillStyle = grad1;
 topRoundedBar(ctx, bx, by, barW, bh, 6);
 ctx.fill();

 ctx.fillStyle = '#FFFFFF';
 ctx.font = '700 11px "IBM Plex Mono", sans-serif';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'alphabetic';
 ctx.fillText((i === 0 ? '1,000+' : devs[i].toLocaleString()), cx, by + 18);
 }

 var ly = padA.top + phA - (animsK[i] / maxAnims) * phA;
 pts.push({ x: cx, y: ly, val: animsK[i] });

 ctx.fillStyle = pal.text;
 ctx.font = '700 12px system-ui, sans-serif';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'alphabetic';
 ctx.fillText(labelsA[i], cx, padA.top + phA + 20);
 ctx.fillStyle = pal.tick;
 ctx.font = '10.5px system-ui, sans-serif';
 ctx.fillText(subA[i], cx, padA.top + phA + 35);

 hitRegions.chartCh1.push({
 idx: i,
 x: padA.left + stepA * i, y: padA.top, w: stepA, h: phA + 38,
 html: isEn()
 ? ('<strong>' + labelsA[i] + ' Production Scale</strong><br/>' +
 '• Development Team: <strong>' + (i === 0 ? '1,000+ devs' : devs[i].toLocaleString() + ' staff') + '</strong><br/>' +
 '• Unique NPC Animations: <strong>' + (i === 2 ? '600,000+' : (animsK[i] * 1000).toLocaleString()) + ' clips</strong>')
 : ('<strong>' + labelsA[i] + ' 工业化投入规模</strong><br/>' +
 '• 研发团队规模：<strong>' + (i === 0 ? '1,000+ 人' : devs[i].toLocaleString() + ' 人') + '</strong><br/>' +
 '• 独立 NPC 动画库：<strong>' + (i === 2 ? '600,000+ 组' : (animsK[i] * 1000).toLocaleString() + ' 组') + '</strong>')
 });
 }

 if (state.ch1Series.s2) {
 ctx.save();
 drawSmoothLine(ctx, pts);
 ctx.strokeStyle = pal.c2;
 ctx.lineWidth = 2.8;
 ctx.stroke();
 ctx.restore();

 for (var n = 0; n < pts.length; n++) {
 ctx.fillStyle = pal.pillBg;
 ctx.beginPath();
 ctx.arc(pts[n].x, pts[n].y, 6, 0, Math.PI * 2);
 ctx.fill();
 ctx.fillStyle = pal.c2;
 ctx.beginPath();
 ctx.arc(pts[n].x, pts[n].y, 4.2, 0, Math.PI * 2);
 ctx.fill();
 drawValueBadge(ctx, (n === 2 ? '600k+' : pts[n].val + 'k'), pts[n].x, pts[n].y - 16, pal.c2, pal);
 }
 }
 } else {
 if (metaEl) {
 metaEl.innerHTML = isEn()
 ? '<span style="color:var(--chart-c1);">■ First 24h–48h Launch Burst (M Views)</span><span style="color:var(--chart-c2);">■ Cumulative YouTube Views by Launch (M Views)</span>'
 : '<span style="color:var(--chart-c1);">■ 首 24h–48h 爆发播放量 (百万次)</span><span style="color:var(--chart-c2);">■ 截至首发 YouTube 单平台累计 (百万次)</span>';
 }
 if (leg1) leg1.textContent = isEn() ? 'Opening 24h / 48h Surge Views (Million)' : '首 24h / 48h 爆发播放量 (百万次)';
 if (leg2) leg2.textContent = isEn() ? 'Cumulative YouTube Views by Launch (Million)' : '截至首发日 YouTube 累计播放量 (百万次)';

 var padB = { top: 28, right: 24, bottom: 44, left: 52 };
 var pwB = w - padB.left - padB.right;
 var phB = h - padB.top - padB.bottom;
 var labelsB = isEn()
 ? ['GTA V Reveal (2011)', 'GTA VI Trailer 1 (2023.12)', 'GTA VI Trailer 2 (2025.05)']
 : ['GTA V 首支预告 (2011)', 'GTA VI 首支预告 (2023.12)', 'GTA VI 第二支预告 (2025.05)'];
 var subB = isEn()
 ? ['12-Yr Baseline', '93M 24h / 101M 48h YT', '475M 24h Cross-Platform']
 : ['前作12年累计基准', '首24h 9300万 / 48h 1.01亿', '首24h 全平台 4.75亿纪录'];
 var burstM = [12, 101, 475];
 var cumYtM = [100, 302.6, 190.0];
 var maxViews = 520;

 for (var j = 0; j <= 4; j++) {
 var v = (maxViews / 4) * j;
 var yGrid = padB.top + phB - (j / 4) * phB;
 ctx.strokeStyle = pal.grid;
 ctx.lineWidth = 1;
 ctx.beginPath();
 ctx.moveTo(padB.left, yGrid);
 ctx.lineTo(padB.left + pwB, yGrid);
 ctx.stroke();

 ctx.fillStyle = pal.tick;
 ctx.font = '11px "IBM Plex Mono", sans-serif';
 ctx.textAlign = 'right';
 ctx.textBaseline = 'middle';
 ctx.fillText(Math.round(v) + 'M', padB.left - 8, yGrid);
 }

 var stepB = pwB / labelsB.length;
 var bW = Math.min(54, Math.max(24, stepB * 0.26));

 for (var k = 0; k < labelsB.length; k++) {
 var centerX = padB.left + stepB * (k + 0.5);
 if (hoverState.chartCh1 === k) {
 ctx.fillStyle = pal.hoverBand;
 roundRectPath(ctx, padB.left + stepB * k + 6, padB.top, stepB - 12, phB, 8);
 ctx.fill();
 }

 if (state.ch1Series.s1) {
 var h1 = (burstM[k] / maxViews) * phB;
 var x1 = state.ch1Series.s2 ? (centerX - bW - 5) : (centerX - bW / 2);
 var y1 = padB.top + phB - h1;
 var g1 = ctx.createLinearGradient(0, y1, 0, padB.top + phB);
 g1.addColorStop(0, '#3399FF');
 g1.addColorStop(1, '#0066CC');
 ctx.fillStyle = g1;
 topRoundedBar(ctx, x1, y1, bW, h1, 6);
 ctx.fill();
 drawValueBadge(ctx, burstM[k] + 'M', x1 + bW / 2, y1 - 12, pal.c1, pal);
 }

 if (state.ch1Series.s2) {
 var h2 = (cumYtM[k] / maxViews) * phB;
 var x2 = state.ch1Series.s1 ? (centerX + 5) : (centerX - bW / 2);
 var y2 = padB.top + phB - h2;
 var g2 = ctx.createLinearGradient(0, y2, 0, padB.top + phB);
 g2.addColorStop(0, '#34D399');
 g2.addColorStop(1, '#16A34A');
 ctx.fillStyle = g2;
 topRoundedBar(ctx, x2, y2, bW, h2, 6);
 ctx.fill();
 drawValueBadge(ctx, cumYtM[k].toFixed(0) + 'M', x2 + bW / 2, y2 - 12, pal.c2, pal);
 }

 ctx.fillStyle = pal.text;
 ctx.font = '700 ' + (w < 460 ? '10.5px' : '11.5px') + ' system-ui, sans-serif';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'alphabetic';
 ctx.fillText(labelsB[k], centerX, padB.top + phB + 20);
 ctx.fillStyle = pal.tick;
 ctx.font = '10px system-ui, sans-serif';
 ctx.fillText(subB[k], centerX, padB.top + phB + 35);

 hitRegions.chartCh1.push({
 idx: k,
 x: padB.left + stepB * k, y: padB.top, w: stepB, h: phB + 38,
 html: isEn()
 ? ('<strong>' + labelsB[k] + '</strong><br/>' +
 '• Opening Burst: <strong>' + burstM[k] + 'M views</strong> (' + subB[k] + ')<br/>' +
 '• Cumulative YouTube Views: <strong>' + cumYtM[k] + 'M views</strong>')
 : ('<strong>' + labelsB[k] + '</strong><br/>' +
 '• 首波爆发播放量：<strong>' + burstM[k] + 'M 次</strong> (' + subB[k] + ')<br/>' +
 '• YouTube 单平台累计：<strong>' + cumYtM[k] + 'M 次</strong>')
 });
 }
 }
 }

 /* Chart 2: 5-Axis Open-World Product Moat Radar Chart */
 function drawRadarChart() {
 var env = prepareCanvas('chartRadar');
 if (!env) return;
 var ctx = env.ctx, w = env.w, h = env.h;
 var pal = getPalette();
 hitRegions.chartRadar = [];

 var axes = isEn()
 ? ['World & NPC Density', 'RAGE RTGI & Physics', 'Launch Polish (MC)', 'Narrative & Leads', 'Live & Creator UGC']
 : ['世界生态与NPC密度', 'RAGE光追与物理拟真', '首发品控与媒体口碑', '双主角叙事与音乐', '长尾在线与UGC潜力'];
 var pillarAxisMap = [0, 1, 2, 4];
 var highlightedAxis = hoverState.chartRadar >= 0 ? hoverState.chartRadar : pillarAxisMap[state.activePillar];

 var series = [
 { key: 'gta6', name: isEn() ? 'GTA VI (2026)' : 'GTA VI (2026)', color: pal.c1, fill: 'rgba(51, 153, 255, 0.24)', vals: [9.9, 9.8, 9.9, 9.7, 9.6] },
 { key: 'gta5', name: isEn() ? 'GTA V (2013)' : 'GTA V (2013)', color: pal.c2, fill: 'rgba(34, 197, 94, 0.16)', vals: [8.4, 7.8, 9.7, 9.1, 9.8] },
 { key: 'cp2077', name: isEn() ? 'Cyberpunk 2077' : '赛博朋克 2077', color: pal.c3, fill: 'rgba(255, 183, 77, 0.14)', vals: [8.3, 9.2, 6.8, 9.0, 6.5] }
 ];

 var cx = w / 2;
 var cy = h / 2 + 8;
 var sidePad = w < 420 ? 88 : 106;
 var radius = Math.max(60, Math.min((w - sidePad * 2) / 2, h * 0.35));
 var total = axes.length;

 for (var ring = 2; ring <= 10; ring += 2) {
 var r = (ring / 10) * radius;
 ctx.strokeStyle = pal.grid;
 ctx.lineWidth = ring === 10 ? 1.3 : 1;
 ctx.beginPath();
 for (var i = 0; i < total; i++) {
 var ang = -Math.PI / 2 + (i * 2 * Math.PI) / total;
 var px = cx + Math.cos(ang) * r;
 var py = cy + Math.sin(ang) * r;
 if (i === 0) ctx.moveTo(px, py);
 else ctx.lineTo(px, py);
 }
 ctx.closePath();
 ctx.stroke();

 ctx.fillStyle = pal.tick;
 ctx.font = '600 9.5px "IBM Plex Mono", sans-serif';
 ctx.textAlign = 'left';
 ctx.textBaseline = 'middle';
 ctx.fillText(String(ring), cx + 4, cy - r);
 }

 for (var a = 0; a < total; a++) {
 var angle = -Math.PI / 2 + (a * 2 * Math.PI) / total;
 var ax = cx + Math.cos(angle) * radius;
 var ay = cy + Math.sin(angle) * radius;
 var isHi = a === highlightedAxis;

 ctx.strokeStyle = isHi ? pal.c1 : pal.grid;
 ctx.lineWidth = isHi ? 1.8 : 1;
 ctx.beginPath();
 ctx.moveTo(cx, cy);
 ctx.lineTo(ax, ay);
 ctx.stroke();

 var lx = cx + Math.cos(angle) * (radius + 14);
 var ly = cy + Math.sin(angle) * (radius + 15);
 ctx.fillStyle = isHi ? pal.c1 : pal.text;
 ctx.font = (isHi ? '800 ' : '600 ') + (w < 420 ? '10.5px' : '11.5px') + ' system-ui, sans-serif';
 ctx.textBaseline = 'middle';
 if (Math.abs(Math.cos(angle)) < 0.2) ctx.textAlign = 'center';
 else if (Math.cos(angle) > 0) ctx.textAlign = 'left';
 else ctx.textAlign = 'right';
 ctx.fillText(axes[a], lx, ly);

 hitRegions.chartRadar.push({
 idx: a,
 x: Math.min(ax, lx) - 36, y: Math.min(ay, ly) - 22, w: 72 + Math.abs(lx - ax), h: 44,
 html: '<strong>' + axes[a] + (isEn() ? ' (10-Pt Scale)' : ' (10分制评估)') + '</strong><br/>' +
 '• ' + series[0].name + ': <strong>' + series[0].vals[a].toFixed(1) + '</strong><br/>' +
 '• ' + series[1].name + ': <strong>' + series[1].vals[a].toFixed(1) + '</strong><br/>' +
 '• ' + series[2].name + ': <strong>' + series[2].vals[a].toFixed(1) + '</strong>'
 });
 }

 for (var s = 0; s < series.length; s++) {
 var item = series[s];
 if (!state.radarSeries[item.key]) continue;
 ctx.beginPath();
 for (var idx = 0; idx < total; idx++) {
 var theta = -Math.PI / 2 + (idx * 2 * Math.PI) / total;
 var dist = (item.vals[idx] / 10) * radius;
 var vx = cx + Math.cos(theta) * dist;
 var vy = cy + Math.sin(theta) * dist;
 if (idx === 0) ctx.moveTo(vx, vy);
 else ctx.lineTo(vx, vy);
 }
 ctx.closePath();
 ctx.fillStyle = item.fill;
 ctx.fill();
 ctx.strokeStyle = item.color;
 ctx.lineWidth = 2.4;
 ctx.stroke();

 for (var pIdx = 0; pIdx < total; pIdx++) {
 var pTheta = -Math.PI / 2 + (pIdx * 2 * Math.PI) / total;
 var pDist = (item.vals[pIdx] / 10) * radius;
 var pX = cx + Math.cos(pTheta) * pDist;
 var pY = cy + Math.sin(pTheta) * pDist;
 ctx.fillStyle = pal.pillBg;
 ctx.beginPath();
 ctx.arc(pX, pY, 5.2, 0, Math.PI * 2);
 ctx.fill();
 ctx.fillStyle = item.color;
 ctx.beginPath();
 ctx.arc(pX, pY, 3.6, 0, Math.PI * 2);
 ctx.fill();
 }
 }
 }

 /* Chart 3: Two-Deck Full-Width Horizontal Progress/Bar Chart (Zero Label Truncation) */
 function drawHorizontalBars() {
 var env = prepareCanvas('chartBars');
 if (!env) return;
 var ctx = env.ctx, w = env.w, h = env.h;
 var pal = getPalette();
 hitRegions.chartBars = [];

 var items = isEn() ? [
 { label: 'Grand Theft Auto VI Metacritic Score (Nov 18, 2026)', val: 99.0, unit: ' pts', cStart: '#34D399', cEnd: '#16A34A', sub: '125+ Reviews · All-Time Tie', note: 'Ties Ocarina of Time (1998) for #1 in Metacritic history; sole 21st-century 99' },
 { label: 'GTA V & Red Dead Redemption 2 Metacritic Benchmark', val: 97.0, unit: ' pts', cStart: '#3399FF', cEnd: '#0073E6', sub: '3 Straight ≥97 Flagships', note: 'Rockstar North/Studios delivered 97+ across three consecutive mainline epics' },
 { label: 'Zelda: Tears of the Kingdom Metacritic Reference (2023)', val: 96.0, unit: ' pts', cStart: '#60A5FA', cEnd: '#2563EB', sub: '96 / 100 · $69.99 Pioneer', note: 'Prior console generation high-water mark before GTA VI reached 99' },
 { label: 'Cyberpunk 2077 PC Launch Metacritic Baseline (Dec 2020)', val: 86.0, unit: ' pts', cStart: '#FBBF24', cEnd: '#D97706', sub: '86 PC (PS4 Delisted)', note: 'Illustrates the steep reputational cost of shipping before console optimization' },
 { label: 'Est. $99.99 Ultimate Edition Share of Pre-Orders (2026)', val: 77.0, unit: '%', cStart: '#A78BFA', cEnd: '#7C3AED', sub: 'TechPowerUp Est. Mix', note: 'High-tier Ultimate Edition demand substantially boosted pre-launch ASP' },
 { label: 'PlayStation 5 Share of Recent GTA Ecosystem Sales (Nov 2026)', val: 54.2, unit: '%', cStart: '#38BDF8', cEnd: '#0284C7', sub: 'PS5 54.2% · Steam 25.2%', note: 'Alinea Analytics: PS5 leads console ecosystem engagement entering GTA VI launch' }
 ] : [
 { label: 'Grand Theft Auto VI 权威媒体综合评分 Metacritic (2026.11)', val: 99.0, unit: ' 分', cStart: '#34D399', cEnd: '#16A34A', sub: '125+篇评测 · 并列历史第一', note: '追平 1998 年《时之笛》，成为 21 世纪唯一斩获 99 分的殿堂级作品' },
 { label: '前作 GTA V 与《荒野大镖客：救赎2》Metacritic 历史基准', val: 97.0, unit: ' 分', cStart: '#3399FF', cEnd: '#0073E6', sub: '连续三代正统旗舰 ≥97分', note: '印证 Rockstar 跨世代长周期打磨体系极高的品控稳定性' },
 { label: '《塞尔达传说：王国之泪》Metacritic 世代参照 (2023)', val: 96.0, unit: ' 分', cStart: '#60A5FA', cEnd: '#2563EB', sub: '96 / 100 · $69.99 破冰代表', note: '本世代第一方开放世界高分标杆，被 GTA VI 以 99 分再度刷新上限' },
 { label: '《赛博朋克 2077》PC 首发版 Metacritic 对照 (2020.12)', val: 86.0, unit: ' 分', cStart: '#FBBF24', cEnd: '#D97706', sub: 'PC 86分 (PS4版曾下架)', note: '凸显超大型开放世界仓促抢发的风险，验证 GTA VI 两次延期打磨的必要性' },
 { label: 'GTA 6 早期预购中 $99.99 终极版估算占比 (行业监测)', val: 77.0, unit: '%', cStart: '#A78BFA', cEnd: '#7C3AED', sub: 'TechPowerUp 援引行业估算', note: '核心玩家高度青睐含专属任务、载具与服饰的 $99.99 Ultimate Edition' },
 { label: '2026年11月 GTA 生态新购平台 PS5 份额 (Alinea 数据)', val: 54.2, unit: '%', cStart: '#38BDF8', cEnd: '#0284C7', sub: 'PS5 54.2% · Steam 25.2%', note: 'PS5 与 PS5 Pro 构成 GTA VI 首发期最核心主机硬件基本盘' }
 ];

 var pad = { top: 10, right: 18, bottom: 26, left: 18 };
 var pw = w - pad.left - pad.right;
 var ph = h - pad.top - pad.bottom;
 var maxX = 100;

 for (var g = 0; g <= 5; g++) {
 var xVal = g * 20;
 var gx = pad.left + (xVal / maxX) * pw;
 ctx.strokeStyle = pal.grid;
 ctx.lineWidth = 1;
 ctx.beginPath();
 ctx.moveTo(gx, pad.top);
 ctx.lineTo(gx, pad.top + ph);
 ctx.stroke();

 ctx.fillStyle = pal.tick;
 ctx.font = '10.5px "IBM Plex Mono", sans-serif';
 ctx.textAlign = g === 0 ? 'left' : (g === 5 ? 'right' : 'center');
 ctx.textBaseline = 'alphabetic';
 ctx.fillText(String(xVal), gx, pad.top + ph + 18);
 }

 var rowH = ph / items.length;

 /* 95-Point Hall-of-Fame Dashed Line across Top 4 Metascore Rows */
 var targetX = pad.left + (95 / maxX) * pw;
 ctx.save();
 ctx.setLineDash([4, 4]);
 ctx.strokeStyle = pal.c3;
 ctx.lineWidth = 1.5;
 ctx.beginPath();
 ctx.moveTo(targetX, pad.top + 4);
 ctx.lineTo(targetX, pad.top + rowH * 4 - 4);
 ctx.stroke();
 ctx.restore();

 for (var i = 0; i < items.length; i++) {
 var rowTop = pad.top + rowH * i;
 if (hoverState.chartBars === i) {
 ctx.fillStyle = pal.hoverBand;
 roundRectPath(ctx, pad.left - 6, rowTop + 2, pw + 12, rowH - 4, 8);
 ctx.fill();
 }

 var labelY = rowTop + Math.max(15, rowH * 0.34);
 var barY = rowTop + Math.max(22, rowH * 0.50);
 var barH = Math.min(15, Math.max(11, rowH * 0.26));
 var bw = Math.max(8, (items[i].val / maxX) * pw);

 ctx.fillStyle = pal.text;
 ctx.font = '600 ' + (w < 460 ? '11px' : '12px') + ' system-ui, sans-serif';
 ctx.textAlign = 'left';
 ctx.textBaseline = 'alphabetic';
 ctx.fillText(items[i].label, pad.left, labelY);

 var valStr = items[i].val.toFixed(1) + items[i].unit;
 ctx.font = '800 12.5px "IBM Plex Mono", sans-serif';
 ctx.fillStyle = pal.isDark ? items[i].cStart : items[i].cEnd;
 ctx.textAlign = 'right';
 ctx.fillText(valStr, pad.left + pw, labelY);

 if (w >= 580) {
 var valW = ctx.measureText(valStr).width + 10;
 ctx.font = '500 11px "IBM Plex Mono", system-ui, sans-serif';
 ctx.fillStyle = pal.tick;
 ctx.fillText(items[i].sub, pad.left + pw - valW, labelY);
 }

 ctx.fillStyle = pal.trackBg;
 roundRectPath(ctx, pad.left, barY, pw, barH, barH / 2);
 ctx.fill();

 var barGrad = ctx.createLinearGradient(pad.left, 0, pad.left + bw, 0);
 barGrad.addColorStop(0, items[i].cStart);
 barGrad.addColorStop(1, items[i].cEnd);
 ctx.fillStyle = barGrad;
 roundRectPath(ctx, pad.left, barY, bw, barH, barH / 2);
 ctx.fill();

 hitRegions.chartBars.push({
 idx: i,
 x: pad.left, y: rowTop, w: pw, h: rowH,
 html: isEn()
 ? ('<strong>' + items[i].label + ': ' + valStr + '</strong><br/>• Context: ' + items[i].sub + '<br/>• Takeaway: ' + items[i].note)
 : ('<strong>' + items[i].label + '：' + valStr + '</strong><br/>• 数据口径：' + items[i].sub + '<br/>• 深度解读：' + items[i].note)
 });
 }
 }

 /* Chart 4: Blockbuster Opening / Pre-Launch Unit Sales (M) vs Metacritic Score */
 function drawEpsComboChart() {
 var env = prepareCanvas('chartEps');
 if (!env) return;
 var ctx = env.ctx, w = env.w, h = env.h;
 var pal = getPalette();
 hitRegions.chartEps = [];

 var titles = isEn()
 ? ['CP 2077', 'Zelda TotK', 'GTA V', 'RDR 2', 'GTA VI']
 : ['赛博朋克2077', '王国之泪', 'GTA V', '荒野大镖客2', 'GTA VI'];
 var subTitles = isEn()
 ? ['(Pre-Orders)', '(First 3d)', '(First 24h)', '(First 13d)', '(Pre-Orders Only)']
 : ['(发售前预购)', '(首3日销量)', '(首24h吉尼斯)', '(首13日出货)', '(仅发售前预购)'];
 var unitsM = [8.0, 10.0, 11.21, 17.0, 19.0];
 var metaScores = [86.0, 96.0, 97.0, 97.0, 99.0];

 var pad = { top: 26, right: 50, bottom: 44, left: 48 };
 var pw = w - pad.left - pad.right;
 var ph = h - pad.top - pad.bottom;

 var minU = 0, maxU = 24.0;
 var minM = 80.0, maxM = 100.0;

 for (var g = 0; g <= 4; g++) {
 var ratio = g / 4;
 var gy = pad.top + ph - ratio * ph;
 ctx.strokeStyle = pal.grid;
 ctx.lineWidth = 1;
 ctx.beginPath();
 ctx.moveTo(pad.left, gy);
 ctx.lineTo(pad.left + pw, gy);
 ctx.stroke();

 var uTick = minU + ratio * (maxU - minU);
 var mTick = minM + ratio * (maxM - minM);
 ctx.font = '11px "IBM Plex Mono", sans-serif';
 ctx.textBaseline = 'middle';
 ctx.fillStyle = pal.tick;
 ctx.textAlign = 'right';
 ctx.fillText(uTick.toFixed(0) + 'M', pad.left - 7, gy);
 ctx.textAlign = 'left';
 ctx.fillStyle = pal.c2;
 ctx.fillText(mTick.toFixed(0), pad.left + pw + 7, gy);
 }

 /* 95.0 Hall-of-Fame Threshold Dashed Line */
 var targetY = pad.top + ph - ((95.0 - minM) / (maxM - minM)) * ph;
 ctx.save();
 ctx.setLineDash([5, 5]);
 ctx.strokeStyle = pal.c3;
 ctx.lineWidth = 1.5;
 ctx.beginPath();
 ctx.moveTo(pad.left, targetY);
 ctx.lineTo(pad.left + pw, targetY);
 ctx.stroke();
 ctx.restore();

 var step = pw / titles.length;
 var barW = Math.min(48, Math.max(24, step * 0.42));
 var linePts = [];

 for (var i = 0; i < titles.length; i++) {
 var cx = pad.left + step * (i + 0.5);
 if (hoverState.chartEps === i) {
 ctx.fillStyle = pal.hoverBand;
 roundRectPath(ctx, pad.left + step * i + 4, pad.top, step - 8, ph, 6);
 ctx.fill();
 }

 if (state.epsSeries.rev) {
 var bh = ((unitsM[i] - minU) / (maxU - minU)) * ph;
 var bx = cx - barW / 2;
 var by = pad.top + ph - bh;
 var eGrad = ctx.createLinearGradient(0, by, 0, pad.top + ph);
 if (i === 4) {
 eGrad.addColorStop(0, '#66B2FF');
 eGrad.addColorStop(1, '#0073E6');
 } else {
 eGrad.addColorStop(0, '#3399FF');
 eGrad.addColorStop(1, '#0059B2');
 }
 ctx.fillStyle = eGrad;
 topRoundedBar(ctx, bx, by, barW, bh, 6);
 ctx.fill();

 ctx.fillStyle = '#FFFFFF';
 ctx.font = '700 10.5px "IBM Plex Mono", sans-serif';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'alphabetic';
 ctx.fillText((i === 4 ? '>19M' : unitsM[i].toFixed(1) + 'M'), cx, by + 17);
 }

 var oy = pad.top + ph - ((metaScores[i] - minM) / (maxM - minM)) * ph;
 linePts.push({ x: cx, y: oy, mc: metaScores[i] });

 ctx.fillStyle = pal.text;
 ctx.font = '700 ' + (w < 460 ? '10.5px' : '11.5px') + ' system-ui, sans-serif';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'alphabetic';
 ctx.fillText(titles[i], cx, pad.top + ph + 19);
 ctx.fillStyle = pal.tick;
 ctx.font = '10px system-ui, sans-serif';
 ctx.fillText(subTitles[i], cx, pad.top + ph + 33);

 hitRegions.chartEps.push({
 idx: i,
 x: pad.left + step * i, y: pad.top, w: step, h: ph + 36,
 html: isEn()
 ? ('<strong>' + titles[i] + ' ' + subTitles[i] + '</strong><br/>' +
 '• Window Volume: <strong>' + (i === 4 ? '>19.0M copies (>$1.8B)' : unitsM[i] + 'M copies') + '</strong><br/>' +
 '• Metacritic Score: <strong>' + metaScores[i].toFixed(0) + ' / 100</strong>')
 : ('<strong>' + titles[i] + ' ' + subTitles[i] + '</strong><br/>' +
 '• 对应窗口销量：<strong>' + (i === 4 ? '>1,900万份 (预售超$18亿)' : unitsM[i] + 'M 份') + '</strong><br/>' +
 '• Metacritic 媒体均分：<strong>' + metaScores[i].toFixed(0) + ' / 100</strong>')
 });
 }

 if (w >= 480) {
 drawValueBadge(ctx, isEn() ? 'Hall of Fame 95' : '95分神作线', pad.left + pw * 0.22, targetY + 13, pal.c3, pal);
 }

 if (state.epsSeries.oci) {
 ctx.save();
 drawSmoothLine(ctx, linePts);
 ctx.strokeStyle = pal.c2;
 ctx.lineWidth = 2.8;
 ctx.stroke();
 ctx.restore();

 for (var m = 0; m < linePts.length; m++) {
 ctx.fillStyle = pal.pillBg;
 ctx.beginPath();
 ctx.arc(linePts[m].x, linePts[m].y, 6, 0, Math.PI * 2);
 ctx.fill();
 ctx.fillStyle = pal.c2;
 ctx.beginPath();
 ctx.arc(linePts[m].x, linePts[m].y, 4.2, 0, Math.PI * 2);
 ctx.fill();
 drawValueBadge(ctx, 'MC ' + linePts[m].mc.toFixed(0), linePts[m].x, Math.max(12, linePts[m].y - 15), pal.c2, pal);
 }
 }
 }

 /* Chart 5: Lifecycle Gross Bookings Simulator Dual-Curve + Crosshair Chart */
 function drawSimChart() {
 var env = prepareCanvas('chartSim');
 if (!env) return;
 var ctx = env.ctx, w = env.w, h = env.h;
 var pal = getPalette();
 hitRegions.chartSim = [];

 var simRes = computeLifecycleSeries();
 var yrs = simRes.yrs;
 var totalSeries = simRes.cumTotalB;
 var boxOnlySeries = simRes.cumBoxB;

 var maxVal = Math.max(totalSeries[yrs], 5.0) * 1.12;
 var pad = { top: 20, right: 20, bottom: 28, left: 54 };
 var pw = w - pad.left - pad.right;
 var ph = h - pad.top - pad.bottom;

 for (var g = 0; g <= 3; g++) {
 var v = (maxVal / 3) * g;
 var gy = pad.top + ph - (g / 3) * ph;
 ctx.strokeStyle = pal.grid;
 ctx.lineWidth = 1;
 ctx.beginPath();
 ctx.moveTo(pad.left, gy);
 ctx.lineTo(pad.left + pw, gy);
 ctx.stroke();

 ctx.fillStyle = pal.tick;
 ctx.font = '10.5px "IBM Plex Mono", sans-serif';
 ctx.textAlign = 'right';
 ctx.textBaseline = 'middle';
 ctx.fillText('$' + v.toFixed(1) + 'B', pad.left - 7, gy);
 }

 var stepX = pw / yrs;

 /* Full-game box-only dashed curve */
 ctx.save();
 ctx.setLineDash([4, 4]);
 ctx.strokeStyle = pal.tick;
 ctx.lineWidth = 1.7;
 ctx.beginPath();
 for (var i = 0; i <= yrs; i++) {
 var px = pad.left + (i / yrs) * pw;
 var py = pad.top + ph - (boxOnlySeries[i] / maxVal) * ph;
 if (i === 0) ctx.moveTo(px, py);
 else ctx.lineTo(px, py);
 }
 ctx.stroke();
 ctx.restore();

 /* Cumulative Total Bookings (Box + Online/UGC) solid curve & area */
 ctx.beginPath();
 for (var j = 0; j <= yrs; j++) {
 var tx = pad.left + (j / yrs) * pw;
 var ty = pad.top + ph - (totalSeries[j] / maxVal) * ph;
 if (j === 0) ctx.moveTo(tx, ty);
 else ctx.lineTo(tx, ty);

 var liveDiff = totalSeries[j] - boxOnlySeries[j];
 hitRegions.chartSim.push({
 idx: j,
 x: tx - Math.max(6, stepX * 0.5), y: pad.top, w: Math.max(12, stepX), h: ph + 24,
 html: isEn()
 ? ('<strong>Year ' + j + ' Cumulative Monetization</strong><br/>' +
 '• Total Ecosystem Bookings: <strong>$' + totalSeries[j].toFixed(2) + 'B</strong><br/>' +
 '• Full-Game Box Revenue: $' + boxOnlySeries[j].toFixed(2) + 'B<br/>' +
 '• Online + Cfx.re UGC Lift: <strong style="color:#22C55E;">+$' + liveDiff.toFixed(2) + 'B</strong>')
 : ('<strong>发售后第 ' + j + ' 年累计流水对比</strong><br/>' +
 '• 全生态累计总流水：<strong>$' + totalSeries[j].toFixed(2) + 'B</strong><br/>' +
 '• 仅买断制本体累计：$' + boxOnlySeries[j].toFixed(2) + 'B<br/>' +
 '• 在线模式 + UGC 增量：<strong style="color:#22C55E;">+$' + liveDiff.toFixed(2) + 'B</strong>')
 });
 }
 ctx.strokeStyle = pal.c1;
 ctx.lineWidth = 2.8;
 ctx.stroke();

 ctx.lineTo(pad.left + pw, pad.top + ph);
 ctx.lineTo(pad.left, pad.top + ph);
 ctx.closePath();
 var grad = ctx.createLinearGradient(0, pad.top, 0, pad.top + ph);
 grad.addColorStop(0, 'rgba(0, 115, 230, 0.30)');
 grad.addColorStop(1, 'rgba(0, 115, 230, 0.01)');
 ctx.fillStyle = grad;
 ctx.fill();

 var midYr = Math.max(1, Math.floor(yrs / 2));
 var keyYears = [0, 1, midYr, yrs];
 if (hoverState.chartSim >= 0 && hoverState.chartSim <= yrs) {
 var hi = hoverState.chartSim;
 var hx = pad.left + (hi / yrs) * pw;
 var hy1 = pad.top + ph - (totalSeries[hi] / maxVal) * ph;
 var hy2 = pad.top + ph - (boxOnlySeries[hi] / maxVal) * ph;
 ctx.save();
 ctx.setLineDash([3, 3]);
 ctx.strokeStyle = pal.c1;
 ctx.lineWidth = 1.2;
 ctx.beginPath();
 ctx.moveTo(hx, pad.top);
 ctx.lineTo(hx, pad.top + ph);
 ctx.stroke();
 ctx.restore();

 ctx.fillStyle = pal.tick;
 ctx.beginPath();
 ctx.arc(hx, hy2, 4, 0, Math.PI * 2);
 ctx.fill();
 ctx.fillStyle = pal.c1;
 ctx.beginPath();
 ctx.arc(hx, hy1, 5.5, 0, Math.PI * 2);
 ctx.fill();
 }

 for (var ky = 0; ky < keyYears.length; ky++) {
 var yrIdx = keyYears[ky];
 var kx = pad.left + (yrIdx / yrs) * pw;
 var kyY = pad.top + ph - (totalSeries[yrIdx] / maxVal) * ph;
 ctx.fillStyle = pal.pillBg;
 ctx.beginPath();
 ctx.arc(kx, kyY, 5, 0, Math.PI * 2);
 ctx.fill();
 ctx.fillStyle = pal.c1;
 ctx.beginPath();
 ctx.arc(kx, kyY, 3.5, 0, Math.PI * 2);
 ctx.fill();
 }

 var endX = pad.left + pw;
 var endY = pad.top + ph - (totalSeries[yrs] / maxVal) * ph;
 drawValueBadge(ctx, '$' + totalSeries[yrs].toFixed(2) + 'B', Math.min(w - 42, endX - 24), Math.max(pad.top + 12, endY - 14), pal.c1, pal);

 ctx.fillStyle = pal.tick;
 ctx.font = '10.5px "IBM Plex Mono", sans-serif';
 ctx.textBaseline = 'alphabetic';
 ctx.textAlign = 'left';
 ctx.fillText(isEn() ? 'Launch' : '首发起点', pad.left, pad.top + ph + 19);
 ctx.textAlign = 'center';
 ctx.fillText((isEn() ? ('Year ' + midYr) : ('第 ' + midYr + ' 年')) + ' ($' + totalSeries[midYr].toFixed(1) + 'B)', pad.left + (midYr / yrs) * pw, pad.top + ph + 19);
 ctx.textAlign = 'right';
 ctx.fillText(isEn() ? ('Year ' + yrs) : ('第 ' + yrs + ' 年'), pad.left + pw, pad.top + ph + 19);
 }

 var redrawMap = {
 chartCh1: drawCh1Chart,
 chartRadar: drawRadarChart,
 chartBars: drawHorizontalBars,
 chartEps: drawEpsComboChart,
 chartSim: drawSimChart
 };

 function renderAllCharts() {
 drawCh1Chart();
 drawRadarChart();
 drawHorizontalBars();
 drawEpsComboChart();
 drawSimChart();
 }

 /* ======================================================================
 7. Hover & Touch Tooltips + Active Crosshair Redraw
 ====================================================================== */
 function wireCanvasTooltip(canvasId) {
 var canvas = document.getElementById(canvasId);
 var tip = document.getElementById('chartTooltip');
 if (!canvas || !tip) return;

 function handlePointer(clientX, clientY) {
 var rect = canvas.getBoundingClientRect();
 var mx = clientX - rect.left;
 var my = clientY - rect.top;
 var regions = hitRegions[canvasId] || [];
 var found = null;
 for (var i = 0; i < regions.length; i++) {
 var r = regions[i];
 if (mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h) {
 found = r;
 break;
 }
 }
 var nextIdx = found && typeof found.idx === 'number' ? found.idx : -1;
 if (hoverState[canvasId] !== nextIdx) {
 hoverState[canvasId] = nextIdx;
 if (redrawMap[canvasId]) redrawMap[canvasId]();
 }
 if (found) {
 tip.innerHTML = found.html;
 tip.style.display = 'block';
 var tipW = tip.offsetWidth || 255;
 var tipH = tip.offsetHeight || 72;
 var leftPos = clientX + 14;
 if (leftPos + tipW > window.innerWidth - 12) {
 leftPos = Math.max(12, clientX - tipW - 14);
 }
 var topPos = Math.max(12, Math.min(window.innerHeight - tipH - 12, clientY - 18));
 tip.style.left = leftPos + 'px';
 tip.style.top = topPos + 'px';
 } else {
 tip.style.display = 'none';
 }
 }

 canvas.addEventListener('mousemove', function (e) {
 handlePointer(e.clientX, e.clientY);
 });

 canvas.addEventListener('touchstart', function (e) {
 if (e.touches && e.touches[0]) {
 handlePointer(e.touches[0].clientX, e.touches[0].clientY);
 }
 }, { passive: true });

 canvas.addEventListener('mouseleave', function () {
 if (hoverState[canvasId] !== -1) {
 hoverState[canvasId] = -1;
 if (redrawMap[canvasId]) redrawMap[canvasId]();
 }
 tip.style.display = 'none';
 });
 }

 /* ======================================================================
 8. Standalone HTML Download Export
 ====================================================================== */
 function exportStandaloneHtml() {
 var doctype = '<!DOCTYPE html>' + String.fromCharCode(10);
 var htmlContent = doctype + document.documentElement.outerHTML;
 var blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
 var url = URL.createObjectURL(blob);
 var link = document.createElement('a');
 link.href = url;
 link.download = 'GTA6_Product_Analysis.html';
 document.body.appendChild(link);
 link.click();
 document.body.removeChild(link);
 setTimeout(function () {
 URL.revokeObjectURL(url);
 }, 1500);
 showToast(isEn() ? 'Exported standalone file: GTA6_Product_Analysis.html' : '已导出独立网页 GTA6_Product_Analysis.html');
 }

 /* ======================================================================
 9. Event Listeners & Initialization
 ====================================================================== */
 function init() {
 var rawTheme = safeGetStorage(STORAGE_THEME_KEY);
 var savedTheme = rawTheme ? String(rawTheme).replace(/^"|"$/g, '') : '';
 if (savedTheme === 'light' || savedTheme === 'dark') {
 state.theme = savedTheme;
 }
 var rawLang = safeGetStorage(STORAGE_LANG_KEY);
 var savedLang = rawLang ? String(rawLang).replace(/^"|"$/g, '') : '';
 if (savedLang === 'zh' || savedLang === 'en') {
 state.lang = savedLang;
 }
 window.addEventListener('storage', function (ev) {
 if (ev.key === STORAGE_THEME_KEY && ev.newValue) {
 var nt = String(ev.newValue).replace(/^"|"$/g, '');
 if ((nt === 'light' || nt === 'dark') && nt !== state.theme) applyTheme(nt, true);
 } else if (ev.key === STORAGE_LANG_KEY && ev.newValue) {
 var nl = String(ev.newValue).replace(/^"|"$/g, '');
 if ((nl === 'zh' || nl === 'en') && nl !== state.lang) applyLanguage(nl, true);
 }
 });
 var savedChecks = safeGetStorage(STORAGE_CHECK_KEY);
 if (savedChecks) {
 try {
 var parsed = JSON.parse(savedChecks);
 if (Array.isArray(parsed) && parsed.length === CHECKLIST_ITEMS.length) {
 state.checks = parsed.map(Boolean);
 }
 } catch (e) {
 /* Ignore malformed storage */
 }
 }

 applyTheme(state.theme, true);
 applyLanguage(state.lang, true);

 document.getElementById('langZhBtn').addEventListener('click', function () { applyLanguage('zh', false); });
 document.getElementById('langEnBtn').addEventListener('click', function () { applyLanguage('en', false); });
 var abThm = document.getElementById('appbarThemeBtn');
 if (abThm) {
 abThm.addEventListener('click', function () { applyTheme(state.theme === 'dark' ? 'light' : 'dark', false); });
 }

 /* Sidebar & Theme Controls */
 document.getElementById('sidebarToggleBtn').addEventListener('click', toggleSidebar);
 document.getElementById('drawerBackdrop').addEventListener('click', closeMobileDrawer);
 void 0;
 void 0;

 /* Sidebar Export & Print Buttons */
 void 0;
 void 0;

 /* Close mobile drawer on TOC click */
 var tocLinks = document.querySelectorAll('#tocNavList .mui-nav-link');
 for (var t = 0; t < tocLinks.length; t++) {
 tocLinks[t].addEventListener('click', closeMobileDrawer);
 }

 /* Quick Jump Search (Ctrl+K / Cmd+K) */
 var jumpInput = document.getElementById('quickJumpInput');
 var jumpPop = document.getElementById('quickJumpPopover');
 function renderJumpList(q) {
 var kw = (q || '').trim().toLowerCase();
 var activeJump = isEn() ? QUICK_JUMP_EN : QUICK_JUMP_INDEX;
 var list = activeJump.filter(function (item, idx) {
 var zhIt = QUICK_JUMP_INDEX[idx] || item;
 var enIt = QUICK_JUMP_EN[idx] || item;
 return !kw || (zhIt.title + ' ' + zhIt.sub + ' ' + enIt.title + ' ' + enIt.sub).toLowerCase().indexOf(kw) !== -1;
 });
 if (!list.length) {
 jumpPop.innerHTML = '<div style="padding:10px;font-size:0.78rem;color:var(--text-muted);">' + (isEn() ? 'No matching section' : '未匹配到对应章节') + '</div>';
 } else {
 jumpPop.innerHTML = list.map(function (item) {
 return '<button type="button" class="quick-jump-item" data-jump-sec="' + item.sec + '">' +
 '<span class="quick-jump-item-title">' + escapeHtml(item.title) + '</span>' +
 '<span class="quick-jump-item-sub">' + escapeHtml(item.sub) + '</span>' +
 '</button>';
 }).join('');
 }
 jumpPop.classList.add('open');
 }

 jumpInput.addEventListener('focus', function () { renderJumpList(jumpInput.value); });
 jumpInput.addEventListener('input', function () { renderJumpList(jumpInput.value); });
 jumpPop.addEventListener('click', function (e) {
 var btn = e.target.closest('[data-jump-sec]');
 if (!btn) return;
 var targetId = btn.getAttribute('data-jump-sec');
 var secEl = document.getElementById(targetId);
 if (secEl) secEl.scrollIntoView({ behavior: 'smooth' });
 jumpPop.classList.remove('open');
 });
 document.addEventListener('click', function (e) {
 if (!e.target.closest('.quick-search-wrap')) {
 jumpPop.classList.remove('open');
 }
 });
 document.addEventListener('keydown', function (e) {
 if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
 e.preventDefault();
 jumpInput.focus();
 } else if (e.key === 'Escape') {
 jumpPop.classList.remove('open');
 closeMobileDrawer();
 }
 });

 /* Ch 01 View A / View B Tabs */
 var ch1Btns = document.querySelectorAll('[data-ch1-view]');
 for (var c = 0; c < ch1Btns.length; c++) {
 ch1Btns[c].addEventListener('click', function () {
 state.ch1View = this.getAttribute('data-ch1-view');
 document.getElementById('ch1TabA').classList.toggle('active', state.ch1View === 'viewA');
 document.getElementById('ch1TabB').classList.toggle('active', state.ch1View === 'viewB');
 syncCh1HeaderText();
 drawCh1Chart();
 });
 }

 /* Expandable Matrix Card Collapses */
 var collapseBtns = document.querySelectorAll('[data-collapse-target]');
 for (var m = 0; m < collapseBtns.length; m++) {
 collapseBtns[m].addEventListener('click', function () {
 var panelId = this.getAttribute('data-collapse-target');
 var panel = document.getElementById(panelId);
 if (!panel) return;
 panel.classList.toggle('open');
 syncCollapseButtonsText();
 });
 }

 /* Ch 02 Pillar Selection & Radar Legend Toggles */
 var pillarCards = document.querySelectorAll('[data-pillar]');
 for (var p = 0; p < pillarCards.length; p++) {
 pillarCards[p].addEventListener('click', function () {
 var idx = parseInt(this.getAttribute('data-pillar'), 10) || 0;
 state.activePillar = idx;
 for (var k = 0; k < pillarCards.length; k++) {
 pillarCards[k].classList.toggle('active', k === idx);
 }
 document.getElementById('pillarFocusNote').innerHTML = '<div>' + (isEn() ? PILLAR_NOTES_EN : PILLAR_NOTES)[idx] + '</div>';
 drawRadarChart();
 });
 }

 var radarPills = document.querySelectorAll('[data-radar-key]');
 for (var r = 0; r < radarPills.length; r++) {
 radarPills[r].addEventListener('click', function () {
 var key = this.getAttribute('data-radar-key');
 state.radarSeries[key] = !state.radarSeries[key];
 if (!state.radarSeries.gta6 && !state.radarSeries.gta5 && !state.radarSeries.cp2077) {
 state.radarSeries[key] = true;
 }
 this.classList.toggle('muted', !state.radarSeries[key]);
 drawRadarChart();
 });
 }

 /* Ch 03 Peer Search & Filter */
 document.getElementById('peerSearchInput').addEventListener('input', function () {
 state.peerQuery = this.value;
 renderPeerTable();
 });
 var peerFilterBtns = document.querySelectorAll('[data-peer-filter]');
 for (var pf = 0; pf < peerFilterBtns.length; pf++) {
 peerFilterBtns[pf].addEventListener('click', function () {
 state.peerFilter = this.getAttribute('data-peer-filter');
 for (var x = 0; x < peerFilterBtns.length; x++) {
 peerFilterBtns[x].classList.toggle('active', peerFilterBtns[x] === this);
 }
 renderPeerTable();
 });
 }

 /* Ch 04 Simulator Controls */
 var uSlider = document.getElementById('simPrincipalSlider');
 var aSlider = document.getElementById('simCagrSlider');
 var lSlider = document.getElementById('simLiveArpuSlider');
 var ySlider = document.getElementById('simYearsSlider');
 var dToggle = document.getElementById('simDripToggle');

 uSlider.addEventListener('input', function () {
 state.sim.units = parseFloat(this.value) || 175;
 state.sim.preset = '';
 updateSimulatorUI();
 });
 aSlider.addEventListener('input', function () {
 state.sim.asp = parseFloat(this.value) || 76;
 state.sim.preset = '';
 updateSimulatorUI();
 });
 lSlider.addEventListener('input', function () {
 state.sim.liveArpu = parseFloat(this.value) || 0;
 state.sim.preset = '';
 updateSimulatorUI();
 });
 ySlider.addEventListener('input', function () {
 state.sim.years = parseInt(this.value, 10) || 8;
 state.sim.preset = '';
 updateSimulatorUI();
 });
 dToggle.addEventListener('change', function () {
 state.sim.pcUgc = !!this.checked;
 updateSimulatorUI();
 });

 var presetBtns = document.querySelectorAll('[data-preset]');
 for (var pb = 0; pb < presetBtns.length; pb++) {
 presetBtns[pb].addEventListener('click', function () {
 var key = this.getAttribute('data-preset');
 var cfg = PRESETS[key];
 if (!cfg) return;
 state.sim.units = cfg.units;
 state.sim.asp = cfg.asp;
 state.sim.liveArpu = cfg.liveArpu;
 state.sim.years = cfg.years;
 state.sim.pcUgc = cfg.pcUgc;
 state.sim.preset = key;
 uSlider.value = String(cfg.units);
 aSlider.value = String(cfg.asp);
 lSlider.value = String(cfg.liveArpu);
 ySlider.value = String(cfg.years);
 dToggle.checked = cfg.pcUgc;
 updateSimulatorUI();
 });
 }

 /* Ch 06 Checklist Controls */
 document.getElementById('checklistContainer').addEventListener('change', function (e) {
 var input = e.target.closest('[data-check-input]');
 if (!input) return;
 var idx = parseInt(input.getAttribute('data-check-input'), 10);
 state.checks[idx] = !!input.checked;
 safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
 renderChecklist();
 });
 document.getElementById('checkAllBtn').addEventListener('click', function () {
 state.checks = [true, true, true, true, true, true];
 safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
 renderChecklist();
 showToast(isEn() ? 'Checked all 6 GTA VI mega-IP moat criteria' : '已勾选全部 6 项 GTA 6 现象级护城河核查指标');
 });
 document.getElementById('resetCheckBtn').addEventListener('click', function () {
 state.checks = [true, true, true, true, false, false];
 safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
 renderChecklist();
 showToast(isEn() ? 'Checklist reset to baseline (67%)' : '核查清单已恢复默认基准状态 (67%)');
 });

 /* Reading Progress & Scroll-Spy */
 function updateScrollProgress() {
 var docEl = document.documentElement;
 var scrollTop = window.scrollY || docEl.scrollTop || 0;
 var maxScroll = Math.max(1, docEl.scrollHeight - window.innerHeight);
 var pct = Math.min(100, Math.max(0, (scrollTop / maxScroll) * 100));
 document.getElementById('readingProgressBar').style.width = pct + '%';
 }
 window.addEventListener('scroll', updateScrollProgress, { passive: true });
 updateScrollProgress();

 if ('IntersectionObserver' in window) {
 var secObserver = new IntersectionObserver(function (entries) {
 entries.forEach(function (entry) {
 if (entry.isIntersecting) {
 var id = entry.target.id;
 for (var i = 0; i < tocLinks.length; i++) {
 tocLinks[i].classList.toggle('active', tocLinks[i].getAttribute('data-sec') === id);
 }
 }
 });
 }, { rootMargin: '-18% 0px -68% 0px', threshold: 0.02 });

 for (var s = 0; s <= 7; s++) {
 var secNode = document.getElementById('sec-0' + s);
 if (secNode) secObserver.observe(secNode);
 }
 }

 /* Wire Tooltips & Resize Redraw */
 wireCanvasTooltip('chartCh1');
 wireCanvasTooltip('chartRadar');
 wireCanvasTooltip('chartBars');
 wireCanvasTooltip('chartEps');
 wireCanvasTooltip('chartSim');

 /* Wire Ch1 & Ch4 Legend Series Toggles */
 var ch1SeriesBtns = document.querySelectorAll('[data-ch1-series]');
 for (var csIdx = 0; csIdx < ch1SeriesBtns.length; csIdx++) {
 ch1SeriesBtns[csIdx].addEventListener('click', function () {
 var sk = this.getAttribute('data-ch1-series');
 state.ch1Series[sk] = !state.ch1Series[sk];
 if (!state.ch1Series.s1 && !state.ch1Series.s2) state.ch1Series[sk] = true;
 this.classList.toggle('muted', !state.ch1Series[sk]);
 drawCh1Chart();
 });
 }

 var epsSeriesBtns = document.querySelectorAll('[data-eps-series]');
 for (var esIdx = 0; esIdx < epsSeriesBtns.length; esIdx++) {
 epsSeriesBtns[esIdx].addEventListener('click', function () {
 var ek = this.getAttribute('data-eps-series');
 state.epsSeries[ek] = !state.epsSeries[ek];
 if (!state.epsSeries.rev && !state.epsSeries.oci) state.epsSeries[ek] = true;
 this.classList.toggle('muted', !state.epsSeries[ek]);
 drawEpsComboChart();
 });
 }

 var resizeTimer = null;
 function scheduleRedraw() {
 if (resizeTimer) clearTimeout(resizeTimer);
 resizeTimer = setTimeout(renderAllCharts, 60);
 }
 window.addEventListener('resize', scheduleRedraw);
 if ('ResizeObserver' in window) {
 var mainEl = document.querySelector('.main-content');
 if (mainEl) {
 var ro = new ResizeObserver(scheduleRedraw);
 ro.observe(mainEl);
 }
 }
 }

 if (document.readyState === 'loading') {
 document.addEventListener('DOMContentLoaded', init);
 } else {
 init();
 }
 })();
 