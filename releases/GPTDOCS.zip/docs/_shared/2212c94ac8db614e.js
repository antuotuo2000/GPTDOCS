
    (function () {
      'use strict';

      /* ======================================================================
         1. Grounded Datasets & State Model
         ====================================================================== */
      var STORAGE_THEME_KEY = 'mui_portal_theme_v4';
      var STORAGE_LANG_KEY = 'mui_portal_lang_v1';
      var DOC_TITLE_ZH = '奥驰亚集团 Altria Group (MO) 企业文化与组织架构深度研究报告 | 数据中心';
      var DOC_TITLE_EN = 'Altria Group (MO) Corporate Culture & Organizational Architecture Deep Dive | Research Hub';
      var I18N_RICH_LIST = [{"key": "mo_r00", "match_zh": "奥驰亚集团 Altria Group, Inc. 企业文化与组织架构深度研究报告：", "zh": "奥驰亚集团 Altria Group, Inc. 企业文化与组织架构深度研究报告：<span class=\"gradient-accent\">自我颠覆愿景、强合规基因与高人效现金流堡垒</span>", "en": "Altria Group, Inc. Corporate Culture &amp; Organizational Architecture Deep Dive: <span class=\"gradient-accent\">Self-Disrupting Vision, Regulatory Rigor &amp; High-Efficiency Cash Fortress</span>"}, {"key": "mo_r01", "match_zh": "如何在长达半个世纪的严厉监管", "zh": "如何在长达半个世纪的严厉监管、诉讼围剿与传统卷烟销量持续萎缩中，不仅稳健存续，还创下 <strong>57 年内 61 次上调股息</strong>的“股息之王”纪录？奥驰亚（Altria Group, NYSE: MO）给出的答案是将“自我革新的企业文化”制度化 <a class=\"cite-link\" href=\"https://www.altria.com/about-altria/our-vision-and-cultural-aspiration\" target=\"_blank\" rel=\"noopener noreferrer\">Altria Vision &amp; Culture ↗</a>。 2007–2008 年先后剥离卡夫食品与菲莫国际（PMI）后，奥驰亚砍掉冗余层级，重塑为<strong>“总部战略与资本配置中枢 + 高度专业化运营子公司（PM USA、USSTC、Helix 等）+ 统一销售分销（AGDC）与企业服务（ALCS）共享平台”</strong>的精干架构 <a class=\"cite-link\" href=\"https://www.altria.com/about-altria/At_A_Glance/corporate-fact-sheet\" target=\"_blank\" rel=\"noopener noreferrer\">Altria Fact Sheet ↗</a>。 截至 FY2025，奥驰亚仅凭约 <strong>5,900 名全职员工</strong>（其中工程与科学研发技术岗占比高达 <strong>45.4%</strong>） <a class=\"cite-link\" href=\"https://www.reveliolabs.com/companies/altria-group/employees\" target=\"_blank\" rel=\"noopener noreferrer\">Revelio Labs ↗</a>， 实现净营收 <strong>$232.79 亿</strong>（扣除消费税后净营收 <strong>$201.39 亿</strong>）、总调整后运营公司利润率（OCI Margin）高达 <strong>62.4%</strong>、人均扣税创收达 <strong>$3.41M</strong> <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">Altria FY25 Release ↗</a>。 2026 年 5 月 14 日，逾 30 年资历的原 CFO <strong>萨尔·曼库索（Sal Mancuso）</strong>正式接替退休的比利·吉福德（Billy Gifford）出任 CEO，原 PM USA 总裁 Heather Newman 接任 CFO，带领公司迈向“超越吸烟（Moving Beyond Smoking）”的下一阶段 <a class=\"cite-link\" href=\"https://tobaccoreporter.com/2025/12/11/altria-ceo-gifford-to-retire-in-2026-mancuso-named-successor/\" target=\"_blank\" rel=\"noopener noreferrer\">Tobacco Reporter ↗</a>。", "en": "How has a company endured half a century of stringent regulation, litigation headwinds, and secular cigarette volume declines while delivering <strong>61 dividend increases in 57 years</strong> as an iconic Dividend King? Altria Group (NYSE: MO) institutionalized a culture of deliberate self-disruption <a class=\"cite-link\" href=\"https://www.altria.com/about-altria/our-vision-and-cultural-aspiration\" target=\"_blank\" rel=\"noopener noreferrer\">Altria Vision &amp; Culture ↗</a>. Following the 2007–2008 spin-offs of Kraft Foods and Philip Morris International (PMI), Altria eliminated conglomerate bloat and rebuilt around a lean <strong>\"Holding Capital-Allocation Hub + Specialized Operating Companies (PM USA, USSTC, Helix) + Shared Retail Distribution (AGDC) &amp; Enterprise Science/Compliance Platforms (ALCS)\"</strong> matrix <a class=\"cite-link\" href=\"https://www.altria.com/about-altria/At_A_Glance/corporate-fact-sheet\" target=\"_blank\" rel=\"noopener noreferrer\">Altria Fact Sheet ↗</a>. In FY2025, with just <strong>~5,900 full-time employees</strong> (<strong>45.4%</strong> in engineering and scientific R&amp;D roles) <a class=\"cite-link\" href=\"https://www.reveliolabs.com/companies/altria-group/employees\" target=\"_blank\" rel=\"noopener noreferrer\">Revelio Labs ↗</a>, Altria generated <strong>$23.28B</strong> in net revenues (<strong>$20.14B</strong> net of excise taxes), a <strong>62.4%</strong> total adjusted OCI margin, and <strong>$3.41M</strong> in net revenue per employee <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">Altria FY25 Release ↗</a>. On May 14, 2026, 30+-year veteran CFO <strong>Sal Mancuso</strong> succeeded retiring CEO Billy Gifford alongside incoming CFO Heather Newman, steering the next chapter of <em>Moving Beyond Smoking</em> <a class=\"cite-link\" href=\"https://tobaccoreporter.com/2025/12/11/altria-ceo-gifford-to-retire-in-2026-mancuso-named-successor/\" target=\"_blank\" rel=\"noopener noreferrer\">Tobacco Reporter ↗</a>."}, {"key": "mo_r02", "match_zh": "约 5,900 名员工人均扣税创收", "zh": "约 5,900 名员工人均扣税创收 $341 万、人均净利 $118 万，较 2008 年分拆初期 ($1.53M) 翻倍有余 <a class=\"cite-link\" href=\"https://en.arincen.com/instruments/MO/profile\" target=\"_blank\" rel=\"noopener noreferrer\">Arincen 10-K ↗</a>。", "en": "~5,900 FTEs generate $3.41M in revenue net of excise taxes and $1.18M in net income per employee—more than double FY2008 ($1.53M) <a class=\"cite-link\" href=\"https://en.arincen.com/instruments/MO/profile\" target=\"_blank\" rel=\"noopener noreferrer\">Arincen 10-K ↗</a>."}, {"key": "mo_r03", "match_zh": "依托万宝路 (Marlboro) 与哥本哈根", "zh": "依托万宝路 (Marlboro) 与哥本哈根 (Copenhagen) 定价权，FY25 调整后 OCI 达 $125.68 亿，持续超越 2028 企业目标 <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">FY25 Release ↗</a>。", "en": "Backed by Marlboro and Copenhagen pricing power, FY25 adjusted OCI reached $12.57B, consistently beating the ≥60% 2028 Enterprise Goal <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">FY25 Release ↗</a>."}, {"key": "mo_r04", "match_zh": "FY25 全年派息 $70 亿", "zh": "FY25 全年派息 $70 亿；2026 年 8 月再度上调季度股息 4.7% 至 $1.11/股，达成 57 年内第 61 次上调 <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Increases-Quarterly-Dividend-to-1-11-Per-Share/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">Dividend ↗</a>。", "en": "$7.0B paid in FY25 dividends; hiked quarterly dividend +4.7% to $1.11/sh in Aug 2026—marking 61 increases in 57 years <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Increases-Quarterly-Dividend-to-1-11-Per-Share/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">Dividend ↗</a>."}, {"key": "mo_r05", "match_zh": "覆盖全美超 30 万家零售终端", "zh": "覆盖全美超 30 万家零售终端；2026 Q3 上调全年调整后稀释 EPS 指引至 $5.66–$5.74（前值 $5.56–$5.72） <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2026-Third-Quarter-and-Nine-Months-Results-Announces-Expanded-Share-Repurchase-Program-Raises-2026-Full-Year-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">26Q3 Release ↗</a>。", "en": "Reaches >300,000 U.S. retail doors; Q3 2026 raised full-year adjusted diluted EPS guidance to $5.66–$5.74 (up from $5.56–$5.72) <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2026-Third-Quarter-and-Nine-Months-Results-Announces-Expanded-Share-Repurchase-Program-Raises-2026-Full-Year-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">26Q3 Release ↗</a>."}, {"key": "mo_r06", "match_zh": "防止传统卷烟业务（PM USA）的守成惯性", "zh": "防止传统卷烟业务（PM USA）的守成惯性掣肘新物种，独立设立 Helix Innovations 专攻 on! / on! PLUS 尼古丁袋，并与日本烟草合资设立 Horizon Innovations 推进加热不燃管线 <a class=\"cite-link\" href=\"https://www.altria.com/about-altria/our-companies\" target=\"_blank\" rel=\"noopener noreferrer\">Our Companies ↗</a>。", "en": "Ring-fences next-gen ventures from legacy combustible inertia—running Helix Innovations independently for on! / on! PLUS pouches and partnering with JT via Horizon Innovations on heated tobacco <a class=\"cite-link\" href=\"https://www.altria.com/about-altria/our-companies\" target=\"_blank\" rel=\"noopener noreferrer\">Our Companies ↗</a>."}, {"key": "mo_r07", "match_zh": "前端子公司专注品类心智与敏捷迭代", "zh": "前端子公司专注品类心智与敏捷迭代，后端由 AGDC 统一掌控超 30 万零售终端货架，由 ALCS 集中承担 FDA 毒理科学实证、合规风控与数字化财务支撑 <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">FY25 Release ↗</a>。", "en": "Operating units stay focused on category agility while AGDC commands >300,000 retail shelves and ALCS centralizes FDA toxicology, PMTA filings, legal compliance, and digital analytics <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">FY25 Release ↗</a>."}, {"key": "mo_r08", "match_zh": "2024 年启动多阶段降本增效工程", "zh": "2024 年启动多阶段降本增效工程，目标至 2029 年累计节降至少 $6 亿美元成本，将全职员工从 2008 年 10,400 人精简至 2025 年 5,900 人并定向反哺无烟研发 <a class=\"cite-link\" href=\"https://quartr.com/events/altria-group-inc-mo-q3-2026_33fjoS2B\" target=\"_blank\" rel=\"noopener noreferrer\">Q3 2026 Summary ↗</a>。", "en": "Launched multi-phase efficiency program in 2024 targeting ≥$600M in cumulative cost savings by 2029, streamlining headcount from 10,400 (FY08) to 5,900 (FY25) and reinvesting into smoke-free R&amp;D <a class=\"cite-link\" href=\"https://quartr.com/events/altria-group-inc-mo-q3-2026_33fjoS2B\" target=\"_blank\" rel=\"noopener noreferrer\">Q3 2026 Summary ↗</a>."}, {"key": "mo_r09", "match_zh": "2026年5月14日 CEO 换届平稳交接", "zh": "<strong>2026年5月14日 CEO 换届平稳交接：Sal Mancuso (CEO) × Heather Newman (CFO)</strong> —— 两位均在奥驰亚体系深耕逾 25 年，兼具财务资本纪律、PM USA 定价实战与企业战略视野，延续组织文化内生传承 <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2025/Altria-Group-Inc--Announces-Retirement-of-CEO-Billy-Gifford-and-Appointment-of-Sal-Mancuso-as-Successor/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">Succession Release ↗</a>。", "en": "<strong>May 14, 2026 Seamless Leadership Transition: Sal Mancuso (CEO) × Heather Newman (CFO)</strong> — Both bring 25+ years inside Altria across capital discipline, PM USA pricing execution, and enterprise strategy, preserving cultural continuity <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2025/Altria-Group-Inc--Announces-Retirement-of-CEO-Billy-Gifford-and-Appointment-of-Sal-Mancuso-as-Successor/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">Succession Release ↗</a>."}, {"key": "mo_r10", "match_zh": "在全美卷烟行业销量年均下滑约", "zh": "在全美卷烟行业销量年均下滑约 7%–8% 的结构性逆风下，PM USA 与 John Middleton 借助 Circana/MSAi 零售扫描数据实时调控各州价差与促销深度，推动 FY2025 可燃板块调整后 OCI 利润率逆势提升 1.8 个百分点至 63.4% <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">Table 2 · FY25 ↗</a>。", "en": "Despite ~7%–8% annual U.S. cigarette volume headwinds, PM USA and John Middleton deploy real-time Circana/MSAi scanner analytics to calibrate state-level price gaps and promotional depth, lifting FY25 Smokeable adjusted OCI margin +1.8pp to 63.4% <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">Table 2 · FY25 ↗</a>."}, {"key": "mo_r11", "match_zh": "依托 USSTC（Copenhagen、Skoal）与 Helix", "zh": "依托 USSTC（Copenhagen、Skoal）与 Helix Innovations 培育 on!（FY25 出货 1.778 亿罐，+10.9%）及升级版 on! PLUS，并拓展瑞典、英国及七大国际市场（FUMi）。2025 年 12 月 19 日，Helix 正式获美国 FDA 对 6 款 on! PLUS 产品的上市营销授权 (PMTA) <a class=\"cite-link\" href=\"https://www.fda.gov/tobacco-products/ctp-newsroom/fda-authorizes-6-nicotine-pouch-products-completing-review-record-time\" target=\"_blank\" rel=\"noopener noreferrer\">FDA PMTA ↗</a>。", "en": "Pairs USSTC (Copenhagen, Skoal) with Helix Innovations to scale on! (177.8M cans shipped in FY25, +10.9%) and next-gen on! PLUS alongside international FUMi expansion. On Dec 19, 2025, Helix earned landmark U.S. FDA PMTA marketing authorization for 6 on! PLUS products <a class=\"cite-link\" href=\"https://www.fda.gov/tobacco-products/ctp-newsroom/fda-authorizes-6-nicotine-pouch-products-completing-review-record-time\" target=\"_blank\" rel=\"noopener noreferrer\">FDA PMTA ↗</a>."}, {"key": "mo_r12", "match_zh": "Helix 已于 2024 Q4 提前达成盈利里程碑", "zh": "Helix 已于 2024 Q4 提前达成盈利里程碑；获批的 6 款 on! PLUS 涵盖薄荷、冬青与烟草口味（6mg/9mg），并在 2026 年依托 AGDC 网络快速铺向全美超 12 万家零售门店 <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/on-PLUS-Expands-Nationwide-Retail-Availability/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">on! PLUS Expansion ↗</a>。", "en": "Helix achieved profitability ahead of schedule in Q4 2024; the 6 FDA-authorized on! PLUS SKUs (mint, wintergreen &amp; tobacco in 6mg/9mg) scaled rapidly across >120,000 U.S. stores in 2026 via AGDC <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/on-PLUS-Expands-Nationwide-Retail-Availability/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">on! PLUS Expansion ↗</a>."}, {"key": "mo_r13", "match_zh": "里士满（Richmond）研发中心汇聚毒理学家", "zh": "里士满（Richmond）研发中心汇聚毒理学家、化学家、行为科学家与工程专家（工程与科学岗位占全员 45.4%），构建临床与真实世界减害证据库，并将“防止未成年人接触”与“责任是业务基石”直接挂钩高管薪酬考核 <a class=\"cite-link\" href=\"https://www.reveliolabs.com/companies/altria-group/employees\" target=\"_blank\" rel=\"noopener noreferrer\">Revelio Labs ↗</a>。", "en": "Its Richmond R&amp;D hub unites toxicologists, chemists, behavioral scientists, and engineers (45.4% of total headcount) to build clinical harm-reduction evidence while tying underage-access prevention directly to executive compensation <a class=\"cite-link\" href=\"https://www.reveliolabs.com/companies/altria-group/employees\" target=\"_blank\" rel=\"noopener noreferrer\">Revelio Labs ↗</a>."}, {"key": "mo_r14", "match_zh": "在政治透明度与公共政策合规披露方面", "zh": "在政治透明度与公共政策合规披露方面，奥驰亚连续 9 年获评 CPA-Zicklin 政治支出自愿披露指数“Trendsetter（标杆企业）”，以制度化透明消解外部监管摩擦 <a class=\"cite-link\" href=\"https://www.altria.com/responsibility\" target=\"_blank\" rel=\"noopener noreferrer\">Altria Responsibility ↗</a>。", "en": "Altria has been named a CPA-Zicklin Corporate Political Disclosure \"Trendsetter\" for 9 consecutive years, using institutionalized transparency to reduce regulatory friction <a class=\"cite-link\" href=\"https://www.altria.com/responsibility\" target=\"_blank\" rel=\"noopener noreferrer\">Altria Responsibility ↗</a>."}, {"key": "mo_r15", "match_zh": "采取“内部概念孵化 + 外部伙伴渠道赋能”", "zh": "采取“内部概念孵化 + 外部伙伴渠道赋能”的轻资产纪律模式（如 AGDC 助推清洁能量饮 Proper Wild 在 2025 年铺入超 25,000 家门店），同时持有百威英博（ABI）与大麻素龙头 Cronos 股权作为长期战略期权 <a class=\"cite-link\" href=\"https://www.altria.com/about-altria/our-companies/investments\" target=\"_blank\" rel=\"noopener noreferrer\">Altria Investments ↗</a>。", "en": "Pursues asset-light internal incubation and partner distribution enablement (e.g., AGDC expanding clean-energy shot Proper Wild to >25,000 stores in 2025) alongside strategic equity stakes in AB InBev (ABI) and Cronos <a class=\"cite-link\" href=\"https://www.altria.com/about-altria/our-companies/investments\" target=\"_blank\" rel=\"noopener noreferrer\">Altria Investments ↗</a>."}, {"key": "mo_r16", "match_zh": "1. 自我革命定力：", "zh": "<strong>1. 自我革命定力：</strong>在传统现金牛仍极度赚钱时确立 Moving Beyond Smoking 愿景并持续投入 FDA 科学减害管线。<br/> <strong>2. 极简高人效标杆：</strong>5,900 名员工创造 $201.39 亿扣税营收与 62.4% 调整后 OCI 率，人均创收高居美股消费品前列。<br/> <strong>3. 股东信托契约：</strong>半个多世纪严守现金分红与回购纪律，57 年 61 次加息穿越多轮通胀与监管周期。", "en": "<strong>1. Proactive Self-Disruption:</strong> Committed to <em>Moving Beyond Smoking</em> and FDA harm-reduction science while legacy cash cows remain highly profitable.<br/> <strong>2. Elite Workforce Productivity:</strong> ~5,900 employees generate $20.14B in net revenue ex-excise and a 62.4% adjusted OCI margin—among the highest in U.S. consumer staples.<br/> <strong>3. Fiduciary Dividend Covenant:</strong> 61 dividend increases across 57 years through multiple inflation, litigation, and regulatory cycles."}, {"key": "mo_r17", "match_zh": "1. 合规慢节奏 vs 非法电子烟冲击：", "zh": "<strong>1. 合规慢节奏 vs 非法电子烟冲击：</strong>严守联邦 PMTA 流程使其在 2022–2026 年直面占雾化品类超 60% 的非法调味一次性电子烟分流，且 NJOY ACE 因 ITC 专利裁决自 2025 年 3 月暂停在美销售。<br/> <strong>2. 大额外部并购磨合教训：</strong>2018 年斥资 $128 亿入股 JUUL 最终减记逾百亿美元并退出（FY25 亦对电子烟商誉计提非现金减值）。<br/> <strong>3. 本土单一市场集中度：</strong>剥离 PMI 后约 89%+ 员工与核心利润高度集中于美国本土监管环境。", "en": "<strong>1. Regulatory Pace vs. Illicit E-Vapor Flood:</strong> Strict PMTA compliance exposed Altria to illicit flavored disposables (>60% of U.S. e-vapor), while ITC patent rulings halted NJOY ACE U.S. sales in March 2025.<br/> <strong>2. Costly M&amp;A Scars:</strong> Its $12.8B 2018 stake in JUUL resulted in >$10B of write-downs prior to exit (plus non-cash e-vapor goodwill impairment in FY25).<br/> <strong>3. Single-Country Concentration:</strong> Post-PMI spin-off, ~89%+ of staff and operating profits depend on U.S. regulatory and tax policy."}, {"key": "mo_r18", "match_zh": "原菲利普莫里斯集团横跨全球烟草", "zh": "原菲利普莫里斯集团横跨全球烟草、卡夫食品与啤酒，2005 年员工规模一度高达 19.9 万人；2003 年更名 Altria，并于 2007–2008 年果断分拆卡夫食品与菲莫国际 (PMI)，释放本土高现金流业务估值并彻底消除跨国官僚层级 <a class=\"cite-link\" href=\"https://en.arincen.com/instruments/MO/profile\" target=\"_blank\" rel=\"noopener noreferrer\">Arincen History ↗</a>。", "en": "Legacy Philip Morris spanned global tobacco, Kraft Foods, and beer—peaking at 199,000 employees in 2005. Renamed Altria in 2003, it spun off Kraft and PMI in 2007–2008 to unlock U.S. cash-flow valuation and strip away global conglomerate bureaucracy <a class=\"cite-link\" href=\"https://en.arincen.com/instruments/MO/profile\" target=\"_blank\" rel=\"noopener noreferrer\">Arincen History ↗</a>."}, {"key": "mo_r19", "match_zh": "2020 年原 CFO 比利·吉福德", "zh": "2020 年原 CFO 比利·吉福德（Billy Gifford）出任 CEO，正式确立 Moving Beyond Smoking 企业愿景；果断出清 JUUL 股权包袱、2024 年以 $27 亿税前收益向 PMI 移交 IQOS 美国商业化权益回笼资金，集中火力培育 Helix (on! / on! PLUS) 与 Optimize &amp; Accelerate 精益改革 <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">Altria FY25 Release ↗</a>。", "en": "Named CEO in 2020, former CFO Billy Gifford launched <em>Moving Beyond Smoking</em>, exited the JUUL overhang, monetized U.S. IQOS commercialization rights to PMI for $2.7B pre-tax in 2024, and focused resources on Helix (on! / on! PLUS) and <em>Optimize &amp; Accelerate</em> <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">Altria FY25 Release ↗</a>."}, {"key": "mo_r20", "match_zh": "2026 年 5 月 14 日年度股东大会后", "zh": "2026 年 5 月 14 日年度股东大会后，1990 年加入 PM USA、历任合规与财务核心要职的 CFO 萨尔·曼库索正式接任 CEO，原首席战略与增长官兼前 PM USA 总裁 Heather Newman 出任 CFO，在扩大 $10 亿股票回购与第 61 次加息的同时稳步推进无烟矩阵商业化 <a class=\"cite-link\" href=\"https://tobaccoreporter.com/2025/12/11/altria-ceo-gifford-to-retire-in-2026-mancuso-named-successor/\" target=\"_blank\" rel=\"noopener noreferrer\">Tobacco Reporter ↗</a>。", "en": "Following the May 14, 2026 Annual Meeting, CFO Sal Mancuso (joined PM USA in 1990) assumed the CEO role alongside CFO Heather Newman (former CSO &amp; PM USA President), pairing an expanded $1B+ buyback and 61st dividend hike with disciplined smoke-free scaling <a class=\"cite-link\" href=\"https://tobaccoreporter.com/2025/12/11/altria-ceo-gifford-to-retire-in-2026-mancuso-named-successor/\" target=\"_blank\" rel=\"noopener noreferrer\">Tobacco Reporter ↗</a>."}, {"key": "mo_r21", "match_zh": "通过“Helix 独立研发敏捷迭代", "zh": "通过“Helix 独立研发敏捷迭代 + AGDC 30 万终端铺货 + ALCS 毒理申报”协同，on! 于 2024 Q4 提前盈利，并在 2025 年 12 月斩获 6 款 on! PLUS 产品的 FDA PMTA 营销授权 <a class=\"cite-link\" href=\"https://www.altria.com/about-altria/our-companies/helix-innovations\" target=\"_blank\" rel=\"noopener noreferrer\">Helix Innovations ↗</a>。", "en": "Combining Helix agile R&amp;D, AGDC 300k-store distribution, and ALCS toxicology submissions, on! turned profitable in Q4 2024 and won FDA PMTA authorization for 6 on! PLUS SKUs in Dec 2025 <a class=\"cite-link\" href=\"https://www.altria.com/about-altria/our-companies/helix-innovations\" target=\"_blank\" rel=\"noopener noreferrer\">Helix Innovations ↗</a>."}, {"key": "mo_r22", "match_zh": "2025 年 3 月 ITC 排除令致 NJOY ACE", "zh": "2025 年 3 月 ITC 排除令致 NJOY ACE 暂停在美销售并计提商誉减值后，管理层在 2026 指引中明确假设 ACE 年内不返市，在执法尚未肃清非法一次性电子烟前拒绝盲目烧钱补贴 <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2026-Third-Quarter-and-Nine-Months-Results-Announces-Expanded-Share-Repurchase-Program-Raises-2026-Full-Year-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">26Q3 Guidance ↗</a>。", "en": "After March 2025 ITC exclusion orders halted NJOY ACE U.S. shipments, management prudently excluded ACE from 2026 guidance and refused to subsidize volume while illicit disposables distort the market <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2026-Third-Quarter-and-Nine-Months-Results-Announces-Expanded-Share-Repurchase-Program-Raises-2026-Full-Year-Earnings-Guidance/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">26Q3 Guidance ↗</a>."}, {"key": "mo_r23", "match_zh": "即便经历诉讼和解、金融危机与品类转型", "zh": "即便经历诉讼和解、金融危机与品类转型，董事会仍于 2026 年 8 月将季度股息上调 4.7% 至 $1.11/股（年化 $4.44/股），把自由现金流优先回馈股东写入公司治理基因 <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Increases-Quarterly-Dividend-to-1-11-Per-Share/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">Altria Dividend ↗</a>。", "en": "Across litigation settlements, financial crises, and category shifts, the Board raised the quarterly dividend +4.7% to $1.11/sh ($4.44 annualized) in Aug 2026—embedding shareholder cash return into governance DNA <a class=\"cite-link\" href=\"https://investor.altria.com/press-releases/news-details/2026/Altria-Increases-Quarterly-Dividend-to-1-11-Per-Share/default.aspx\" target=\"_blank\" rel=\"noopener noreferrer\">Altria Dividend ↗</a>."}];
      var I18N_TEXT_PAIRS = [["数据中心", "Research Hub"], ["奥驰亚 (Altria) 企业文化与组织架构研报", "Altria Corporate Culture & Org Report"], ["奥驰亚企业文化研报", "Altria Culture Monograph"], ["Moving Beyond Smoking 愿景 × 专业运营子公司矩阵 × 57年61次股息增长的极简高人效机器", "Moving Beyond Smoking × Operating Matrix × 61 Dividend Hikes in 57 Years"], ["组织形态与中枢", "Org Model"], ["5,900人 · 控股+共享", "5,900 FTE · Hub+Shared"], ["FY25 人均创收/净利", "FY25 Rev / NI per FTE"], ["调整后 OCI / 年化息", "Adj. OCI / Annual Div"], ["62.4% · $4.44/股", "62.4% · $4.44/sh"], ["站点与关联导航", "Site & Related Reports"], ["返回数据中心首页", "Back to Research Hub"], ["奥驰亚 CEO 曼库索研报", "Sal Mancuso CEO Report"], ["核心研究章节 (00 – 07)", "Report Chapters (00 – 07)"], ["执行摘要与核心指标", "Executive Summary & KPIs"], ["运营公司矩阵与无烟转型", "Operating Matrix & Transition"], ["四大文化支柱与合规护城河", "4 Cultural Pillars & FDA Moat"], ["全球烟草巨头文化横向对比", "Global Peer Culture Matrix"], ["资本纪律、利润率与股息复利", "Capital Discipline & DRIP Sim"], ["三代演进与管理得失复盘", "3-Era Evolution & Case Studies"], ["奥驰亚文化法则核查清单", "Governance Diagnostic Checklist"], ["数据来源与监管核验索引", "Primary Filings & Sources"], ["阅读与导出工具", "Reading & Export Tools"], ["浅色外观", "Light"], ["深色外观", "Dark"], ["导出 HTML", "Export HTML"], ["打印 / PDF", "Print / PDF"], ["组织史定评：商业史高回报“逆风转型现金奶牛机器”", "Verdict: High-Return Cash-Flow Compounder Navigating Secular Transition"], ["研究横跨：帝国分拆 (2007–2008) · 吉福德无烟重塑 (2020–2026) · 曼库索接棒 (2026.05+)", "Scope: Spin-Offs (2007–08) · Gifford Reset (2020–26) · Mancuso Era (May 2026+)"], ["数据基准：FY2025 10-K / 2026 Q3", "Baseline: FY2025 10-K / Q3 2026"], ["CORE THESIS · Moving Beyond Smoking × 控股+共享服务中台 × 极致定价与资本纪律 × 57年61次加息", "CORE THESIS · Moving Beyond Smoking × Holding + Shared Services × Pricing & Capital Rigor × 61 Dividend Hikes"], ["自我颠覆愿景 (Moving Beyond Smoking)", "Self-Disrupting Vision (Moving Beyond Smoking)"], ["主动引导 21+ 成年烟民向经科学验证的低风险无烟产品（on! 与 FDA 授权的 on! PLUS 尼古丁袋等）迁移，用内部组织革新取代被动防守萎缩。", "Actively transitions adult 21+ smokers toward scientifically substantiated smoke-free products (on! and FDA-authorized on! PLUS pouches), replacing passive decline with internal renewal."], ["极简组织 × 共享渠道中台 (AGDC / ALCS)", "Lean Workforce × Shared Platforms (AGDC / ALCS)"], ["5,900 名员工撬动全美超 30 万家零售终端货架覆盖，传统高利润现金牛与敏捷无烟新物种共享分销网络、FDA 法规申报与毒理科学基础设施。", "~5,900 employees power >300,000 U.S. retail doors as legacy cash cows and agile smoke-free brands share nationwide distribution, FDA regulatory filing, and toxicology infrastructure."], ["“责任是基石”与严苛资本配置纪律", "Responsibility-First & Strict Capital Discipline"], ["从 JUUL 与 NJOY 外部并购磨合中进化出“FDA 合规先行 + 2.0x 债务/EBITDA 红线 + 约 80% 调整后 EPS 现金派息回馈股东”的刚性财务铁律。", "Evolved from JUUL and NJOY lessons into a strict covenant: FDA authorization first, ~2.0x Debt/EBITDA ceiling, and progressive cash dividend payouts (~80% target ratio)."], ["人均创收与技术密度 (FY25)", "Rev / Employee & R&D Share (FY25)"], ["45.4% 工程研发", "45.4% Eng & Sci"], ["总调整后运营公司利润率", "Total Adjusted OCI Margin"], ["目标 ≥60%", "Goal ≥60%"], ["股息之王连续加息纪录", "Dividend King Growth Streak"], ["年化 $4.44/股", "$4.44/sh Annual"], ["61 次 / 57年", "61x / 57 Yrs"], ["终端网络与 2026 业绩指引", "Retail Reach & 2026 Guidance"], ["一、运营子公司矩阵与共享中台：奥驰亚如何用 5,900 人驾驭双轨转型？", "1. Operating Subsidiary Matrix & Shared Platforms: Steering a Dual-Track Transition with 5,900 People"], ["前沿品牌独立敏捷创新（Helix / Horizon） × 后端分销与合规共享赋能（AGDC / ALCS）", "Agile Front-End Brand Incubation (Helix / Horizon) × Shared Distribution & Compliance Backbone (AGDC / ALCS)"], ["Optimize & Accelerate · ≥$600M 节降", "Optimize & Accelerate · ≥$600M Savings"], ["Altria Group, Inc. 控股母公司中枢（Richmond, VA · 战略演进 / 2.0x 资本配置 / 股东回报契约）", "Altria Group, Inc. Parent Holding Hub (Richmond, VA · Strategy / 2.0x Leverage Discipline / Dividend Covenant)"], ["2026.05.14 新核心班底：Sal Mancuso (CEO, 1990年入职) × Heather Newman (CFO, 1999年入职)", "May 14, 2026 Leadership Core: Sal Mancuso (CEO, joined 1990) × Heather Newman (CFO, joined 1999)"], ["CASH COW · 传统核心防守", "CASH COW · COMBUSTIBLE CORE"], ["Marlboro（高端份额 59.4%）与 Black & Mild 雪茄；FY25 扣税净营收 $174.43 亿，调整后 OCI 率 63.4%。", "Marlboro (59.4% premium share) & Black & Mild cigars; FY25 net rev ex-excise $17.44B, 63.4% adj. OCI margin."], ["SMOKE-FREE · 口含减害先锋", "SMOKE-FREE · ORAL PIONEER"], ["Copenhagen / Skoal + 现代尼古丁袋 on! 与 FDA 授权 on! PLUS；FY25 扣税营收 $27.04 亿，调整后 OCI 率 67.9%。", "Copenhagen / Skoal + modern pouches on! & FDA-authorized on! PLUS; FY25 net rev $2.70B, 67.9% adj. OCI margin."], ["NEXT-GEN · 加热与雾化", "NEXT-GEN · HEATED & E-VAPOR"], ["与日本烟草 (JT) 合资 Horizon 推进加热烟草；NJOY 严守专利与监管边界审慎投入。", "Horizon JV with Japan Tobacco (JT) for heated tobacco; disciplined capital posture on NJOY amid patent/regulatory rules."], ["OPTIONALITY · 战略期权", "OPTIONALITY · EQUITY & BEYOND"], ["持有百威英博与 Cronos 股权收益缓冲，并通过渠道赋能功能饮品 Proper Wild 铺入 >25,000 店。", "AB InBev & Cronos equity stakes plus AGDC distribution scaling clean-energy drink Proper Wild across >25,000 doors."], ["AGDC（Altria Group Distribution Company）共享终端分销铁军", "AGDC (Altria Group Distribution Company) Shared Retail Distribution Force"], ["统一打通全美 >300,000 家便利店与零售货架陈列管理，新品牌无需自建地面销售团队即可秒级铺货。", "Unifies shelf-space management across >300,000 U.S. convenience and retail stores—giving new brands instant national reach."], ["ALCS（Altria Client Services）共享科学、合规与数字化中台", "ALCS (Altria Client Services) Shared Toxicology, Regulatory & Digital Backbone"], ["集中约 2,730 名毒理学、工程研发、FDA PMTA 申报、法务诉讼与零售扫描数据定价专家统一赋能。", "Pools ~2,730 toxicology, engineering R&D, FDA PMTA filing, litigation, and retail scanner pricing specialists across all subsidiaries."], ["1. “现金牛防守”与“无烟进攻”组织隔离", "1. Structural Separation: Cash-Cow Defense vs. Smoke-Free Offense"], ["2. AGDC 与 ALCS 两大共享赋能中台", "2. Dual Shared Enablement Platforms: AGDC & ALCS"], ["3. “Optimize & Accelerate” 精益效率文化", "3. 'Optimize & Accelerate' Lean Productivity Culture"], ["里程碑", "MILESTONE"], ["FY2023–FY2025 扣税后净营收结构与现金牛利润支柱（$B · SEC 10-K）", "FY2023–FY2025 Revenues Net of Excise Taxes by Core Segment ($B · SEC 10-K)"], ["可燃烟草（Smokeable）稳守 $17.4B+ 现金基底，无烟口服烟草（Oral Tobacco）稳步扩张至 $2.70B", "Smokeable defends a $17.4B+ cash base while Oral Tobacco expands steadily to $2.70B"], ["视图A: 双轨业务扣税营收", "View A: Segment Net Revenue"], ["视图B: 精简组织与人效跃升", "View B: Lean Staff & Rev/FTE"], ["极致定价权与精细化收入管理（PM USA & Middleton）", "Precision Revenue Growth Management & Pricing Power (PM USA & Middleton)"], ["OCI 率 63.4%", "OCI Margin 63.4%"], ["展开微观执行机制", "Show Execution Mechanics"], ["收起微观执行机制", "Hide Execution Mechanics"], ["通过“高端万宝路（59.4% 高端份额）利润锚定 + 折扣子线 Marlboro Black 承接价格敏感客群”的分层RGM（收入增长管理）体系，FY2025 可燃板块创造高达 $110.64 亿调整后 OCI，为集团股息与无烟研发提供充沛造血。", "Using tiered Revenue Growth Management—anchoring premium margins with flagship Marlboro (59.4% premium share) while retaining price-sensitive adults via Marlboro Black—Smokeable generated $11.06B in FY25 adjusted OCI to fund dividends and smoke-free R&D."], ["现代口服尼古丁与减害攻坚（USSTC & Helix Innovations）", "Modern Oral Nicotine & Harm-Reduction Scaling (USSTC & Helix Innovations)"], ["2025.12 获 FDA 授权", "FDA PMTA Dec 2025"], ["毒理学科学实证与严苛合规文化（Regulatory & R&D）", "Toxicological Science & Compliance-First Culture (Regulatory & R&D)"], ["~2,730 名技术专家", "~2,730 Tech & Sci Staff"], ["“超越尼古丁”轻资产孵化与股权期权（Beyond Nicotine）", "Asset-Light 'Beyond Nicotine' Incubation & Strategic Stakes"], ["2028 ≥5款非尼古丁", "≥5 Non-Nicotine by 2028"], ["吸取早年重资产跨界教训后，奥驰亚聚焦提神专注、减压放松等成年消费场景做低成本实测，同时仅在 2026 Q3 单季即从 ABI 获得 $1.91 亿美元调整后权益收益（同比 +21.7%）。", "Applying capital-light discipline to adult energy and relaxation occasions while harvesting $191M in Q3 2026 adjusted equity earnings (+21.7% YoY) from its AB InBev stake."], ["二、四大企业文化支柱：塑造未来、坚守正道、彼此关怀、并肩迎战", "2. Four Cultural Pillars: Shape Our Future, Do What's Right, Care as Owners, Deliver Together"], ["点击左侧任一文化支柱卡片，联动查看奥驰亚组织行为准则与五维文化竞争力画像", "Click any pillar card on the left to inspect Altria's behavioral norms and 5-axis cultural radar"], ["护城河定性：极宽 (Wide Moat · 百年品牌 + 30万终端 + FDA壁垒)", "Moat Rating: Wide Moat (Iconic Brands + 300k Doors + FDA PMTA Barrier)"], ["01 · 塑造未来（We Shape Our Future）", "01 · We Shape Our Future"], ["将 Moving Beyond Smoking 确立为全员北极星，鼓励员工预判行业拐点、承担审慎的创新风险，持续向 on! PLUS 等下一代合规无烟管线倾斜资源。", "Sets Moving Beyond Smoking as the enterprise North Star, backing calculated innovation risk and channeling capital into FDA-authorized platforms like on! PLUS."], ["02 · 坚守正道（We Do What's Right）", "02 · We Do What's Right"], ["Speak Up 合规铁律", "Speak Up Integrity"], ["历经 1998 年《主和解协议》(MSA) 洗礼后锻造出“透明、诚信与勇敢发声”文化，严格限定仅面向 21+ 成年烟民沟通，以行业最高自律标准换取 FDA 长期监管互信。", "Forged post-1998 Master Settlement Agreement (MSA): radical compliance transparency, strict 21+ adult-only marketing guardrails, and earned regulatory credibility with the FDA."], ["03 · 彼此关怀与主人翁意识（We Care & Act as Owners）", "03 · We Care & Act as Owners"], ["25年+ 内部传承", "25+ Yr Internal Bench"], ["形成强凝聚力的“家人式互挺 (Have Each Other's Backs)”文化，尊重各运营子公司独立品牌基因，通过极低流失率与跨板块轮岗（如 Mancuso 与 Newman）沉淀深厚组织记忆。", "High-cohesion 'have each other's backs' ownership culture with low attrition and cross-subsidiary leadership rotation (exemplified by Mancuso and Newman) preserving institutional memory."], ["04 · 交付极致与韧性迎战（Deliver & Rise Together）", "04 · Deliver & Rise Together"], ["Grit 商业韧性", "Commercial Grit"], ["面对通胀压力下成年消费者向折扣品牌分流（FY25 行业折扣烟份额升至 31.8%），敏捷运用战术产品线与精准促销稳固基本盘，连续兑现 ≥60% OCI 利润率承诺。", "Counters inflation-driven downtrading (industry discount share at 31.8% in FY25) with tactical price tiers and disciplined cost control, sustaining ≥60% adjusted OCI margins."], ["奥驰亚企业文化五维特征对比雷达图（10分制标杆评估）", "5-Axis Corporate Culture Benchmark Radar (10-Point Institutional Scale)"], ["点击下方图例胶囊可单独开关对比曲线，悬停查看各维度评分", "Click legend pills below to toggle peer curves; hover vertices for exact scores"], ["奥驰亚 (Altria · 本土高息标杆)", "Altria (MO · U.S. Cash & Dividend Leader)"], ["菲莫国际 (PMI · 全球激进无烟)", "Philip Morris Intl (PMI · Global Smoke-Free)"], ["传统消费防御巨头基准", "Global Consumer Staples Benchmark"], ["三、全球顶级烟草与防御巨头文化对比：四种转型路径与利润率统治力", "3. Global Tobacco & Defensive Staples Peer Matrix: Four Transition Playbooks"], ["支持按企业、CEO、核心品牌（Marlboro / on! / ZYN / IQOS / Vuse）或文化关键词实时筛选对比", "Filter or search in real time by company, CEO, flagship brand (Marlboro / on! / ZYN / IQOS / Vuse), or cultural trait"], ["全部标杆企业", "All Peers"], ["现金流与股息稳健派", "Cash & Dividend Compounders"], ["全球扩张与激进无烟派", "Global Smoke-Free Expanders"], ["企业与核心掌舵人", "Company & Leadership"], ["战略定位与市场重心", "Strategic Focus & Footprint"], ["核心组织文化特征", "Core Cultural DNA"], ["员工规模与人效特征", "Workforce & Rev / FTE"], ["营业利润率与股东回报", "Operating Margin & Return"], ["与奥驰亚企业文化的异同及优劣势评估", "Comparative Assessment vs. Altria"], ["奥驰亚各业务板块调整后 OCI 利润率 vs 员工职能结构拆解（%）", "Altria Segment Adjusted OCI Margins vs. Workforce Functional Mix (%)"], ["数据来源：Altria FY2025 财报 Schedule 15（重述口径）及 Revelio Labs 2026 职能分布统计（45.4% + 37.3% + 17.3% = 100%）", "Sources: Altria FY2025 Schedule 15 (recast basis) & Revelio Labs 2026 functional breakdown (45.4% + 37.3% + 17.3% = 100%)"], ["绿色/蓝色：板块与集团调整后 OCI 利润率 (虚线为 60% 目标线)", "Green / Blue: Segment & Total Adjusted OCI Margin (dashed = 60% goal)"], ["紫色/琥珀色：2026 全公司三大职能人才占比 (合计 100%)", "Purple / Amber: 2026 Enterprise Functional Talent Share (100% total)"], ["四、资本纪律与股息复利推演：从 $341万超高人效到 57 年 61 次加息奇迹", "4. Capital Discipline & DRIP Compounding: From $3.41M Rev/FTE to 61 Dividend Hikes"], ["以股东回报检验治理文化：严守 2.0x 债务/合并 EBITDA 红线与渐进式股息增长承诺", "Testing culture via capital allocation: strict ~2.0x Debt/EBITDA ceiling and progressive dividend growth"], ["FY25 总股东现金回报 $8.0B", "FY25 Total Cash Return $8.0B"], ["连续多年稳居 ≥60% 的 2028 企业目标红线之上（GAAP 报告口径 OCI 率 51.1%）。", "Consistently clears the ≥60% 2028 Enterprise Goal floor (GAAP reported OCI margin: 51.1%)."], ["$4.44/股", "$4.44/sh"], ["2025 全年派息 $70 亿；2026 年 8 月上调季息至 $1.11/股，完成 57 年第 61 次增长。", "$7.0B paid in FY25 dividends; lifted quarterly payout to $1.11/sh in Aug 2026 (61st increase in 57 yrs)."], ["总债务/合并 EBITDA 严格锚定 2.0x（净债务比 1.7x），兼顾投资级信用与 2026Q3 扩充的 $10 亿+ 回购。", "Total Debt / Consolidated EBITDA anchored at 2.0x (1.7x net), balancing investment-grade credit with $1B+ buybacks."], ["从 2022 基数 $4.87 升至 2025 年 $5.42，2026 Q3 上调全年指引中值至 $5.70。", "Expanded from $4.87 (FY22 recast base) to $5.42 in FY25, with FY26 guidance midpoint raised to $5.70 in Q3 2026."], ["FY2022–FY2026E 逆风盈利韧性：调整后稀释 EPS ($) 与总调整后 OCI 利润率 (%)", "FY2022–FY2026E Earnings Resilience: Adjusted Diluted EPS ($) & Total Adjusted OCI Margin (%)"], ["柱状图（左轴）为重述口径调整后稀释 EPS；折线（右轴）为总调整后 OCI 利润率及 60.0% 2028 目标底线", "Bars (left axis): recast Adjusted Diluted EPS ($); Line (right axis): Total Adjusted OCI Margin (%) vs. 60.0% goal floor"], ["■ 左轴：调整后稀释 EPS ($/股)", "■ Left Axis: Adjusted Diluted EPS ($/sh)"], ["● 右轴：总调整后 OCI 利润率 (%)", "● Right Axis: Total Adjusted OCI Margin (%)"], ["调整后稀释 EPS (左轴 · $)", "Adjusted Diluted EPS (Left · $)"], ["总调整后 OCI 利润率 (右轴 · %)", "Total Adjusted OCI Margin (Right · %)"], ["--- 2028 企业目标底线 ≥60.0%", "--- 2028 Enterprise Goal Floor ≥60.0%"], ["高股息防御复利测算器（股息再投资模型）", "Defensive High-Yield DRIP Compounding Simulator"], ["开启股息红利全额再投资 DRIP (+7.2%/年)", "Enable Full Dividend Reinvestment · DRIP (+7.2%/yr)"], ["将每年高现金分红自动买入更多低估值股份实现份额复利", "Automatically reinvests annual cash dividends into additional low-multiple shares"], ["① 2008–2026 分拆后纯本土高股息时代", "① 2008–2026 Post-Spin U.S. High-Yield Era"], ["18年 · 5.2%", "18Y · 5.2%"], ["② 1996–2026 三十年烟草逆风长牛", "② 1996–2026 30-Year Secular Contrarian Run"], ["30年 · 5.6%", "30Y · 5.6%"], ["③ 2026–2036 曼库索时代稳健防守基准", "③ 2026–2036 Mancuso Era Base Case"], ["10年 · 4.5%", "10Y · 4.5%"], ["初始投入本金 (USD)", "Initial Principal (USD)"], ["长期持有年限 (Years)", "Holding Horizon (Years)"], ["基础股价年化增值率 (Price CAGR %)", "Base Share Price CAGR (%)"], ["期末预估总资产 (Ending Value)", "Projected Ending Value"], ["总回报倍数 (MOIC) / 综合年化", "Total MOIC / Blended CAGR"], ["累计净复利收益 (Net Gain)", "Cumulative Net Gain"], ["━ 含股息再投资总资产轨迹", "━ Total Wealth with DRIP Reinvestment"], ["- - 仅股价增值基准 (不含分红再投)", "- - Price Appreciation Only (Ex-DRIP)"], ["悬停曲线可逐年对比“开启 DRIP 复利总资产”与“仅靠股价增值”的超额收益剪刀差。", "Hover along the curve to inspect year-by-year total wealth with DRIP vs. price appreciation alone."], ["正向组织文化遗产定评", "Enduring Organizational Strengths"], ["客观局限与组织张力反思", "Structural Constraints & Tensions"], ["五、三代文化演进与管理复盘：从“多元化帝国”到“极简高息无烟先锋”", "5. Three-Era Cultural Evolution & Case Studies: From Conglomerate to Lean Dividend Pioneer"], ["跨越四十年的组织瘦身、并购止损与内部高管梯队接力", "Four decades of spin-off streamlining, M&A stop-loss discipline, and internal succession"], ["199,000人 (FY05) → 5,900人 (FY25)", "199,000 FTE (FY05) → 5,900 FTE (FY25)"], ["第一幕 · 超级帝国与战略瘦身 (1985–2008) —— 从多元控股到纯血聚焦", "Act I · Conglomerate Peak & Strategic Spin-Offs (1985–2008) — Pure-Play Focus"], ["员工 19.9万 → 1.04万", "Staff 199k → 10.4k"], ["第二幕 · 愿景重塑与并购反思 (2018–2026) —— 吉福德掌舵与无烟转型", "Act II · Vision Reset & M&A Discipline (2018–2026) — Gifford's Smoke-Free Pivot"], ["OCI 率冲上 62.4%", "OCI Margin Hits 62.4%"], ["第三幕 · 内部接班与稳健新程 (2026.05+) —— 萨尔·曼库索接任 CEO", "Act III · Internal Continuity & Disciplined Growth (May 2026+) — Sal Mancuso CEO"], ["2026.05.14 股东大会交接", "May 14, 2026 Handover"], ["案例 01 · 2018–2023", "Case 01 · 2018–2023"], ["风控铁律重构", "M&A Guardrail Reset"], ["$128亿 JUUL 投资惨痛复盘与果断止损", "The $12.8B JUUL Write-Down & Clean Exit"], ["高溢价参股外部创业公司遭遇未成年人监管风暴后，奥驰亚管理层彻底摒弃“花大钱买增长”幻想，确立“一切新产品必须以 FDA 科学授权与严格 21+ 成年消费群体合规为前提”的组织红线。", "After underage-vaping backlash decimated its high-multiple JUUL stake, Altria permanently rejected growth-at-any-cost M&A and mandated strict FDA science authorization and 21+ guardrails."], ["案例 02 · 2019–2026", "Case 02 · 2019–2026"], ["中台赋能典范", "Shared-Platform Flywheel"], ["on! 现代口含尼古丁袋的内生式逆袭", "Organic Scaling of on! & FDA-Authorized on! PLUS"], ["案例 03 · 2025–2026", "Case 03 · 2025–2026"], ["资本克制纪律", "Capital Restraint"], ["面对 NJOY 专利禁令的审慎克制", "Prudent Capital Restraint Following NJOY ITC Ruling"], ["案例 04 · 1969–2026", "Case 04 · 1969–2026"], ["股东契约图腾", "Shareholder Covenant"], ["连续 57 年 61 次上调股息的信用图腾", "61 Dividend Increases Across 57 Years"], ["法则一：", "Law 01:"], ["面对长期需求下行，“主动自我颠覆愿景”远胜“鸵鸟式防御”，唯有自己革自己的命才能掌握利润池迁移主动权。", "In secularly declining categories, proactive self-disruption beats defensive denial—only internal renewal captures shifting profit pools."], ["法则二：", "Law 02:"], ["用“共享分销与合规中台（AGDC/ALCS）”托举独立小团队（Helix），兼顾初创速度与巨头规模壁垒。", "Pair independent agile product units (Helix) with shared distribution and regulatory platforms (AGDC/ALCS) to unite startup speed with scale."], ["法则三：", "Law 03:"], ["行业越受严苛监管，科学实证与工程研发人才密度（45.4% 技术岗占比）越是不可复制的准入护城河。", "The stricter the regulatory regime, the deeper the moat created by scientific and engineering talent density (45.4% technical share)."], ["六、“奥驰亚文化法则”现金牛与转型企业交互式核查清单", "6. Interactive 'Altria Culture Laws' Governance & Cash-Cow Diagnostic Checklist"], ["用于评估任何成熟高现金流企业在行业逆风期的组织韧性与股东友好度（勾选状态自动保存在本地）", "Evaluate organizational resilience and shareholder alignment across mature cash-flow compounders (saved locally)"], ["全部勾选", "Check All"], ["重置清单", "Reset"], ["数据来源与一手监管/财报核验索引（SEC EDGAR & Official Releases）", "Primary Regulatory Filings & Official Disclosures Index (SEC EDGAR & FDA)"], ["本研报所有财务、人效、监管授权与治理变迁数据均严格核验自美国证监会（SEC EDGAR）、奥驰亚投资者关系官网（Altria Investor Relations）、美国食品药品监督管理局（FDA）及权威研究机构公开披露文件，仅供企业文化与商业模式研究参考，不构成任何投资建议。", "All financial, headcount, FDA authorization, and leadership figures are verified directly against U.S. SEC EDGAR filings, Altria Investor Relations releases, U.S. FDA PMTA orders, and institutional datasets. For organizational and business research only; not investment advice."]];
      var I18N_ATTR_PAIRS = [["展开/收起章节目录", "Toggle Chapter Sidebar"], ["切换目录侧边栏", "Toggle Chapter Sidebar"], ["面包屑导航", "Breadcrumb Navigation"], ["检索章节或指标…", "Jump to chapter or KPI…"], ["快速跳转章节或指标", "Quick jump to chapter or metric"], ["研究章节目录与站点导航", "Report Chapters & Site Navigation"], ["站点导航与章节目录", "Site Links & Table of Contents"], ["外观模式切换", "Appearance Theme Switch"], ["阅读与导出工具", "Reading & Export Tools"], ["导出独立 HTML 文件 (.html)", "Export Standalone HTML File (.html)"], ["打印或导出 PDF 研报", "Print or Save Report as PDF"], ["第一章图表视图切换", "Chapter 01 Chart View Switch"], ["搜索企业、掌舵人、品牌 (on! / ZYN / Vuse) 或文化特征…", "Search company, CEO, brand (on! / ZYN / Vuse) or culture…"], ["筛选对比企业", "Filter benchmark peers"], ["标杆企业分类筛选", "Peer category filter"], ["全球顶级烟草与消费防御巨头企业文化横向对比表", "Global Tobacco & Defensive Staples Corporate Culture Comparison"], ["历史与前瞻复利预设周期", "Historical & Forward Compounding Presets"], ["核查完成度进度条", "Checklist Completion Progress"]];

      var PILLAR_NOTES_EN = [
        '<strong>Selected Pillar (01 · We Shape Our Future):</strong> Management channels ≥$600M in <em>Optimize &amp; Accelerate</em> savings directly into smoke-free R&amp;D, nationwide on! PLUS distribution, and contract manufacturing capabilities <a class="cite-link" href="https://www.altria.com/Investors/2028-enterprise-goals" target="_blank" rel="noopener noreferrer">2028 Goals ↗</a>.',
        '<strong>Selected Pillar (02 · We Do What\'s Right):</strong> Enforces strict 21+ adult-only marketing, retail age-validation technology, and top-rated CPA-Zicklin political disclosure transparency for 9 straight years <a class="cite-link" href="https://www.altria.com/responsibility" target="_blank" rel="noopener noreferrer">Responsibility ↗</a>.',
        '<strong>Selected Pillar (03 · We Care &amp; Act as Owners):</strong> Incoming May 2026 CEO Sal Mancuso (joined 1990) and CFO Heather Newman (joined 1999) exemplify multi-decade internal cross-subsidiary leadership development <a class="cite-link" href="https://tobaccoreporter.com/2025/12/11/altria-ceo-gifford-to-retire-in-2026-mancuso-named-successor/" target="_blank" rel="noopener noreferrer">Tobacco Reporter ↗</a>.',
        '<strong>Selected Pillar (04 · Deliver &amp; Rise Together):</strong> Amid U.S. cigarette volume headwinds and a 31.8% discount segment share, precision RGM pricing lifted FY25 adjusted OCI margin to 62.4% <a class="cite-link" href="https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx" target="_blank" rel="noopener noreferrer">FY25 Release ↗</a>.'
      ];

      var PEER_ROWS_EN = [
        {
          category: 'dividend',
          benchmark: true,
          company: 'Benchmark: Altria Group (MO)',
          leader: 'Billy Gifford / Sal Mancuso (May 2026+)',
          positioning: 'U.S. domestic focus + compliant smoke-free pivot (Marlboro / Copenhagen / on! PLUS)',
          culture: 'Holding hub + AGDC/ALCS shared platforms + ultra-lean productivity',
          headcount: '~5,900 FTE · $3.41M Net Rev / FTE',
          margins: '62.4% Adj. OCI Margin · 61 hikes in 57 yrs ($4.44/sh)',
          verdict: 'Cash-flow & dividend leader: leanest org footprint without foreign FX or heavy overseas distribution overhead, maximizing shareholder payout.',
          sourceLabel: 'Altria FY25 Release',
          sourceUrl: 'https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx'
        },
        {
          category: 'global',
          benchmark: false,
          company: 'Philip Morris Intl (PMI · PM)',
          leader: 'Jacek Olczak',
          positioning: '180+ global markets + aggressive Smoke-Free Future (IQOS + ZYN)',
          culture: 'Global consumer-tech execution + Swedish Match acquisition ($16B+ R&D)',
          headcount: '~84,900 FTE · Multi-market global footprint',
          margins: 'FY25 Net Rev >$40B · 41.5% smoke-free mix (43% in Q1 26)',
          verdict: 'Aggressive global sibling: leads global heated & oral growth post-2008 spin-off, though operating with ~14.4x Altria\'s headcount.',
          sourceLabel: 'PMI 2025 Annual Report',
          sourceUrl: 'https://www.sec.gov/Archives/edgar/data/1413329/000162828026021174/pmi_2025xannualreport.pdf'
        },
        {
          category: 'global',
          benchmark: false,
          company: 'British American Tobacco (BAT · BTI)',
          leader: 'Tadeu Marroco',
          positioning: 'Multi-category global portfolio (Vuse vapor / Velo oral / glo heated)',
          culture: 'Multi-region matrix + simultaneous investment across 3 new categories',
          headcount: '>40,000 FTE · 100+ international markets',
          margins: 'H1 2026 Adj. Operating Margin 43.7% · 19.8% smokeless share',
          verdict: 'Broad multi-track bet vs. focused execution: broad next-gen footprint, but lower revenue per employee and margin than Altria.',
          sourceLabel: 'BAT H1 2026 Report',
          sourceUrl: 'https://www.bat.com/media/press-releases/_2026/july/half-year-report-for-the-six-months-to-30-june-2026'
        },
        {
          category: 'dividend',
          benchmark: false,
          company: 'Coca-Cola Company (KO)',
          leader: 'James Quincey',
          positioning: 'Asset-light concentrate core + global franchised bottler network',
          culture: 'Networked brand stewardship + 64-year consecutive Dividend King streak',
          headcount: '~65,900 FTE (FY25 10-K) · Franchise model',
          margins: 'FY25 Operating Margin 28.7% · 64 straight dividend hikes',
          verdict: 'Cross-sector Dividend King peer: shares century-old brand power and shelf dominance, while Altria\'s 62.4% OCI margin is >2x higher.',
          sourceLabel: 'Coca-Cola FY25 10-K',
          sourceUrl: 'https://www.sec.gov/Archives/edgar/data/21344/000162828026010047/ko-20251231.htm'
        }
      ];

      var CHECKLIST_ITEMS_EN = [
        {
          tag: 'Self-Disruption',
          title: '1. North-Star Self-Disruption Test: Does leadership define a vision beyond its legacy core?',
          desc: 'While legacy products still generate peak cash, has management publicly committed to a science-backed replacement pipeline like Moving Beyond Smoking?'
        },
        {
          tag: '$3.41M / FTE',
          title: '2. Lean Hub & Productivity Test: Are revenue per employee and margins compounding?',
          desc: 'Post-divestitures, has the organization stripped away bureaucracy (10,400 → 5,900 FTEs) while expanding both net revenue/FTE and OCI margins?'
        },
        {
          tag: 'AGDC / ALCS Backbone',
          title: '3. Shared Platform Leverage Test: Can new brands plug directly into scale distribution?',
          desc: 'Can incubated brands (such as Helix on! PLUS) immediately access >300,000 retail doors and centralized FDA regulatory science?'
        },
        {
          tag: '45.4% Tech & Sci',
          title: '4. Regulatory & Scientific Density Test: Is R&D talent dense enough to clear FDA bars?',
          desc: 'In heavily regulated industries, does scientific and engineering talent density build a durable FDA PMTA authorization moat?'
        },
        {
          tag: 'Capital Discipline',
          title: '5. Sunk-Cost & M&A Guardrail Test: Has management internalized past deal lessons?',
          desc: 'Following JUUL and NJOY hurdles, does leadership enforce strict valuation and regulatory discipline rather than subsidizing unprofitable share?'
        },
        {
          tag: '61 Hikes · 2.0x Debt',
          title: '6. Dividend King & Leverage Ceiling Test: Are debt caps and payout rules sacrosanct?',
          desc: 'Does the company anchor Debt/EBITDA near ~2.0x while returning free cash flow consistently through progressive dividends and buybacks?'
        }
      ];

      var QUICK_JUMP_EN = [
        { sec: 'sec-00', title: '00 Executive Summary & KPIs', sub: '$3.41M Rev/FTE · 62.4% Adj. OCI · 61 Hikes in 57 Yrs' },
        { sec: 'sec-01', title: '01 Operating Matrix & Transition', sub: 'PM USA / Helix on! PLUS / AGDC 300k Doors / Productivity Chart' },
        { sec: 'sec-02', title: '02 Four Cultural Pillars & FDA Moat', sub: 'Shape Our Future · Do What\'s Right · 5-Axis Culture Radar' },
        { sec: 'sec-03', title: '03 Global Tobacco Peer Comparison', sub: 'Altria MO vs. PMI vs. BAT vs. Coca-Cola KO' },
        { sec: 'sec-04', title: '04 Capital Discipline & DRIP Simulator', sub: 'FY26 EPS Guidance $5.66–$5.74 · Interactive DRIP Compounding' },
        { sec: 'sec-05', title: '05 Three-Era Evolution & Case Studies', sub: '2008 Spin-Off · Gifford Reset · May 2026 Sal Mancuso CEO' },
        { sec: 'sec-06', title: '06 Altria Governance Checklist', sub: '6-Point Cash-Cow Transition Diagnostic (Saved Locally)' },
        { sec: 'sec-07', title: '07 Primary Filings & Sources Index', sub: 'SEC EDGAR · Altria IR · U.S. FDA PMTA Orders' }
      ];

      var STORAGE_CHECK_KEY = 'mui_mo_culture_checks_v2';

      var PILLAR_NOTES = [
        '<strong>当前选中支柱解读（01 塑造未来）：</strong>管理层将 Optimize &amp; Accelerate 计划节降的至少 $6 亿美元成本定向重投于无烟研发、on! PLUS 全国扩店与数字合同制造能力建设 <a class="cite-link" href="https://www.altria.com/Investors/2028-enterprise-goals" target="_blank" rel="noopener noreferrer">2028 Goals ↗</a>。',
        '<strong>当前选中支柱解读（02 坚守正道）：</strong>坚持仅向 21+ 成年尼古丁消费者营销，建立行业最严苛的零售商年龄核验与政治支出披露机制（连续 9 年获评 CPA-Zicklin 透明度标杆） <a class="cite-link" href="https://www.altria.com/responsibility" target="_blank" rel="noopener noreferrer">Responsibility ↗</a>。',
        '<strong>当前选中支柱解读（03 彼此关怀与主人翁意识）：</strong>2026 年 5 月接任 CEO 的 Sal Mancuso（1990 年入职）与 CFO Heather Newman（1999 年入职）均由内部跨子公司培养产生，确保资本纪律与组织契约零断层 <a class="cite-link" href="https://tobaccoreporter.com/2025/12/11/altria-ceo-gifford-to-retire-in-2026-mancuso-named-successor/" target="_blank" rel="noopener noreferrer">Tobacco Reporter ↗</a>。',
        '<strong>当前选中支柱解读（04 交付极致与韧性迎战）：</strong>在全美卷烟销量下滑与折扣烟份额升至 31.8% 的逆风中，依靠精准区域定价与成本节降实现 FY25 调整后 OCI 利润率逆势增至 62.4% <a class="cite-link" href="https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx" target="_blank" rel="noopener noreferrer">FY25 Release ↗</a>。'
      ];

      var PEER_ROWS = [
        {
          category: 'dividend',
          benchmark: true,
          company: '研究基准：奥驰亚 (Altria · MO)',
          leader: '吉福德 / 萨尔·曼库索 (2026.05+)',
          positioning: '美国本土单一深耕 + 合规无烟渐进转型 (Marlboro / Copenhagen / on! PLUS)',
          culture: '控股中枢 + AGDC/ALCS 共享中台 + 极简高人效',
          headcount: '~5,900人 · 人均扣税创收 $3.41M',
          margins: '总调整后 OCI 率 62.4% · 57年61次加息 ($4.44/股)',
          verdict: '现金流与股息统治力居首：组织最为精简，无需承担跨国多币种与海外重资产铺网成本，将核心品牌利润最大化回馈股东。',
          sourceLabel: 'Altria FY25 Release',
          sourceUrl: 'https://investor.altria.com/press-releases/news-details/2026/Altria-Reports-2025-Fourth-Quarter-and-Full-Year-Results-Provides-2026-Earnings-Guidance/default.aspx'
        },
        {
          category: 'global',
          benchmark: false,
          company: '菲莫国际 (PMI · PM)',
          leader: '奥尔扎克 (Jacek Olczak)',
          positioning: '全球 180+ 市场覆盖 + 激进“无烟未来”转型 (IQOS + ZYN)',
          culture: '跨国消费电子化运营 + 重金并购瑞典火柴 ($16B+ 累计研发投入)',
          headcount: '~8.49万人 · 全球化重资产多国运营',
          margins: 'FY25 净营收破 $400亿 · 无烟营收占比达 41.5% (26Q1 达 43%)',
          verdict: '同根分拆的激进兄弟：2008 年自奥驰亚分拆后押注加热不燃与 ZYN 口含袋，无烟增速领跑全球，但员工规模约为奥驰亚 14.4 倍。',
          sourceLabel: 'PMI 2025 Annual Report',
          sourceUrl: 'https://www.sec.gov/Archives/edgar/data/1413329/000162828026021174/pmi_2025xannualreport.pdf'
        },
        {
          category: 'global',
          benchmark: false,
          company: '英美烟草 (BAT · BTI)',
          leader: '马罗科 (Tadeu Marroco)',
          positioning: '全球多品类全覆盖 (雾化 Vuse / 口含 Velo / 加热 glo)',
          culture: '多区域矩阵管理 + 三大新烟草赛道并行投入',
          headcount: '>4.0万人 · 覆盖百余国多元市场',
          margins: '26H1 调整后营业利润率 43.7% · 无烟占营收 19.8%',
          verdict: '全赛道撒网 vs 精准聚焦：BAT 在三大新品类全面布局，但此前曾对美国雷诺兹卷烟品牌计提巨额减值，人均创收与利润率低于奥驰亚。',
          sourceLabel: 'BAT H1 2026 Report',
          sourceUrl: 'https://www.bat.com/media/press-releases/_2026/july/half-year-report-for-the-six-months-to-30-june-2026'
        },
        {
          category: 'dividend',
          benchmark: false,
          company: '可口可乐 (Coca-Cola · KO)',
          leader: '詹鲲杰 (James Quincey)',
          positioning: '浓缩液轻资产核心 + 全球特许装瓶伙伴网络',
          culture: '网络化品牌心智运营 + 连续 64 年上调股息的股息王契约',
          headcount: '~6.59万人 (FY25 10-K) · 特许经营协同',
          margins: 'FY25 营业利润率 28.7% · 连续 64 年加息',
          verdict: '跨行业股息复利对照：两者同属“百年心智护城河 + 极致终端货架掌控 + 半世纪以上股息增长”典范，而奥驰亚运营利润率 (62.4%) 逾其两倍。',
          sourceLabel: 'Coca-Cola FY25 10-K',
          sourceUrl: 'https://www.sec.gov/Archives/edgar/data/21344/000162828026010047/ko-20251231.htm'
        }
      ];

      var CHECKLIST_ITEMS = [
        {
          tag: '转型愿景定力',
          title: '1. “自我颠覆北极星”测试：是否有勇气定义超越旧核心的愿景？',
          desc: '在传统业务仍贡献绝大部分利润时，管理层是否公开确立 Moving Beyond Smoking 级别的自我替代战略并配套真金白银研发？'
        },
        {
          tag: '$3.41M/人效标杆',
          title: '2. 极简总部与超高人效测试：人均创收与利润率是否持续进化？',
          desc: '在剥离非核心资产后，组织是否持续消除官僚冗余（从 10,400 人精简至 5,900 人），实现人均创收与 OCI 利润率同步攀升？'
        },
        {
          tag: 'AGDC/ALCS 协同',
          title: '3. 共享渠道与合规中台测试：新品牌能否直接复用巨头分销网络？',
          desc: '独立孵化的创新子品牌（如 Helix on! PLUS）能否零摩擦接入超 30 万家零售终端与统一法务科学申报平台？'
        },
        {
          tag: '45.4% 技术占比',
          title: '4. 科学实证与强合规护城河测试：技术与毒理研发人才密度是否够高？',
          desc: '在强监管行业中，工程与科学研发岗位占比是否足以支撑严苛的 FDA PMTA 临床与毒理学审评壁垒？'
        },
        {
          tag: '理性资本配置',
          title: '5. 审慎试错与沉没成本止损测试：是否吸取过往高溢价并购教训？',
          desc: '经历 JUUL 与 NJOY 外部磨合后，管理层在面对非法产品冲击与专利纠纷时是否坚守资本克制，拒绝盲目烧钱扩张？'
        },
        {
          tag: '61次加息 · 2.0x杠杆',
          title: '6. 股息之王契约与杠杆红线测试：债务上限与派息纪律是否刚性？',
          desc: '是否严格锚定约 2.0x 债务/EBITDA 杠杆上限，并将自由现金流以渐进式股息与回购持续兑现给长期股东？'
        }
      ];

      var QUICK_JUMP_INDEX = [
        { sec: 'sec-00', title: '00 执行摘要与核心指标', sub: '$3.41M 人均创收 · 62.4% OCI 率 · 57年61次加息' },
        { sec: 'sec-01', title: '01 运营公司矩阵与无烟转型', sub: 'PM USA / Helix on! PLUS / AGDC 30万终端 / 人效图表' },
        { sec: 'sec-02', title: '02 四大文化支柱与合规护城河', sub: '塑造未来 · 坚守正道 · 五维文化对比雷达图' },
        { sec: 'sec-03', title: '03 全球烟草巨头文化横向对比', sub: '奥驰亚 MO vs 菲莫国际 PMI vs 英美烟草 BAT vs 可口可乐 KO' },
        { sec: 'sec-04', title: '04 资本纪律、利润率与股息复利', sub: 'EPS 指引 $5.66–$5.74 · 交互式 DRIP 股息复利测算器' },
        { sec: 'sec-05', title: '05 三代演进与管理得失复盘', sub: '2008 分拆 · 吉福德重塑 · 2026.05 萨尔·曼库索接任 CEO' },
        { sec: 'sec-06', title: '06 奥驰亚文化法则核查清单', sub: '6 项转型现金牛治理自测与本地持久化评分' },
        { sec: 'sec-07', title: '07 数据来源与监管核验索引', sub: 'SEC EDGAR · Altria IR · FDA PMTA 权威信源档案' }
      ];

      var PRESETS = {
        p1: { principal: 10000, years: 18, priceCagr: 5.2, drip: true },
        p2: { principal: 10000, years: 30, priceCagr: 5.6, drip: true },
        p3: { principal: 10000, years: 10, priceCagr: 4.5, drip: true }
      };

      var state = {
        lang: 'zh',
        theme: 'light',
        ch1View: 'viewA',
        activePillar: 0,
        radarSeries: { mo: true, pmi: true, ko: true },
        peerFilter: 'all',
        peerQuery: '',
        sim: { principal: 10000, years: 18, priceCagr: 5.2, drip: true, preset: 'p1' },
        checks: [true, true, true, false, false, false]
      };

      /* Safe LocalStorage Helpers */
      function safeGetStorage(key) {
        try {
          return window.localStorage.getItem(key);
        } catch (err) {
          return null;
        }
      }

      function safeSetStorage(key, val) {
        try {
          window.localStorage.setItem(key, val);
        } catch (err) {
          /* Ignore storage quota/sandbox restrictions */
        }
      }

      /* Toast Notification (MUI Snackbar) */
      var toastTimer = null;
      function showToast(message) {
        var el = document.getElementById('muiSnackbar');
        if (!el) return;
        el.textContent = message;
        el.classList.add('show');
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(function () {
          el.classList.remove('show');
        }, 2800);
      }

      /* ======================================================================
         2. Theme Switching & Sidebar Drawer
         ====================================================================== */
      function isEn() {
        return state.lang === 'en';
      }

      var _zhToEnText = {};
      var _enToZhText = {};
      for (var _ti = 0; _ti < I18N_TEXT_PAIRS.length; _ti++) {
        _zhToEnText[I18N_TEXT_PAIRS[_ti][0]] = I18N_TEXT_PAIRS[_ti][1];
        _enToZhText[I18N_TEXT_PAIRS[_ti][1]] = I18N_TEXT_PAIRS[_ti][0];
      }
      var _zhToEnAttr = {};
      var _enToZhAttr = {};
      for (var _ai = 0; _ai < I18N_ATTR_PAIRS.length; _ai++) {
        _zhToEnAttr[I18N_ATTR_PAIRS[_ai][0]] = I18N_ATTR_PAIRS[_ai][1];
        _enToZhAttr[I18N_ATTR_PAIRS[_ai][1]] = I18N_ATTR_PAIRS[_ai][0];
      }
      var _richMapByKey = {};
      for (var _ri = 0; _ri < I18N_RICH_LIST.length; _ri++) {
        _richMapByKey[I18N_RICH_LIST[_ri].key] = I18N_RICH_LIST[_ri];
      }

      function bindRichBlocksOnce() {
        var candidates = document.querySelectorAll('h1, p, div');
        for (var i = 0; i < candidates.length; i++) {
          var el = candidates[i];
          if (el.getAttribute('data-i18n-rich')) continue;
          if (el.id === 'pillarFocusNote' || el.closest('#pillarFocusNote')) continue;
          var normTxt = (el.textContent || '').replace(/\s+/g, ' ').trim();
          for (var j = 0; j < I18N_RICH_LIST.length; j++) {
            var item = I18N_RICH_LIST[j];
            if (normTxt.indexOf(item.match_zh) === 0 && el.children.length <= 25) {
              /* Verify no child block divisions inside */
              if (!el.querySelector('div, p, ul, table, canvas')) {
                el.setAttribute('data-i18n-rich', item.key);
                break;
              }
            }
          }
        }
      }

      function syncCh1HeaderText() {
        var titleEl = document.getElementById('ch1ChartTitle');
        var subEl = document.getElementById('ch1ChartSub');
        if (!titleEl || !subEl) return;
        if (state.ch1View === 'viewA') {
          titleEl.textContent = isEn()
            ? 'FY2023–FY2025 Revenues Net of Excise Taxes by Core Segment ($B · SEC 10-K)'
            : 'FY2023–FY2025 扣税后净营收结构与现金牛利润支柱（$B · SEC 10-K）';
          subEl.textContent = isEn()
            ? 'Smokeable defends a $17.4B+ cash base while Oral Tobacco expands steadily to $2.70B'
            : '可燃烟草（Smokeable）稳守 $17.4B+ 现金基底，无烟口服烟草（Oral Tobacco）稳步扩张至 $2.70B';
        } else {
          titleEl.textContent = isEn()
            ? 'FY2008–FY2025 Headcount Streamlining (k FTEs) vs. Net Revenue per Employee ($M)'
            : 'FY2008–FY2025 员工人数精简（千人）vs 人均扣税创收跃升（$M）';
          subEl.textContent = isEn()
            ? 'Since the 2008 PMI spin-off, FTEs streamlined from 10,400 to 5,900 while net rev/employee more than doubled ($1.53M → $3.41M)'
            : '自 2008 年剥离菲莫国际以来全职员工由 10,400 人精简至 5,900 人，人均创收由 $1.53M 跃升至 $3.41M';
        }
      }

      function syncCollapseButtonsText() {
        var btns = document.querySelectorAll('[data-collapse-target]');
        for (var i = 0; i < btns.length; i++) {
          var pid = btns[i].getAttribute('data-collapse-target');
          var panel = document.getElementById(pid);
          var isOpen = panel && panel.classList.contains('open');
          if (isEn()) {
            btns[i].innerHTML = isOpen ? '<span>Hide Execution Mechanics</span> <span>⌃</span>' : '<span>Show Execution Mechanics</span> <span>⌄</span>';
          } else {
            btns[i].innerHTML = isOpen ? '<span>收起微观执行机制</span> <span>⌃</span>' : '<span>展开微观执行机制</span> <span>⌄</span>';
          }
        }
      }

      function applyLanguage(lang, silent) {
        bindRichBlocksOnce();
        state.lang = lang === 'en' ? 'en' : 'zh';
        var en = isEn();
        document.documentElement.setAttribute('lang', en ? 'en' : 'zh-CN');
        document.documentElement.setAttribute('data-lang', state.lang);
        document.title = en ? DOC_TITLE_EN : DOC_TITLE_ZH;

        var lGrp = document.getElementById('langSwitchGroup');
        if (lGrp) lGrp.setAttribute('aria-label', en ? 'Language switcher' : '语言切换');
        var abThmBtn = document.getElementById('appbarThemeBtn');
        if (abThmBtn) {
          abThmBtn.setAttribute('title', en ? 'Toggle Light / Dark theme' : '切换浅色 / 深色主题');
          abThmBtn.setAttribute('aria-label', en ? 'Toggle color theme' : '切换深浅色主题');
        }
        var dynNavSpans = document.querySelectorAll('[data-i18n-zh][data-i18n-en]');
        for (var dn = 0; dn < dynNavSpans.length; dn++) {
          dynNavSpans[dn].textContent = en ? dynNavSpans[dn].getAttribute('data-i18n-en') : dynNavSpans[dn].getAttribute('data-i18n-zh');
        }
        var lGrp2 = document.getElementById('langSwitchGroup');
        if (lGrp2) lGrp2.setAttribute('aria-label', en ? 'Language switcher' : '语言切换');
        var zhBtn = document.getElementById('langZhBtn');
        var enBtn = document.getElementById('langEnBtn');
        if (zhBtn && enBtn) {
          zhBtn.classList.toggle('active', !en);
          enBtn.classList.toggle('active', en);
          zhBtn.setAttribute('aria-pressed', !en ? 'true' : 'false');
          enBtn.setAttribute('aria-pressed', en ? 'true' : 'false');
        }
        var dynNavSpans = document.querySelectorAll('[data-i18n-zh][data-i18n-en]');
        for (var dn = 0; dn < dynNavSpans.length; dn++) {
          dynNavSpans[dn].textContent = en ? dynNavSpans[dn].getAttribute('data-i18n-en') : dynNavSpans[dn].getAttribute('data-i18n-zh');
        }

        /* 1. Update Rich Prose Blocks */
        var richNodes = document.querySelectorAll('[data-i18n-rich]');
        for (var r = 0; r < richNodes.length; r++) {
          var rk = richNodes[r].getAttribute('data-i18n-rich');
          var rEntry = _richMapByKey[rk];
          if (rEntry) {
            richNodes[r].innerHTML = en ? rEntry.en : rEntry.zh;
          }
        }

        /* 2. Walk Pure Text Nodes */
        var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
        var tNode;
        while ((tNode = walker.nextNode())) {
          var pEl = tNode.parentElement;
          if (!pEl) continue;
          var tag = pEl.tagName;
          if (tag === 'SCRIPT' || tag === 'STYLE') continue;
          if (pEl.closest('#langSwitchGroup') || pEl.closest('[data-i18n-rich]') || pEl.closest('#pillarFocusNote')) continue;
          var raw = tNode.nodeValue || '';
          var trimmed = raw.replace(/\s+/g, ' ').trim();
          if (!trimmed) continue;
          var mapped = en ? _zhToEnText[trimmed] : _enToZhText[trimmed];
          if (mapped) {
            var leadMatch = raw.match(/^\s*/);
            var trailMatch = raw.match(/\s*$/);
            tNode.nodeValue = (leadMatch ? leadMatch[0] : '') + mapped + (trailMatch ? trailMatch[0] : '');
          }
        }

        /* 3. Update Attributes (placeholder, title, aria-label) */
        var allEls = document.querySelectorAll('[placeholder], [title], [aria-label]');
        var attrNames = ['placeholder', 'title', 'aria-label'];
        for (var a = 0; a < allEls.length; a++) {
          if (allEls[a].closest('#langSwitchGroup')) continue;
          for (var k = 0; k < attrNames.length; k++) {
            var an = attrNames[k];
            var av = allEls[a].getAttribute(an);
            if (!av) continue;
            var nextAv = en ? _zhToEnAttr[av] : _enToZhAttr[av];
            if (nextAv) allEls[a].setAttribute(an, nextAv);
          }
        }

        /* 4. Update Dynamic Panels & Redraw All 5 High-DPI Charts */
        var pNote = document.getElementById('pillarFocusNote');
        if (pNote) {
          var notesArr = en ? PILLAR_NOTES_EN : PILLAR_NOTES;
          pNote.innerHTML = '<div>' + notesArr[state.activePillar] + '</div>';
        }
        syncCh1HeaderText();
        syncCollapseButtonsText();
        renderPeerTable();
        renderChecklist();
        updateSimulatorUI();
        renderAllCharts();
        safeSetStorage(STORAGE_LANG_KEY, state.lang);

        if (!silent) {
          showToast(en ? 'Switched to English Research Edition' : '已切换至中文深度研报视图');
        }
      }

      function applyTheme(theme, silent) {
        state.theme = theme === 'dark' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', state.theme);
        var abIconEl = document.getElementById('appbarThemeIcon');
        if (abIconEl) abIconEl.innerHTML = (state.theme === 'dark') ? '<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zm18 0h2c.55 0 1-.45 1-1s-.45-1-1-1h-2c-.55 0-1 .45-1 1s.45 1 1 1zM11 2v2c0 .55.45 1 1 1s1-.45 1-1V2c0-.55-.45-1-1-1s-1 .45-1 1zm0 18v2c0 .55.45 1 1 1s1-.45 1-1v-2c0-.55-.45-1-1-1s-1 .45-1 1zM5.99 4.58a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0s.39-1.03 0-1.41L5.99 4.58zm12.37 12.37a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0a.996.996 0 0 0 0-1.41l-1.06-1.06zm1.06-10.96a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06zM7.05 18.36a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06z"/></svg>' : '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3a9 9 0 1 0 9 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 0 1-4.4 2.26 5.403 5.403 0 0 1-3.14-9.8c-.44-.06-.9-.1-1.36-.1z"/></svg>';
        var sDarkBtn = document.getElementById('sideThemeDarkBtn');
        var sLightBtn = document.getElementById('sideThemeLightBtn');
        if (sDarkBtn && sLightBtn) {
          void 0;
          void 0;
        }
        safeSetStorage(STORAGE_THEME_KEY, state.theme);
        renderAllCharts();
        if (!silent) {
          showToast(state.theme === 'dark' ? (isEn() ? 'Switched to Dark Mode' : '已切换至 MUI 深海黑曜石护眼模式') : (isEn() ? 'Switched to Light Mode' : '已切换至 MUI 浅色明亮阅读模式'));
        }
      }

      function toggleSidebar() {
        if (window.innerWidth <= 1120) {
          document.body.classList.toggle('drawer-open');
        } else {
          document.body.classList.toggle('sidebar-collapsed');
          setTimeout(renderAllCharts, 60);
        }
      }

      function closeMobileDrawer() {
        document.body.classList.remove('drawer-open');
      }

      /* ======================================================================
         3. Peer Comparison Table Rendering & Filtering
         ====================================================================== */
      function escapeHtml(str) {
        return String(str)
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;');
      }

      function highlightMatch(text, query) {
        var safe = escapeHtml(text);
        if (!query) return safe;
        var escapedQ = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        var re = new RegExp('(' + escapedQ + ')', 'gi');
        return safe.replace(re, '<mark class="hl">$1</mark>');
      }

      function renderPeerTable() {
        var tbody = document.getElementById('peerTableBody');
        var badge = document.getElementById('peerCountBadge');
        if (!tbody) return;

        var activeRows = isEn() ? PEER_ROWS_EN : PEER_ROWS;
        var q = state.peerQuery.trim().toLowerCase();
        var filtered = activeRows.filter(function (row, idx) {
          var catOk = state.peerFilter === 'all' || row.category === state.peerFilter;
          if (!catOk) return false;
          if (!q) return true;
          var zhR = PEER_ROWS[idx] || row;
          var enR = PEER_ROWS_EN[idx] || row;
          var hay = (zhR.company + ' ' + zhR.leader + ' ' + zhR.positioning + ' ' + zhR.culture + ' ' + zhR.verdict + ' ' + enR.company + ' ' + enR.leader + ' ' + enR.positioning + ' ' + enR.culture + ' ' + enR.verdict).toLowerCase();
          return hay.indexOf(q) !== -1;
        });

        if (badge) {
          badge.textContent = isEn()
            ? ('Showing ' + filtered.length + ' / ' + activeRows.length + ' Peers')
            : ('显示 ' + filtered.length + ' / ' + activeRows.length + ' 家标杆企业');
        }

        if (!filtered.length) {
          tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:28px;">' + (isEn() ? 'No matching benchmark companies found. Try another keyword or reset filters.' : '未找到匹配的标杆企业记录，请尝试其他关键词或重置筛选条件。') + '</td></tr>';
          return;
        }

        var rawQ = state.peerQuery.trim();
        tbody.innerHTML = filtered.map(function (r) {
          return '<tr class="' + (r.benchmark ? 'benchmark-row' : '') + '">' +
            '<td><strong style="color:var(--text-primary);display:block;">' + highlightMatch(r.company, rawQ) + '</strong><span style="font-size:0.76rem;color:var(--text-muted);">' + highlightMatch(r.leader, rawQ) + '</span></td>' +
            '<td>' + highlightMatch(r.positioning, rawQ) + '</td>' +
            '<td>' + highlightMatch(r.culture, rawQ) + '</td>' +
            '<td class="mono" style="font-size:0.79rem;">' + highlightMatch(r.headcount, rawQ) + '</td>' +
            '<td class="mono" style="font-size:0.79rem;color:var(--mui-primary-lighter);font-weight:700;">' + highlightMatch(r.margins, rawQ) + '</td>' +
            '<td>' + highlightMatch(r.verdict, rawQ) + ' <a class="cite-link" href="' + r.sourceUrl + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(r.sourceLabel) + ' ↗</a></td>' +
            '</tr>';
        }).join('');
      }

      /* ======================================================================
         4. DRIP Dividend Compounding Simulator
         ====================================================================== */
      function formatCurrency(val) {
        return '$' + Math.round(val).toLocaleString('en-US');
      }

      function updateSimulatorUI() {
        var p = state.sim.principal;
        var yrs = state.sim.years;
        var cagr = state.sim.priceCagr;
        var dripRate = state.sim.drip ? 7.2 : 0.0;
        var totalRate = (cagr + dripRate) / 100;

        var endingValue = p * Math.pow(1 + totalRate, yrs);
        var moic = endingValue / p;
        var netGain = endingValue - p;
        var midYear = Math.max(1, Math.floor(yrs / 2));
        var midValue = p * Math.pow(1 + totalRate, midYear);

        document.getElementById('simPrincipalLabel').textContent = formatCurrency(p);
        document.getElementById('simYearsLabel').textContent = yrs + (isEn() ? ' yrs' : ' 年');
        document.getElementById('simCagrLabel').textContent = cagr.toFixed(1) + '%';

        document.getElementById('simEndingVal').textContent = formatCurrency(endingValue);
        document.getElementById('simMoicVal').textContent = moic.toFixed(2) + 'x · ' + (totalRate * 100).toFixed(2) + '%';
        document.getElementById('simNetGainVal').textContent = formatCurrency(netGain);
        document.getElementById('simMidLabel').textContent = isEn() ? ('Year ' + midYear + ' Midpoint Value') : ('第 ' + midYear + ' 年中期资产节点');
        document.getElementById('simMidVal').textContent = formatCurrency(midValue);

        var presetBtns = document.querySelectorAll('[data-preset]');
        for (var i = 0; i < presetBtns.length; i++) {
          presetBtns[i].classList.toggle('active', presetBtns[i].getAttribute('data-preset') === state.sim.preset);
        }

        drawSimChart();
      }

      /* ======================================================================
         5. Interactive Checklist
         ====================================================================== */
      function renderChecklist() {
        var container = document.getElementById('checklistContainer');
        var chip = document.getElementById('checklistScoreChip');
        var bar = document.getElementById('checklistProgressBar');
        if (!container) return;

        var itemsList = isEn() ? CHECKLIST_ITEMS_EN : CHECKLIST_ITEMS;
        var doneCount = state.checks.filter(Boolean).length;
        var pct = Math.round((doneCount / itemsList.length) * 100);
        if (chip) {
          chip.textContent = isEn()
            ? ('Verified ' + doneCount + ' / ' + itemsList.length + ' (' + pct + '%)')
            : ('已核查 ' + doneCount + ' / ' + itemsList.length + ' 项 (' + pct + '%)');
        }
        if (bar) {
          bar.style.width = pct + '%';
        }

        container.innerHTML = itemsList.map(function (item, idx) {
          var isChecked = !!state.checks[idx];
          return '<label class="check-card ' + (isChecked ? 'checked' : '') + '" data-check-idx="' + idx + '">' +
            '<input type="checkbox" data-check-input="' + idx + '" ' + (isChecked ? 'checked' : '') + ' />' +
            '<div style="flex:1;">' +
              '<div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:6px;margin-bottom:4px;">' +
                '<span class="check-title">' + escapeHtml(item.title) + '</span>' +
                '<span class="mui-chip mono">' + escapeHtml(item.tag) + '</span>' +
              '</div>' +
              '<p class="check-desc">' + escapeHtml(item.desc) + '</p>' +
            '</div>' +
          '</label>';
        }).join('');
      }

      /* ======================================================================
         6. Built-In Zero-Dependency MUI X Charts-Style High-DPI Engine
         ====================================================================== */
      state.ch1Series = { s1: true, s2: true };
      state.epsSeries = { eps: true, oci: true };

      var hitRegions = {
        chartCh1: [],
        chartRadar: [],
        chartBars: [],
        chartEps: [],
        chartSim: []
      };

      var hoverState = {
        chartCh1: -1,
        chartRadar: -1,
        chartBars: -1,
        chartEps: -1,
        chartSim: -1
      };

      function getPalette() {
        var cs = getComputedStyle(document.documentElement);
        var isDark = state.theme === 'dark';
        return {
          isDark: isDark,
          grid: cs.getPropertyValue('--chart-grid').trim() || (isDark ? 'rgba(148,163,184,0.13)' : 'rgba(100,116,139,0.16)'),
          tick: cs.getPropertyValue('--chart-tick').trim() || '#94A3B8',
          text: cs.getPropertyValue('--text-primary').trim() || '#F3F6F9',
          sub: cs.getPropertyValue('--text-secondary').trim() || '#B2BAC2',
          pillBg: isDark ? 'rgba(9, 13, 22, 0.88)' : 'rgba(255, 255, 255, 0.94)',
          pillBorder: isDark ? 'rgba(51, 153, 255, 0.28)' : 'rgba(0, 115, 230, 0.24)',
          trackBg: isDark ? 'rgba(148, 163, 184, 0.10)' : 'rgba(15, 25, 36, 0.06)',
          hoverBand: isDark ? 'rgba(51, 153, 255, 0.07)' : 'rgba(0, 115, 230, 0.05)',
          c1: cs.getPropertyValue('--chart-c1').trim() || '#3399FF',
          c2: cs.getPropertyValue('--chart-c2').trim() || '#22C55E',
          c3: cs.getPropertyValue('--chart-c3').trim() || '#FFB74D',
          c4: cs.getPropertyValue('--chart-c4').trim() || '#A78BFA'
        };
      }

      function prepareCanvas(id) {
        var canvas = document.getElementById(id);
        if (!canvas || !canvas.parentElement) return null;
        var stage = canvas.parentElement;
        var rect = stage.getBoundingClientRect();
        var w = Math.max(240, Math.floor(rect.width));
        var h = Math.max(170, Math.floor(rect.height));
        var dpr = Math.min(window.devicePixelRatio || 1, 2.5);
        /* Lock CSS size strictly to parent stage so DPR scaling NEVER mutates layout */
        canvas.style.width = w + 'px';
        canvas.style.height = h + 'px';
        var targetW = Math.floor(w * dpr);
        var targetH = Math.floor(h * dpr);
        if (canvas.width !== targetW) canvas.width = targetW;
        if (canvas.height !== targetH) canvas.height = targetH;
        var ctx = canvas.getContext('2d');
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, w, h);
        return { ctx: ctx, w: w, h: h, canvas: canvas };
      }

      function roundRectPath(ctx, x, y, w, h, r) {
        if (w <= 0 || h <= 0) return;
        var radius = Math.min(r, w / 2, h / 2);
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + w - radius, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
        ctx.lineTo(x + w, y + h - radius);
        ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
        ctx.lineTo(x + radius, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
      }

      function topRoundedBar(ctx, x, y, w, h, r) {
        if (w <= 0 || h <= 0) return;
        var rad = Math.min(r, w / 2, h);
        ctx.beginPath();
        ctx.moveTo(x, y + h);
        ctx.lineTo(x, y + rad);
        ctx.quadraticCurveTo(x, y, x + rad, y);
        ctx.lineTo(x + w - rad, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
        ctx.lineTo(x + w, y + h);
        ctx.closePath();
      }

      function drawValueBadge(ctx, text, cx, cy, fgColor, pal) {
        ctx.save();
        ctx.font = '700 11px "IBM Plex Mono", system-ui, sans-serif';
        var tw = ctx.measureText(text).width + 10;
        var th = 18;
        var bx = cx - tw / 2;
        var by = cy - th / 2;
        ctx.fillStyle = pal.pillBg;
        roundRectPath(ctx, bx, by, tw, th, 5);
        ctx.fill();
        ctx.strokeStyle = pal.pillBorder;
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.fillStyle = fgColor;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(text, cx, cy + 0.5);
        ctx.restore();
      }

      function drawSmoothLine(ctx, pts) {
        if (!pts.length) return;
        ctx.beginPath();
        ctx.moveTo(pts[0].x, pts[0].y);
        for (var i = 0; i < pts.length - 1; i++) {
          var xc = (pts[i].x + pts[i + 1].x) / 2;
          ctx.bezierCurveTo(xc, pts[i].y, xc, pts[i + 1].y, pts[i + 1].x, pts[i + 1].y);
        }
      }

      /* Chart 1: View A (Grouped Bar + Share Callouts) & View B (Dual-Axis Employee vs Rev/Emp) */
      function drawCh1Chart() {
        var env = prepareCanvas('chartCh1');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h;
        var pal = getPalette();
        hitRegions.chartCh1 = [];

        var metaEl = document.getElementById('ch1AxisMeta');
        var leg1 = document.getElementById('ch1Leg1');
        var leg2 = document.getElementById('ch1Leg2');

        if (state.ch1View === 'viewA') {
          if (metaEl) {
            metaEl.innerHTML = isEn()
              ? '<span style="color:var(--chart-c1);">■ Left Axis: Revenue Net of Excise Taxes ($B)</span><span style="color:var(--text-muted);">FY25 Combined Net Revenue $20.14B (Oral Share 13.4%)</span>'
              : '<span style="color:var(--chart-c1);">■ 左轴：扣消费税净营收 ($B)</span><span style="color:var(--text-muted);">FY25 合计扣税净营收 $20.14B (其中无烟口服占 13.4%)</span>';
          }
          if (leg1) leg1.textContent = isEn() ? 'Smokeable Net Revenue ex-Excise ($B · Marlboro / Black & Mild)' : 'Smokeable 可燃烟草扣税营收 ($B · Marlboro / Black & Mild)';
          if (leg2) leg2.textContent = isEn() ? 'Oral Tobacco Net Revenue ex-Excise ($B · Copenhagen / on!)' : 'Oral Tobacco 口服无烟扣税营收 ($B · Copenhagen / on!)';

          var padA = { top: 26, right: 20, bottom: 44, left: 48 };
          var pwA = w - padA.left - padA.right;
          var phA = h - padA.top - padA.bottom;
          var labelsA = ['FY2023', 'FY2024', 'FY2025'];
          var smokeable = [17.89, 17.74, 17.44];
          var oral = [2.56, 2.67, 2.70];
          var totals = [20.48, 20.44, 20.14];
          var maxY = 22.0;

          for (var g = 0; g <= 4; g++) {
            var val = (maxY / 4) * g;
            var gy = padA.top + phA - (g / 4) * phA;
            ctx.strokeStyle = pal.grid;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(padA.left, gy);
            ctx.lineTo(padA.left + pwA, gy);
            ctx.stroke();

            ctx.fillStyle = pal.tick;
            ctx.font = '11px "IBM Plex Mono", sans-serif';
            ctx.textAlign = 'right';
            ctx.textBaseline = 'middle';
            ctx.fillText('$' + val.toFixed(1) + 'B', padA.left - 8, gy);
          }

          var stepA = pwA / labelsA.length;
          var barW = Math.min(54, Math.max(24, stepA * 0.27));

          for (var i = 0; i < labelsA.length; i++) {
            var cx = padA.left + stepA * (i + 0.5);

            if (hoverState.chartCh1 === i) {
              ctx.fillStyle = pal.hoverBand;
              roundRectPath(ctx, padA.left + stepA * i + 6, padA.top, stepA - 12, phA, 8);
              ctx.fill();
            }

            if (state.ch1Series.s1) {
              var h1 = (smokeable[i] / maxY) * phA;
              var x1 = state.ch1Series.s2 ? (cx - barW - 5) : (cx - barW / 2);
              var y1 = padA.top + phA - h1;
              var grad1 = ctx.createLinearGradient(0, y1, 0, padA.top + phA);
              grad1.addColorStop(0, '#3399FF');
              grad1.addColorStop(1, '#0066CC');
              ctx.fillStyle = grad1;
              topRoundedBar(ctx, x1, y1, barW, h1, 6);
              ctx.fill();
              drawValueBadge(ctx, '$' + smokeable[i].toFixed(2) + 'B', x1 + barW / 2, y1 - 12, pal.c1, pal);
            }

            if (state.ch1Series.s2) {
              var h2 = (oral[i] / maxY) * phA;
              var x2 = state.ch1Series.s1 ? (cx + 5) : (cx - barW / 2);
              var y2 = padA.top + phA - h2;
              var grad2 = ctx.createLinearGradient(0, y2, 0, padA.top + phA);
              grad2.addColorStop(0, '#34D399');
              grad2.addColorStop(1, '#16A34A');
              ctx.fillStyle = grad2;
              topRoundedBar(ctx, x2, y2, barW, h2, 6);
              ctx.fill();
              drawValueBadge(ctx, '$' + oral[i].toFixed(2) + 'B', x2 + barW / 2, y2 - 12, pal.c2, pal);
            }

            ctx.fillStyle = pal.text;
            ctx.font = '700 12px system-ui, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'alphabetic';
            ctx.fillText(labelsA[i], cx, padA.top + phA + 20);
            ctx.fillStyle = pal.tick;
            ctx.font = '10.5px "IBM Plex Mono", sans-serif';
            ctx.fillText((isEn() ? 'Total $' : '合计 $') + totals[i].toFixed(2) + 'B', cx, padA.top + phA + 35);

            hitRegions.chartCh1.push({
              idx: i,
              x: padA.left + stepA * i, y: padA.top, w: stepA, h: phA + 36,
              html: isEn()
                ? ('<strong>' + labelsA[i] + ' Revenue Net of Excise Taxes</strong><br/>' +
                   '• Smokeable Products: <strong>$' + smokeable[i].toFixed(2) + 'B</strong><br/>' +
                   '• Oral Tobacco: <strong>$' + oral[i].toFixed(2) + 'B</strong> (' + ((oral[i] / totals[i]) * 100).toFixed(1) + '%)<br/>' +
                   '• Combined Segment Net Revenue: <strong>$' + totals[i].toFixed(2) + 'B</strong>')
                : ('<strong>' + labelsA[i] + ' 扣消费税净营收结构</strong><br/>' +
                   '• 可燃烟草 (Smokeable)：<strong>$' + smokeable[i].toFixed(2) + 'B</strong><br/>' +
                   '• 无烟口服 (Oral Tobacco)：<strong>$' + oral[i].toFixed(2) + 'B</strong> (' + ((oral[i] / totals[i]) * 100).toFixed(1) + '%)<br/>' +
                   '• 全公司扣税净营收合计：<strong>$' + totals[i].toFixed(2) + 'B</strong>')
            });
          }
        } else {
          if (metaEl) {
            metaEl.innerHTML = isEn()
              ? '<span style="color:var(--chart-c1);">■ Left Axis: Full-Time Employees (k)</span><span style="color:var(--chart-c2);">● Right Axis: Net Revenue / Employee ($M)</span>'
              : '<span style="color:var(--chart-c1);">■ 左轴：全职员工人数 (千人)</span><span style="color:var(--chart-c2);">● 右轴：人均扣税创收 ($M/人)</span>';
          }
          if (leg1) leg1.textContent = isEn() ? 'Full-Time Employees (Left Axis · k)' : '全职员工人数 Full-Time Employees (左轴 · 千人)';
          if (leg2) leg2.textContent = isEn() ? 'Net Revenue per Employee (Right Axis · $M)' : '人均扣税净营收 Revenue per Employee (右轴 · $M)';

          var padB = { top: 28, right: 50, bottom: 38, left: 46 };
          var pwB = w - padB.left - padB.right;
          var phB = h - padB.top - padB.bottom;
          var labelsB = ['FY08', 'FY12', 'FY16', 'FY20', 'FY23', 'FY24', 'FY25'];
          var fullLabelsB = isEn() ? ['FY2008 (Post-Spin Base)', 'FY2012', 'FY2016', 'FY2020', 'FY2023', 'FY2024', 'FY2025'] : ['FY2008 (分拆起步)', 'FY2012', 'FY2016', 'FY2020', 'FY2023', 'FY2024', 'FY2025'];
          var empK = [10.4, 9.1, 8.3, 7.1, 6.4, 6.2, 5.9];
          var revM = [1.53, 1.92, 2.33, 2.94, 3.20, 3.30, 3.41];
          /* Separate scales cleanly so bars occupy lower band and revenue/employee rises cleanly above */
          var maxEmp = 22.0;
          var minRev = 0.8, maxRev = 3.8;

          for (var j = 0; j <= 4; j++) {
            var r = j / 4;
            var yGrid = padB.top + phB - r * phB;
            ctx.strokeStyle = pal.grid;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(padB.left, yGrid);
            ctx.lineTo(padB.left + pwB, yGrid);
            ctx.stroke();

            ctx.font = '11px "IBM Plex Mono", sans-serif';
            ctx.textBaseline = 'middle';
            ctx.fillStyle = pal.tick;
            ctx.textAlign = 'right';
            ctx.fillText((maxEmp * r).toFixed(1) + 'k', padB.left - 7, yGrid);

            ctx.fillStyle = pal.c2;
            ctx.textAlign = 'left';
            ctx.fillText('$' + (minRev + r * (maxRev - minRev)).toFixed(1) + 'M', padB.left + pwB + 7, yGrid);
          }

          var stepB = pwB / labelsB.length;
          var bWidth = Math.min(36, Math.max(18, stepB * 0.42));
          var pts = [];

          for (var k = 0; k < labelsB.length; k++) {
            var centerX = padB.left + stepB * (k + 0.5);
            if (hoverState.chartCh1 === k) {
              ctx.fillStyle = pal.hoverBand;
              roundRectPath(ctx, padB.left + stepB * k + 3, padB.top, stepB - 6, phB, 6);
              ctx.fill();
            }

            if (state.ch1Series.s1) {
              var bH = (empK[k] / maxEmp) * phB;
              var bX = centerX - bWidth / 2;
              var bY = padB.top + phB - bH;
              var bGrad = ctx.createLinearGradient(0, bY, 0, padB.top + phB);
              if (pal.isDark) {
                bGrad.addColorStop(0, 'rgba(51, 153, 255, 0.72)');
                bGrad.addColorStop(1, 'rgba(0, 115, 230, 0.26)');
              } else {
                bGrad.addColorStop(0, '#1985F1');
                bGrad.addColorStop(1, '#0066CC');
              }
              ctx.fillStyle = bGrad;
              topRoundedBar(ctx, bX, bY, bWidth, bH, 5);
              ctx.fill();
              ctx.strokeStyle = pal.c1;
              ctx.lineWidth = 1.2;
              ctx.stroke();

              ctx.fillStyle = '#FFFFFF';
              if (!pal.isDark) ctx.fillStyle = '#0F1924';
              ctx.font = '700 9.5px "IBM Plex Mono", sans-serif';
              ctx.textAlign = 'center';
              ctx.textBaseline = 'alphabetic';
              if (bH > 22) {
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(empK[k].toFixed(1) + 'k', centerX, bY + 15);
              }
            }

            var lY = padB.top + phB - ((revM[k] - minRev) / (maxRev - minRev)) * phB;
            pts.push({ x: centerX, y: lY, rev: revM[k] });

            ctx.fillStyle = k === 0 || k === 6 ? pal.text : pal.tick;
            ctx.font = (k === 0 || k === 6 ? '700 ' : '600 ') + '11.5px system-ui, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'alphabetic';
            ctx.fillText(labelsB[k], centerX, padB.top + phB + 22);

            hitRegions.chartCh1.push({
              idx: k,
              x: padB.left + stepB * k, y: padB.top, w: stepB, h: phB + 28,
              html: isEn()
                ? ('<strong>' + fullLabelsB[k] + '</strong><br/>' +
                   '• Full-Time Employees: <strong>' + Math.round(empK[k] * 1000).toLocaleString() + ' FTEs</strong><br/>' +
                   '• Net Revenue / Employee: <strong>$' + revM[k].toFixed(2) + 'M / FTE</strong>')
                : ('<strong>' + fullLabelsB[k] + '</strong><br/>' +
                   '• 全职员工总数：<strong>' + Math.round(empK[k] * 1000).toLocaleString() + ' 人</strong><br/>' +
                   '• 人均扣税净营收：<strong>$' + revM[k].toFixed(2) + 'M / 人</strong>')
            });
          }

          if (state.ch1Series.s2) {
            ctx.save();
            drawSmoothLine(ctx, pts);
            ctx.strokeStyle = pal.c2;
            ctx.lineWidth = 2.8;
            ctx.stroke();
            ctx.restore();

            for (var n = 0; n < pts.length; n++) {
              ctx.fillStyle = pal.pillBg;
              ctx.beginPath();
              ctx.arc(pts[n].x, pts[n].y, 6, 0, Math.PI * 2);
              ctx.fill();
              ctx.fillStyle = pal.c2;
              ctx.beginPath();
              ctx.arc(pts[n].x, pts[n].y, 4.2, 0, Math.PI * 2);
              ctx.fill();

              /* Show all badges on wide screens, or key inflection points on narrow mobile */
              if (w >= 500 || n % 2 === 0 || n === pts.length - 1) {
                drawValueBadge(ctx, '$' + pts[n].rev.toFixed(2) + 'M', pts[n].x, pts[n].y - 16, pal.c2, pal);
              }
            }
          }
        }
      }

      /* Chart 2: 5-Dimension Corporate Culture Radar Chart */
      function drawRadarChart() {
        var env = prepareCanvas('chartRadar');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h;
        var pal = getPalette();
        hitRegions.chartRadar = [];

        var axes = isEn()
          ? ['Pricing & Margin', 'FDA & Science', 'Dividend Yield', 'Lean Productivity', 'Smoke-Free Scale']
          : ['核心定价与利润率', '合规与毒理科学', '股息与股东回馈', '精简组织高人效', '全球与无烟扩张'];
        /* Map Left Pillar 0..3 to Radar Axis highlight */
        var pillarAxisMap = [4, 1, 3, 0];
        var highlightedAxis = hoverState.chartRadar >= 0 ? hoverState.chartRadar : pillarAxisMap[state.activePillar];

        var series = [
          { key: 'mo', name: '奥驰亚 (Altria)', color: pal.c1, fill: 'rgba(51, 153, 255, 0.24)', vals: [9.6, 9.2, 9.8, 9.7, 6.4] },
          { key: 'pmi', name: '菲莫国际 (PMI)', color: pal.c2, fill: 'rgba(34, 197, 94, 0.16)', vals: [8.5, 9.0, 8.2, 6.5, 9.5] },
          { key: 'ko', name: '消费防御巨头基准', color: pal.c3, fill: 'rgba(255, 183, 77, 0.14)', vals: [6.8, 7.2, 8.8, 6.2, 7.0] }
        ];

        var cx = w / 2;
        var cy = h / 2 + 8;
        var sidePad = w < 420 ? 86 : 104;
        var radius = Math.max(62, Math.min((w - sidePad * 2) / 2, h * 0.35));
        var total = axes.length;

        for (var ring = 2; ring <= 10; ring += 2) {
          var r = (ring / 10) * radius;
          ctx.strokeStyle = pal.grid;
          ctx.lineWidth = ring === 10 ? 1.3 : 1;
          ctx.beginPath();
          for (var i = 0; i < total; i++) {
            var ang = -Math.PI / 2 + (i * 2 * Math.PI) / total;
            var px = cx + Math.cos(ang) * r;
            var py = cy + Math.sin(ang) * r;
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
          }
          ctx.closePath();
          ctx.stroke();

          /* Scale ring number along top vertical spoke */
          ctx.fillStyle = pal.tick;
          ctx.font = '600 9.5px "IBM Plex Mono", sans-serif';
          ctx.textAlign = 'left';
          ctx.textBaseline = 'middle';
          ctx.fillText(String(ring), cx + 4, cy - r);
        }

        for (var a = 0; a < total; a++) {
          var angle = -Math.PI / 2 + (a * 2 * Math.PI) / total;
          var ax = cx + Math.cos(angle) * radius;
          var ay = cy + Math.sin(angle) * radius;
          var isHi = a === highlightedAxis;

          ctx.strokeStyle = isHi ? pal.c1 : pal.grid;
          ctx.lineWidth = isHi ? 1.8 : 1;
          ctx.beginPath();
          ctx.moveTo(cx, cy);
          ctx.lineTo(ax, ay);
          ctx.stroke();

          var lx = cx + Math.cos(angle) * (radius + 14);
          var ly = cy + Math.sin(angle) * (radius + 15);
          ctx.fillStyle = isHi ? pal.c1 : pal.text;
          ctx.font = (isHi ? '800 ' : '600 ') + (w < 420 ? '10.5px' : '11.5px') + ' system-ui, sans-serif';
          ctx.textBaseline = 'middle';
          if (Math.abs(Math.cos(angle)) < 0.2) ctx.textAlign = 'center';
          else if (Math.cos(angle) > 0) ctx.textAlign = 'left';
          else ctx.textAlign = 'right';
          ctx.fillText(axes[a], lx, ly);

          /* Wide hit region covering vertex + axis label */
          hitRegions.chartRadar.push({
            idx: a,
            x: Math.min(ax, lx) - 36, y: Math.min(ay, ly) - 22, w: 72 + Math.abs(lx - ax), h: 44,
            html: '<strong>' + axes[a] + ' (10分制标杆评估)</strong><br/>' +
                  '• 奥驰亚 (MO)：<strong>' + series[0].vals[a].toFixed(1) + ' 分</strong><br/>' +
                  '• 菲莫国际 (PMI)：<strong>' + series[1].vals[a].toFixed(1) + ' 分</strong><br/>' +
                  '• 消费防御巨头：<strong>' + series[2].vals[a].toFixed(1) + ' 分</strong>'
          });
        }

        for (var s = 0; s < series.length; s++) {
          var item = series[s];
          if (!state.radarSeries[item.key]) continue;
          ctx.beginPath();
          for (var idx = 0; idx < total; idx++) {
            var theta = -Math.PI / 2 + (idx * 2 * Math.PI) / total;
            var dist = (item.vals[idx] / 10) * radius;
            var vx = cx + Math.cos(theta) * dist;
            var vy = cy + Math.sin(theta) * dist;
            if (idx === 0) ctx.moveTo(vx, vy);
            else ctx.lineTo(vx, vy);
          }
          ctx.closePath();
          ctx.fillStyle = item.fill;
          ctx.fill();
          ctx.strokeStyle = item.color;
          ctx.lineWidth = 2.4;
          ctx.stroke();

          for (var pIdx = 0; pIdx < total; pIdx++) {
            var pTheta = -Math.PI / 2 + (pIdx * 2 * Math.PI) / total;
            var pDist = (item.vals[pIdx] / 10) * radius;
            var pX = cx + Math.cos(pTheta) * pDist;
            var pY = cy + Math.sin(pTheta) * pDist;
            ctx.fillStyle = pal.pillBg;
            ctx.beginPath();
            ctx.arc(pX, pY, 5.2, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = item.color;
            ctx.beginPath();
            ctx.arc(pX, pY, 3.6, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }

      /* Chart 3: Two-Deck Full-Width Horizontal Progress/Bar Chart (ZERO Label Truncation at ANY Width!) */
      function drawHorizontalBars() {
        var env = prepareCanvas('chartBars');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h;
        var pal = getPalette();
        hitRegions.chartBars = [];

        var items = isEn() ? [
          { label: 'Oral Tobacco Segment Adjusted OCI Margin (FY25)', val: 67.9, cStart: '#34D399', cEnd: '#16A34A', group: 'oci', sub: '$1,835M / $2,704M', note: 'Driven by high-margin Copenhagen & scaling on! nicotine pouches' },
          { label: 'Smokeable Products Segment Adjusted OCI Margin (FY25)', val: 63.4, cStart: '#3399FF', cEnd: '#0073E6', group: 'oci', sub: '$11,064M / $17,443M (+1.8pp)', note: 'Marlboro RGM pricing power offset industry volume decline (+1.8pp YoY)' },
          { label: 'Total Enterprise Adjusted OCI Margin (FY25)', val: 62.4, cStart: '#60A5FA', cEnd: '#2563EB', group: 'oci', sub: '$12,568M / $20,139M (Goal ≥60%)', note: 'Consistently clears the ≥60.0% 2028 Enterprise Goal floor' },
          { label: 'Engineering & Scientific R&D Talent Share (2026)', val: 45.4, cStart: '#A78BFA', cEnd: '#7C3AED', group: 'hr', sub: '~2,730 R&D & Toxicology Staff', note: 'Revelio Labs data: underpins FDA PMTA clinical & toxicology moat' },
          { label: 'Finance & Supply Chain Operations Share (2026)', val: 37.3, cStart: '#FBBF24', cEnd: '#D97706', group: 'hr', sub: 'Lean Mfg + ALCS Shared Hub', note: 'Supports Optimize & Accelerate automation and 2.0x leverage rigor' },
          { label: 'Sales & Trade Marketing Talent Share (2026)', val: 17.3, cStart: '#38BDF8', cEnd: '#0284C7', group: 'hr', sub: 'AGDC >300,000 Retail Doors', note: 'Scanner-enabled field force covering >300k U.S. stores' }
        ] : [
          { label: 'Oral Tobacco 口服无烟板块调整后 OCI 利润率 (FY25)', val: 67.9, cStart: '#34D399', cEnd: '#16A34A', group: 'oci', sub: '$1,835M / $2,704M', note: 'Copenhagen 与 on! 高毛利驱动，高居全集团利润率榜首' },
          { label: 'Smokeable 可燃烟草板块调整后 OCI 利润率 (FY25)', val: 63.4, cStart: '#3399FF', cEnd: '#0073E6', group: 'oci', sub: '$11,064M / $17,443M (+1.8pp)', note: 'Marlboro 超强定价权对冲卷烟销量下行，逆势扩张 1.8 个百分点' },
          { label: '全公司总调整后运营公司利润率 Total Adj. OCI (FY25)', val: 62.4, cStart: '#60A5FA', cEnd: '#2563EB', group: 'oci', sub: '$12,568M / $20,139M (目标 ≥60%)', note: '持续稳居 2028 企业目标 ≥60.0% 底线之上' },
          { label: '全公司工程与科学研发人才占比 Engineering & R&D (2026)', val: 45.4, cStart: '#A78BFA', cEnd: '#7C3AED', group: 'hr', sub: '~2,730 名研发与毒理专家', note: 'Revelio Labs 统计：构筑 FDA PMTA 临床毒理与合规科学壁垒' },
          { label: '全公司财务与供应链运营人才占比 Finance & Ops (2026)', val: 37.3, cStart: '#FBBF24', cEnd: '#D97706', group: 'hr', sub: '精益制造 + ALCS 中台', note: '支撑 Optimize & Accelerate 自动化改造与 2.0x 资本配置纪律' },
          { label: '全公司销售与品牌营销人才占比 Sales & Marketing (2026)', val: 17.3, cStart: '#38BDF8', cEnd: '#0284C7', group: 'hr', sub: 'AGDC 覆盖 >300,000 终端', note: '数字化零售扫描系统赋能精干铁军覆盖超 30 万家门店' }
        ];

        var pad = { top: 10, right: 18, bottom: 26, left: 18 };
        var pw = w - pad.left - pad.right;
        var ph = h - pad.top - pad.bottom;
        var maxX = 80;

        /* Vertical gridlines & bottom ticks */
        for (var g = 0; g <= 4; g++) {
          var xVal = g * 20;
          var gx = pad.left + (xVal / maxX) * pw;
          ctx.strokeStyle = pal.grid;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(gx, pad.top);
          ctx.lineTo(gx, pad.top + ph);
          ctx.stroke();

          ctx.fillStyle = pal.tick;
          ctx.font = '10.5px "IBM Plex Mono", sans-serif';
          ctx.textAlign = g === 0 ? 'left' : (g === 4 ? 'right' : 'center');
          ctx.textBaseline = 'alphabetic';
          ctx.fillText(xVal + '%', gx, pad.top + ph + 18);
        }

        var rowH = ph / items.length;

        /* 60% Target dashed line spanning the top 3 OCI margin rows */
        var targetX = pad.left + (60 / maxX) * pw;
        ctx.save();
        ctx.setLineDash([4, 4]);
        ctx.strokeStyle = pal.c3;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(targetX, pad.top + 4);
        ctx.lineTo(targetX, pad.top + rowH * 3 - 4);
        ctx.stroke();
        ctx.restore();

        for (var i = 0; i < items.length; i++) {
          var rowTop = pad.top + rowH * i;
          var isHovered = hoverState.chartBars === i;
          if (isHovered) {
            ctx.fillStyle = pal.hoverBand;
            roundRectPath(ctx, pad.left - 6, rowTop + 2, pw + 12, rowH - 4, 8);
            ctx.fill();
          }

          var labelY = rowTop + Math.max(15, rowH * 0.34);
          var barY = rowTop + Math.max(22, rowH * 0.50);
          var barH = Math.min(15, Math.max(11, rowH * 0.26));
          var bw = Math.max(8, (items[i].val / maxX) * pw);

          /* Full untruncated title on left, sub + bold % on right */
          ctx.fillStyle = pal.text;
          ctx.font = '600 ' + (w < 460 ? '11px' : '12px') + ' system-ui, sans-serif';
          ctx.textAlign = 'left';
          ctx.textBaseline = 'alphabetic';
          ctx.fillText(items[i].label, pad.left, labelY);

          var valStr = items[i].val.toFixed(1) + '%';
          ctx.font = '800 12.5px "IBM Plex Mono", sans-serif';
          ctx.fillStyle = pal.isDark ? items[i].cStart : items[i].cEnd;
          ctx.textAlign = 'right';
          ctx.fillText(valStr, pad.left + pw, labelY);

          if (w >= 560) {
            var valW = ctx.measureText(valStr).width + 10;
            ctx.font = '500 11px "IBM Plex Mono", system-ui, sans-serif';
            ctx.fillStyle = pal.tick;
            ctx.fillText(items[i].sub, pad.left + pw - valW, labelY);
          }

          /* Background track + gradient bar */
          ctx.fillStyle = pal.trackBg;
          roundRectPath(ctx, pad.left, barY, pw, barH, barH / 2);
          ctx.fill();

          var barGrad = ctx.createLinearGradient(pad.left, 0, pad.left + bw, 0);
          barGrad.addColorStop(0, items[i].cStart);
          barGrad.addColorStop(1, items[i].cEnd);
          ctx.fillStyle = barGrad;
          roundRectPath(ctx, pad.left, barY, bw, barH, barH / 2);
          ctx.fill();

          hitRegions.chartBars.push({
            idx: i,
            x: pad.left, y: rowTop, w: pw, h: rowH,
            html: isEn()
              ? ('<strong>' + items[i].label + ': ' + items[i].val.toFixed(1) + '%</strong><br/>• Basis: ' + items[i].sub + '<br/>• Insight: ' + items[i].note)
              : ('<strong>' + items[i].label + '：' + items[i].val.toFixed(1) + '%</strong><br/>• 口径明细：' + items[i].sub + '<br/>• 业务解读：' + items[i].note)
          });
        }
      }

      /* Chart 4: FY2022–FY2026E Adjusted Diluted EPS & Total Adjusted OCI Margin */
      function drawEpsComboChart() {
        var env = prepareCanvas('chartEps');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h;
        var pal = getPalette();
        hitRegions.chartEps = [];

        var years = ['FY2022', 'FY2023', 'FY2024', 'FY2025', 'FY2026E'];
        var subYears = isEn() ? ['(2028 Base)', '', '(Recast)', '(+4.4% YoY)', '(Guidance)'] : ['(2028基准)', '', '(重述口径)', '(+4.4% YoY)', '(指引中值)'];
        var eps = [4.87, 4.95, 5.19, 5.42, 5.70];
        var oci = [59.4, 60.3, 60.3, 62.4, 62.6];

        var pad = { top: 26, right: 50, bottom: 44, left: 48 };
        var pw = w - pad.left - pad.right;
        var ph = h - pad.top - pad.bottom;

        var minEps = 4.0, maxEps = 7.0;
        var minOci = 54.0, maxOci = 64.0;

        for (var g = 0; g <= 4; g++) {
          var ratio = g / 4;
          var gy = pad.top + ph - ratio * ph;
          ctx.strokeStyle = pal.grid;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(pad.left, gy);
          ctx.lineTo(pad.left + pw, gy);
          ctx.stroke();

          var eTick = minEps + ratio * (maxEps - minEps);
          var oTick = minOci + ratio * (maxOci - minOci);
          ctx.font = '11px "IBM Plex Mono", sans-serif';
          ctx.textBaseline = 'middle';
          ctx.fillStyle = pal.tick;
          ctx.textAlign = 'right';
          ctx.fillText('$' + eTick.toFixed(2), pad.left - 7, gy);
          ctx.textAlign = 'left';
          ctx.fillStyle = pal.c2;
          ctx.fillText(oTick.toFixed(1) + '%', pad.left + pw + 7, gy);
        }

        /* 60.0% 2028 Enterprise Goal Floor Dashed Line */
        var targetY = pad.top + ph - ((60.0 - minOci) / (maxOci - minOci)) * ph;
        ctx.save();
        ctx.setLineDash([5, 5]);
        ctx.strokeStyle = pal.c3;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(pad.left, targetY);
        ctx.lineTo(pad.left + pw, targetY);
        ctx.stroke();
        ctx.restore();

        var step = pw / years.length;
        var barW = Math.min(46, Math.max(24, step * 0.42));
        var linePts = [];

        for (var i = 0; i < years.length; i++) {
          var cx = pad.left + step * (i + 0.5);
          if (hoverState.chartEps === i) {
            ctx.fillStyle = pal.hoverBand;
            roundRectPath(ctx, pad.left + step * i + 4, pad.top, step - 8, ph, 6);
            ctx.fill();
          }

          if (state.epsSeries.eps) {
            var bh = ((eps[i] - minEps) / (maxEps - minEps)) * ph;
            var bx = cx - barW / 2;
            var by = pad.top + ph - bh;
            var eGrad = ctx.createLinearGradient(0, by, 0, pad.top + ph);
            if (i === 4) {
              eGrad.addColorStop(0, '#66B2FF');
              eGrad.addColorStop(1, '#1985F1');
            } else {
              eGrad.addColorStop(0, '#3399FF');
              eGrad.addColorStop(1, '#0066CC');
            }
            ctx.fillStyle = eGrad;
            topRoundedBar(ctx, bx, by, barW, bh, 6);
            ctx.fill();

            ctx.fillStyle = '#FFFFFF';
            ctx.font = '700 11px "IBM Plex Mono", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'alphabetic';
            ctx.fillText('$' + eps[i].toFixed(2), cx, by + 17);
          }

          var oy = pad.top + ph - ((oci[i] - minOci) / (maxOci - minOci)) * ph;
          linePts.push({ x: cx, y: oy, oci: oci[i] });

          ctx.fillStyle = pal.text;
          ctx.font = '700 11.5px system-ui, sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'alphabetic';
          ctx.fillText(years[i], cx, pad.top + ph + 19);
          if (subYears[i]) {
            ctx.fillStyle = pal.tick;
            ctx.font = '10px system-ui, sans-serif';
            ctx.fillText(subYears[i], cx, pad.top + ph + 33);
          }

          hitRegions.chartEps.push({
            idx: i,
            x: pad.left + step * i, y: pad.top, w: step, h: ph + 36,
            html: isEn()
              ? ('<strong>' + years[i] + ' ' + subYears[i] + '</strong><br/>' +
                 '• Adjusted Diluted EPS: <strong>$' + eps[i].toFixed(2) + '</strong>' + (i === 4 ? ' (Range $5.66–$5.74)' : '') + '<br/>' +
                 '• Total Adjusted OCI Margin: <strong>' + oci[i].toFixed(1) + '%</strong> (Goal ≥60.0%)')
              : ('<strong>' + years[i] + ' ' + subYears[i] + '</strong><br/>' +
                 '• 调整后稀释 EPS：<strong>$' + eps[i].toFixed(2) + '</strong>' + (i === 4 ? ' (指引区间 $5.66–$5.74)' : '') + '<br/>' +
                 '• 总调整后 OCI 利润率：<strong>' + oci[i].toFixed(1) + '%</strong> (目标 ≥60.0%)')
          });
        }

        /* Place 60% target pill cleanly in open gap between FY24 & FY25 */
        if (w >= 460) {
          drawValueBadge(ctx, isEn() ? 'Goal ≥60.0%' : '目标 ≥60.0%', pad.left + pw * 0.60, targetY + 13, pal.c3, pal);
        }

        if (state.epsSeries.oci) {
          ctx.save();
          drawSmoothLine(ctx, linePts);
          ctx.strokeStyle = pal.c2;
          ctx.lineWidth = 2.8;
          ctx.stroke();
          ctx.restore();

          for (var m = 0; m < linePts.length; m++) {
            ctx.fillStyle = pal.pillBg;
            ctx.beginPath();
            ctx.arc(linePts[m].x, linePts[m].y, 6, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = pal.c2;
            ctx.beginPath();
            ctx.arc(linePts[m].x, linePts[m].y, 4.2, 0, Math.PI * 2);
            ctx.fill();
            drawValueBadge(ctx, linePts[m].oci.toFixed(1) + '%', linePts[m].x, linePts[m].y - 16, pal.c2, pal);
          }
        }
      }

      /* Chart 5: DRIP Compounding Simulator Dual-Curve + Crosshair Chart */
      function drawSimChart() {
        var env = prepareCanvas('chartSim');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h;
        var pal = getPalette();
        hitRegions.chartSim = [];

        var p = state.sim.principal;
        var yrs = state.sim.years;
        var priceRate = state.sim.priceCagr / 100;
        var totalRate = (state.sim.priceCagr + (state.sim.drip ? 7.2 : 0)) / 100;

        var totalSeries = [];
        var priceOnlySeries = [];
        for (var y = 0; y <= yrs; y++) {
          totalSeries.push(p * Math.pow(1 + totalRate, y));
          priceOnlySeries.push(p * Math.pow(1 + priceRate, y));
        }

        var maxVal = Math.max(totalSeries[yrs], priceOnlySeries[yrs], p * 1.2) * 1.08;
        var pad = { top: 20, right: 20, bottom: 28, left: 58 };
        var pw = w - pad.left - pad.right;
        var ph = h - pad.top - pad.bottom;

        for (var g = 0; g <= 3; g++) {
          var v = (maxVal / 3) * g;
          var gy = pad.top + ph - (g / 3) * ph;
          ctx.strokeStyle = pal.grid;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(pad.left, gy);
          ctx.lineTo(pad.left + pw, gy);
          ctx.stroke();

          ctx.fillStyle = pal.tick;
          ctx.font = '10.5px "IBM Plex Mono", sans-serif';
          ctx.textAlign = 'right';
          ctx.textBaseline = 'middle';
          var labelStr = v >= 1000000 ? ('$' + (v / 1000000).toFixed(2) + 'M') : ('$' + Math.round(v / 1000) + 'k');
          ctx.fillText(labelStr, pad.left - 7, gy);
        }

        var stepX = pw / yrs;

        /* Price-only dashed curve */
        ctx.save();
        ctx.setLineDash([4, 4]);
        ctx.strokeStyle = pal.tick;
        ctx.lineWidth = 1.7;
        ctx.beginPath();
        for (var i = 0; i <= yrs; i++) {
          var px = pad.left + (i / yrs) * pw;
          var py = pad.top + ph - (priceOnlySeries[i] / maxVal) * ph;
          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.stroke();
        ctx.restore();

        /* Active DRIP / Total curve + smooth area fill */
        ctx.beginPath();
        for (var j = 0; j <= yrs; j++) {
          var tx = pad.left + (j / yrs) * pw;
          var ty = pad.top + ph - (totalSeries[j] / maxVal) * ph;
          if (j === 0) ctx.moveTo(tx, ty);
          else ctx.lineTo(tx, ty);

          var diff = totalSeries[j] - priceOnlySeries[j];
          hitRegions.chartSim.push({
            idx: j,
            x: tx - Math.max(6, stepX * 0.5), y: pad.top, w: Math.max(12, stepX), h: ph + 24,
            html: isEn()
              ? ('<strong>Year ' + j + ' Portfolio Comparison</strong><br/>' +
                 '• Total Value (Active Setting): <strong>' + formatCurrency(totalSeries[j]) + '</strong><br/>' +
                 '• Price Appreciation Only: ' + formatCurrency(priceOnlySeries[j]) + '<br/>' +
                 '• DRIP Compounding Alpha: <strong style="color:#22C55E;">+' + formatCurrency(diff) + '</strong>')
              : ('<strong>持有第 ' + j + ' 年资产对比</strong><br/>' +
                 '• 当前设定总资产：<strong>' + formatCurrency(totalSeries[j]) + '</strong><br/>' +
                 '• 仅股价增值基准：' + formatCurrency(priceOnlySeries[j]) + '<br/>' +
                 '• DRIP 股息复利超额贡献：<strong style="color:#22C55E;">+' + formatCurrency(diff) + '</strong>')
          });
        }
        ctx.strokeStyle = pal.c1;
        ctx.lineWidth = 2.8;
        ctx.stroke();

        ctx.lineTo(pad.left + pw, pad.top + ph);
        ctx.lineTo(pad.left, pad.top + ph);
        ctx.closePath();
        var grad = ctx.createLinearGradient(0, pad.top, 0, pad.top + ph);
        grad.addColorStop(0, 'rgba(0, 115, 230, 0.30)');
        grad.addColorStop(1, 'rgba(0, 115, 230, 0.01)');
        ctx.fillStyle = grad;
        ctx.fill();

        /* Midpoint & Endpoint Callout Dots + Optional Hover Crosshair */
        var midYr = Math.max(1, Math.floor(yrs / 2));
        var keyYears = [0, midYr, yrs];
        if (hoverState.chartSim >= 0 && hoverState.chartSim <= yrs) {
          var hi = hoverState.chartSim;
          var hx = pad.left + (hi / yrs) * pw;
          var hy1 = pad.top + ph - (totalSeries[hi] / maxVal) * ph;
          var hy2 = pad.top + ph - (priceOnlySeries[hi] / maxVal) * ph;
          ctx.save();
          ctx.setLineDash([3, 3]);
          ctx.strokeStyle = pal.c1;
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(hx, pad.top);
          ctx.lineTo(hx, pad.top + ph);
          ctx.stroke();
          ctx.restore();

          ctx.fillStyle = pal.tick;
          ctx.beginPath();
          ctx.arc(hx, hy2, 4, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = pal.c1;
          ctx.beginPath();
          ctx.arc(hx, hy1, 5.5, 0, Math.PI * 2);
          ctx.fill();
        }

        for (var ky = 0; ky < keyYears.length; ky++) {
          var yrIdx = keyYears[ky];
          var kx = pad.left + (yrIdx / yrs) * pw;
          var kyY = pad.top + ph - (totalSeries[yrIdx] / maxVal) * ph;
          ctx.fillStyle = pal.pillBg;
          ctx.beginPath();
          ctx.arc(kx, kyY, 5, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = pal.c1;
          ctx.beginPath();
          ctx.arc(kx, kyY, 3.5, 0, Math.PI * 2);
          ctx.fill();
        }

        /* Endpoint value badge */
        var endX = pad.left + pw;
        var endY = pad.top + ph - (totalSeries[yrs] / maxVal) * ph;
        drawValueBadge(ctx, formatCurrency(totalSeries[yrs]), Math.min(w - 42, endX - 24), Math.max(pad.top + 12, endY - 14), pal.c1, pal);

        ctx.fillStyle = pal.tick;
        ctx.font = '10.5px "IBM Plex Mono", sans-serif';
        ctx.textBaseline = 'alphabetic';
        ctx.textAlign = 'left';
        ctx.fillText(isEn() ? 'Year 0' : '第 0 年', pad.left, pad.top + ph + 19);
        ctx.textAlign = 'center';
        ctx.fillText((isEn() ? ('Year ' + midYr) : ('第 ' + midYr + ' 年')) + ' (' + formatCurrency(totalSeries[midYr]) + ')', pad.left + (midYr / yrs) * pw, pad.top + ph + 19);
        ctx.textAlign = 'right';
        ctx.fillText(isEn() ? ('Year ' + yrs) : ('第 ' + yrs + ' 年'), pad.left + pw, pad.top + ph + 19);
      }

      var redrawMap = {
        chartCh1: drawCh1Chart,
        chartRadar: drawRadarChart,
        chartBars: drawHorizontalBars,
        chartEps: drawEpsComboChart,
        chartSim: drawSimChart
      };

      function renderAllCharts() {
        drawCh1Chart();
        drawRadarChart();
        drawHorizontalBars();
        drawEpsComboChart();
        drawSimChart();
      }

      /* ======================================================================
         7. Hover & Touch Tooltips + Active Crosshair Redraw
         ====================================================================== */
      function wireCanvasTooltip(canvasId) {
        var canvas = document.getElementById(canvasId);
        var tip = document.getElementById('chartTooltip');
        if (!canvas || !tip) return;

        function handlePointer(clientX, clientY) {
          var rect = canvas.getBoundingClientRect();
          var mx = clientX - rect.left;
          var my = clientY - rect.top;
          var regions = hitRegions[canvasId] || [];
          var found = null;
          for (var i = 0; i < regions.length; i++) {
            var r = regions[i];
            if (mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h) {
              found = r;
              break;
            }
          }
          var nextIdx = found && typeof found.idx === 'number' ? found.idx : -1;
          if (hoverState[canvasId] !== nextIdx) {
            hoverState[canvasId] = nextIdx;
            if (redrawMap[canvasId]) redrawMap[canvasId]();
          }
          if (found) {
            tip.innerHTML = found.html;
            tip.style.display = 'block';
            var tipW = tip.offsetWidth || 250;
            var tipH = tip.offsetHeight || 72;
            var leftPos = clientX + 14;
            if (leftPos + tipW > window.innerWidth - 12) {
              leftPos = Math.max(12, clientX - tipW - 14);
            }
            var topPos = Math.max(12, Math.min(window.innerHeight - tipH - 12, clientY - 18));
            tip.style.left = leftPos + 'px';
            tip.style.top = topPos + 'px';
          } else {
            tip.style.display = 'none';
          }
        }

        canvas.addEventListener('mousemove', function (e) {
          handlePointer(e.clientX, e.clientY);
        });

        canvas.addEventListener('touchstart', function (e) {
          if (e.touches && e.touches[0]) {
            handlePointer(e.touches[0].clientX, e.touches[0].clientY);
          }
        }, { passive: true });

        canvas.addEventListener('mouseleave', function () {
          if (hoverState[canvasId] !== -1) {
            hoverState[canvasId] = -1;
            if (redrawMap[canvasId]) redrawMap[canvasId]();
          }
          tip.style.display = 'none';
        });
      }

      /* ======================================================================
         8. Standalone HTML Download Export
         ====================================================================== */
      function exportStandaloneHtml() {
        var doctype = '<!DOCTYPE html>\n';
        var htmlContent = doctype + document.documentElement.outerHTML;
        var blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
        var url = URL.createObjectURL(blob);
        var link = document.createElement('a');
        link.href = url;
        link.download = 'Altria_Corporate_Culture_Analysis.html';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(function () {
          URL.revokeObjectURL(url);
        }, 1500);
        showToast(isEn() ? 'Exported standalone file: Altria_Corporate_Culture_Analysis.html' : '已导出独立网页 Altria_Corporate_Culture_Analysis.html');
      }

      /* ======================================================================
         9. Event Listeners & Initialization
         ====================================================================== */
      function init() {
        /* Load persisted theme & checklist */
        var rawTheme = safeGetStorage(STORAGE_THEME_KEY);
        var savedTheme = rawTheme ? String(rawTheme).replace(/^"|"$/g, '') : '';
        if (savedTheme === 'light' || savedTheme === 'dark') {
          state.theme = savedTheme;
        }
        var rawLang = safeGetStorage(STORAGE_LANG_KEY);
        var savedLang = rawLang ? String(rawLang).replace(/^"|"$/g, '') : '';
        if (savedLang === 'zh' || savedLang === 'en') {
          state.lang = savedLang;
        }
        window.addEventListener('storage', function (ev) {
          if (ev.key === STORAGE_THEME_KEY && ev.newValue) {
            var nt = String(ev.newValue).replace(/^"|"$/g, '');
            if ((nt === 'light' || nt === 'dark') && nt !== state.theme) applyTheme(nt, true);
          } else if (ev.key === STORAGE_LANG_KEY && ev.newValue) {
            var nl = String(ev.newValue).replace(/^"|"$/g, '');
            if ((nl === 'zh' || nl === 'en') && nl !== state.lang) applyLanguage(nl, true);
          }
        });
        var savedChecks = safeGetStorage(STORAGE_CHECK_KEY);
        if (savedChecks) {
          try {
            var parsed = JSON.parse(savedChecks);
            if (Array.isArray(parsed) && parsed.length === CHECKLIST_ITEMS.length) {
              state.checks = parsed.map(Boolean);
            }
          } catch (e) {
            /* Ignore malformed storage */
          }
        }

        applyTheme(state.theme, true);
        applyLanguage(state.lang, true);
        document.getElementById('langZhBtn').addEventListener('click', function () { applyLanguage('zh', false); });
        document.getElementById('langEnBtn').addEventListener('click', function () { applyLanguage('en', false); });
        var abThm = document.getElementById('appbarThemeBtn');
        if (abThm) { abThm.addEventListener('click', function () { applyTheme(state.theme === 'dark' ? 'light' : 'dark', false); }); }

        /* Sidebar & Theme Controls */
        document.getElementById('sidebarToggleBtn').addEventListener('click', toggleSidebar);
        document.getElementById('drawerBackdrop').addEventListener('click', closeMobileDrawer);
        void 0;
        void 0;

        /* Sidebar Export & Print Buttons */
        void 0;
        void 0;

        /* Close mobile drawer on TOC click */
        var tocLinks = document.querySelectorAll('#tocNavList .mui-nav-link');
        for (var t = 0; t < tocLinks.length; t++) {
          tocLinks[t].addEventListener('click', closeMobileDrawer);
        }

        /* Quick Jump Search (Ctrl+K / Cmd+K) */
        var jumpInput = document.getElementById('quickJumpInput');
        var jumpPop = document.getElementById('quickJumpPopover');
        function renderJumpList(q) {
          var kw = (q || '').trim().toLowerCase();
          var activeJump = isEn() ? QUICK_JUMP_EN : QUICK_JUMP_INDEX;
          var list = activeJump.filter(function (item, idx) {
            var zhIt = QUICK_JUMP_INDEX[idx] || item;
            var enIt = QUICK_JUMP_EN[idx] || item;
            return !kw || (zhIt.title + ' ' + zhIt.sub + ' ' + enIt.title + ' ' + enIt.sub).toLowerCase().indexOf(kw) !== -1;
          });
          if (!list.length) {
            jumpPop.innerHTML = '<div style="padding:10px;font-size:0.78rem;color:var(--text-muted);">' + (isEn() ? 'No matching section' : '未匹配到对应章节') + '</div>';
          } else {
            jumpPop.innerHTML = list.map(function (item) {
              return '<button type="button" class="quick-jump-item" data-jump-sec="' + item.sec + '">' +
                '<span class="quick-jump-item-title">' + escapeHtml(item.title) + '</span>' +
                '<span class="quick-jump-item-sub">' + escapeHtml(item.sub) + '</span>' +
              '</button>';
            }).join('');
          }
          jumpPop.classList.add('open');
        }

        jumpInput.addEventListener('focus', function () { renderJumpList(jumpInput.value); });
        jumpInput.addEventListener('input', function () { renderJumpList(jumpInput.value); });
        jumpPop.addEventListener('click', function (e) {
          var btn = e.target.closest('[data-jump-sec]');
          if (!btn) return;
          var targetId = btn.getAttribute('data-jump-sec');
          var secEl = document.getElementById(targetId);
          if (secEl) secEl.scrollIntoView({ behavior: 'smooth' });
          jumpPop.classList.remove('open');
        });
        document.addEventListener('click', function (e) {
          if (!e.target.closest('.quick-search-wrap')) {
            jumpPop.classList.remove('open');
          }
        });
        document.addEventListener('keydown', function (e) {
          if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
            e.preventDefault();
            jumpInput.focus();
          } else if (e.key === 'Escape') {
            jumpPop.classList.remove('open');
            closeMobileDrawer();
          }
        });

        /* Ch 01 View A / View B Tabs */
        var ch1Btns = document.querySelectorAll('[data-ch1-view]');
        for (var c = 0; c < ch1Btns.length; c++) {
          ch1Btns[c].addEventListener('click', function () {
            state.ch1View = this.getAttribute('data-ch1-view');
            document.getElementById('ch1TabA').classList.toggle('active', state.ch1View === 'viewA');
            document.getElementById('ch1TabB').classList.toggle('active', state.ch1View === 'viewB');
            syncCh1HeaderText();
            drawCh1Chart();
          });
        }

        /* Expandable Matrix Card Collapses */
        var collapseBtns = document.querySelectorAll('[data-collapse-target]');
        for (var m = 0; m < collapseBtns.length; m++) {
          collapseBtns[m].addEventListener('click', function () {
            var panelId = this.getAttribute('data-collapse-target');
            var panel = document.getElementById(panelId);
            if (!panel) return;
            var isOpen = panel.classList.toggle('open');
            syncCollapseButtonsText();
          });
        }

        /* Ch 02 Pillar Selection & Radar Legend Toggles */
        var pillarCards = document.querySelectorAll('[data-pillar]');
        for (var p = 0; p < pillarCards.length; p++) {
          pillarCards[p].addEventListener('click', function () {
            var idx = parseInt(this.getAttribute('data-pillar'), 10) || 0;
            state.activePillar = idx;
            for (var k = 0; k < pillarCards.length; k++) {
              pillarCards[k].classList.toggle('active', k === idx);
            }
            document.getElementById('pillarFocusNote').innerHTML = '<div>' + (isEn() ? PILLAR_NOTES_EN : PILLAR_NOTES)[idx] + '</div>';
            drawRadarChart();
          });
        }

        var radarPills = document.querySelectorAll('[data-radar-key]');
        for (var r = 0; r < radarPills.length; r++) {
          radarPills[r].addEventListener('click', function () {
            var key = this.getAttribute('data-radar-key');
            state.radarSeries[key] = !state.radarSeries[key];
            if (!state.radarSeries.mo && !state.radarSeries.pmi && !state.radarSeries.ko) {
              state.radarSeries[key] = true;
            }
            this.classList.toggle('muted', !state.radarSeries[key]);
            drawRadarChart();
          });
        }

        /* Ch 03 Peer Search & Filter */
        document.getElementById('peerSearchInput').addEventListener('input', function () {
          state.peerQuery = this.value;
          renderPeerTable();
        });
        var peerFilterBtns = document.querySelectorAll('[data-peer-filter]');
        for (var pf = 0; pf < peerFilterBtns.length; pf++) {
          peerFilterBtns[pf].addEventListener('click', function () {
            state.peerFilter = this.getAttribute('data-peer-filter');
            for (var x = 0; x < peerFilterBtns.length; x++) {
              peerFilterBtns[x].classList.toggle('active', peerFilterBtns[x] === this);
            }
            renderPeerTable();
          });
        }

        /* Ch 04 Simulator Controls */
        var pSlider = document.getElementById('simPrincipalSlider');
        var ySlider = document.getElementById('simYearsSlider');
        var cSlider = document.getElementById('simCagrSlider');
        var dToggle = document.getElementById('simDripToggle');

        pSlider.addEventListener('input', function () {
          state.sim.principal = parseFloat(this.value) || 10000;
          state.sim.preset = '';
          updateSimulatorUI();
        });
        ySlider.addEventListener('input', function () {
          state.sim.years = parseInt(this.value, 10) || 18;
          state.sim.preset = '';
          updateSimulatorUI();
        });
        cSlider.addEventListener('input', function () {
          state.sim.priceCagr = parseFloat(this.value) || 0;
          state.sim.preset = '';
          updateSimulatorUI();
        });
        dToggle.addEventListener('change', function () {
          state.sim.drip = !!this.checked;
          updateSimulatorUI();
        });

        var presetBtns = document.querySelectorAll('[data-preset]');
        for (var pb = 0; pb < presetBtns.length; pb++) {
          presetBtns[pb].addEventListener('click', function () {
            var key = this.getAttribute('data-preset');
            var cfg = PRESETS[key];
            if (!cfg) return;
            state.sim.principal = cfg.principal;
            state.sim.years = cfg.years;
            state.sim.priceCagr = cfg.priceCagr;
            state.sim.drip = cfg.drip;
            state.sim.preset = key;
            pSlider.value = String(cfg.principal);
            ySlider.value = String(cfg.years);
            cSlider.value = String(cfg.priceCagr);
            dToggle.checked = cfg.drip;
            updateSimulatorUI();
          });
        }

        /* Ch 06 Checklist Controls */
        document.getElementById('checklistContainer').addEventListener('change', function (e) {
          var input = e.target.closest('[data-check-input]');
          if (!input) return;
          var idx = parseInt(input.getAttribute('data-check-input'), 10);
          state.checks[idx] = !!input.checked;
          safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
          renderChecklist();
        });
        document.getElementById('checkAllBtn').addEventListener('click', function () {
          state.checks = [true, true, true, true, true, true];
          safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
          renderChecklist();
          showToast(isEn() ? 'Checked all 6 Altria governance criteria' : '已勾选全部 6 项奥驰亚企业文化核查指标');
        });
        document.getElementById('resetCheckBtn').addEventListener('click', function () {
          state.checks = [true, true, true, false, false, false];
          safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
          renderChecklist();
          showToast(isEn() ? 'Checklist reset to default baseline (50%)' : '核查清单已恢复默认基准状态 (50%)');
        });

        /* Reading Progress & Scroll-Spy */
        function updateScrollProgress() {
          var docEl = document.documentElement;
          var scrollTop = window.scrollY || docEl.scrollTop || 0;
          var maxScroll = Math.max(1, docEl.scrollHeight - window.innerHeight);
          var pct = Math.min(100, Math.max(0, (scrollTop / maxScroll) * 100));
          document.getElementById('readingProgressBar').style.width = pct + '%';
        }
        window.addEventListener('scroll', updateScrollProgress, { passive: true });
        updateScrollProgress();

        if ('IntersectionObserver' in window) {
          var secObserver = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
              if (entry.isIntersecting) {
                var id = entry.target.id;
                for (var i = 0; i < tocLinks.length; i++) {
                  tocLinks[i].classList.toggle('active', tocLinks[i].getAttribute('data-sec') === id);
                }
              }
            });
          }, { rootMargin: '-18% 0px -68% 0px', threshold: 0.02 });

          for (var s = 0; s <= 7; s++) {
            var secNode = document.getElementById('sec-0' + s);
            if (secNode) secObserver.observe(secNode);
          }
        }

        /* Wire Tooltips & Resize Redraw */
        wireCanvasTooltip('chartCh1');
        wireCanvasTooltip('chartRadar');
        wireCanvasTooltip('chartBars');
        wireCanvasTooltip('chartEps');
        wireCanvasTooltip('chartSim');

        /* Wire Ch1 & Ch4 EPS Legend Series Toggles */
        var ch1SeriesBtns = document.querySelectorAll('[data-ch1-series]');
        for (var csIdx = 0; csIdx < ch1SeriesBtns.length; csIdx++) {
          ch1SeriesBtns[csIdx].addEventListener('click', function () {
            var sk = this.getAttribute('data-ch1-series');
            state.ch1Series[sk] = !state.ch1Series[sk];
            if (!state.ch1Series.s1 && !state.ch1Series.s2) state.ch1Series[sk] = true;
            this.classList.toggle('muted', !state.ch1Series[sk]);
            drawCh1Chart();
          });
        }

        var epsSeriesBtns = document.querySelectorAll('[data-eps-series]');
        for (var esIdx = 0; esIdx < epsSeriesBtns.length; esIdx++) {
          epsSeriesBtns[esIdx].addEventListener('click', function () {
            var ek = this.getAttribute('data-eps-series');
            state.epsSeries[ek] = !state.epsSeries[ek];
            if (!state.epsSeries.eps && !state.epsSeries.oci) state.epsSeries[ek] = true;
            this.classList.toggle('muted', !state.epsSeries[ek]);
            drawEpsComboChart();
          });
        }

        var resizeTimer = null;
        function scheduleRedraw() {
          if (resizeTimer) clearTimeout(resizeTimer);
          resizeTimer = setTimeout(renderAllCharts, 60);
        }
        window.addEventListener('resize', scheduleRedraw);
        if ('ResizeObserver' in window) {
          var mainEl = document.querySelector('.main-content');
          if (mainEl) {
            var ro = new ResizeObserver(scheduleRedraw);
            ro.observe(mainEl);
          }
        }
      }

      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
      } else {
        init();
      }
    })();
  