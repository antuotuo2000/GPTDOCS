
    (function () {
      'use strict';

      var STORAGE_THEME_KEY = 'mui_portal_theme_v4';
      var STORAGE_LANG_KEY = 'mui_portal_lang_v1';
      var STORAGE_CHECK_KEY = 'aapl_iphone_kpi_state_v2';
      var DOC_TITLE_ZH = '苹果公司 Apple Inc. (NASDAQ: AAPL) & iPhone 生态深度研究报告 | 数据中心';
      var DOC_TITLE_EN = 'Apple Inc. (AAPL) & iPhone Ecosystem Deep Dive | Research Hub';

      var I18N_RICH_LIST = [{"key": "ip_r00", "match_zh": "苹果公司 Apple Inc. (NASDAQ: AAPL) & iPhone 深度研究报告：", "zh": "苹果公司 Apple Inc. (NASDAQ: AAPL) &amp; iPhone 深度研究报告：<span class=\"gradient-accent\">$2,541亿超级换机周期、折叠屏破局与 25 亿终端现金流帝国</span>", "en": "Apple Inc. (NASDAQ: AAPL) &amp; iPhone Ecosystem Deep Dive: <span class=\"gradient-accent\">$254.1B Super-Cycle, iPhone Duo Foldable &amp; 2.5B-Device Cash Fortress</span>"}, {"key": "ip_r01", "match_zh": "新任 CEO John Ternus（原硬件工程高级副总裁", "zh": "新任 CEO <strong>John Ternus</strong>（原硬件工程高级副总裁，2026年9月1日正式接棒转任执行董事长的 Tim Cook）在 2026 年 11 月交出苹果史上最强劲的 <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/11/apple-reports-fourth-quarter-results/\" target=\"_blank\" rel=\"noopener noreferrer\">FY2026 全年及 Q4 财报 ↗</a>：受益于 <strong>iPhone 17 系列首年破 $1,700亿 销售纪录</strong>以及 2026 年 9 月错峰首发的<strong>首款折叠屏 iPhone Duo 与 iPhone 18 Pro / Pro Max</strong>，FY2026 全年 iPhone 净营收飙升 <strong>+21.2% 至 $2,541.0亿</strong>（占集团总营收 <strong>53.1%</strong>），大中华区全年营收强劲反弹 <strong>+28% 至 $824亿</strong>。集团全年总营收创下 <strong>$4,788.3亿（+15.1% YoY）</strong> 历史新高，摊薄 EPS 增长 <strong>+20.4% 至 $8.98</strong>，全年自由现金流暴增 <strong>+38% 至 $1,361亿</strong>，推动市值突破 <strong>$5.16万亿美元</strong>。", "en": "New CEO <strong>John Ternus</strong> (former SVP of Hardware Engineering, who succeeded Tim Cook on Sept 1, 2026 as Cook became Executive Chairman) delivered Apple's strongest <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/11/apple-reports-fourth-quarter-results/\" target=\"_blank\" rel=\"noopener noreferrer\">FY2026 &amp; Q4 Results ↗</a> in Nov 2026: powered by the <strong>iPhone 17 lineup ($170B+ first-year sales)</strong> and the staggered Sept 2026 launch of Apple's first foldable <strong>iPhone Duo &amp; iPhone 18 Pro / Pro Max</strong>, FY26 iPhone revenue surged <strong>+21.2% to $254.10B</strong> (<strong>53.1%</strong> of total revenue), while Greater China rebounded <strong>+28% to $82.4B</strong>. Total revenue hit an all-time high of <strong>$478.83B (+15.1% YoY)</strong>, diluted EPS rose <strong>+20.4% to $8.98</strong>, and free cash flow jumped <strong>+38% to $136.1B</strong>, lifting market cap past <strong>$5.16 trillion</strong>."}, {"key": "ip_r02", "match_zh": "据 Counterpoint Research 与 Recon Analytics 调研", "zh": "据 <a class=\"cite-link\" href=\"https://counterpointresearch.com/cn/reports/apple-iphone-18-launch-pro-model-strategy\" target=\"_blank\" rel=\"noopener noreferrer\">Counterpoint Research ↗</a> 与 <a class=\"cite-link\" href=\"https://www.reconanalytics.com/62-of-base-iphone-18-buyers-interested-in-switching-to-more-expensive-pro-pro-max-or-fold-models/\" target=\"_blank\" rel=\"noopener noreferrer\">Recon Analytics 调研 ↗</a>，苹果在 2026 年 9 月率先推出 iPhone Duo（首款折叠屏）与 iPhone 18 Pro / Pro Max 并延后基础款 iPhone 18，促使高达 62% 原计划购买基础款的美国消费者转向高溢价机型。", "en": "Per <a class=\"cite-link\" href=\"https://counterpointresearch.com/cn/reports/apple-iphone-18-launch-pro-model-strategy\" target=\"_blank\" rel=\"noopener noreferrer\">Counterpoint Research ↗</a> and <a class=\"cite-link\" href=\"https://www.reconanalytics.com/62-of-base-iphone-18-buyers-interested-in-switching-to-more-expensive-pro-pro-max-or-fold-models/\" target=\"_blank\" rel=\"noopener noreferrer\">Recon Analytics ↗</a>, launching iPhone Duo and iPhone 18 Pro / Pro Max in Sept 2026 while deferring the base iPhone 18 pushed 62% of prospective base buyers toward higher-ASP Pro or foldable models."}, {"key": "ip_r03", "match_zh": "扭转 FY2025（-4%）颓势，FY2026 大中华区", "zh": "扭转 FY2025（-4%）颓势，FY2026 大中华区净营收激增 +28% 至 $824亿（Q4 单季 +21%）。<a class=\"cite-link\" href=\"https://shattered.io/iphone-18-pro-sales-3-1-percent-above-iphone-17-counterpoint-2026/\" target=\"_blank\" rel=\"noopener noreferrer\">iPhone 18 Pro 系列上市前三周中国销量同比飙升 +29% ↗</a>，带动全球首发期销量超越 17 Pro 同期 +3.1%。", "en": "Reversing FY25's -4% dip, FY26 Greater China revenue jumped +28% to $82.4B (+21% in Q4). <a class=\"cite-link\" href=\"https://shattered.io/iphone-18-pro-sales-3-1-percent-above-iphone-17-counterpoint-2026/\" target=\"_blank\" rel=\"noopener noreferrer\">iPhone 18 Pro China sales surged +29% YoY ↗</a> in its first 3 weeks, lifting global launch-window sales +3.1% above 17 Pro."}, {"key": "ip_r04", "match_zh": "据 Counterpoint 统计，iPhone 17 系列", "zh": "据 <a class=\"cite-link\" href=\"https://counterpointresearch.com/cn/insights/iphone-17-series-outpaces-previous-series-first-year-revenue-over-170-billion-dollars\" target=\"_blank\" rel=\"noopener noreferrer\">Counterpoint 统计 ↗</a>，iPhone 17 系列首年累计创收逾 $1,700亿 超越历代机型；2026Q2 标准版 iPhone 17 以 6.0% 全球单机份额蝉联全球最畅销手机，17 Pro Max 与 17 Pro 包揽亚军与季军。", "en": "Per <a class=\"cite-link\" href=\"https://counterpointresearch.com/cn/insights/iphone-17-series-outpaces-previous-series-first-year-revenue-over-170-billion-dollars\" target=\"_blank\" rel=\"noopener noreferrer\">Counterpoint ↗</a>, the iPhone 17 lineup surpassed $170B in first-year revenue; in Q2 2026, base iPhone 17 led all global models with 6.0% share, followed by 17 Pro Max and 17 Pro."}, {"key": "ip_r05", "match_zh": "2026 年 9 月 18 日开售的 iPhone 18 Pro", "zh": "2026 年 9 月 18 日开售的 iPhone 18 Pro / Pro Max 与苹果首款折叠屏手机 iPhone Duo 仅计入 FY26Q4 财报最后 9 天，即推动 Q4 iPhone 营收增长 +17.5% 至 $575.8亿。COO Sabih Khan 在 <a class=\"cite-link\" href=\"https://fifthperson.com/apple-q4-2026/\" target=\"_blank\" rel=\"noopener noreferrer\">业绩会上指出 ↗</a>，iPhone Duo 初期需求极其火爆但处于严重产能受限状态，将把大量未交付订单顺延至 FY2027Q1 假日季兑现。", "en": "On sale Sept 18, 2026, iPhone 18 Pro / Pro Max and Apple's first foldable iPhone Duo had just 9 selling days in FY26Q4 yet propelled Q4 iPhone revenue +17.5% to $57.58B. COO Sabih Khan noted on the <a class=\"cite-link\" href=\"https://fifthperson.com/apple-q4-2026/\" target=\"_blank\" rel=\"noopener noreferrer\">Q4 Earnings Call ↗</a> that iPhone Duo remains supply-constrained, pushing backlog into FY27Q1."}, {"key": "ip_r06", "match_zh": "在全球智能手机大盘因存储芯片短缺", "zh": "在全球智能手机大盘因存储芯片短缺于 2026Q2 下滑 6.7%~7.4% 的逆风下，<a class=\"cite-link\" href=\"https://counterpointresearch.com/en/insights/apple-iphone-market-share\" target=\"_blank\" rel=\"noopener noreferrer\">苹果 Q2 全球出货量逆势大增 +13% YoY ↗</a>（其中韩国 +35%、中国 +23%、欧洲 +22%、美国与日本 +6%）。美国运营商 T-Mobile 与 AT&amp;T 将以旧换新补贴上限从 $1,000 提升至 $1,100，强力支撑存量 iPhone 用户的跨代升级。", "en": "While global smartphone shipments fell 6.7%–7.4% in Q2 2026 amid memory shortages, <a class=\"cite-link\" href=\"https://counterpointresearch.com/en/insights/apple-iphone-market-share\" target=\"_blank\" rel=\"noopener noreferrer\">Apple shipments jumped +13% YoY ↗</a> (Korea +35%, China +23%, Europe +22%, US/Japan +6%), aided by $1,100 T-Mobile and AT&amp;T trade-in promos."}, {"key": "ip_r07", "match_zh": "苹果在 FY2026 10-K 年报", "zh": "苹果在 <a class=\"cite-link\" href=\"https://www.tradingview.com/news/tradingview:3fa053e38b41a:0-apple-fy-2026-revenue-478-83b-eps-8-98-10-k-summary/\" target=\"_blank\" rel=\"noopener noreferrer\">FY2026 10-K 年报 ↗</a>中明确警示，内存与闪存供应紧张及涨价预计将在 FY2027 进一步加剧，且提价可能无法完全抵消成本并抑制需求。", "en": "In its <a class=\"cite-link\" href=\"https://www.tradingview.com/news/tradingview:3fa053e38b41a:0-apple-fy-2026-revenue-478-83b-eps-8-98-10-k-summary/\" target=\"_blank\" rel=\"noopener noreferrer\">FY2026 10-K ↗</a>, Apple warned that tight DRAM/NAND supply and rising component prices will intensify in FY2027 and may not be fully offset by pricing."}, {"key": "ip_r08", "match_zh": "1. iPhone Duo 折叠机与错峰发布打开 ASP 天花板：", "zh": "<strong>1. iPhone Duo 折叠机与错峰发布打开 ASP 天花板：</strong>苹果首次切入超高端折叠屏市场即出现一机难求，配合 2027 春季补齐标准版 iPhone 18 的双波段节奏，平滑淡旺季波动。<br/><strong>2. 大中华区 +28% 强劲反转证伪份额流失论：</strong>FY2026 大中华区营收反弹至 $824亿，证明超高端用户对 iOS 生态粘性不可替代。<br/><strong>3. 不做重资产 AI 军备竞赛的现金流赢家：</strong>FY26 CapEx 仅 $90亿（不及云巨头单季 1/4），凭 25 亿终端坐享 $1,361亿 自由现金流。", "en": "<strong>1. iPhone Duo &amp; Staggered Launch Lift ASP:</strong> Supply-constrained foldable demand plus a H1 2027 base iPhone 18 wave smooths seasonality.<br/><strong>2. +28% Greater China Rebound:</strong> Reached $82.4B in FY26, disproving structural share-loss fears at the ultra-premium tier.<br/><strong>3. Capital-Light AI Cash Winner:</strong> Just $9.0B CapEx (under 25% of hyperscalers' quarterly spend) generated $136.1B in FCF across 2.5B active devices."}, {"key": "ip_r09", "match_zh": "1. DRAM 与 NAND 闪存成本暴涨威胁硬件毛利率：", "zh": "<strong>1. DRAM 与 NAND 闪存成本暴涨威胁硬件毛利率：</strong>AI 服务器抢占产能导致内存合约价飙升，且 FY26Q4 约 1pp 一次性关税退税红利不可持续。<br/><strong>2. 服务业务增速放缓至高个位数（8%~9%）：</strong>受欧盟 DMA、外部支付链接令及手游疲软影响，Q4 增速降至 +9.8% 并指引 Q1 放缓至 +8%~+9%。<br/><strong>3. ~39.5x 市盈率透支预期：</strong>较十年均值（23.5x）溢价近 70%，高股价使 $864亿 回购仅能注销约 1.7% 股本。", "en": "<strong>1. DRAM/NAND Cost Surge vs. Hardware Margins:</strong> AI server demand is driving up memory prices while Q4's ~1pp tariff refund fades.<br/><strong>2. Services Deceleration (8%–9%):</strong> EU DMA, external payment-link rules, and softer gaming slowed Q4 growth to +9.8% (Q1 guide +8%–9%).<br/><strong>3. ~39.5x P/E Valuation Stretch:</strong> A ~70% premium to the 10-yr average (23.5x) reduces $86.4B buyback retirement yield to ~1.7%/yr."}];
      var I18N_TEXT_PAIRS = [["数据中心", "Research Hub"], ["苹果公司 Apple Inc. (AAPL) & iPhone 生态深度研究报告", "Apple Inc. (AAPL) & iPhone Ecosystem Monograph"], ["iPhone 生态研报", "iPhone Ecosystem Monograph"], ["全球高端智能手机霸主 · 25亿活跃硬件底座与 $1,361亿 自由现金流复利帝国", "Global Flagship Smartphone Leader · 2.5B Active Devices & $136.1B FCF Empire"], ["参考股价 (总市值)", "Share Price (Market Cap)"], ["FY26 iPhone 净营收", "FY26 iPhone Revenue"], ["FY26 EPS 与市盈率", "FY26 EPS & P/E"], ["站点与关联导航", "Site & Related Reports"], ["返回数据中心首页", "Back to Research Hub"], ["核心研究章节 (00 – 07)", "Report Chapters (00 – 07)"], ["执行摘要与核心指标", "Executive Summary & KPIs"], ["iPhone 产品矩阵与收入架构", "Product Matrix & Revenue"], ["行业地位与四重生态护城河", "Industry & 4 Economic Moats"], ["全球高端手机巨头横向对比", "Global Smartphone Peer Matrix"], ["财务健康与回购复利推演", "Financials & Buyback Sim"], ["投资决策与存储涨价风险", "Valuation & Memory Risk"], ["季度跟踪 KPI 核查清单", "Quarterly KPI Checklist"], ["数据来源与监管核验索引", "Primary Filings & Sources"], ["阅读与导出工具", "Reading & Export Tools"], ["浅色外观", "Light"], ["深色外观", "Dark"], ["导出 HTML", "Export HTML"], ["打印 / PDF", "Print / PDF"], ["评级：核心持有 / 逢回调增配 (Hold / Accumulate on Dips)", "Rating: Core Hold / Accumulate on Dips"], ["周期：FY2026 创纪录年报与 iPhone Duo / 18 Pro 错峰换机潮", "Cycle: Record FY2026 & iPhone Duo / 18 Pro Staggered Wave"], ["数据基准：FY2026 10-K / 2026年11月", "Baseline: FY2026 10-K / Nov 2026"], ["CORE THESIS · iPhone 年入 $2,541亿 (+21%) × iPhone Duo 折叠形态破局 × 25亿活跃设备驱动 $1,233亿 高毛利服务飞轮", "CORE THESIS · $254.1B iPhone (+21%) × iPhone Duo Foldable × 2.5B Devices Driving $123.3B Services"], ["错峰发布策略拉升 iPhone ASP", "Staggered Launch Lifts iPhone ASP"], ["2026秋季优先发布 iPhone Duo 折叠机与 18 Pro 系列（延后标准版 iPhone 18），Q4 单季 iPhone 营收同比增长 17.5% 至 $575.8亿。", "Fall 2026 prioritized iPhone Duo & 18 Pro (deferring base 18), lifting Q4 iPhone revenue +17.5% YoY to $57.58B."], ["25亿装机量托底 76% 毛利服务业务", "2.5B Base Powers 76%-Margin Services"], ["全球活跃设备逾 25 亿台、付费订阅超 15 亿份，驱动 FY26 服务营收达 $1,233亿（Q4 毛利率高达 76.0%，贡献全公司约 44% 毛利）。", "Over 2.5B active devices and 1.5B+ paid subscriptions drove $123.3B in FY26 Services (76.0% Q4 GM, ~44% of gross profit)."], ["核心矛盾：~39.5x 高估值 vs 存储涨价", "Key Tension: ~39.5x P/E vs. Memory Inflation"], ["AI 服务器挤占产能引爆 DRAM/NAND 芯片涨价潮，叠加关税退税红利消退与 ~39.5x TTM P/E 溢价，考验 FY27 利润率韧性。", "AI-driven DRAM/NAND price surges, fading tariff refunds, and ~39.5x TTM P/E test FY27 margin resilience."], ["总市值与最新股价", "Market Cap & Share Price"], ["2026年11月首次站上 $350 大关（流通股约 145.3 亿股），静态市盈率 ~39.5x（远期 FY27E P/E ~37.6x）。", "Crossed $350 in Nov 2026 (~14.53B shares), trading at ~39.5x trailing P/E (~37.6x FY27E)."], ["FY2026 iPhone 净营收", "FY2026 iPhone Net Sales"], ["占苹果总营收（$478.83B）的 53.1%；其中 FY26Q4 单季 iPhone 营收达 $57.58B（+17.5% YoY）创 9 月季度历史最高纪录。", "53.1% of Apple's $478.83B revenue; Q4 iPhone sales hit a September-quarter record of $57.58B (+17.5% YoY)."], ["FY2026 综合毛利率 & FCF", "FY2026 Gross Margin & FCF"], ["全年毛利率同比扩张 1.9pp 至 48.8%（Q4 硬件毛利率 37.2%、服务毛利率 76.0%）；轻资本 CapEx（$9.0B）推升自由现金流大增 +38%。", "Full-year GM expanded +1.9pp to 48.8% (Q4 products 37.2%, services 76.0%); $9.0B CapEx yielded +38% FCF growth."], ["FY2026 摊薄 EPS 与股东回报", "FY2026 Diluted EPS & Return"], ["回购 $86.4B", "$86.4B Buyback"], ["全年净利润 $1,321.8亿（+18% YoY），叠加 $864亿 股票回购注销与 $1.08/股 年化股息，推动摊薄 EPS 跃升 +20.4%。", "FY26 net income of $132.18B (+18% YoY), $86.4B buybacks, and $1.08/sh dividend drove +20.4% diluted EPS growth."], ["一、iPhone 产品矩阵与收入架构：错峰旗舰周期、折叠机破局与服务高毛利变现", "1. iPhone Product Lineup & Revenue Architecture: Staggered Flagships, Foldable & Services"], ["iPhone 超级换机周期 ($254.1B) × Apple Services ($123.3B) × 25亿活跃硬件生态底座", "iPhone Super-Cycle ($254.1B) × Apple Services ($123.3B) × 2.5B Active Device Base"], ["FY26 iPhone 占比 53.1%", "iPhone 53.1% of FY26"], ["Apple Inc. 25亿活跃终端生态中枢（John Ternus CEO · 错峰发布策略 · 轻资本 $9.0B CapEx 现金流机器）", "Apple Inc. 2.5B-Device Ecosystem Hub (CEO John Ternus · Staggered Launch · $9.0B CapEx Cash Machine)"], ["FY2026 集团总营收 $478.83B (+15.1% YoY) · 综合毛利率 48.8% · 自由现金流 $136.1B (+38% YoY)", "FY2026 Total Revenue $478.83B (+15.1% YoY) · Gross Margin 48.8% · Free Cash Flow $136.1B (+38% YoY)"], ["FLAGSHIP · 占集团营收 53.1%", "FLAGSHIP · 53.1% OF REV"], ["iPhone 18 Pro & iPhone Duo 折叠机首发热销，$254.10B 全年净营收 (+21.2%)。", "iPhone 18 Pro & foldable iPhone Duo drove $254.10B FY26 revenue (+21.2% YoY)."], ["CHINA & GLOBAL · 全年 +28%", "CHINA & GLOBAL · +28% YOY"], ["大中华区 & 全球换机潮", "Greater China & Global Upgrades"], ["大中华区强势反弹至 $82.4B (+28%)，iPhone 17 系列首年营收破 $1,700亿。", "Greater China rebounded to $82.4B (+28%); iPhone 17 surpassed $170B in year-one sales."], ["SERVICES · Q4 毛利率 76.0%", "SERVICES · 76.0% Q4 GM"], ["App Store / iCloud / Maps 广告", "App Store / iCloud / Maps Ads"], ["全年营收 $123.30B (+12.9%)，付费订阅超 15 亿份，贡献全公司约 44% 毛利。", "$123.30B FY26 revenue (+12.9%), 1.5B+ paid subscriptions, ~44% of Apple's total gross profit."], ["AI & HARDWARE · 研发 $45.8B", "AI & HARDWARE · $45.8B R&D"], ["新版 Siri AI + Mac / iPad", "New Siri AI + Mac / iPad"], ["Mac Q4 大增 +23.7% 至 $10.8B；研发费率 9.6% 集中投入端侧 AI 与自研芯片。", "Mac Q4 surged +23.7% to $10.8B; 9.6% R&D focused on on-device AI and Apple Silicon."], ["秋季错峰发布纪律（Staggered Launch：Pro + Duo 先行，基础款延后）", "Staggered Launch Discipline (Pro + Duo First, Base Model Deferred)"], ["促使 62% 原计划买标准版的美国用户转向高溢价 Pro 或折叠机型，大幅抬升全系平均售价 (ASP)。", "Converted 62% of prospective base buyers into higher-ASP Pro or foldable models."], ["软硬芯云一体闭环 + 轻资本混合云 AI（CapEx 仅 $9.0B）", "Silicon-to-Cloud Integration + Capital-Light AI ($9.0B CapEx)"], ["93.8% 经营现金流转化为自由现金流 ($136.1B)，避免云巨头每年 $1,750亿+ 重资产算力折旧陷阱。", "Converted 93.8% of operating cash flow into $136.1B FCF without hyperscaler capex drag."], ["1. 错峰发布锁定 Pro 与 Duo 超高端需求", "1. Staggered Launch Captures Pro & Duo Demand"], ["2. 大中华区强势逆袭：全年营收大增 +28%", "2. Greater China Rebound: +28% to $82.4B"], ["3. iPhone 17 霸榜全球：首年破 $1,700亿", "3. iPhone 17 Dominance: $170B+ Year-One Sales"], ["里程碑", "MILESTONE"], ["FY2027Q1 官方业绩指引：总营收同比 +7%~+10% (服务 +8%~+9%) · iPhone Duo 供不应求积压订单顺延交付。", "FY2027Q1 Guidance: Total Revenue +7% to +10% YoY (Services +8%–9%) · iPhone Duo backlog carries into Q1."], ["视图A: 五年营收结构演进", "View A: 5-Yr Revenue Evolution"], ["视图B: FY26 核心增速拆解", "View B: FY26 Growth Breakdown"], ["1. 超高端旗舰矩阵（iPhone 18 Pro / Pro Max + 折叠屏 iPhone Duo）", "1. Ultra-Premium Flagships (iPhone 18 Pro / Pro Max + iPhone Duo)"], ["展开微观执行机制", "Show Execution Mechanics"], ["收起微观执行机制", "Hide Execution Mechanics"], ["iPhone Duo 为苹果史上首款折叠形态手机，2026 年 9 月 18 日首发即陷入供不应求，显著拉升 FY27Q1 假日季平均售价与高端换机预期。", "iPhone Duo—Apple's first foldable—sold out immediately on Sept 18, 2026, boosting holiday ASP and upgrade momentum."], ["2. 全球走量与份额基石（iPhone 17 系列 & 存量换机潮）", "2. Global Volume Anchor (iPhone 17 Lineup & Carrier Trade-Ins)"], ["首年营收 >$170B", "Year-1 Rev >$170B"], ["2026Q2 iPhone 17 占全球单机销量 6.0% 位居第一，17 Pro Max 与 17 Pro 包揽二、三名，构建全价格带防御纵深。", "In Q2 2026, iPhone 17 ranked #1 globally at 6.0% unit share, with 17 Pro Max and 17 Pro taking #2 and #3."], ["3. iPhone 衍生服务生态（App Store / iCloud / Apple Pay / Maps 广告）", "3. Services Monetization Flywheel (App Store / iCloud / Maps Ads)"], ["Q4 毛利率 76.0%", "Q4 GM 76.0%"], ["依托逾 25 亿台活跃设备底座，FY2026 服务业务净营收增长 +12.9% 至 $1,233.0亿（Q4 单季 $315.7亿），付费订阅突破 15 亿份，并在美加正式上线 Apple Maps 搜索广告。", "Backed by 2.5B+ active devices and 1.5B+ paid subscriptions, FY26 Services grew +12.9% to $123.30B ($31.57B in Q4), adding Apple Maps search ads in the US & Canada."], ["全球活跃设备突破 25 亿台、付费订阅超 15 亿份，服务业务以 27.6% 的营收占比贡献了苹果约 44% 的毛利润。", "With 2.5B+ active devices, Services represents 27.6% of Q4 revenue yet generates ~44% of total gross profit."], ["4. 端侧 AI 与跨终端协同（新版 Siri AI + Mac / iPad / Wearables）", "4. On-Device AI & Multi-Device Synergy (Siri AI + Mac / iPad)"], ["研发投入 $45.8B (+32%)", "R&D $45.8B (+32%)"], ["FY2026 苹果研发费用激增 +32.4% 至 $458亿（占营收 9.6%），集中投向新版 Siri AI 与 Apple Silicon 端侧算力；Q4 Mac 营收大增 +23.7% 至 $108亿创财年新高。", "FY26 R&D surged +32.4% to $45.8B (9.6% of sales) for next-gen Siri AI and Apple Silicon; Q4 Mac sales jumped +23.7% to $10.8B."], ["iPhone 强力拉动全生态硬件协同，FY26 Mac、iPad 与可穿戴设备合计贡献 ~$101.4B 营收，形成极高跨设备留存闭环。", "iPhone anchors cross-device adoption across ~$101.4B of Mac, iPad, and Wearables revenue, minimizing churn."], ["二、行业地位与四重核心护城河：芯片垂直整合、25亿生态闭环与供应链霸权", "2. Industry Position & Four Economic Moats: Silicon, 2.5B Ecosystem & Supply Chain"], ["点击左侧任一护城河卡片，联动查看核心数据与五维竞争雷达图", "Click any moat card on the left to inspect key metrics and the 5-axis competitive radar"], ["护城河评级：极宽 (Wide Moat · 全球智能手机利润池占比 >80%)", "Moat Rating: Wide Moat (>80% Global Smartphone Profit Share)"], ["01 · 25亿活跃设备与 iOS 极高迁移成本", "01 · 2.5B Active Devices & High Switching Costs"], ["流失率 <5%", "Churn <5%"], ["iMessage、iCloud、Apple Watch、AirPods 与 15 亿+ 付费订阅将全球逾 25 亿台设备锁入 iOS 闭环，多设备用户跨系统流失率不足 5%。", "iMessage, iCloud, Apple Watch, AirPods, and 1.5B+ subscriptions lock in 2.5B+ devices with <5% multi-device churn."], ["02 · Apple Silicon 芯片与软硬一体垂直整合", "02 · Apple Silicon & Hardware-Software Integration"], ["台积电首发制程", "Leading-Node Silicon"], ["从 A 系列 Pro 芯片、M 系列芯片到自研调制解调器与端侧神经网络引擎，锁定台积电先进制程首发产能并筑起端侧 AI 能效壁垒。", "In-house A-series, M-series, and modem silicon secure leading TSMC nodes and unmatched on-device AI efficiency."], ["03 · $800+ 超高端定价权与二手保值率护城河", "03 · $800+ Ultra-Premium Pricing & Resale Value"], [">65% 超高端份额", ">65% Ultra-Premium"], ["垄断全球 $800+ 市场逾 65% 份额，高残值率令运营商（最高 $1,100 补贴）能以更低净成本撬动用户升级至 Pro Max 与 Duo。", "Commands >65% of the $800+ tier; high resale value enables $1,100 carrier trade-in subsidies for Pro Max and Duo."], ["04 · 供应链议价霸权与轻资本 AI 现金转化率", "04 · Supply-Chain Power & 93.8% FCF Conversion"], ["93.8% FCF 转化", "93.8% FCF Conv."], ["FY2026 CapEx 仅 $90亿（占营收 1.9%），$1,451亿 经营现金流中高达 93.8%（$1,361亿）转化为自由现金流，且享有存储芯片优先保供权。", "With just $9.0B CapEx (1.9% of sales), 93.8% of $145.1B operating cash flow became FCF alongside priority memory supply."], ["全球智能手机巨头五维护城河雷达图（10分制标杆评估）", "5-Axis Global Smartphone Moat Benchmark Radar (10-Point Scale)"], ["点击下方图例胶囊可单独开关对比曲线，悬停顶点查看各维度评分", "Click legend pills below to toggle peer curves; hover vertices for exact scores"], ["苹果 iPhone (AAPL)", "Apple iPhone (AAPL)"], ["三星 Galaxy (005930)", "Samsung Galaxy (005930)"], ["小米集团 (1810.HK)", "Xiaomi Corp (1810.HK)"], ["三、全球智能手机巨头横向对比：存储涨价潮分化市场，iPhone 与三星头部通吃", "3. Global Smartphone Peer Matrix: Memory Inflation Bifurcates the Market"], ["支持按厂商、旗舰机型、市盈率或存储涨价抗压关键词实时筛选对比", "Filter or search in real time by OEM, flagship device, P/E, or memory-inflation resilience"], ["显示 5 / 5 家全球巨头", "Showing 5 / 5 Global Leaders"], ["全部核心厂商", "All Leaders"], ["全球双寡头 (Apple/Samsung)", "Global Duopoly (Apple/Samsung)"], ["中国本土与新兴旗舰 (华为/小米)", "China Leaders (Huawei/Xiaomi)"], ["移动生态与 AI 平台 (Google)", "Mobile OS & AI (Google)"], ["厂商名称与核心旗舰", "OEM & Flagships"], ["2026 市场份额与动能", "2026 Share & Momentum"], ["高端与 AI 生态卡位", "Premium & AI Positioning"], ["市盈率 P/E", "P/E Multiple"], ["营业利润率", "Operating Margin"], ["抗存储涨价韧性", "Memory Resilience"], ["核心优劣势与 2026 竞争格局评估", "2026 Competitive Assessment"], ["全球主流手机与移动生态巨头营业利润率 vs 2026Q2 出货同比增速（%）", "Operating Margin vs. Q2 2026 Smartphone Shipment Growth YoY (%)"], ["在 2026 年存储芯片涨价危机导致大众市场萎缩 6.7%~7.4% 的背景下，苹果凭借 31.1% 营业利润率与 +13.0% 出货增速展现统治力", "Amid a 6.7%–7.4% industry contraction from memory inflation, Apple posted 31.1% operating margin and +13.0% Q2 shipment growth"], ["IDC / Counterpoint 2026 实证", "IDC / Counterpoint 2026"], ["四、财务健康度与估值体系：$1,361亿自由现金流与“千亿级回购注销”复利机器", "4. Financial Health & Capital Return: $136.1B FCF & Buyback Compounding Engine"], ["FY2026 股票回购 $86.4B · 5年累计注销 12.7% 摊薄总股本", "FY2026 Buybacks $86.4B · 12.7% Diluted Share Reduction Over 5 Years"], ["FY26 股东现金回报 ~$102.0B", "FY26 Capital Return ~$102.0B"], ["FY26 综合毛利率跃升至 48.8%（+1.9pp），Q4 硬件毛利率 37.2%，服务毛利率 76.0%。", "FY26 GM climbed +1.9pp to 48.8% (Q4 products 37.2%, services 76.0%)."], ["全年经营现金流 $1,451亿，扣除仅 $90亿 CapEx 后 FCF 暴增 +38%（扣除 SBC 后 ~$1,223亿）。", "Operating cash flow of $145.1B minus $9.0B CapEx yielded +38% FCF growth (~$122.3B ex-SBC)."], ["+$56.8B 净现金", "+$56.8B Net Cash"], ["截至 Q4 末持有现金及证券 $1,369亿、总债务 $801亿；CFO 确认不再强求“净现金中性”目标。", "$136.9B cash & securities vs. $80.1B debt; CFO Kevan Parekh dropped rigid net-cash-neutral target."], ["FY26 回购 $864亿（Q4 单季回购 $240亿 + 派息 $39亿），年化股息上调至 $1.08/股。", "$86.4B FY26 buybacks ($24B in Q4 + $3.9B dividends); annualized dividend raised to $1.08/sh."], ["FY2021–FY2026 摊薄每股收益（Diluted EPS）飙升 vs 加权平均稀释总股本缩减（剪刀差效应）", "FY2021–FY2026 Diluted EPS Surge vs. Share Count Retirement (Scissor Effect)"], ["依靠每年 $800亿–$900亿 级别的股票回购，稀释总股本从 FY21 的 168.65 亿股降至 FY26 的 147.20 亿股，助力 EPS 从 $5.61 跃升至 $8.98", "Consistent $80B–$90B annual buybacks shrank diluted shares from 16.87B (FY21) to 14.72B (FY26), lifting EPS from $5.61 to $8.98"], ["5年注销 21.45亿股 (-12.7%)", "2.15B Shares Retired (-12.7%)"], ["■ 左轴：GAAP 摊薄 EPS ($/股)", "■ Left Axis: GAAP Diluted EPS ($/sh)"], ["● 右轴：稀释总股本 (十亿股)", "● Right Axis: Diluted Shares (B)"], ["GAAP 摊薄每股收益 Diluted EPS (左轴 · $)", "GAAP Diluted EPS (Left · $)"], ["加权平均稀释总股本 (右轴 · B股)", "Weighted Diluted Shares (Right · B)"], ["iPhone 现金流机器：“股票回购注销增厚 + 股息复利”总回报动态推演器", "iPhone Cash Machine: Buyback Retirement + Dividend DRIP Return Simulator"], ["开启股息自动再投资 (DRIP · $1.08/股)", "Enable Dividend Reinvestment (DRIP · $1.08/sh)"], ["基准参考股价 $353.80 | FY26 EPS $8.98 | 自动将季度现金分红再买入股份", "Base price $353.80 | FY26 EPS $8.98 | Automatically reinvests quarterly dividends"], ["① 1.2% 保守注销（高估值期缩量）", "① 1.2% Conservative Buyback (High P/E)"], ["10年 · 1.2% 回购", "10Y · 1.2% Retire"], ["② 1.8% 基准注销（FY26 当前速率）", "② 1.8% Base Buyback (FY26 Pace)"], ["10年 · 1.8% 回购", "10Y · 1.8% Retire"], ["③ 2.8% 加速注销（近 5 年历史均值）", "③ 2.8% Accelerated Buyback (5-Yr Avg)"], ["10年 · 2.8% 回购", "10Y · 2.8% Retire"], ["初始投入本金 (USD)", "Initial Principal (USD)"], ["长期持有年限 (Years)", "Holding Horizon (Years)"], ["年均内生净利润增长率 (Organic Growth %)", "Annual Organic Net Income Growth (%)"], ["期末预计持仓总市值 (Ending Value)", "Projected Ending Portfolio Value"], ["期末预计 EPS / 综合年化增速", "Projected End EPS / EPS CAGR"], ["穿透底层利润份额增幅 (Ownership Boost)", "Underlying Ownership Boost"], ["累计现金分红总额 (Cumulative Div)", "Cumulative Cash Dividends"], ["━ 含当前回购与复利总资产轨迹", "━ Active Buyback + DRIP Trajectory"], ["- - 无回购纯内生增长基准", "- - Organic Growth Only (Ex-Buyback)"], ["悬停曲线可逐年对比“回购注销+股息复利”与“无回购基准”的长期复利剪刀差。", "Hover along the curve to inspect year-by-year compounding alpha from share retirement."], ["多头核心论点 (Bull Thesis)", "Bull Thesis (Foldable + Capital-Light AI)"], ["空头担忧论点 (Bear Thesis)", "Bear Thesis (~39.5x P/E + Memory Costs)"], ["五、投资决策与风险配置框架：FY2027 三情景估值推演与硬件-生态配对策略", "5. Valuation Scenarios & Risk Allocation: FY2027 Three-Case Framework"], ["配置建议：长线底仓锁定复利 · 静待 32x–34x ($300–$320) 回调窗口加仓", "Strategy: Hold Core Compounder · Accumulate on Pullbacks to 32x–34x ($300–$320)"], ["12个月估值锚：$267 – $400", "12M Range: $267 – $400"], ["牛市情景 · 40.0x FY27E EPS $10.00 ($400) —— iPhone Duo 放量 + 毛利率守稳 49%+", "Bull Case · 40.0x FY27E EPS $10.00 ($400) — iPhone Duo Ramp & 49%+ GM"], ["概率 25% · 回报 +13%~+15%", "Prob 25% · +13% to +15%"], ["iPhone Duo 折叠机良率爬坡后在 FY27 全面放量，叠加 2027 春季标准版 iPhone 18 接力与新版 Siri AI 引爆换机潮；高端机型涨价完全转嫁内存成本，市值冲击 $5.8T。", "iPhone Duo yields normalize for full FY27 scaling alongside spring iPhone 18 and new Siri AI; premium pricing fully offsets memory costs, lifting valuation toward $5.8T."], ["基准情景 · 36.0x–38.0x EPS $9.40 ($338–$357) —— 稳健增长消化高估值", "Base Case · 36.0x–38.0x EPS $9.40 ($338–$357) — Digesting Multiple"], ["概率 50% · 回报 -3%~+4%", "Prob 50% · -3% to +4%"], ["FY2027 营收在 FY26 超高基数（+15%）上实现 7%–9% 稳健增长，存储芯片涨价与服务增速放缓（~8.5%）使 EPS 温和增长至华尔街共识 $9.40，以时间换空间消化估值。", "Revenue grows 7%–9% off FY26's +15% base; memory inflation and ~8.5% Services growth moderate EPS to consensus $9.40 as valuation consolidates."], ["熊市情景 · 30.0x–32.0x EPS $8.90 ($267–$285) —— 内存挤压 + 服务监管冲击", "Bear Case · 30.0x–32.0x EPS $8.90 ($267–$285) — Margin & Reg Reset"], ["概率 25% · 回调 -19%~-24%", "Prob 25% · -19% to -24%"], ["DRAM/NAND 价格暴涨导致硬件毛利率回落 200bps+，关税退税消失；同时欧美 App Store 反垄断整改与 Google 搜索分成调整冲击服务收入，触发估值向 30x 均值回归。", "DRAM/NAND inflation compresses product GM by 200bps+ as tariff refunds fade, while App Store & Google TAC regulatory shifts reset P/E toward 30x."], ["风险 01 · 极高关注", "Risk 01 · Critical"], ["成本与关税红利退坡", "Margin Headwind"], ["存储芯片涨价与关税退税退坡", "DRAM / NAND Inflation & Fading Tariff Refunds"], ["风险 02 · 高关注", "Risk 02 · High"], ["增速放缓至 8%–9%", "Slowing to 8%–9%"], ["服务业务监管逆风与增速换挡", "Services Regulatory Headwinds & Deceleration"], ["Q4 服务营收同比增速已从 Q3 的 +12.1% 放缓至 +9.8%，且管理层指引 FY27Q1 进一步放缓至 8%–9%，需密切跟踪 App Store 抽成率与 Google TAC 许可费变动。", "Services YoY growth eased from +12.1% (Q3) to +9.8% (Q4) with +8%–9% Q1 guidance amid EU DMA, US payment-link rulings, and softer gaming."], ["风险 03 · 中高关注", "Risk 03 · Medium-High"], ["供应受限顺延交付", "Supply Constraints"], ["新品产能瓶颈（iPhone Duo / Mac / iPad）", "New-Product Supply Bottlenecks (Duo / Mac / iPad)"], ["COO Sabih Khan 坦言目前无法给出 iPhone Duo 供需平衡的明确时间表，同时存储器件短缺正直接限制 Mac 与 iPad 在 FY27Q1 假日旺季的出货上限。", "COO Sabih Khan noted no firm timeline for iPhone Duo supply-demand balance, while memory tightness caps Q1 Mac and iPad shipments."], ["风险 04 · 中高关注", "Risk 04 · Medium-High"], ["溢价 70% + 第三方算力", "70% P/E Premium"], ["高估值压缩安全边际与第三方算力依赖", "Stretched ~39.5x P/E & Third-Party Cloud Reliance"], ["苹果在 10-K 风险因素中将“部分 AI 计算依赖第三方基础设施”列入潜在风险；同时在 5.1% 无风险美债利率下，2.6% 的 FCF 收益率对任何业绩低于预期极为敏感。", "Apple flagged reliance on third-party AI compute in its 10-K; at a 5.1% Treasury yield, a 2.6% FCF yield leaves narrow margin for earnings misses."], ["策略一：", "Playbook 01:"], ["以 AAPL 作为 25 亿终端入口底仓，适度搭配上游存储与晶圆龙头（TSM / 三星 / 美光），自然对冲 DRAM/NAND 涨价。", "Pair AAPL's 2.5B-device base with upstream memory & foundry leaders (TSM / Samsung / Micron) to hedge DRAM/NAND inflation."], ["策略二：", "Playbook 02:"], ["严守估值纪律不追高 ~40x：存量底仓持有享受回购复利，新增资金静待回踩 $305–$320（32x–34x P/E）分批吸筹。", "Avoid chasing ~40x P/E: hold core shares for buyback compounding and stage new buys on pullbacks to $305–$320 (32x–34x)."], ["策略三：", "Playbook 03:"], ["机构持仓者可卖出 30–45 天到期、行权价 $375–$385 的虚值看涨期权（Covered Call），额外增厚 3%–5% 年化现金收益。", "Sell 30–45 DTE out-of-the-money Covered Calls ($375–$385 strike) to add 3%–5% annualized cash yield above the 0.30% dividend."], ["六、季度基本面跟踪 KPI 交互式核查清单（FY2027 重点监测）", "6. Interactive Quarterly Fundamental Tracking Checklist (FY2027 Monitor)"], ["点击勾选季度财报中已验证达标的经营指标（勾选状态自动保存在本地），持续校验换机周期与利润率韧性", "Track verified quarterly milestones (saved locally) across upgrade cycles, margins, and services resilience"], ["全部勾选", "Check All"], ["重置清单", "Reset"], ["数据来源与监管/行业档案核验索引（SEC EDGAR & Industry Trackers）", "Primary Regulatory Filings & Industry Trackers Index (SEC EDGAR & Counterpoint)"], ["本深度研究报告基于苹果公司公开财务报告（FY2022–FY2026 Form 10-K / 8-K）、2026年11月 Q4 业绩电话会议披露数据及 Counterpoint Research、IDC、StatCounter 全球智能手机跟踪报告整理生成，旨在提供结构化的产业分析与资本回报估值框架，不构成任何证券买卖建议。", "Compiled from Apple Inc. Form 10-K/8-K filings (FY2022–FY2026), Nov 2026 Q4 earnings call disclosures, and Counterpoint/IDC/StatCounter smartphone trackers. For institutional research only; not investment advice."]];
      var I18N_ATTR_PAIRS = [["展开/收起章节目录", "Toggle Chapter Sidebar"], ["切换目录侧边栏", "Toggle Chapter Sidebar"], ["面包屑导航", "Breadcrumb Navigation"], ["检索章节或指标…", "Jump to chapter or KPI…"], ["快速跳转章节或指标", "Quick jump to chapter or metric"], ["研究章节目录与站点导航", "Report Chapters & Site Navigation"], ["站点导航与章节目录", "Site Links & Table of Contents"], ["外观模式切换", "Appearance Theme Switch"], ["阅读与导出工具", "Reading & Export Tools"], ["导出独立 HTML 文件 (.html)", "Export Standalone HTML File (.html)"], ["打印或导出 PDF 研报", "Print or Save Report as PDF"], ["第一章图表视图切换", "Chapter 01 Chart View Switch"], ["搜索厂商、旗舰机、市盈率或存储抗压关键词…", "Search OEM, flagship, P/E, or memory resilience…"], ["筛选对比厂商", "Filter benchmark OEMs"], ["标杆厂商分类筛选", "OEM category filter"], ["全球智能手机与生态巨头横向对比表", "Global Smartphone & Ecosystem Peer Matrix"], ["股票回购注销速率预设", "Buyback Retirement Pace Presets"], ["核查完成度进度条", "Checklist Completion Progress"]];
      var PILLAR_NOTES = ["<strong>当前选中护城河解读（01 25亿设备与极高迁移成本）：</strong>全球活跃设备超 25 亿台、付费订阅逾 15 亿份，多设备用户跨系统流失率低于 5%，直接托底 $1,233亿 服务收入 <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/11/apple-reports-fourth-quarter-results/\" target=\"_blank\" rel=\"noopener noreferrer\">Apple FY26 Q4 ↗</a>。", "<strong>当前选中护城河解读（02 Apple Silicon 全栈垂直整合）：</strong>自研 A/M 系列芯片与端侧神经网络引擎结合台积电先进制程首发产能，构筑竞争对手难以复制的能效与端侧 AI 体验护城河。", "<strong>当前选中护城河解读（03 $800+ 超高端定价权）：</strong>iPhone 17 系列首年营收突破 $1,700亿，叠加 iPhone Duo 折叠机与运营商 $1,100 换机补贴，牢牢垄断全球 $800+ 超高端利润池 <a class=\"cite-link\" href=\"https://counterpointresearch.com/cn/insights/iphone-17-series-outpaces-previous-series-first-year-revenue-over-170-billion-dollars\" target=\"_blank\" rel=\"noopener noreferrer\">Counterpoint ↗</a>。", "<strong>当前选中护城河解读（04 轻资本供应链霸权）：</strong>FY2026 CapEx 仅 $90亿（占营收 1.9%），93.8% 经营现金流转化为 $1,361亿 自由现金流，在存储芯片涨价危机中具备顶级保供与议价权。"];
      var PILLAR_NOTES_EN = ["<strong>Selected Moat (01 · 2.5B Devices &amp; Switching Costs):</strong> 2.5B+ active devices and 1.5B+ paid subscriptions keep multi-device churn under 5%, anchoring $123.3B in Services revenue <a class=\"cite-link\" href=\"https://www.apple.com/newsroom/2026/11/apple-reports-fourth-quarter-results/\" target=\"_blank\" rel=\"noopener noreferrer\">Apple FY26 Q4 ↗</a>.", "<strong>Selected Moat (02 · Apple Silicon Integration):</strong> In-house A/M-series chips and Neural Engines paired with leading-edge TSMC nodes create an unmatched on-device AI and battery efficiency moat.", "<strong>Selected Moat (03 · $800+ Ultra-Premium Pricing):</strong> iPhone 17 ($170B+ year-one sales), iPhone Duo, and $1,100 carrier trade-ins lock in >65% share of the global $800+ profit pool <a class=\"cite-link\" href=\"https://counterpointresearch.com/cn/insights/iphone-17-series-outpaces-previous-series-first-year-revenue-over-170-billion-dollars\" target=\"_blank\" rel=\"noopener noreferrer\">Counterpoint ↗</a>.", "<strong>Selected Moat (04 · Capital-Light Supply Power):</strong> Just $9.0B CapEx (1.9% of sales) converted 93.8% of operating cash flow into $136.1B FCF while securing priority memory allocation."];
      var PEER_ROWS = [{"category": "core", "benchmark": true, "company": "苹果 (AAPL · 生态利润霸主)", "leader": "iPhone 18 Pro / iPhone Duo / 17", "positioning": "全球活跃份额 27.6% · Q2出货 +13% / 中国 +23%", "culture": "包揽全球畅销机 Top 3 · ~39.5x TTM P/E", "headcount": "营业利润率 31.1%–32.0%", "margins": "抗存储涨价：极强 (高ASP+76%服务毛利)", "verdict": "全行业利润池绝对统治者：凭 iPhone 17/18 Pro 与首款折叠机 iPhone Duo 独占全球超高端换机潮；风险在于 ~39.5x 估值与内存涨价。", "sourceLabel": "Apple FY26 Q4", "sourceUrl": "https://www.apple.com/newsroom/2026/11/apple-reports-fourth-quarter-results/"}, {"category": "flagship", "benchmark": false, "company": "三星电子 (005930.KS)", "leader": "Galaxy S26 Ultra / Z Fold 系列", "positioning": "2026Q2 出货 6,270万台 (+8.1% · 份额 22.6%)", "culture": "S26 Ultra 跃居畅销榜前列 · ~6.4x TTM P/E", "headcount": "营业利润率 ~14.5%", "margins": "抗存储涨价：极强 (自有DRAM/NAND产线)", "verdict": "存储涨价最大受益者与折叠屏先驱：与苹果各占全球畅销 Top 10 机型中的 5 席，自有半导体业务直接受益于内存涨价。", "sourceLabel": "Counterpoint", "sourceUrl": "https://counterpointresearch.com/en/insights/apple-iphone-market-share"}, {"category": "china", "benchmark": false, "company": "华为终端 (Huawei)", "leader": "Mate 系列 / Pura 系列 / 三折叠", "positioning": "2026Q2 中国市场份额攀升至 23% 居首", "culture": "原生鸿蒙 HarmonyOS 高增 · 未上市", "headcount": "营业利润率 ~11.0%–13.5%", "margins": "抗存储涨价：较强 (本土供应链协同)", "verdict": "iPhone 大中华区头号劲敌：凭借麒麟芯片迭代与 HarmonyOS 生态在中国高端市场与苹果贴身肉搏（Q2 中国份额 23% vs 苹果 18%）。", "sourceLabel": "Counterpoint", "sourceUrl": "https://shattered.io/iphone-18-pro-sales-3-1-percent-above-iphone-17-counterpoint-2026/"}, {"category": "china", "benchmark": false, "company": "小米集团 (1810.HK)", "leader": "Xiaomi 16/17 / Redmi / 人车家生态", "positioning": "2026Q2 出货 3,120万台 (-26.3% YoY · 11.8%)", "culture": "中低端受存储涨价严重挤压 · ~21.5x P/E", "headcount": "营业利润率 ~8.2%", "margins": "抗存储涨价：较弱 (走量机BOM占比高)", "verdict": "人车家突围但手机受困内存危机：据 IDC 2026Q2 数据，因 AI 服务器推高 DRAM/NAND 价格冲击中低端机型，小米 Q2 出货下滑 26.3%。", "sourceLabel": "IDC 2026Q2", "sourceUrl": "https://commandlinux.com/statistics/android-oem-market-share-samsung-xiaomi-google-motorola/"}, {"category": "ecosystem", "benchmark": false, "company": "谷歌 Alphabet (GOOGL)", "leader": "Pixel 10/11 系列 / Android (69% OS)", "positioning": "2026Q2 Pixel 全球出货同比 +16%", "culture": "Gemini 原生 AI + 搜索分成盟友 · ~18.8x Fwd", "headcount": "营业利润率 33.3% (集团)", "margins": "抗存储涨价：强 (高毛利广告补贴硬件)", "verdict": "既是 AI 对手又是百亿搜索分成金主：Pixel 增速达 +16%；谷歌每年向苹果支付 Safari 默认搜索授权费，但面临高额 AI CapEx 压力。", "sourceLabel": "IDC / StatCounter", "sourceUrl": "https://commandlinux.com/statistics/android-oem-market-share-samsung-xiaomi-google-motorola/"}];
      var PEER_ROWS_EN = [{"category": "core", "benchmark": true, "company": "Apple (AAPL · Profit Leader)", "leader": "iPhone 18 Pro / iPhone Duo / 17", "positioning": "27.6% Active Share · Q2 +13% / China +23%", "culture": "Swept Global Top 3 Models · ~39.5x TTM P/E", "headcount": "Operating Margin 31.1%–32.0%", "margins": "Memory Resilience: Very High (ASP + 76% Services)", "verdict": "Dominant industry profit pool owner: iPhone 17/18 Pro and iPhone Duo lead ultra-premium upgrades; key watchpoints are ~39.5x P/E and memory costs.", "sourceLabel": "Apple FY26 Q4", "sourceUrl": "https://www.apple.com/newsroom/2026/11/apple-reports-fourth-quarter-results/"}, {"category": "flagship", "benchmark": false, "company": "Samsung Electronics (005930.KS)", "leader": "Galaxy S26 Ultra / Z Fold Series", "positioning": "Q2 26 Shipments 62.7M (+8.1% · 22.6% share)", "culture": "S26 Ultra Top Seller · ~6.4x TTM P/E", "headcount": "Operating Margin ~14.5%", "margins": "Memory Resilience: Very High (In-House DRAM/NAND)", "verdict": "Memory-inflation beneficiary & foldable pioneer: shares 5 of the global Top 10 bestsellers with Apple, though lacking high-margin OS services.", "sourceLabel": "Counterpoint", "sourceUrl": "https://counterpointresearch.com/en/insights/apple-iphone-market-share"}, {"category": "china", "benchmark": false, "company": "Huawei Consumer BG", "leader": "Mate / Pura / Tri-Fold Series", "positioning": "Q2 26 China Market Share #1 at 23%", "culture": "HarmonyOS Native Ecosystem · Private", "headcount": "Operating Margin ~11.0%–13.5%", "margins": "Memory Resilience: Solid (Domestic Supply)", "verdict": "Apple's #1 Greater China rival: Kirin silicon and HarmonyOS lead domestic share (23% vs. Apple's 18% in Q2), though GMS limits overseas reach.", "sourceLabel": "Counterpoint", "sourceUrl": "https://shattered.io/iphone-18-pro-sales-3-1-percent-above-iphone-17-counterpoint-2026/"}, {"category": "china", "benchmark": false, "company": "Xiaomi Corp (1810.HK)", "leader": "Xiaomi 16/17 / Redmi / EV Ecosystem", "positioning": "Q2 26 Shipments 31.2M (-26.3% YoY · 11.8%)", "culture": "Mid/Low-Tier Margin Squeeze · ~21.5x P/E", "headcount": "Operating Margin ~8.2%", "margins": "Memory Resilience: Weak (High BOM Ratio)", "verdict": "EV expansion offset by memory squeeze: per IDC Q2 2026, rising DRAM/NAND costs hit entry-tier volumes (-26.3% YoY), highlighting Apple's ASP shield.", "sourceLabel": "IDC 2026Q2", "sourceUrl": "https://commandlinux.com/statistics/android-oem-market-share-samsung-xiaomi-google-motorola/"}, {"category": "ecosystem", "benchmark": false, "company": "Alphabet / Google (GOOGL)", "leader": "Pixel 10/11 / Android (69% OS Share)", "positioning": "Q2 26 Pixel Global Shipments +16% YoY", "culture": "Gemini Native AI + TAC Partner · ~18.8x Fwd", "headcount": "Operating Margin 33.3% (Group)", "margins": "Memory Resilience: High (Ad Profit Buffer)", "verdict": "Both AI rival and key TAC partner: Pixel grew +16% YoY while Google pays Safari search licensing fees, though facing heavy AI CapEx ($175B+).", "sourceLabel": "IDC / StatCounter", "sourceUrl": "https://commandlinux.com/statistics/android-oem-market-share-samsung-xiaomi-google-motorola/"}];
      var CHECKLIST_ITEMS = [{"tag": "ASP 核心引擎", "title": "1. iPhone Duo 折叠机产能爬坡与 18 Pro 系列全球交付节奏", "desc": "26Q4 首发期 18 Pro 系列全球销量同比 +3.1%（中国 +29%）；需跟踪 FY27Q1 假日季 iPhone Duo 发货周期是否从当前的严重缺货显著缩短。"}, {"tag": "区域胜负手", "title": "2. 大中华区营收反弹延续性（FY26 全年 +28% / Q4 +21%）", "desc": "大中华区 FY26 营收重返 $824亿 高位；后续季度需核查面对华为 Mate/Pura 新品竞争，苹果中国市场份额（Q2 为 18%）能否守住正增长。"}, {"tag": "生态基本盘", "title": "3. 25亿+ 活跃设备底座与 15亿+ 付费订阅双位数扩张", "desc": "已验证全球活跃设备突破 25 亿台、付费订阅超 15 亿份且保持双位数增长，这是支撑 $1,233亿 服务收入的最底层基石。"}, {"tag": "利润率警戒线", "title": "4. 硬件毛利率（Q4 37.2%）抵御 DRAM/NAND 涨价的能力", "desc": "剔除 Q4 约 1pp 关税退税一次性收益后，检验 FY27 各季集团综合毛利率能否守住 47.0%–48.0% 区间而不被内存涨价大幅侵蚀。"}, {"tag": "第二曲线韧性", "title": "5. 服务业务增速守住 8%–10% 底线及 Maps 原生广告放量", "desc": "跟踪美加地区 Apple Maps 搜索广告的 ARPU 贡献能否对冲外部支付链接分流与手游疲软，确保服务毛利率稳居 75%+。"}, {"tag": "双波段与资本回报", "title": "6. 2027春季标准版 iPhone 18 补齐节奏与每季 $200亿+ 回购力度", "desc": "观察错峰至 2027 上半年发布的标准版 iPhone 18 能否激活大众换机盘，同时监测每季股票回购金额是否维持在 $200亿–$240亿 高位。"}];
      var CHECKLIST_ITEMS_EN = [{"tag": "ASP Engine", "title": "1. iPhone Duo Yield Ramp & 18 Pro Global Lead Times", "desc": "18 Pro launch sales rose +3.1% YoY (+29% in China); monitor whether iPhone Duo supply tightness eases during the FY27Q1 holiday quarter."}, {"tag": "Regional Swing", "title": "2. Greater China Rebound Durability (FY26 +28% / Q4 +21%)", "desc": "Greater China reached $82.4B in FY26; track Q1–Q2 share defense against Huawei Mate/Pura flagships."}, {"tag": "Ecosystem Base", "title": "3. 2.5B+ Active Devices & 1.5B+ Paid Subscriptions Growth", "desc": "Verified 2.5B+ active devices and 1.5B+ paid subscriptions growing double digits—underpinning $123.3B in Services."}, {"tag": "Margin Watch", "title": "4. Product Gross Margin (Q4 37.2%) vs. DRAM/NAND Inflation", "desc": "Excluding Q4's ~1pp tariff refund, verify whether consolidated FY27 gross margin holds the 47.0%–48.0% band."}, {"tag": "Services Floor", "title": "5. Services Growth Holding 8%–10% & Apple Maps Ads Scaling", "desc": "Track US/Canada Apple Maps search ad ARPU offsetting App Store link-out rules while keeping Services GM ≥75%."}, {"tag": "Dual-Wave & Buybacks", "title": "6. Spring 2027 Base iPhone 18 Launch & $20B+ Quarterly Buybacks", "desc": "Verify mass-market upgrade lift from H1 2027's base iPhone 18 alongside $20B–$24B quarterly share repurchases."}];
      var QUICK_JUMP_INDEX = [{"sec": "sec-00", "title": "00 执行摘要与核心指标", "sub": "$5.16T 市值 · $254.1B iPhone 营收 · 48.8% 毛利率 · $8.98 EPS"}, {"sec": "sec-01", "title": "01 iPhone 产品矩阵与收入架构", "sub": "iPhone Duo / 18 Pro 错峰 · $123.3B 服务 · 五年营收演进图"}, {"sec": "sec-02", "title": "02 行业地位与四重生态护城河", "sub": "25亿设备 · Apple Silicon · $800+ 定价权 · 五维雷达图"}, {"sec": "sec-03", "title": "03 全球高端手机巨头横向对比", "sub": "苹果 vs 三星 vs 华为 vs 小米 vs 谷歌 · 营业利润率与出货增速"}, {"sec": "sec-04", "title": "04 财务健康与回购复利推演", "sub": "$136.1B FCF · 5年注销 12.7% 股本 · 回购+股息复利模拟器"}, {"sec": "sec-05", "title": "05 投资决策与存储涨价风险", "sub": "FY27 三情景 ($267–$400) · DRAM/NAND 风险 · 杠铃配置策略"}, {"sec": "sec-06", "title": "06 季度跟踪 KPI 核查清单", "sub": "FY2027 6 项核心跟踪指标自测与本地持久化评分"}, {"sec": "sec-07", "title": "07 数据来源与监管核验索引", "sub": "Apple FY26 10-K · Counterpoint · IDC · Recon Analytics"}];
      var QUICK_JUMP_EN = [{"sec": "sec-00", "title": "00 Executive Summary & KPIs", "sub": "$5.16T Cap · $254.1B iPhone · 48.8% GM · $8.98 EPS"}, {"sec": "sec-01", "title": "01 Product Matrix & Revenue", "sub": "iPhone Duo / 18 Pro · $123.3B Services · 5-Yr Revenue Chart"}, {"sec": "sec-02", "title": "02 Industry & 4 Economic Moats", "sub": "2.5B Devices · Apple Silicon · $800+ Pricing · 5-Axis Radar"}, {"sec": "sec-03", "title": "03 Global Smartphone Peer Matrix", "sub": "Apple vs. Samsung vs. Huawei vs. Xiaomi vs. Google"}, {"sec": "sec-04", "title": "04 Financials & Buyback Sim", "sub": "$136.1B FCF · 12.7% Share Retirement · Buyback+DRIP Simulator"}, {"sec": "sec-05", "title": "05 Valuation & Memory Risk", "sub": "FY27 Cases ($267–$400) · DRAM/NAND Costs · Barbell Playbook"}, {"sec": "sec-06", "title": "06 Quarterly KPI Checklist", "sub": "6 FY2027 Fundamental Tracking Milestones (Saved Locally)"}, {"sec": "sec-07", "title": "07 Primary Filings & Sources Index", "sub": "Apple FY26 10-K · Counterpoint · IDC · Recon Analytics"}];

      var PRESETS = {
        p1: { principal: 50000, years: 10, priceCagr: 8.0, buyback: 0.012, drip: true },
        p2: { principal: 50000, years: 10, priceCagr: 8.0, buyback: 0.018, drip: true },
        p3: { principal: 50000, years: 10, priceCagr: 8.0, buyback: 0.028, drip: true }
      };

      var state = {
        lang: 'zh',
        theme: 'dark',
        ch1View: 'viewA',
        activePillar: 0,
        radarSeries: { aapl: true, sam: true, mi: true },
        ch1Series: { s1: true, s2: true },
        epsSeries: { eps: true, shares: true },
        peerFilter: 'all',
        peerQuery: '',
        sim: { principal: 50000, years: 10, priceCagr: 8.0, buyback: 0.018, drip: true, preset: 'p2' },
        checks: [true, true, true, false, false, false]
      };

      function safeGetStorage(key) { try { return window.localStorage.getItem(key); } catch (e) { return null; } }
      function safeSetStorage(key, val) { try { window.localStorage.setItem(key, val); } catch (e) {} }

      var toastTimer = null;
      function showToast(msg) {
        var el = document.getElementById('muiSnackbar');
        if (!el) return;
        el.textContent = msg; el.classList.add('show');
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(function () { el.classList.remove('show'); }, 2800);
      }

      function isEn() { return state.lang === 'en'; }
      var _zhToEnText = {}, _enToZhText = {};
      for (var _ti = 0; _ti < I18N_TEXT_PAIRS.length; _ti++) {
        _zhToEnText[I18N_TEXT_PAIRS[_ti][0]] = I18N_TEXT_PAIRS[_ti][1];
        _enToZhText[I18N_TEXT_PAIRS[_ti][1]] = I18N_TEXT_PAIRS[_ti][0];
      }
      var _zhToEnAttr = {}, _enToZhAttr = {};
      for (var _ai = 0; _ai < I18N_ATTR_PAIRS.length; _ai++) {
        _zhToEnAttr[I18N_ATTR_PAIRS[_ai][0]] = I18N_ATTR_PAIRS[_ai][1];
        _enToZhAttr[I18N_ATTR_PAIRS[_ai][1]] = I18N_ATTR_PAIRS[_ai][0];
      }
      var _richMapByKey = {};
      for (var _ri = 0; _ri < I18N_RICH_LIST.length; _ri++) _richMapByKey[I18N_RICH_LIST[_ri].key] = I18N_RICH_LIST[_ri];

      function bindRichBlocksOnce() {
        var candidates = document.querySelectorAll('h1, p, div');
        for (var i = 0; i < candidates.length; i++) {
          var el = candidates[i];
          if (el.getAttribute('data-i18n-rich')) continue;
          if (el.id === 'pillarFocusNote' || el.closest('#pillarFocusNote')) continue;
          var normTxt = (el.textContent || '').replace(/\s+/g, ' ').trim();
          for (var j = 0; j < I18N_RICH_LIST.length; j++) {
            var item = I18N_RICH_LIST[j];
            if (normTxt.indexOf(item.match_zh) === 0 && el.children.length <= 25 && !el.querySelector('div, p, ul, table, canvas')) {
              el.setAttribute('data-i18n-rich', item.key);
              break;
            }
          }
        }
      }

      function syncCh1HeaderText() {
        var tEl = document.getElementById('ch1ChartTitle'), sEl = document.getElementById('ch1ChartSub');
        if (!tEl || !sEl) return;
        if (state.ch1View === 'viewA') {
          tEl.textContent = isEn() ? 'FY2022–FY2026 iPhone Revenue, Services & Total Revenue ($B)' : 'FY2022–FY2026 iPhone 净营收、服务营收与集团总营收演进 ($B)';
          sEl.textContent = isEn() ? 'iPhone broke out of its $200B–$210B plateau to $254.1B (+21.2%) alongside $123.3B Services' : 'iPhone 突破三年 ~$200B–$210B 平台期跃升至 $254.1B (+21.2%)，与 $123.3B 服务营收共筑双引擎';
        } else {
          tEl.textContent = isEn() ? 'FY2026 & Q4 Core Margins, Mix & YoY Growth Breakdown (%)' : 'FY2026 & Q4 核心利润率与区域/品类增速拆解 (%)';
          sEl.textContent = isEn() ? '76.0% Q4 Services GM, 53.1% iPhone revenue share, +28% Greater China & +21.2% iPhone growth' : '服务毛利率高达 76.0%，iPhone 贡献 53.1% 营收，大中华区 (+28%) 与 iPhone (+21.2%) 领跑增长';
        }
      }

      function syncCollapseButtonsText() {
        var btns = document.querySelectorAll('[data-collapse-target]');
        for (var i = 0; i < btns.length; i++) {
          var p = document.getElementById(btns[i].getAttribute('data-collapse-target'));
          var open = p && p.classList.contains('open');
          btns[i].innerHTML = isEn()
            ? (open ? '<span>Hide Execution Mechanics</span> <span>⌃</span>' : '<span>Show Execution Mechanics</span> <span>⌄</span>')
            : (open ? '<span>收起微观执行机制</span> <span>⌃</span>' : '<span>展开微观执行机制</span> <span>⌄</span>');
        }
      }

      function applyLanguage(lang, silent) {
        bindRichBlocksOnce();
        state.lang = lang === 'en' ? 'en' : 'zh';
        var en = isEn();
        document.documentElement.setAttribute('lang', en ? 'en' : 'zh-CN');
        document.documentElement.setAttribute('data-lang', state.lang);
        document.title = en ? DOC_TITLE_EN : DOC_TITLE_ZH;

        var zhB = document.getElementById('langZhBtn'), enB = document.getElementById('langEnBtn');
        if (zhB && enB) {
          zhB.classList.toggle('active', !en); enB.classList.toggle('active', en);
          zhB.setAttribute('aria-pressed', !en ? 'true' : 'false'); enB.setAttribute('aria-pressed', en ? 'true' : 'false');
        }
        var lGrp = document.getElementById('langSwitchGroup');
        if (lGrp) lGrp.setAttribute('aria-label', en ? 'Language switcher' : '语言切换');
        var abThmBtn = document.getElementById('appbarThemeBtn');
        if (abThmBtn) {
          abThmBtn.setAttribute('title', en ? 'Toggle Light / Dark theme' : '切换浅色 / 深色主题');
          abThmBtn.setAttribute('aria-label', en ? 'Toggle color theme' : '切换深浅色主题');
        }
        var dynNav = document.querySelectorAll('[data-i18n-zh][data-i18n-en]');
        for (var dn = 0; dn < dynNav.length; dn++) {
          dynNav[dn].textContent = en ? dynNav[dn].getAttribute('data-i18n-en') : dynNav[dn].getAttribute('data-i18n-zh');
        }

        var richNodes = document.querySelectorAll('[data-i18n-rich]');
        for (var r = 0; r < richNodes.length; r++) {
          var rEntry = _richMapByKey[richNodes[r].getAttribute('data-i18n-rich')];
          if (rEntry) richNodes[r].innerHTML = en ? rEntry.en : rEntry.zh;
        }

        var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
        var tNode;
        while ((tNode = walker.nextNode())) {
          var pEl = tNode.parentElement;
          if (!pEl || pEl.tagName === 'SCRIPT' || pEl.tagName === 'STYLE') continue;
          if (pEl.closest('#langSwitchGroup') || pEl.closest('[data-i18n-rich]') || pEl.closest('#pillarFocusNote')) continue;
          var raw = tNode.nodeValue || '', trimmed = raw.replace(/\s+/g, ' ').trim();
          if (!trimmed) continue;
          var mapped = en ? _zhToEnText[trimmed] : _enToZhText[trimmed];
          if (mapped) {
            var lead = raw.match(/^\s*/), trail = raw.match(/\s*$/);
            tNode.nodeValue = (lead ? lead[0] : '') + mapped + (trail ? trail[0] : '');
          }
        }

        var allEls = document.querySelectorAll('[placeholder], [title], [aria-label]');
        var attrs = ['placeholder', 'title', 'aria-label'];
        for (var a = 0; a < allEls.length; a++) {
          if (allEls[a].closest('#langSwitchGroup')) continue;
          for (var k = 0; k < attrs.length; k++) {
            var av = allEls[a].getAttribute(attrs[k]);
            if (!av) continue;
            var nx = en ? _zhToEnAttr[av] : _enToZhAttr[av];
            if (nx) allEls[a].setAttribute(attrs[k], nx);
          }
        }

        var pNote = document.getElementById('pillarFocusNote');
        if (pNote) pNote.innerHTML = '<div>' + (en ? PILLAR_NOTES_EN : PILLAR_NOTES)[state.activePillar] + '</div>';
        syncCh1HeaderText();
        syncCollapseButtonsText();
        renderPeerTable();
        renderChecklist();
        updateSimulatorUI();
        renderAllCharts();
        safeSetStorage(STORAGE_LANG_KEY, state.lang);
        if (!silent) showToast(en ? 'Switched to English Research Edition' : '已切换至中文深度研报视图');
      }

      function applyTheme(theme, silent) {
        state.theme = theme === 'dark' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', state.theme);
        var abIcon = document.getElementById('appbarThemeIcon');
        if (abIcon) abIcon.innerHTML = (state.theme === 'dark')
          ? '<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zm18 0h2c.55 0 1-.45 1-1s-.45-1-1-1h-2c-.55 0-1 .45-1 1s.45 1 1 1zM11 2v2c0 .55.45 1 1 1s1-.45 1-1V2c0-.55-.45-1-1-1s-1 .45-1 1zm0 18v2c0 .55.45 1 1 1s1-.45 1-1v-2c0-.55-.45-1-1-1s-1 .45-1 1zM5.99 4.58a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0s.39-1.03 0-1.41L5.99 4.58zm12.37 12.37a.996.996 0 0 0-1.41 0 .996.996 0 0 0 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0a.996.996 0 0 0 0-1.41l-1.06-1.06zm1.06-10.96a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06zM7.05 18.36a.996.996 0 0 0 0-1.41.996.996 0 0 0-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41s1.03.39 1.41 0l1.06-1.06z"/></svg>'
          : '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3a9 9 0 1 0 9 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 0 1-4.4 2.26 5.403 5.403 0 0 1-3.14-9.8c-.44-.06-.9-.1-1.36-.1z"/></svg>';
        var sD = document.getElementById('sideThemeDarkBtn'), sL = document.getElementById('sideThemeLightBtn');
        if (sD && sL) { void 0; void 0; }
        safeSetStorage(STORAGE_THEME_KEY, state.theme);
        renderAllCharts();
        if (!silent) showToast(state.theme === 'dark' ? (isEn() ? 'Switched to Dark Mode' : '已切换至 MUI 深海黑曜石护眼模式') : (isEn() ? 'Switched to Light Mode' : '已切换至 MUI 浅色明亮阅读模式'));
      }

      function toggleSidebar() {
        if (window.innerWidth <= 1120) document.body.classList.toggle('drawer-open');
        else { document.body.classList.toggle('sidebar-collapsed'); setTimeout(renderAllCharts, 60); }
      }
      function closeMobileDrawer() { document.body.classList.remove('drawer-open'); }
      function escapeHtml(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
      function highlightMatch(t, q) {
        var safe = escapeHtml(t);
        if (!q) return safe;
        return safe.replace(new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi'), '<mark class="hl">$1</mark>');
      }

      function renderPeerTable() {
        var tbody = document.getElementById('peerTableBody'), badge = document.getElementById('peerCountBadge');
        if (!tbody) return;
        var rows = isEn() ? PEER_ROWS_EN : PEER_ROWS;
        var q = state.peerQuery.trim().toLowerCase();
        var filtered = rows.filter(function (row, idx) {
          if (!(state.peerFilter === 'all' || row.category === 'core' || row.category === state.peerFilter)) return false;
          if (!q) return true;
          var zhR = PEER_ROWS[idx] || row, enR = PEER_ROWS_EN[idx] || row;
          return (zhR.company + ' ' + zhR.leader + ' ' + zhR.positioning + ' ' + zhR.culture + ' ' + zhR.verdict + ' ' + enR.company + ' ' + enR.leader + ' ' + enR.positioning + ' ' + enR.culture + ' ' + enR.verdict).toLowerCase().indexOf(q) !== -1;
        });
        if (badge) badge.textContent = isEn() ? ('Showing ' + filtered.length + ' / ' + rows.length + ' Leaders') : ('显示 ' + filtered.length + ' / ' + rows.length + ' 家全球巨头');
        if (!filtered.length) {
          tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:28px;">' + (isEn() ? 'No matching smartphone peers found.' : '未找到匹配的厂商记录，请尝试清空搜索词或切换分类。') + '</td></tr>';
          return;
        }
        var rq = state.peerQuery.trim();
        tbody.innerHTML = filtered.map(function (r) {
          return '<tr class="' + (r.benchmark ? 'benchmark-row' : '') + '">' +
            '<td><strong style="color:var(--text-primary);display:block;">' + highlightMatch(r.company, rq) + '</strong><span style="font-size:0.76rem;color:var(--text-muted);">' + highlightMatch(r.leader, rq) + '</span></td>' +
            '<td>' + highlightMatch(r.positioning, rq) + '</td>' +
            '<td>' + highlightMatch(r.culture, rq) + '</td>' +
            '<td class="mono" style="font-size:0.79rem;">' + highlightMatch(r.headcount, rq) + '</td>' +
            '<td class="mono" style="font-size:0.79rem;color:var(--mui-primary-lighter);font-weight:700;">' + highlightMatch(r.margins, rq) + '</td>' +
            '<td>' + highlightMatch(r.verdict, rq) + ' <a class="cite-link" href="' + r.sourceUrl + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(r.sourceLabel) + ' ↗</a></td>' +
          '</tr>';
        }).join('');
      }

      function formatCurrency(v) { return '$' + Math.round(v).toLocaleString('en-US'); }

      function updateSimulatorUI() {
        var p = state.sim.principal, yrs = state.sim.years, g = state.sim.priceCagr / 100, bb = state.sim.buyback;
        var epsRate = ((1 + g) / (1 - bb)) - 1;
        var initPrice = 353.80, initEps = 8.98, initDps = 1.08;
        var initShares = p / initPrice, shares = initShares, price = initPrice, eps = initEps, dps = initDps, cashPool = 0, cumDiv = 0;

        for (var y = 1; y <= yrs; y++) {
          var aDiv = shares * dps; cumDiv += aDiv;
          var nextPrice = price * (1 + epsRate);
          eps = eps * (1 + epsRate);
          if (state.sim.drip) shares += aDiv / ((price + nextPrice) / 2);
          else cashPool += aDiv;
          price = nextPrice; dps = dps * (1 + epsRate);
        }
        var endVal = (shares * price) + cashPool;
        var ownBoost = (((shares / initShares) / Math.pow(1 - bb, yrs)) - 1) * 100;

        document.getElementById('simPrincipalLabel').textContent = formatCurrency(p);
        document.getElementById('simYearsLabel').textContent = yrs + (isEn() ? ' yrs' : ' 年');
        document.getElementById('simCagrLabel').textContent = state.sim.priceCagr.toFixed(1) + '%';
        document.getElementById('simEndingVal').textContent = formatCurrency(endVal);
        document.getElementById('simMoicVal').textContent = '$' + eps.toFixed(2) + ' · ' + (epsRate * 100).toFixed(2) + '%';
        document.getElementById('simNetGainVal').textContent = '+' + ownBoost.toFixed(1) + '%';
        document.getElementById('simMidVal').textContent = formatCurrency(cumDiv);

        var pBtns = document.querySelectorAll('[data-preset]');
        for (var i = 0; i < pBtns.length; i++) pBtns[i].classList.toggle('active', pBtns[i].getAttribute('data-preset') === state.sim.preset);
        drawSimChart();
      }

      function renderChecklist() {
        var cont = document.getElementById('checklistContainer'), chip = document.getElementById('checklistScoreChip'), bar = document.getElementById('checklistProgressBar');
        if (!cont) return;
        var items = isEn() ? CHECKLIST_ITEMS_EN : CHECKLIST_ITEMS;
        var done = state.checks.filter(Boolean).length, pct = Math.round((done / items.length) * 100);
        if (chip) chip.textContent = isEn() ? ('Verified ' + done + ' / ' + items.length + ' (' + pct + '%)') : ('已核查 ' + done + ' / ' + items.length + ' 项 (' + pct + '%)');
        if (bar) bar.style.width = pct + '%';
        cont.innerHTML = items.map(function (it, idx) {
          var ck = !!state.checks[idx];
          return '<label class="check-card ' + (ck ? 'checked' : '') + '" data-check-idx="' + idx + '">' +
            '<input type="checkbox" data-check-input="' + idx + '" ' + (ck ? 'checked' : '') + ' />' +
            '<div style="flex:1;"><div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:6px;margin-bottom:4px;">' +
            '<span class="check-title">' + escapeHtml(it.title) + '</span><span class="mui-chip mono">' + escapeHtml(it.tag) + '</span></div>' +
            '<p class="check-desc">' + escapeHtml(it.desc) + '</p></div></label>';
        }).join('');
      }

      /* High-DPI Canvas Engine */
      var hitRegions = { chartCh1: [], chartRadar: [], chartBars: [], chartEps: [], chartSim: [] };
      var hoverState = { chartCh1: -1, chartRadar: -1, chartBars: -1, chartEps: -1, chartSim: -1 };

      function getPalette() {
        var cs = getComputedStyle(document.documentElement), isDark = state.theme === 'dark';
        return {
          isDark: isDark,
          grid: cs.getPropertyValue('--chart-grid').trim() || (isDark ? 'rgba(148,163,184,0.13)' : 'rgba(100,116,139,0.16)'),
          tick: cs.getPropertyValue('--chart-tick').trim() || '#94A3B8',
          text: cs.getPropertyValue('--text-primary').trim() || '#F3F6F9',
          pillBg: isDark ? 'rgba(9, 13, 22, 0.88)' : 'rgba(255, 255, 255, 0.94)',
          pillBorder: isDark ? 'rgba(51, 153, 255, 0.28)' : 'rgba(0, 115, 230, 0.24)',
          trackBg: isDark ? 'rgba(148, 163, 184, 0.10)' : 'rgba(15, 25, 36, 0.06)',
          hoverBand: isDark ? 'rgba(51, 153, 255, 0.07)' : 'rgba(0, 115, 230, 0.05)',
          c1: cs.getPropertyValue('--chart-c1').trim() || '#3399FF',
          c2: cs.getPropertyValue('--chart-c2').trim() || '#22C55E',
          c3: cs.getPropertyValue('--chart-c3').trim() || '#FFB74D'
        };
      }

      function prepareCanvas(id) {
        var cv = document.getElementById(id);
        if (!cv || !cv.parentElement) return null;
        var rect = cv.parentElement.getBoundingClientRect();
        var w = Math.max(240, Math.floor(rect.width)), h = Math.max(170, Math.floor(rect.height));
        var dpr = Math.min(window.devicePixelRatio || 1, 2.5);
        cv.style.width = w + 'px'; cv.style.height = h + 'px';
        if (cv.width !== Math.floor(w * dpr)) cv.width = Math.floor(w * dpr);
        if (cv.height !== Math.floor(h * dpr)) cv.height = Math.floor(h * dpr);
        var ctx = cv.getContext('2d');
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, w, h);
        return { ctx: ctx, w: w, h: h };
      }

      function roundRectPath(ctx, x, y, w, h, r) {
        if (w <= 0 || h <= 0) return;
        var rad = Math.min(r, w / 2, h / 2);
        ctx.beginPath(); ctx.moveTo(x + rad, y); ctx.lineTo(x + w - rad, y); ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
        ctx.lineTo(x + w, y + h - rad); ctx.quadraticCurveTo(x + w, y + h, x + w - rad, y + h);
        ctx.lineTo(x + rad, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - rad);
        ctx.lineTo(x, y + rad); ctx.quadraticCurveTo(x, y, x + rad, y); ctx.closePath();
      }

      function topRoundedBar(ctx, x, y, w, h, r) {
        if (w <= 0 || h <= 0) return;
        var rad = Math.min(r, w / 2, h);
        ctx.beginPath(); ctx.moveTo(x, y + h); ctx.lineTo(x, y + rad); ctx.quadraticCurveTo(x, y, x + rad, y);
        ctx.lineTo(x + w - rad, y); ctx.quadraticCurveTo(x + w, y, x + w, y + rad); ctx.lineTo(x + w, y + h); ctx.closePath();
      }

      function drawValueBadge(ctx, text, cx, cy, fg, pal) {
        ctx.save();
        ctx.font = '700 10.5px "IBM Plex Mono", system-ui, sans-serif';
        var tw = ctx.measureText(text).width + 10, th = 18;
        ctx.fillStyle = pal.pillBg;
        roundRectPath(ctx, cx - tw / 2, cy - th / 2, tw, th, 5);
        ctx.fill();
        ctx.strokeStyle = pal.pillBorder; ctx.lineWidth = 1; ctx.stroke();
        ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(text, cx, cy + 0.5);
        ctx.restore();
      }

      function drawSmoothLine(ctx, pts) {
        if (!pts.length) return;
        ctx.beginPath(); ctx.moveTo(pts[0].x, pts[0].y);
        for (var i = 0; i < pts.length - 1; i++) {
          var xc = (pts[i].x + pts[i + 1].x) / 2;
          ctx.bezierCurveTo(xc, pts[i].y, xc, pts[i + 1].y, pts[i + 1].x, pts[i + 1].y);
        }
      }

      function drawCh1Chart() {
        var env = prepareCanvas('chartCh1');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h, pal = getPalette();
        hitRegions.chartCh1 = [];
        var metaEl = document.getElementById('ch1AxisMeta'), leg1 = document.getElementById('ch1Leg1'), leg2 = document.getElementById('ch1Leg2');

        if (state.ch1View === 'viewA') {
          if (metaEl) metaEl.innerHTML = isEn()
            ? '<span style="color:var(--chart-c1);">■ Bars: iPhone &amp; Services ($B)</span><span style="color:var(--chart-c3);">● Line: Total Apple Revenue ($B)</span>'
            : '<span style="color:var(--chart-c1);">■ 柱状：iPhone &amp; 服务营收 ($B)</span><span style="color:var(--chart-c3);">● 折线：集团总净营收 ($B)</span>';
          if (leg1) leg1.textContent = isEn() ? 'iPhone Net Revenue ($B)' : 'iPhone 净营收 ($B)';
          if (leg2) leg2.textContent = isEn() ? 'Services Net Revenue ($B)' : 'Services 服务净营收 ($B)';

          var pad = { top: 26, right: 20, bottom: 38, left: 52 }, pw = w - pad.left - pad.right, ph = h - pad.top - pad.bottom;
          var labels = ['FY2022', 'FY2023', 'FY2024', 'FY2025', 'FY2026'];
          var ip = [205.49, 200.58, 201.18, 209.60, 254.10];
          var sv = [78.13, 85.20, 96.17, 109.20, 123.30];
          var tot = [394.33, 383.29, 391.04, 416.16, 478.83];
          var maxY = 520;

          for (var g = 0; g <= 4; g++) {
            var v = (maxY / 4) * g, gy = pad.top + ph - (g / 4) * ph;
            ctx.strokeStyle = pal.grid; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(pad.left, gy); ctx.lineTo(pad.left + pw, gy); ctx.stroke();
            ctx.fillStyle = pal.tick; ctx.font = '11px "IBM Plex Mono", sans-serif'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
            ctx.fillText('$' + v.toFixed(0) + 'B', pad.left - 8, gy);
          }

          var step = pw / labels.length, barW = Math.min(34, Math.max(14, step * 0.28)), pts = [];
          for (var i = 0; i < labels.length; i++) {
            var cx = pad.left + step * (i + 0.5);
            if (hoverState.chartCh1 === i) { ctx.fillStyle = pal.hoverBand; roundRectPath(ctx, pad.left + step * i + 4, pad.top, step - 8, ph, 8); ctx.fill(); }
            if (state.ch1Series.s1) {
              var h1 = (ip[i] / maxY) * ph, x1 = state.ch1Series.s2 ? (cx - barW - 3) : (cx - barW / 2), y1 = pad.top + ph - h1;
              var g1 = ctx.createLinearGradient(0, y1, 0, pad.top + ph);
              g1.addColorStop(0, '#3399FF'); g1.addColorStop(1, '#0066CC');
              ctx.fillStyle = g1; topRoundedBar(ctx, x1, y1, barW, h1, 5); ctx.fill();
            }
            if (state.ch1Series.s2) {
              var h2 = (sv[i] / maxY) * ph, x2 = state.ch1Series.s1 ? (cx + 3) : (cx - barW / 2), y2 = pad.top + ph - h2;
              var g2 = ctx.createLinearGradient(0, y2, 0, pad.top + ph);
              g2.addColorStop(0, '#34D399'); g2.addColorStop(1, '#16A34A');
              ctx.fillStyle = g2; topRoundedBar(ctx, x2, y2, barW, h2, 5); ctx.fill();
            }
            pts.push({ x: cx, y: pad.top + ph - (tot[i] / maxY) * ph, val: tot[i] });
            ctx.fillStyle = pal.text; ctx.font = '700 11.5px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
            ctx.fillText(labels[i], cx, pad.top + ph + 22);
            hitRegions.chartCh1.push({
              idx: i, x: pad.left + step * i, y: pad.top, w: step, h: ph + 28,
              html: '<strong>' + labels[i] + '</strong><br/>• iPhone: <strong>$' + ip[i].toFixed(2) + 'B</strong><br/>• Services: <strong>$' + sv[i].toFixed(2) + 'B</strong><br/>• Total Revenue: <strong>$' + tot[i].toFixed(2) + 'B</strong>'
            });
          }
          drawSmoothLine(ctx, pts); ctx.strokeStyle = pal.c3; ctx.lineWidth = 2.6; ctx.stroke();
          for (var m = 0; m < pts.length; m++) {
            ctx.fillStyle = pal.pillBg; ctx.beginPath(); ctx.arc(pts[m].x, pts[m].y, 5.5, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = pal.c3; ctx.beginPath(); ctx.arc(pts[m].x, pts[m].y, 3.8, 0, Math.PI * 2); ctx.fill();
            drawValueBadge(ctx, '$' + pts[m].val.toFixed(1) + 'B', pts[m].x, pts[m].y - 16, pal.c3, pal);
          }
        } else {
          if (metaEl) metaEl.innerHTML = isEn()
            ? '<span style="color:var(--chart-c1);">■ FY2026 Core Margins &amp; YoY Growth (%)</span><span style="color:var(--text-muted);">SEC 10-K Verified</span>'
            : '<span style="color:var(--chart-c1);">■ FY2026 核心指标与同比增速 (%)</span><span style="color:var(--text-muted);">SEC 10-K 核验</span>';
          var items = isEn() ? [
            { label: 'Services Q4 Gross Margin', val: 76.0, c1: '#FBBF24', c2: '#D97706' },
            { label: 'iPhone Share of FY26 Total Rev', val: 53.1, c1: '#3399FF', c2: '#0073E6' },
            { label: 'FY26 Consolidated Gross Margin', val: 48.8, c1: '#60A5FA', c2: '#2563EB' },
            { label: 'Greater China FY26 YoY Growth', val: 28.0, c1: '#34D399', c2: '#16A34A' },
            { label: 'Mac Q4 YoY Revenue Growth', val: 23.7, c1: '#A78BFA', c2: '#7C3AED' },
            { label: 'iPhone FY26 YoY Revenue Growth', val: 21.2, c1: '#38BDF8', c2: '#0284C7' }
          ] : [
            { label: 'Services 服务业务 Q4 毛利率', val: 76.0, c1: '#FBBF24', c2: '#D97706' },
            { label: 'iPhone 占 FY2026 集团总营收比例', val: 53.1, c1: '#3399FF', c2: '#0073E6' },
            { label: '苹果 FY2026 全年综合毛利率', val: 48.8, c1: '#60A5FA', c2: '#2563EB' },
            { label: '大中华区 FY2026 全年营收同比增速', val: 28.0, c1: '#34D399', c2: '#16A34A' },
            { label: 'Q4 Mac 营收同比增速 (M系列/触控/Neo)', val: 23.7, c1: '#A78BFA', c2: '#7C3AED' },
            { label: 'FY2026 iPhone 全年净营收同比增速', val: 21.2, c1: '#38BDF8', c2: '#0284C7' }
          ];
          var padB = { top: 8, right: 18, bottom: 22, left: 18 }, pwB = w - padB.left - padB.right, phB = h - padB.top - padB.bottom, maxX = 85, rowH = phB / items.length;
          for (var j = 0; j < items.length; j++) {
            var rt = padB.top + rowH * j, ly = rt + rowH * 0.35, by = rt + rowH * 0.54, bh = Math.min(13, rowH * 0.25), bw = (items[j].val / maxX) * pwB;
            ctx.fillStyle = pal.text; ctx.font = '600 11.5px system-ui, sans-serif'; ctx.textAlign = 'left'; ctx.fillText(items[j].label, padB.left, ly);
            ctx.font = '800 12px "IBM Plex Mono", sans-serif'; ctx.fillStyle = pal.isDark ? items[j].c1 : items[j].c2; ctx.textAlign = 'right'; ctx.fillText(items[j].val.toFixed(1) + '%', padB.left + pwB, ly);
            ctx.fillStyle = pal.trackBg; roundRectPath(ctx, padB.left, by, pwB, bh, bh / 2); ctx.fill();
            var bg = ctx.createLinearGradient(padB.left, 0, padB.left + bw, 0); bg.addColorStop(0, items[j].c1); bg.addColorStop(1, items[j].c2);
            ctx.fillStyle = bg; roundRectPath(ctx, padB.left, by, bw, bh, bh / 2); ctx.fill();
            hitRegions.chartCh1.push({ idx: j, x: padB.left, y: rt, w: pwB, h: rowH, html: '<strong>' + items[j].label + '</strong>: ' + items[j].val.toFixed(1) + '%' });
          }
        }
      }

      function drawRadarChart() {
        var env = prepareCanvas('chartRadar');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h, pal = getPalette();
        hitRegions.chartRadar = [];
        var axes = isEn() ? ['$800+ Pricing', 'Silicon & OS', 'Services GM', '2.5B Lock-In', 'Supply Power'] : ['超高端定价权', '芯片垂直整合', '服务高毛利变现', '25亿终端留存', '供应链抗风险'];
        var pillarAxisMap = [3, 1, 0, 4];
        var hiAxis = hoverState.chartRadar >= 0 ? hoverState.chartRadar : pillarAxisMap[state.activePillar];
        var series = [
          { key: 'aapl', color: pal.c1, fill: 'rgba(51, 153, 255, 0.24)', vals: [9.9, 9.8, 9.9, 9.9, 9.2] },
          { key: 'sam', color: pal.c2, fill: 'rgba(34, 197, 94, 0.16)', vals: [8.3, 7.6, 5.8, 7.2, 9.8] },
          { key: 'mi', color: pal.c3, fill: 'rgba(255, 183, 77, 0.14)', vals: [6.8, 6.8, 6.9, 8.2, 6.2] }
        ];
        var cx = w / 2, cy = h / 2 + 8, sidePad = w < 420 ? 86 : 104, radius = Math.max(62, Math.min((w - sidePad * 2) / 2, h * 0.35)), total = axes.length;

        for (var ring = 2; ring <= 10; ring += 2) {
          var r = (ring / 10) * radius;
          ctx.strokeStyle = pal.grid; ctx.lineWidth = ring === 10 ? 1.3 : 1; ctx.beginPath();
          for (var i = 0; i < total; i++) {
            var ang = -Math.PI / 2 + (i * 2 * Math.PI) / total, px = cx + Math.cos(ang) * r, py = cy + Math.sin(ang) * r;
            if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
          }
          ctx.closePath(); ctx.stroke();
          ctx.fillStyle = pal.tick; ctx.font = '600 9.5px "IBM Plex Mono", sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(String(ring), cx + 4, cy - r);
        }

        for (var a = 0; a < total; a++) {
          var angle = -Math.PI / 2 + (a * 2 * Math.PI) / total, ax = cx + Math.cos(angle) * radius, ay = cy + Math.sin(angle) * radius, isHi = a === hiAxis;
          ctx.strokeStyle = isHi ? pal.c1 : pal.grid; ctx.lineWidth = isHi ? 1.8 : 1; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(ax, ay); ctx.stroke();
          var lx = cx + Math.cos(angle) * (radius + 14), ly = cy + Math.sin(angle) * (radius + 15);
          ctx.fillStyle = isHi ? pal.c1 : pal.text; ctx.font = (isHi ? '800 ' : '600 ') + '11px system-ui, sans-serif'; ctx.textBaseline = 'middle';
          ctx.textAlign = Math.abs(Math.cos(angle)) < 0.2 ? 'center' : (Math.cos(angle) > 0 ? 'left' : 'right');
          ctx.fillText(axes[a], lx, ly);
          hitRegions.chartRadar.push({
            idx: a, x: Math.min(ax, lx) - 36, y: Math.min(ay, ly) - 22, w: 72 + Math.abs(lx - ax), h: 44,
            html: '<strong>' + axes[a] + '</strong><br/>• Apple: <strong>' + series[0].vals[a].toFixed(1) + '</strong><br/>• Samsung: <strong>' + series[1].vals[a].toFixed(1) + '</strong><br/>• Xiaomi: <strong>' + series[2].vals[a].toFixed(1) + '</strong>'
          });
        }

        for (var s = 0; s < series.length; s++) {
          var item = series[s];
          if (!state.radarSeries[item.key]) continue;
          ctx.beginPath();
          for (var idx = 0; idx < total; idx++) {
            var th = -Math.PI / 2 + (idx * 2 * Math.PI) / total, d = (item.vals[idx] / 10) * radius;
            var vx = cx + Math.cos(th) * d, vy = cy + Math.sin(th) * d;
            if (idx === 0) ctx.moveTo(vx, vy); else ctx.lineTo(vx, vy);
          }
          ctx.closePath(); ctx.fillStyle = item.fill; ctx.fill(); ctx.strokeStyle = item.color; ctx.lineWidth = 2.4; ctx.stroke();
        }
      }

      function drawHorizontalBars() {
        var env = prepareCanvas('chartBars');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h, pal = getPalette();
        hitRegions.chartBars = [];
        var items = isEn() ? [
          { label: 'Apple (AAPL · iPhone + iOS Ecosystem)', op: 31.1, ship: 13.0 },
          { label: 'Alphabet / Google (Android + Pixel)', op: 33.3, ship: 16.0 },
          { label: 'Samsung Electronics (Galaxy + Memory)', op: 14.5, ship: 8.1 },
          { label: 'Huawei Consumer BG (HarmonyOS + Kirin)', op: 12.2, ship: 18.5 },
          { label: 'Xiaomi Corp (1810.HK · Smartphones + AIoT)', op: 8.2, ship: -26.3 }
        ] : [
          { label: '苹果 (AAPL · iPhone + iOS 生态)', op: 31.1, ship: 13.0 },
          { label: '谷歌 (GOOGL · Android + Pixel)', op: 33.3, ship: 16.0 },
          { label: '三星电子 (005930 · Galaxy + 存储)', op: 14.5, ship: 8.1 },
          { label: '华为终端 (Huawei · 鸿蒙 + 麒麟)', op: 12.2, ship: 18.5 },
          { label: '小米集团 (1810.HK · 手机 + AIoT)', op: 8.2, ship: -26.3 }
        ];

        var pad = { top: 10, right: 18, bottom: 26, left: 18 }, pw = w - pad.left - pad.right, ph = h - pad.top - pad.bottom;
        var minX = -30, maxX = 40, span = maxX - minX, zeroX = pad.left + ((0 - minX) / span) * pw;

        for (var tick = -30; tick <= 40; tick += 10) {
          var gx = pad.left + ((tick - minX) / span) * pw;
          ctx.strokeStyle = tick === 0 ? pal.tick : pal.grid; ctx.lineWidth = tick === 0 ? 1.4 : 1;
          ctx.beginPath(); ctx.moveTo(gx, pad.top); ctx.lineTo(gx, pad.top + ph); ctx.stroke();
          ctx.fillStyle = pal.tick; ctx.font = '10.5px "IBM Plex Mono", sans-serif'; ctx.textAlign = 'center'; ctx.fillText(tick + '%', gx, pad.top + ph + 18);
        }

        var rowH = ph / items.length;
        for (var i = 0; i < items.length; i++) {
          var rTop = pad.top + rowH * i;
          if (hoverState.chartBars === i) { ctx.fillStyle = pal.hoverBand; roundRectPath(ctx, pad.left - 6, rTop + 2, pw + 12, rowH - 4, 8); ctx.fill(); }
          var lY = rTop + 16, b1Y = rTop + 25, b2Y = rTop + 40, bH = 11;
          ctx.fillStyle = pal.text; ctx.font = '600 12px system-ui, sans-serif'; ctx.textAlign = 'left'; ctx.fillText(items[i].label, pad.left, lY);
          ctx.font = '700 11px "IBM Plex Mono", sans-serif'; ctx.textAlign = 'right';
          ctx.fillStyle = pal.c1; ctx.fillText('Op: ' + items[i].op.toFixed(1) + '%  |  Q2 Ship: ' + (items[i].ship > 0 ? '+' : '') + items[i].ship.toFixed(1) + '%', pad.left + pw, lY);

          var opW = (items[i].op / span) * pw;
          ctx.fillStyle = pal.c1; roundRectPath(ctx, zeroX, b1Y, opW, bH, 4); ctx.fill();
          var shW = Math.abs(items[i].ship / span) * pw;
          ctx.fillStyle = items[i].ship >= 0 ? pal.c2 : '#EF4444';
          roundRectPath(ctx, items[i].ship >= 0 ? zeroX : zeroX - shW, b2Y, shW, bH, 4); ctx.fill();

          hitRegions.chartBars.push({
            idx: i, x: pad.left, y: rTop, w: pw, h: rowH,
            html: '<strong>' + items[i].label + '</strong><br/>• Operating Margin: <strong>' + items[i].op.toFixed(1) + '%</strong><br/>• Q2 2026 Shipment YoY: <strong>' + (items[i].ship > 0 ? '+' : '') + items[i].ship.toFixed(1) + '%</strong>'
          });
        }
      }

      function drawEpsComboChart() {
        var env = prepareCanvas('chartEps');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h, pal = getPalette();
        hitRegions.chartEps = [];
        var years = ['FY2021', 'FY2022', 'FY2023', 'FY2024', 'FY2025', 'FY2026'];
        var eps = [5.61, 6.11, 6.13, 6.08, 7.46, 8.98];
        var shares = [16.865, 16.326, 15.813, 15.408, 15.000, 14.720];
        var pad = { top: 26, right: 50, bottom: 38, left: 48 }, pw = w - pad.left - pad.right, ph = h - pad.top - pad.bottom;
        var minE = 4.0, maxE = 10.0, minS = 14.0, maxS = 17.5;

        for (var g = 0; g <= 4; g++) {
          var ratio = g / 4, gy = pad.top + ph - ratio * ph;
          ctx.strokeStyle = pal.grid; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(pad.left, gy); ctx.lineTo(pad.left + pw, gy); ctx.stroke();
          ctx.font = '11px "IBM Plex Mono", sans-serif'; ctx.textBaseline = 'middle';
          ctx.fillStyle = pal.tick; ctx.textAlign = 'right'; ctx.fillText('$' + (minE + ratio * (maxE - minE)).toFixed(1), pad.left - 7, gy);
          ctx.fillStyle = pal.c2; ctx.textAlign = 'left'; ctx.fillText((minS + ratio * (maxS - minS)).toFixed(1) + 'B', pad.left + pw + 7, gy);
        }

        var step = pw / years.length, barW = Math.min(40, Math.max(20, step * 0.42)), pts = [];
        for (var i = 0; i < years.length; i++) {
          var cx = pad.left + step * (i + 0.5);
          if (hoverState.chartEps === i) { ctx.fillStyle = pal.hoverBand; roundRectPath(ctx, pad.left + step * i + 4, pad.top, step - 8, ph, 6); ctx.fill(); }
          if (state.epsSeries.eps) {
            var bh = ((eps[i] - minE) / (maxE - minE)) * ph, by = pad.top + ph - bh;
            var eg = ctx.createLinearGradient(0, by, 0, pad.top + ph); eg.addColorStop(0, '#3399FF'); eg.addColorStop(1, '#0066CC');
            ctx.fillStyle = eg; topRoundedBar(ctx, cx - barW / 2, by, barW, bh, 6); ctx.fill();
            ctx.fillStyle = '#FFFFFF'; ctx.font = '700 10.5px "IBM Plex Mono", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
            ctx.fillText('$' + eps[i].toFixed(2), cx, by + 16);
          }
          var sy = pad.top + ph - ((shares[i] - minS) / (maxS - minS)) * ph;
          pts.push({ x: cx, y: sy, val: shares[i] });
          ctx.fillStyle = pal.text; ctx.font = '700 11.5px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
          ctx.fillText(years[i], cx, pad.top + ph + 20);
          hitRegions.chartEps.push({
            idx: i, x: pad.left + step * i, y: pad.top, w: step, h: ph + 30,
            html: '<strong>' + years[i] + '</strong><br/>• Diluted EPS: <strong>$' + eps[i].toFixed(2) + '</strong><br/>• Diluted Shares: <strong>' + shares[i].toFixed(2) + 'B</strong>'
          });
        }
        if (state.epsSeries.shares) {
          drawSmoothLine(ctx, pts); ctx.strokeStyle = pal.c2; ctx.lineWidth = 2.8; ctx.stroke();
          for (var m = 0; m < pts.length; m++) {
            ctx.fillStyle = pal.pillBg; ctx.beginPath(); ctx.arc(pts[m].x, pts[m].y, 6, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = pal.c2; ctx.beginPath(); ctx.arc(pts[m].x, pts[m].y, 4.2, 0, Math.PI * 2); ctx.fill();
            drawValueBadge(ctx, pts[m].val.toFixed(2) + 'B', pts[m].x, pts[m].y - 16, pal.c2, pal);
          }
        }
      }

      function drawSimChart() {
        var env = prepareCanvas('chartSim');
        if (!env) return;
        var ctx = env.ctx, w = env.w, h = env.h, pal = getPalette();
        hitRegions.chartSim = [];
        var p = state.sim.principal, yrs = state.sim.years, g = state.sim.priceCagr / 100, bb = state.sim.buyback;
        var epsRate = ((1 + g) / (1 - bb)) - 1, divBoost = state.sim.drip ? (1.08 / 353.80) : 0;
        var totS = [], baseS = [];
        for (var y = 0; y <= yrs; y++) { totS.push(p * Math.pow(1 + epsRate + divBoost, y)); baseS.push(p * Math.pow(1 + g, y)); }
        var maxVal = Math.max(totS[yrs], baseS[yrs], p * 1.2) * 1.08;
        var pad = { top: 20, right: 20, bottom: 28, left: 58 }, pw = w - pad.left - pad.right, ph = h - pad.top - pad.bottom;

        for (var j = 0; j <= 3; j++) {
          var v = (maxVal / 3) * j, gy = pad.top + ph - (j / 3) * ph;
          ctx.strokeStyle = pal.grid; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(pad.left, gy); ctx.lineTo(pad.left + pw, gy); ctx.stroke();
          ctx.fillStyle = pal.tick; ctx.font = '10.5px "IBM Plex Mono", sans-serif'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
          ctx.fillText(v >= 1000000 ? ('$' + (v / 1000000).toFixed(2) + 'M') : ('$' + Math.round(v / 1000) + 'k'), pad.left - 7, gy);
        }

        ctx.save(); ctx.setLineDash([4, 4]); ctx.strokeStyle = pal.tick; ctx.lineWidth = 1.6; ctx.beginPath();
        for (var i = 0; i <= yrs; i++) {
          var px = pad.left + (i / yrs) * pw, py = pad.top + ph - (baseS[i] / maxVal) * ph;
          if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.stroke(); ctx.restore();

        var stepX = pw / yrs;
        ctx.beginPath();
        for (var k = 0; k <= yrs; k++) {
          var tx = pad.left + (k / yrs) * pw, ty = pad.top + ph - (totS[k] / maxVal) * ph;
          if (k === 0) ctx.moveTo(tx, ty); else ctx.lineTo(tx, ty);
          hitRegions.chartSim.push({
            idx: k, x: tx - Math.max(6, stepX * 0.5), y: pad.top, w: Math.max(12, stepX), h: ph + 24,
            html: '<strong>' + (isEn() ? 'Year ' + k : '第 ' + k + ' 年') + '</strong><br/>• Buyback + DRIP: <strong>' + formatCurrency(totS[k]) + '</strong><br/>• Organic Only: ' + formatCurrency(baseS[k])
          });
        }
        ctx.strokeStyle = pal.c1; ctx.lineWidth = 2.8; ctx.stroke();
        ctx.lineTo(pad.left + pw, pad.top + ph); ctx.lineTo(pad.left, pad.top + ph); ctx.closePath();
        var grad = ctx.createLinearGradient(0, pad.top, 0, pad.top + ph);
        grad.addColorStop(0, 'rgba(0, 115, 230, 0.30)'); grad.addColorStop(1, 'rgba(0, 115, 230, 0.01)');
        ctx.fillStyle = grad; ctx.fill();

        var endY = pad.top + ph - (totS[yrs] / maxVal) * ph;
        drawValueBadge(ctx, formatCurrency(totS[yrs]), Math.min(w - 48, pad.left + pw - 24), Math.max(pad.top + 12, endY - 14), pal.c1, pal);
        ctx.fillStyle = pal.tick; ctx.font = '10.5px "IBM Plex Mono", sans-serif'; ctx.textBaseline = 'alphabetic';
        ctx.textAlign = 'left'; ctx.fillText(isEn() ? 'Year 0' : '第 0 年', pad.left, pad.top + ph + 19);
        ctx.textAlign = 'right'; ctx.fillText(isEn() ? ('Year ' + yrs) : ('第 ' + yrs + ' 年'), pad.left + pw, pad.top + ph + 19);
      }

      var redrawMap = { chartCh1: drawCh1Chart, chartRadar: drawRadarChart, chartBars: drawHorizontalBars, chartEps: drawEpsComboChart, chartSim: drawSimChart };
      function renderAllCharts() { drawCh1Chart(); drawRadarChart(); drawHorizontalBars(); drawEpsComboChart(); drawSimChart(); }

      function wireCanvasTooltip(cid) {
        var cv = document.getElementById(cid), tip = document.getElementById('chartTooltip');
        if (!cv || !tip) return;
        function handle(cx, cy) {
          var rect = cv.getBoundingClientRect(), mx = cx - rect.left, my = cy - rect.top, regs = hitRegions[cid] || [], found = null;
          for (var i = 0; i < regs.length; i++) if (mx >= regs[i].x && mx <= regs[i].x + regs[i].w && my >= regs[i].y && my <= regs[i].y + regs[i].h) { found = regs[i]; break; }
          var ni = found && typeof found.idx === 'number' ? found.idx : -1;
          if (hoverState[cid] !== ni) { hoverState[cid] = ni; if (redrawMap[cid]) redrawMap[cid](); }
          if (found) {
            tip.innerHTML = found.html; tip.style.display = 'block';
            var tw = tip.offsetWidth || 250, th = tip.offsetHeight || 72, lp = cx + 14;
            if (lp + tw > window.innerWidth - 12) lp = Math.max(12, cx - tw - 14);
            tip.style.left = lp + 'px'; tip.style.top = Math.max(12, Math.min(window.innerHeight - th - 12, cy - 18)) + 'px';
          } else tip.style.display = 'none';
        }
        cv.addEventListener('mousemove', function (e) { handle(e.clientX, e.clientY); });
        cv.addEventListener('mouseleave', function () { if (hoverState[cid] !== -1) { hoverState[cid] = -1; if (redrawMap[cid]) redrawMap[cid](); } tip.style.display = 'none'; });
      }

      function exportStandaloneHtml() {
        var blob = new Blob(['<!DOCTYPE html>\n' + document.documentElement.outerHTML], { type: 'text/html;charset=utf-8' });
        var url = URL.createObjectURL(blob), a = document.createElement('a');
        a.href = url; a.download = 'AAPL_iPhone_Analysis.html'; document.body.appendChild(a); a.click(); document.body.removeChild(a);
        setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
        showToast(isEn() ? 'Exported standalone file: AAPL_iPhone_Analysis.html' : '已导出独立网页 AAPL_iPhone_Analysis.html');
      }

      function init() {
        var rt = safeGetStorage(STORAGE_THEME_KEY);
        if (rt) { rt = String(rt).replace(/^"|"$/g, ''); if (rt === 'light' || rt === 'dark') state.theme = rt; }
        var rl = safeGetStorage(STORAGE_LANG_KEY);
        if (rl) { rl = String(rl).replace(/^"|"$/g, ''); if (rl === 'zh' || rl === 'en') state.lang = rl; }
        window.addEventListener('storage', function (ev) {
          if (ev.key === STORAGE_THEME_KEY && ev.newValue) {
            var nt = String(ev.newValue).replace(/^"|"$/g, '');
            if ((nt === 'light' || nt === 'dark') && nt !== state.theme) applyTheme(nt, true);
          } else if (ev.key === STORAGE_LANG_KEY && ev.newValue) {
            var nl = String(ev.newValue).replace(/^"|"$/g, '');
            if ((nl === 'zh' || nl === 'en') && nl !== state.lang) applyLanguage(nl, true);
          }
        });
        var sc = safeGetStorage(STORAGE_CHECK_KEY);
        if (sc) { try { var p = JSON.parse(sc); if (Array.isArray(p) && p.length === CHECKLIST_ITEMS.length) state.checks = p.map(Boolean); } catch (e) {} }

        applyTheme(state.theme, true);
        applyLanguage(state.lang, true);
        document.getElementById('langZhBtn').addEventListener('click', function () { applyLanguage('zh', false); });
        document.getElementById('langEnBtn').addEventListener('click', function () { applyLanguage('en', false); });
        document.getElementById('appbarThemeBtn').addEventListener('click', function () { applyTheme(state.theme === 'dark' ? 'light' : 'dark', false); });
        document.getElementById('sidebarToggleBtn').addEventListener('click', toggleSidebar);
        document.getElementById('drawerBackdrop').addEventListener('click', closeMobileDrawer);
        void 0;
        void 0;
        void 0;
        void 0;

        var tocLinks = document.querySelectorAll('#tocNavList .mui-nav-link');
        for (var t = 0; t < tocLinks.length; t++) tocLinks[t].addEventListener('click', closeMobileDrawer);

        var jumpInput = document.getElementById('quickJumpInput'), jumpPop = document.getElementById('quickJumpPopover');
        function renderJumpList(q) {
          var kw = (q || '').trim().toLowerCase(), active = isEn() ? QUICK_JUMP_EN : QUICK_JUMP_INDEX;
          var list = active.filter(function (it, idx) {
            var z = QUICK_JUMP_INDEX[idx] || it, e = QUICK_JUMP_EN[idx] || it;
            return !kw || (z.title + ' ' + z.sub + ' ' + e.title + ' ' + e.sub).toLowerCase().indexOf(kw) !== -1;
          });
          jumpPop.innerHTML = list.length ? list.map(function (it) {
            return '<button type="button" class="quick-jump-item" data-jump-sec="' + it.sec + '"><span class="quick-jump-item-title">' + escapeHtml(it.title) + '</span><span class="quick-jump-item-sub">' + escapeHtml(it.sub) + '</span></button>';
          }).join('') : '<div style="padding:10px;font-size:0.78rem;color:var(--text-muted);">' + (isEn() ? 'No matching section' : '未匹配到对应章节') + '</div>';
          jumpPop.classList.add('open');
        }
        jumpInput.addEventListener('focus', function () { renderJumpList(jumpInput.value); });
        jumpInput.addEventListener('input', function () { renderJumpList(jumpInput.value); });
        jumpPop.addEventListener('click', function (e) {
          var b = e.target.closest('[data-jump-sec]');
          if (!b) return;
          var s = document.getElementById(b.getAttribute('data-jump-sec'));
          if (s) s.scrollIntoView({ behavior: 'smooth' });
          jumpPop.classList.remove('open');
        });
        document.addEventListener('click', function (e) { if (!e.target.closest('.quick-search-wrap')) jumpPop.classList.remove('open'); });
        document.addEventListener('keydown', function (e) {
          if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); jumpInput.focus(); }
          else if (e.key === 'Escape') { jumpPop.classList.remove('open'); closeMobileDrawer(); }
        });

        var ch1Btns = document.querySelectorAll('[data-ch1-view]');
        for (var c = 0; c < ch1Btns.length; c++) ch1Btns[c].addEventListener('click', function () {
          state.ch1View = this.getAttribute('data-ch1-view');
          document.getElementById('ch1TabA').classList.toggle('active', state.ch1View === 'viewA');
          document.getElementById('ch1TabB').classList.toggle('active', state.ch1View === 'viewB');
          syncCh1HeaderText(); drawCh1Chart();
        });

        var colBtns = document.querySelectorAll('[data-collapse-target]');
        for (var m = 0; m < colBtns.length; m++) colBtns[m].addEventListener('click', function () {
          var p = document.getElementById(this.getAttribute('data-collapse-target'));
          if (p) { p.classList.toggle('open'); syncCollapseButtonsText(); }
        });

        var pilCards = document.querySelectorAll('[data-pillar]');
        for (var p = 0; p < pilCards.length; p++) pilCards[p].addEventListener('click', function () {
          var idx = parseInt(this.getAttribute('data-pillar'), 10) || 0;
          state.activePillar = idx;
          for (var k = 0; k < pilCards.length; k++) pilCards[k].classList.toggle('active', k === idx);
          document.getElementById('pillarFocusNote').innerHTML = '<div>' + (isEn() ? PILLAR_NOTES_EN : PILLAR_NOTES)[idx] + '</div>';
          drawRadarChart();
        });

        var radPills = document.querySelectorAll('[data-radar-key]');
        for (var r = 0; r < radPills.length; r++) radPills[r].addEventListener('click', function () {
          var key = this.getAttribute('data-radar-key');
          state.radarSeries[key] = !state.radarSeries[key];
          if (!state.radarSeries.aapl && !state.radarSeries.sam && !state.radarSeries.mi) state.radarSeries[key] = true;
          this.classList.toggle('muted', !state.radarSeries[key]);
          drawRadarChart();
        });

        document.getElementById('peerSearchInput').addEventListener('input', function () { state.peerQuery = this.value; renderPeerTable(); });
        var pfBtns = document.querySelectorAll('[data-peer-filter]');
        for (var pf = 0; pf < pfBtns.length; pf++) pfBtns[pf].addEventListener('click', function () {
          state.peerFilter = this.getAttribute('data-peer-filter');
          for (var x = 0; x < pfBtns.length; x++) pfBtns[x].classList.toggle('active', pfBtns[x] === this);
          renderPeerTable();
        });

        var pSlider = document.getElementById('simPrincipalSlider'), ySlider = document.getElementById('simYearsSlider'), cSlider = document.getElementById('simCagrSlider'), dToggle = document.getElementById('simDripToggle');
        pSlider.addEventListener('input', function () { state.sim.principal = parseFloat(this.value) || 50000; updateSimulatorUI(); });
        ySlider.addEventListener('input', function () { state.sim.years = parseInt(this.value, 10) || 10; updateSimulatorUI(); });
        cSlider.addEventListener('input', function () { state.sim.priceCagr = parseFloat(this.value) || 8; updateSimulatorUI(); });
        dToggle.addEventListener('change', function () { state.sim.drip = !!this.checked; updateSimulatorUI(); });

        var preBtns = document.querySelectorAll('[data-preset]');
        for (var pb = 0; pb < preBtns.length; pb++) preBtns[pb].addEventListener('click', function () {
          var cfg = PRESETS[this.getAttribute('data-preset')];
          if (!cfg) return;
          state.sim.principal = cfg.principal; state.sim.years = cfg.years; state.sim.priceCagr = cfg.priceCagr; state.sim.buyback = cfg.buyback; state.sim.drip = cfg.drip; state.sim.preset = this.getAttribute('data-preset');
          pSlider.value = String(cfg.principal); ySlider.value = String(cfg.years); cSlider.value = String(cfg.priceCagr); dToggle.checked = cfg.drip;
          updateSimulatorUI();
        });

        document.getElementById('checklistContainer').addEventListener('change', function (e) {
          var inp = e.target.closest('[data-check-input]');
          if (!inp) return;
          state.checks[parseInt(inp.getAttribute('data-check-input'), 10)] = !!inp.checked;
          safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks));
          renderChecklist();
        });
        document.getElementById('checkAllBtn').addEventListener('click', function () {
          state.checks = [true, true, true, true, true, true]; safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks)); renderChecklist();
          showToast(isEn() ? 'Checked all 6 FY2027 tracking KPIs' : '已勾选全部 6 项季度跟踪 KPI 指标');
        });
        document.getElementById('resetCheckBtn').addEventListener('click', function () {
          state.checks = [true, true, true, false, false, false]; safeSetStorage(STORAGE_CHECK_KEY, JSON.stringify(state.checks)); renderChecklist();
          showToast(isEn() ? 'Checklist reset to default baseline (50%)' : '核查清单已恢复默认基准状态 (50%)');
        });

        function updateScrollProgress() {
          var docEl = document.documentElement, st = window.scrollY || docEl.scrollTop || 0, ms = Math.max(1, docEl.scrollHeight - window.innerHeight);
          document.getElementById('readingProgressBar').style.width = Math.min(100, Math.max(0, (st / ms) * 100)) + '%';
        }
        window.addEventListener('scroll', updateScrollProgress, { passive: true });
        updateScrollProgress();

        if ('IntersectionObserver' in window) {
          var obs = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
              if (en.isIntersecting) for (var i = 0; i < tocLinks.length; i++) tocLinks[i].classList.toggle('active', tocLinks[i].getAttribute('data-sec') === en.target.id);
            });
          }, { rootMargin: '-18% 0px -68% 0px', threshold: 0.02 });
          for (var s = 0; s <= 7; s++) { var sn = document.getElementById('sec-0' + s); if (sn) obs.observe(sn); }
        }

        wireCanvasTooltip('chartCh1'); wireCanvasTooltip('chartRadar'); wireCanvasTooltip('chartBars'); wireCanvasTooltip('chartEps'); wireCanvasTooltip('chartSim');
        var ch1S = document.querySelectorAll('[data-ch1-series]');
        for (var csIdx = 0; csIdx < ch1S.length; csIdx++) ch1S[csIdx].addEventListener('click', function () {
          var sk = this.getAttribute('data-ch1-series');
          state.ch1Series[sk] = !state.ch1Series[sk];
          if (!state.ch1Series.s1 && !state.ch1Series.s2) state.ch1Series[sk] = true;
          this.classList.toggle('muted', !state.ch1Series[sk]); drawCh1Chart();
        });
        var epsS = document.querySelectorAll('[data-eps-series]');
        for (var esIdx = 0; esIdx < epsS.length; esIdx++) epsS[esIdx].addEventListener('click', function () {
          var ek = this.getAttribute('data-eps-series');
          state.epsSeries[ek] = !state.epsSeries[ek];
          if (!state.epsSeries.eps && !state.epsSeries.shares) state.epsSeries[ek] = true;
          this.classList.toggle('muted', !state.epsSeries[ek]); drawEpsComboChart();
        });

        var resizeTimer = null;
        window.addEventListener('resize', function () { if (resizeTimer) clearTimeout(resizeTimer); resizeTimer = setTimeout(renderAllCharts, 60); });
      }

      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
      else init();
    })();
  